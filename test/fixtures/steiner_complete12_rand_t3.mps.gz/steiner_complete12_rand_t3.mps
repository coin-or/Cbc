NAME          steiner_complete12_rand_t3
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 L  cap_0_1
 L  cap_0_2
 L  cap_0_3
 L  cap_0_4
 L  cap_0_5
 L  cap_0_6
 L  cap_0_7
 L  cap_0_8
 L  cap_0_9
 L  cap_0_10
 L  cap_0_11
 L  cap_1_2
 L  cap_1_3
 L  cap_1_4
 L  cap_1_5
 L  cap_1_6
 L  cap_1_7
 L  cap_1_8
 L  cap_1_9
 L  cap_1_10
 L  cap_1_11
 L  cap_2_3
 L  cap_2_4
 L  cap_2_5
 L  cap_2_6
 L  cap_2_7
 L  cap_2_8
 L  cap_2_9
 L  cap_2_10
 L  cap_2_11
 L  cap_3_4
 L  cap_3_5
 L  cap_3_6
 L  cap_3_7
 L  cap_3_8
 L  cap_3_9
 L  cap_3_10
 L  cap_3_11
 L  cap_4_5
 L  cap_4_6
 L  cap_4_7
 L  cap_4_8
 L  cap_4_9
 L  cap_4_10
 L  cap_4_11
 L  cap_5_6
 L  cap_5_7
 L  cap_5_8
 L  cap_5_9
 L  cap_5_10
 L  cap_5_11
 L  cap_6_7
 L  cap_6_8
 L  cap_6_9
 L  cap_6_10
 L  cap_6_11
 L  cap_7_8
 L  cap_7_9
 L  cap_7_10
 L  cap_7_11
 L  cap_8_9
 L  cap_8_10
 L  cap_8_11
 L  cap_9_10
 L  cap_9_11
 L  cap_10_11
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x_0_1     OBJ       3
    x_0_1     cap_0_1   -3
    x_0_2     OBJ       6
    x_0_2     cap_0_2   -3
    x_0_3     OBJ       14
    x_0_3     cap_0_3   -3
    x_0_4     OBJ       11
    x_0_4     cap_0_4   -3
    x_0_5     OBJ       7
    x_0_5     cap_0_5   -3
    x_0_6     OBJ       8
    x_0_6     cap_0_6   -3
    x_0_7     OBJ       16
    x_0_7     cap_0_7   -3
    x_0_8     OBJ       12
    x_0_8     cap_0_8   -3
    x_0_9     OBJ       1
    x_0_9     cap_0_9   -3
    x_0_10    OBJ       13
    x_0_10    cap_0_10  -3
    x_0_11    OBJ       17
    x_0_11    cap_0_11  -3
    x_1_2     OBJ       11
    x_1_2     cap_1_2   -3
    x_1_3     OBJ       13
    x_1_3     cap_1_3   -3
    x_1_4     OBJ       17
    x_1_4     cap_1_4   -3
    x_1_5     OBJ       16
    x_1_5     cap_1_5   -3
    x_1_6     OBJ       5
    x_1_6     cap_1_6   -3
    x_1_7     OBJ       14
    x_1_7     cap_1_7   -3
    x_1_8     OBJ       17
    x_1_8     cap_1_8   -3
    x_1_9     OBJ       17
    x_1_9     cap_1_9   -3
    x_1_10    OBJ       11
    x_1_10    cap_1_10  -3
    x_1_11    OBJ       1
    x_1_11    cap_1_11  -3
    x_2_3     OBJ       20
    x_2_3     cap_2_3   -3
    x_2_4     OBJ       1
    x_2_4     cap_2_4   -3
    x_2_5     OBJ       5
    x_2_5     cap_2_5   -3
    x_2_6     OBJ       16
    x_2_6     cap_2_6   -3
    x_2_7     OBJ       12
    x_2_7     cap_2_7   -3
    x_2_8     OBJ       6
    x_2_8     cap_2_8   -3
    x_2_9     OBJ       12
    x_2_9     cap_2_9   -3
    x_2_10    OBJ       8
    x_2_10    cap_2_10  -3
    x_2_11    OBJ       16
    x_2_11    cap_2_11  -3
    x_3_4     OBJ       13
    x_3_4     cap_3_4   -3
    x_3_5     OBJ       11
    x_3_5     cap_3_5   -3
    x_3_6     OBJ       11
    x_3_6     cap_3_6   -3
    x_3_7     OBJ       1
    x_3_7     cap_3_7   -3
    x_3_8     OBJ       13
    x_3_8     cap_3_8   -3
    x_3_9     OBJ       11
    x_3_9     cap_3_9   -3
    x_3_10    OBJ       3
    x_3_10    cap_3_10  -3
    x_3_11    OBJ       12
    x_3_11    cap_3_11  -3
    x_4_5     OBJ       17
    x_4_5     cap_4_5   -3
    x_4_6     OBJ       4
    x_4_6     cap_4_6   -3
    x_4_7     OBJ       7
    x_4_7     cap_4_7   -3
    x_4_8     OBJ       2
    x_4_8     cap_4_8   -3
    x_4_9     OBJ       20
    x_4_9     cap_4_9   -3
    x_4_10    OBJ       11
    x_4_10    cap_4_10  -3
    x_4_11    OBJ       18
    x_4_11    cap_4_11  -3
    x_5_6     OBJ       19
    x_5_6     cap_5_6   -3
    x_5_7     OBJ       18
    x_5_7     cap_5_7   -3
    x_5_8     OBJ       19
    x_5_8     cap_5_8   -3
    x_5_9     OBJ       11
    x_5_9     cap_5_9   -3
    x_5_10    OBJ       2
    x_5_10    cap_5_10  -3
    x_5_11    OBJ       8
    x_5_11    cap_5_11  -3
    x_6_7     OBJ       19
    x_6_7     cap_6_7   -3
    x_6_8     OBJ       4
    x_6_8     cap_6_8   -3
    x_6_9     OBJ       13
    x_6_9     cap_6_9   -3
    x_6_10    OBJ       17
    x_6_10    cap_6_10  -3
    x_6_11    OBJ       1
    x_6_11    cap_6_11  -3
    x_7_8     OBJ       7
    x_7_8     cap_7_8   -3
    x_7_9     OBJ       11
    x_7_9     cap_7_9   -3
    x_7_10    OBJ       8
    x_7_10    cap_7_10  -3
    x_7_11    OBJ       8
    x_7_11    cap_7_11  -3
    x_8_9     OBJ       18
    x_8_9     cap_8_9   -3
    x_8_10    OBJ       15
    x_8_10    cap_8_10  -3
    x_8_11    OBJ       5
    x_8_11    cap_8_11  -3
    x_9_10    OBJ       20
    x_9_10    cap_9_10  -3
    x_9_11    OBJ       14
    x_9_11    cap_9_11  -3
    x_10_11   OBJ       8
    x_10_11   cap_10_11  -3
    MARK0001  'MARKER'                 'INTEND'
    f_0_1     flow_0    1.0
    f_0_1     flow_1    -1.0
    f_0_1     cap_0_1   1.0
    f_1_0     flow_0    -1.0
    f_1_0     flow_1    1.0
    f_1_0     cap_0_1   1.0
    f_0_2     flow_0    1.0
    f_0_2     flow_2    -1.0
    f_0_2     cap_0_2   1.0
    f_2_0     flow_0    -1.0
    f_2_0     flow_2    1.0
    f_2_0     cap_0_2   1.0
    f_0_3     flow_0    1.0
    f_0_3     flow_3    -1.0
    f_0_3     cap_0_3   1.0
    f_3_0     flow_0    -1.0
    f_3_0     flow_3    1.0
    f_3_0     cap_0_3   1.0
    f_0_4     flow_0    1.0
    f_0_4     flow_4    -1.0
    f_0_4     cap_0_4   1.0
    f_4_0     flow_0    -1.0
    f_4_0     flow_4    1.0
    f_4_0     cap_0_4   1.0
    f_0_5     flow_0    1.0
    f_0_5     flow_5    -1.0
    f_0_5     cap_0_5   1.0
    f_5_0     flow_0    -1.0
    f_5_0     flow_5    1.0
    f_5_0     cap_0_5   1.0
    f_0_6     flow_0    1.0
    f_0_6     flow_6    -1.0
    f_0_6     cap_0_6   1.0
    f_6_0     flow_0    -1.0
    f_6_0     flow_6    1.0
    f_6_0     cap_0_6   1.0
    f_0_7     flow_0    1.0
    f_0_7     flow_7    -1.0
    f_0_7     cap_0_7   1.0
    f_7_0     flow_0    -1.0
    f_7_0     flow_7    1.0
    f_7_0     cap_0_7   1.0
    f_0_8     flow_0    1.0
    f_0_8     flow_8    -1.0
    f_0_8     cap_0_8   1.0
    f_8_0     flow_0    -1.0
    f_8_0     flow_8    1.0
    f_8_0     cap_0_8   1.0
    f_0_9     flow_0    1.0
    f_0_9     flow_9    -1.0
    f_0_9     cap_0_9   1.0
    f_9_0     flow_0    -1.0
    f_9_0     flow_9    1.0
    f_9_0     cap_0_9   1.0
    f_0_10    flow_0    1.0
    f_0_10    flow_10   -1.0
    f_0_10    cap_0_10  1.0
    f_10_0    flow_0    -1.0
    f_10_0    flow_10   1.0
    f_10_0    cap_0_10  1.0
    f_0_11    flow_0    1.0
    f_0_11    flow_11   -1.0
    f_0_11    cap_0_11  1.0
    f_11_0    flow_0    -1.0
    f_11_0    flow_11   1.0
    f_11_0    cap_0_11  1.0
    f_1_2     flow_1    1.0
    f_1_2     flow_2    -1.0
    f_1_2     cap_1_2   1.0
    f_2_1     flow_1    -1.0
    f_2_1     flow_2    1.0
    f_2_1     cap_1_2   1.0
    f_1_3     flow_1    1.0
    f_1_3     flow_3    -1.0
    f_1_3     cap_1_3   1.0
    f_3_1     flow_1    -1.0
    f_3_1     flow_3    1.0
    f_3_1     cap_1_3   1.0
    f_1_4     flow_1    1.0
    f_1_4     flow_4    -1.0
    f_1_4     cap_1_4   1.0
    f_4_1     flow_1    -1.0
    f_4_1     flow_4    1.0
    f_4_1     cap_1_4   1.0
    f_1_5     flow_1    1.0
    f_1_5     flow_5    -1.0
    f_1_5     cap_1_5   1.0
    f_5_1     flow_1    -1.0
    f_5_1     flow_5    1.0
    f_5_1     cap_1_5   1.0
    f_1_6     flow_1    1.0
    f_1_6     flow_6    -1.0
    f_1_6     cap_1_6   1.0
    f_6_1     flow_1    -1.0
    f_6_1     flow_6    1.0
    f_6_1     cap_1_6   1.0
    f_1_7     flow_1    1.0
    f_1_7     flow_7    -1.0
    f_1_7     cap_1_7   1.0
    f_7_1     flow_1    -1.0
    f_7_1     flow_7    1.0
    f_7_1     cap_1_7   1.0
    f_1_8     flow_1    1.0
    f_1_8     flow_8    -1.0
    f_1_8     cap_1_8   1.0
    f_8_1     flow_1    -1.0
    f_8_1     flow_8    1.0
    f_8_1     cap_1_8   1.0
    f_1_9     flow_1    1.0
    f_1_9     flow_9    -1.0
    f_1_9     cap_1_9   1.0
    f_9_1     flow_1    -1.0
    f_9_1     flow_9    1.0
    f_9_1     cap_1_9   1.0
    f_1_10    flow_1    1.0
    f_1_10    flow_10   -1.0
    f_1_10    cap_1_10  1.0
    f_10_1    flow_1    -1.0
    f_10_1    flow_10   1.0
    f_10_1    cap_1_10  1.0
    f_1_11    flow_1    1.0
    f_1_11    flow_11   -1.0
    f_1_11    cap_1_11  1.0
    f_11_1    flow_1    -1.0
    f_11_1    flow_11   1.0
    f_11_1    cap_1_11  1.0
    f_2_3     flow_2    1.0
    f_2_3     flow_3    -1.0
    f_2_3     cap_2_3   1.0
    f_3_2     flow_2    -1.0
    f_3_2     flow_3    1.0
    f_3_2     cap_2_3   1.0
    f_2_4     flow_2    1.0
    f_2_4     flow_4    -1.0
    f_2_4     cap_2_4   1.0
    f_4_2     flow_2    -1.0
    f_4_2     flow_4    1.0
    f_4_2     cap_2_4   1.0
    f_2_5     flow_2    1.0
    f_2_5     flow_5    -1.0
    f_2_5     cap_2_5   1.0
    f_5_2     flow_2    -1.0
    f_5_2     flow_5    1.0
    f_5_2     cap_2_5   1.0
    f_2_6     flow_2    1.0
    f_2_6     flow_6    -1.0
    f_2_6     cap_2_6   1.0
    f_6_2     flow_2    -1.0
    f_6_2     flow_6    1.0
    f_6_2     cap_2_6   1.0
    f_2_7     flow_2    1.0
    f_2_7     flow_7    -1.0
    f_2_7     cap_2_7   1.0
    f_7_2     flow_2    -1.0
    f_7_2     flow_7    1.0
    f_7_2     cap_2_7   1.0
    f_2_8     flow_2    1.0
    f_2_8     flow_8    -1.0
    f_2_8     cap_2_8   1.0
    f_8_2     flow_2    -1.0
    f_8_2     flow_8    1.0
    f_8_2     cap_2_8   1.0
    f_2_9     flow_2    1.0
    f_2_9     flow_9    -1.0
    f_2_9     cap_2_9   1.0
    f_9_2     flow_2    -1.0
    f_9_2     flow_9    1.0
    f_9_2     cap_2_9   1.0
    f_2_10    flow_2    1.0
    f_2_10    flow_10   -1.0
    f_2_10    cap_2_10  1.0
    f_10_2    flow_2    -1.0
    f_10_2    flow_10   1.0
    f_10_2    cap_2_10  1.0
    f_2_11    flow_2    1.0
    f_2_11    flow_11   -1.0
    f_2_11    cap_2_11  1.0
    f_11_2    flow_2    -1.0
    f_11_2    flow_11   1.0
    f_11_2    cap_2_11  1.0
    f_3_4     flow_3    1.0
    f_3_4     flow_4    -1.0
    f_3_4     cap_3_4   1.0
    f_4_3     flow_3    -1.0
    f_4_3     flow_4    1.0
    f_4_3     cap_3_4   1.0
    f_3_5     flow_3    1.0
    f_3_5     flow_5    -1.0
    f_3_5     cap_3_5   1.0
    f_5_3     flow_3    -1.0
    f_5_3     flow_5    1.0
    f_5_3     cap_3_5   1.0
    f_3_6     flow_3    1.0
    f_3_6     flow_6    -1.0
    f_3_6     cap_3_6   1.0
    f_6_3     flow_3    -1.0
    f_6_3     flow_6    1.0
    f_6_3     cap_3_6   1.0
    f_3_7     flow_3    1.0
    f_3_7     flow_7    -1.0
    f_3_7     cap_3_7   1.0
    f_7_3     flow_3    -1.0
    f_7_3     flow_7    1.0
    f_7_3     cap_3_7   1.0
    f_3_8     flow_3    1.0
    f_3_8     flow_8    -1.0
    f_3_8     cap_3_8   1.0
    f_8_3     flow_3    -1.0
    f_8_3     flow_8    1.0
    f_8_3     cap_3_8   1.0
    f_3_9     flow_3    1.0
    f_3_9     flow_9    -1.0
    f_3_9     cap_3_9   1.0
    f_9_3     flow_3    -1.0
    f_9_3     flow_9    1.0
    f_9_3     cap_3_9   1.0
    f_3_10    flow_3    1.0
    f_3_10    flow_10   -1.0
    f_3_10    cap_3_10  1.0
    f_10_3    flow_3    -1.0
    f_10_3    flow_10   1.0
    f_10_3    cap_3_10  1.0
    f_3_11    flow_3    1.0
    f_3_11    flow_11   -1.0
    f_3_11    cap_3_11  1.0
    f_11_3    flow_3    -1.0
    f_11_3    flow_11   1.0
    f_11_3    cap_3_11  1.0
    f_4_5     flow_4    1.0
    f_4_5     flow_5    -1.0
    f_4_5     cap_4_5   1.0
    f_5_4     flow_4    -1.0
    f_5_4     flow_5    1.0
    f_5_4     cap_4_5   1.0
    f_4_6     flow_4    1.0
    f_4_6     flow_6    -1.0
    f_4_6     cap_4_6   1.0
    f_6_4     flow_4    -1.0
    f_6_4     flow_6    1.0
    f_6_4     cap_4_6   1.0
    f_4_7     flow_4    1.0
    f_4_7     flow_7    -1.0
    f_4_7     cap_4_7   1.0
    f_7_4     flow_4    -1.0
    f_7_4     flow_7    1.0
    f_7_4     cap_4_7   1.0
    f_4_8     flow_4    1.0
    f_4_8     flow_8    -1.0
    f_4_8     cap_4_8   1.0
    f_8_4     flow_4    -1.0
    f_8_4     flow_8    1.0
    f_8_4     cap_4_8   1.0
    f_4_9     flow_4    1.0
    f_4_9     flow_9    -1.0
    f_4_9     cap_4_9   1.0
    f_9_4     flow_4    -1.0
    f_9_4     flow_9    1.0
    f_9_4     cap_4_9   1.0
    f_4_10    flow_4    1.0
    f_4_10    flow_10   -1.0
    f_4_10    cap_4_10  1.0
    f_10_4    flow_4    -1.0
    f_10_4    flow_10   1.0
    f_10_4    cap_4_10  1.0
    f_4_11    flow_4    1.0
    f_4_11    flow_11   -1.0
    f_4_11    cap_4_11  1.0
    f_11_4    flow_4    -1.0
    f_11_4    flow_11   1.0
    f_11_4    cap_4_11  1.0
    f_5_6     flow_5    1.0
    f_5_6     flow_6    -1.0
    f_5_6     cap_5_6   1.0
    f_6_5     flow_5    -1.0
    f_6_5     flow_6    1.0
    f_6_5     cap_5_6   1.0
    f_5_7     flow_5    1.0
    f_5_7     flow_7    -1.0
    f_5_7     cap_5_7   1.0
    f_7_5     flow_5    -1.0
    f_7_5     flow_7    1.0
    f_7_5     cap_5_7   1.0
    f_5_8     flow_5    1.0
    f_5_8     flow_8    -1.0
    f_5_8     cap_5_8   1.0
    f_8_5     flow_5    -1.0
    f_8_5     flow_8    1.0
    f_8_5     cap_5_8   1.0
    f_5_9     flow_5    1.0
    f_5_9     flow_9    -1.0
    f_5_9     cap_5_9   1.0
    f_9_5     flow_5    -1.0
    f_9_5     flow_9    1.0
    f_9_5     cap_5_9   1.0
    f_5_10    flow_5    1.0
    f_5_10    flow_10   -1.0
    f_5_10    cap_5_10  1.0
    f_10_5    flow_5    -1.0
    f_10_5    flow_10   1.0
    f_10_5    cap_5_10  1.0
    f_5_11    flow_5    1.0
    f_5_11    flow_11   -1.0
    f_5_11    cap_5_11  1.0
    f_11_5    flow_5    -1.0
    f_11_5    flow_11   1.0
    f_11_5    cap_5_11  1.0
    f_6_7     flow_6    1.0
    f_6_7     flow_7    -1.0
    f_6_7     cap_6_7   1.0
    f_7_6     flow_6    -1.0
    f_7_6     flow_7    1.0
    f_7_6     cap_6_7   1.0
    f_6_8     flow_6    1.0
    f_6_8     flow_8    -1.0
    f_6_8     cap_6_8   1.0
    f_8_6     flow_6    -1.0
    f_8_6     flow_8    1.0
    f_8_6     cap_6_8   1.0
    f_6_9     flow_6    1.0
    f_6_9     flow_9    -1.0
    f_6_9     cap_6_9   1.0
    f_9_6     flow_6    -1.0
    f_9_6     flow_9    1.0
    f_9_6     cap_6_9   1.0
    f_6_10    flow_6    1.0
    f_6_10    flow_10   -1.0
    f_6_10    cap_6_10  1.0
    f_10_6    flow_6    -1.0
    f_10_6    flow_10   1.0
    f_10_6    cap_6_10  1.0
    f_6_11    flow_6    1.0
    f_6_11    flow_11   -1.0
    f_6_11    cap_6_11  1.0
    f_11_6    flow_6    -1.0
    f_11_6    flow_11   1.0
    f_11_6    cap_6_11  1.0
    f_7_8     flow_7    1.0
    f_7_8     flow_8    -1.0
    f_7_8     cap_7_8   1.0
    f_8_7     flow_7    -1.0
    f_8_7     flow_8    1.0
    f_8_7     cap_7_8   1.0
    f_7_9     flow_7    1.0
    f_7_9     flow_9    -1.0
    f_7_9     cap_7_9   1.0
    f_9_7     flow_7    -1.0
    f_9_7     flow_9    1.0
    f_9_7     cap_7_9   1.0
    f_7_10    flow_7    1.0
    f_7_10    flow_10   -1.0
    f_7_10    cap_7_10  1.0
    f_10_7    flow_7    -1.0
    f_10_7    flow_10   1.0
    f_10_7    cap_7_10  1.0
    f_7_11    flow_7    1.0
    f_7_11    flow_11   -1.0
    f_7_11    cap_7_11  1.0
    f_11_7    flow_7    -1.0
    f_11_7    flow_11   1.0
    f_11_7    cap_7_11  1.0
    f_8_9     flow_8    1.0
    f_8_9     flow_9    -1.0
    f_8_9     cap_8_9   1.0
    f_9_8     flow_8    -1.0
    f_9_8     flow_9    1.0
    f_9_8     cap_8_9   1.0
    f_8_10    flow_8    1.0
    f_8_10    flow_10   -1.0
    f_8_10    cap_8_10  1.0
    f_10_8    flow_8    -1.0
    f_10_8    flow_10   1.0
    f_10_8    cap_8_10  1.0
    f_8_11    flow_8    1.0
    f_8_11    flow_11   -1.0
    f_8_11    cap_8_11  1.0
    f_11_8    flow_8    -1.0
    f_11_8    flow_11   1.0
    f_11_8    cap_8_11  1.0
    f_9_10    flow_9    1.0
    f_9_10    flow_10   -1.0
    f_9_10    cap_9_10  1.0
    f_10_9    flow_9    -1.0
    f_10_9    flow_10   1.0
    f_10_9    cap_9_10  1.0
    f_9_11    flow_9    1.0
    f_9_11    flow_11   -1.0
    f_9_11    cap_9_11  1.0
    f_11_9    flow_9    -1.0
    f_11_9    flow_11   1.0
    f_11_9    cap_9_11  1.0
    f_10_11   flow_10   1.0
    f_10_11   flow_11   -1.0
    f_10_11   cap_10_11  1.0
    f_11_10   flow_10   -1.0
    f_11_10   flow_11   1.0
    f_11_10   cap_10_11  1.0
RHS
    RHS       flow_0    3
    RHS       flow_2    -1
    RHS       flow_3    -1
    RHS       flow_7    -1
BOUNDS
 BV BOUND     x_0_1
 BV BOUND     x_0_2
 BV BOUND     x_0_3
 BV BOUND     x_0_4
 BV BOUND     x_0_5
 BV BOUND     x_0_6
 BV BOUND     x_0_7
 BV BOUND     x_0_8
 BV BOUND     x_0_9
 BV BOUND     x_0_10
 BV BOUND     x_0_11
 BV BOUND     x_1_2
 BV BOUND     x_1_3
 BV BOUND     x_1_4
 BV BOUND     x_1_5
 BV BOUND     x_1_6
 BV BOUND     x_1_7
 BV BOUND     x_1_8
 BV BOUND     x_1_9
 BV BOUND     x_1_10
 BV BOUND     x_1_11
 BV BOUND     x_2_3
 BV BOUND     x_2_4
 BV BOUND     x_2_5
 BV BOUND     x_2_6
 BV BOUND     x_2_7
 BV BOUND     x_2_8
 BV BOUND     x_2_9
 BV BOUND     x_2_10
 BV BOUND     x_2_11
 BV BOUND     x_3_4
 BV BOUND     x_3_5
 BV BOUND     x_3_6
 BV BOUND     x_3_7
 BV BOUND     x_3_8
 BV BOUND     x_3_9
 BV BOUND     x_3_10
 BV BOUND     x_3_11
 BV BOUND     x_4_5
 BV BOUND     x_4_6
 BV BOUND     x_4_7
 BV BOUND     x_4_8
 BV BOUND     x_4_9
 BV BOUND     x_4_10
 BV BOUND     x_4_11
 BV BOUND     x_5_6
 BV BOUND     x_5_7
 BV BOUND     x_5_8
 BV BOUND     x_5_9
 BV BOUND     x_5_10
 BV BOUND     x_5_11
 BV BOUND     x_6_7
 BV BOUND     x_6_8
 BV BOUND     x_6_9
 BV BOUND     x_6_10
 BV BOUND     x_6_11
 BV BOUND     x_7_8
 BV BOUND     x_7_9
 BV BOUND     x_7_10
 BV BOUND     x_7_11
 BV BOUND     x_8_9
 BV BOUND     x_8_10
 BV BOUND     x_8_11
 BV BOUND     x_9_10
 BV BOUND     x_9_11
 BV BOUND     x_10_11
 UP BOUND     f_0_1     3
 UP BOUND     f_1_0     3
 UP BOUND     f_0_2     3
 UP BOUND     f_2_0     3
 UP BOUND     f_0_3     3
 UP BOUND     f_3_0     3
 UP BOUND     f_0_4     3
 UP BOUND     f_4_0     3
 UP BOUND     f_0_5     3
 UP BOUND     f_5_0     3
 UP BOUND     f_0_6     3
 UP BOUND     f_6_0     3
 UP BOUND     f_0_7     3
 UP BOUND     f_7_0     3
 UP BOUND     f_0_8     3
 UP BOUND     f_8_0     3
 UP BOUND     f_0_9     3
 UP BOUND     f_9_0     3
 UP BOUND     f_0_10    3
 UP BOUND     f_10_0    3
 UP BOUND     f_0_11    3
 UP BOUND     f_11_0    3
 UP BOUND     f_1_2     3
 UP BOUND     f_2_1     3
 UP BOUND     f_1_3     3
 UP BOUND     f_3_1     3
 UP BOUND     f_1_4     3
 UP BOUND     f_4_1     3
 UP BOUND     f_1_5     3
 UP BOUND     f_5_1     3
 UP BOUND     f_1_6     3
 UP BOUND     f_6_1     3
 UP BOUND     f_1_7     3
 UP BOUND     f_7_1     3
 UP BOUND     f_1_8     3
 UP BOUND     f_8_1     3
 UP BOUND     f_1_9     3
 UP BOUND     f_9_1     3
 UP BOUND     f_1_10    3
 UP BOUND     f_10_1    3
 UP BOUND     f_1_11    3
 UP BOUND     f_11_1    3
 UP BOUND     f_2_3     3
 UP BOUND     f_3_2     3
 UP BOUND     f_2_4     3
 UP BOUND     f_4_2     3
 UP BOUND     f_2_5     3
 UP BOUND     f_5_2     3
 UP BOUND     f_2_6     3
 UP BOUND     f_6_2     3
 UP BOUND     f_2_7     3
 UP BOUND     f_7_2     3
 UP BOUND     f_2_8     3
 UP BOUND     f_8_2     3
 UP BOUND     f_2_9     3
 UP BOUND     f_9_2     3
 UP BOUND     f_2_10    3
 UP BOUND     f_10_2    3
 UP BOUND     f_2_11    3
 UP BOUND     f_11_2    3
 UP BOUND     f_3_4     3
 UP BOUND     f_4_3     3
 UP BOUND     f_3_5     3
 UP BOUND     f_5_3     3
 UP BOUND     f_3_6     3
 UP BOUND     f_6_3     3
 UP BOUND     f_3_7     3
 UP BOUND     f_7_3     3
 UP BOUND     f_3_8     3
 UP BOUND     f_8_3     3
 UP BOUND     f_3_9     3
 UP BOUND     f_9_3     3
 UP BOUND     f_3_10    3
 UP BOUND     f_10_3    3
 UP BOUND     f_3_11    3
 UP BOUND     f_11_3    3
 UP BOUND     f_4_5     3
 UP BOUND     f_5_4     3
 UP BOUND     f_4_6     3
 UP BOUND     f_6_4     3
 UP BOUND     f_4_7     3
 UP BOUND     f_7_4     3
 UP BOUND     f_4_8     3
 UP BOUND     f_8_4     3
 UP BOUND     f_4_9     3
 UP BOUND     f_9_4     3
 UP BOUND     f_4_10    3
 UP BOUND     f_10_4    3
 UP BOUND     f_4_11    3
 UP BOUND     f_11_4    3
 UP BOUND     f_5_6     3
 UP BOUND     f_6_5     3
 UP BOUND     f_5_7     3
 UP BOUND     f_7_5     3
 UP BOUND     f_5_8     3
 UP BOUND     f_8_5     3
 UP BOUND     f_5_9     3
 UP BOUND     f_9_5     3
 UP BOUND     f_5_10    3
 UP BOUND     f_10_5    3
 UP BOUND     f_5_11    3
 UP BOUND     f_11_5    3
 UP BOUND     f_6_7     3
 UP BOUND     f_7_6     3
 UP BOUND     f_6_8     3
 UP BOUND     f_8_6     3
 UP BOUND     f_6_9     3
 UP BOUND     f_9_6     3
 UP BOUND     f_6_10    3
 UP BOUND     f_10_6    3
 UP BOUND     f_6_11    3
 UP BOUND     f_11_6    3
 UP BOUND     f_7_8     3
 UP BOUND     f_8_7     3
 UP BOUND     f_7_9     3
 UP BOUND     f_9_7     3
 UP BOUND     f_7_10    3
 UP BOUND     f_10_7    3
 UP BOUND     f_7_11    3
 UP BOUND     f_11_7    3
 UP BOUND     f_8_9     3
 UP BOUND     f_9_8     3
 UP BOUND     f_8_10    3
 UP BOUND     f_10_8    3
 UP BOUND     f_8_11    3
 UP BOUND     f_11_8    3
 UP BOUND     f_9_10    3
 UP BOUND     f_10_9    3
 UP BOUND     f_9_11    3
 UP BOUND     f_11_9    3
 UP BOUND     f_10_11   3
 UP BOUND     f_11_10   3
ENDATA
