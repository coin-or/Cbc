NAME          SETCOVER
ROWS
 N  OBJ
 G  COVER_0
 G  COVER_1
 G  COVER_2
 G  COVER_3
 G  COVER_4
 G  COVER_5
 G  COVER_6
 G  COVER_7
 G  COVER_8
 G  COVER_9
 G  COVER_10
 G  COVER_11
 G  COVER_12
 G  COVER_13
 G  COVER_14
 G  COVER_15
 G  COVER_16
 G  COVER_17
 G  COVER_18
 G  COVER_19
COLUMNS
    x_0         OBJ       10
    x_0         COVER_0  1.0
    x_0         COVER_2  1.0
    x_0         COVER_8  1.0
    x_0         COVER_10  1.0
    x_0         COVER_13  1.0
    x_0         COVER_19  1.0
    x_1         OBJ       24
    x_1         COVER_1  1.0
    x_1         COVER_4  1.0
    x_1         COVER_7  1.0
    x_1         COVER_10  1.0
    x_1         COVER_13  1.0
    x_1         COVER_15  1.0
    x_1         COVER_18  1.0
    x_2         OBJ       53
    x_2         COVER_7  1.0
    x_2         COVER_8  1.0
    x_2         COVER_10  1.0
    x_2         COVER_15  1.0
    x_2         COVER_18  1.0
    x_3         OBJ       42
    x_3         COVER_0  1.0
    x_3         COVER_6  1.0
    x_3         COVER_11  1.0
    x_3         COVER_15  1.0
    x_3         COVER_19  1.0
    x_4         OBJ       25
    x_4         COVER_2  1.0
    x_4         COVER_3  1.0
    x_4         COVER_4  1.0
    x_4         COVER_10  1.0
    x_4         COVER_12  1.0
    x_4         COVER_13  1.0
    x_4         COVER_15  1.0
    x_4         COVER_18  1.0
    x_5         OBJ       30
    x_5         COVER_2  1.0
    x_5         COVER_3  1.0
    x_5         COVER_4  1.0
    x_5         COVER_10  1.0
    x_5         COVER_11  1.0
    x_5         COVER_12  1.0
    x_5         COVER_13  1.0
    x_5         COVER_15  1.0
    x_5         COVER_18  1.0
    x_6         OBJ       63
    x_6         COVER_7  1.0
    x_6         COVER_9  1.0
    x_6         COVER_10  1.0
    x_6         COVER_17  1.0
    x_6         COVER_18  1.0
    x_6         COVER_19  1.0
    x_7         OBJ       45
    x_7         COVER_0  1.0
    x_7         COVER_1  1.0
    x_7         COVER_2  1.0
    x_7         COVER_4  1.0
    x_7         COVER_5  1.0
    x_7         COVER_14  1.0
    x_7         COVER_15  1.0
    x_7         COVER_17  1.0
    x_7         COVER_19  1.0
    x_8         OBJ       2
    x_8         COVER_0  1.0
    x_8         COVER_2  1.0
    x_8         COVER_4  1.0
    x_8         COVER_10  1.0
    x_8         COVER_17  1.0
    x_9         OBJ       52
    x_9         COVER_1  1.0
    x_9         COVER_10  1.0
    x_9         COVER_11  1.0
    x_9         COVER_17  1.0
    x_9         COVER_19  1.0
    x_10        OBJ       66
    x_10        COVER_1  1.0
    x_10        COVER_3  1.0
    x_10        COVER_5  1.0
    x_10        COVER_7  1.0
    x_10        COVER_9  1.0
    x_10        COVER_10  1.0
    x_10        COVER_11  1.0
    x_10        COVER_12  1.0
    x_10        COVER_17  1.0
    x_10        COVER_19  1.0
    x_11        OBJ       42
    x_11        COVER_1  1.0
    x_11        COVER_3  1.0
    x_11        COVER_5  1.0
    x_11        COVER_11  1.0
    x_11        COVER_12  1.0
    x_11        COVER_13  1.0
    x_11        COVER_15  1.0
    x_11        COVER_19  1.0
    x_12        OBJ       51
    x_12        COVER_0  1.0
    x_12        COVER_7  1.0
    x_12        COVER_11  1.0
    x_12        COVER_12  1.0
    x_12        COVER_14  1.0
    x_12        COVER_19  1.0
    x_13        OBJ       68
    x_13        COVER_6  1.0
    x_13        COVER_19  1.0
    x_14        OBJ       61
    x_14        COVER_0  1.0
    x_14        COVER_3  1.0
    x_14        COVER_4  1.0
    x_14        COVER_5  1.0
    x_14        COVER_8  1.0
    x_14        COVER_14  1.0
    x_14        COVER_16  1.0
    x_14        COVER_19  1.0
    x_15        OBJ       18
    x_15        COVER_0  1.0
    x_15        COVER_2  1.0
    x_15        COVER_3  1.0
    x_15        COVER_4  1.0
    x_15        COVER_5  1.0
    x_15        COVER_8  1.0
    x_15        COVER_14  1.0
    x_15        COVER_16  1.0
    x_15        COVER_19  1.0
    x_16        OBJ       55
    x_16        COVER_0  1.0
    x_16        COVER_1  1.0
    x_16        COVER_5  1.0
    x_16        COVER_11  1.0
    x_16        COVER_13  1.0
    x_16        COVER_14  1.0
    x_16        COVER_17  1.0
    x_17        OBJ       67
    x_17        COVER_1  1.0
    x_17        COVER_3  1.0
    x_17        COVER_4  1.0
    x_17        COVER_5  1.0
    x_17        COVER_11  1.0
    x_17        COVER_14  1.0
    x_17        COVER_16  1.0
    x_18        OBJ       67
    x_18        COVER_1  1.0
    x_18        COVER_6  1.0
    x_18        COVER_9  1.0
    x_18        COVER_17  1.0
    x_18        COVER_18  1.0
    x_19        OBJ       43
    x_19        COVER_3  1.0
    x_19        COVER_5  1.0
    x_19        COVER_7  1.0
    x_19        COVER_11  1.0
    x_19        COVER_12  1.0
    x_19        COVER_13  1.0
    x_20        OBJ       1
    x_20        COVER_3  1.0
    x_20        COVER_5  1.0
    x_20        COVER_6  1.0
    x_20        COVER_7  1.0
    x_20        COVER_8  1.0
    x_20        COVER_10  1.0
    x_20        COVER_11  1.0
    x_20        COVER_12  1.0
    x_20        COVER_13  1.0
    x_20        COVER_15  1.0
    x_20        COVER_16  1.0
    x_20        COVER_19  1.0
    x_21        OBJ       79
    x_21        COVER_2  1.0
    x_21        COVER_4  1.0
    x_21        COVER_5  1.0
    x_21        COVER_10  1.0
    x_21        COVER_11  1.0
    x_21        COVER_12  1.0
    x_21        COVER_13  1.0
    x_21        COVER_15  1.0
    x_21        COVER_17  1.0
    x_21        COVER_18  1.0
    x_22        OBJ       4
    x_22        COVER_2  1.0
    x_22        COVER_4  1.0
    x_22        COVER_12  1.0
    x_22        COVER_13  1.0
    x_23        OBJ       86
    x_23        COVER_0  1.0
    x_23        COVER_4  1.0
    x_23        COVER_5  1.0
    x_23        COVER_7  1.0
    x_23        COVER_10  1.0
    x_23        COVER_11  1.0
    x_23        COVER_16  1.0
    x_23        COVER_17  1.0
    x_24        OBJ       89
    x_24        COVER_1  1.0
    x_24        COVER_7  1.0
    x_24        COVER_9  1.0
    x_24        COVER_14  1.0
    x_24        COVER_15  1.0
    x_24        COVER_16  1.0
    x_24        COVER_19  1.0
RHS
    RHS1      COVER_0  1.0
    RHS1      COVER_1  1.0
    RHS1      COVER_2  1.0
    RHS1      COVER_3  1.0
    RHS1      COVER_4  1.0
    RHS1      COVER_5  1.0
    RHS1      COVER_6  1.0
    RHS1      COVER_7  1.0
    RHS1      COVER_8  1.0
    RHS1      COVER_9  1.0
    RHS1      COVER_10  1.0
    RHS1      COVER_11  1.0
    RHS1      COVER_12  1.0
    RHS1      COVER_13  1.0
    RHS1      COVER_14  1.0
    RHS1      COVER_15  1.0
    RHS1      COVER_16  1.0
    RHS1      COVER_17  1.0
    RHS1      COVER_18  1.0
    RHS1      COVER_19  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
ENDATA
