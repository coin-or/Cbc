NAME          fcnf_complete_bip_5x5
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
COLUMNS
    x_0         OBJ       1.38
    x_0         flow_0      1.0
    x_0         flow_5      -1.0
    x_0         link_0      1.0
    x_1         OBJ       1.93
    x_1         flow_0      1.0
    x_1         flow_6      -1.0
    x_1         link_1      1.0
    x_2         OBJ       1.48
    x_2         flow_0      1.0
    x_2         flow_7      -1.0
    x_2         link_2      1.0
    x_3         OBJ       2.15
    x_3         flow_0      1.0
    x_3         flow_8      -1.0
    x_3         link_3      1.0
    x_4         OBJ       1.16
    x_4         flow_0      1.0
    x_4         flow_9      -1.0
    x_4         link_4      1.0
    x_5         OBJ       2.31
    x_5         flow_1      1.0
    x_5         flow_5      -1.0
    x_5         link_5      1.0
    x_6         OBJ       1.92
    x_6         flow_1      1.0
    x_6         flow_6      -1.0
    x_6         link_6      1.0
    x_7         OBJ       1.61
    x_7         flow_1      1.0
    x_7         flow_7      -1.0
    x_7         link_7      1.0
    x_8         OBJ       2.29
    x_8         flow_1      1.0
    x_8         flow_8      -1.0
    x_8         link_8      1.0
    x_9         OBJ       1.89
    x_9         flow_1      1.0
    x_9         flow_9      -1.0
    x_9         link_9      1.0
    x_10        OBJ       2.47
    x_10        flow_2      1.0
    x_10        flow_5      -1.0
    x_10        link_10     1.0
    x_11        OBJ       0.81
    x_11        flow_2      1.0
    x_11        flow_6      -1.0
    x_11        link_11     1.0
    x_12        OBJ       1.77
    x_12        flow_2      1.0
    x_12        flow_7      -1.0
    x_12        link_12     1.0
    x_13        OBJ       2.12
    x_13        flow_2      1.0
    x_13        flow_8      -1.0
    x_13        link_13     1.0
    x_14        OBJ       1.05
    x_14        flow_2      1.0
    x_14        flow_9      -1.0
    x_14        link_14     1.0
    x_15        OBJ       2.01
    x_15        flow_3      1.0
    x_15        flow_5      -1.0
    x_15        link_15     1.0
    x_16        OBJ       2.7
    x_16        flow_3      1.0
    x_16        flow_6      -1.0
    x_16        link_16     1.0
    x_17        OBJ       1.39
    x_17        flow_3      1.0
    x_17        flow_7      -1.0
    x_17        link_17     1.0
    x_18        OBJ       1.28
    x_18        flow_3      1.0
    x_18        flow_8      -1.0
    x_18        link_18     1.0
    x_19        OBJ       2.86
    x_19        flow_3      1.0
    x_19        flow_9      -1.0
    x_19        link_19     1.0
    x_20        OBJ       2.02
    x_20        flow_4      1.0
    x_20        flow_5      -1.0
    x_20        link_20     1.0
    x_21        OBJ       1.45
    x_21        flow_4      1.0
    x_21        flow_6      -1.0
    x_21        link_21     1.0
    x_22        OBJ       1.61
    x_22        flow_4      1.0
    x_22        flow_7      -1.0
    x_22        link_22     1.0
    x_23        OBJ       0.69
    x_23        flow_4      1.0
    x_23        flow_8      -1.0
    x_23        link_23     1.0
    x_24        OBJ       2.46
    x_24        flow_4      1.0
    x_24        flow_9      -1.0
    x_24        link_24     1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       30.06
    y_0         link_0      -10.0
    y_1         OBJ       24.01
    y_1         link_1      -9.0
    y_2         OBJ       16.43
    y_2         link_2      -9.0
    y_3         OBJ       48.51
    y_3         link_3      -3.0
    y_4         OBJ       48.8
    y_4         link_4      -10.0
    y_5         OBJ       15.32
    y_5         link_5      -8.0
    y_6         OBJ       23.05
    y_6         link_6      -8.0
    y_7         OBJ       23.47
    y_7         link_7      -8.0
    y_8         OBJ       27.37
    y_8         link_8      -8.0
    y_9         OBJ       41.67
    y_9         link_9      -6.0
    y_10        OBJ       40.52
    y_10        link_10     -3.0
    y_11        OBJ       18.43
    y_11        link_11     -9.0
    y_12        OBJ       43.45
    y_12        link_12     -4.0
    y_13        OBJ       45.84
    y_13        link_13     -8.0
    y_14        OBJ       41.05
    y_14        link_14     -9.0
    y_15        OBJ       38.62
    y_15        link_15     -7.0
    y_16        OBJ       43.35
    y_16        link_16     -7.0
    y_17        OBJ       34.79
    y_17        link_17     -10.0
    y_18        OBJ       42.29
    y_18        link_18     -7.0
    y_19        OBJ       33.18
    y_19        link_19     -6.0
    y_20        OBJ       36.96
    y_20        link_20     -6.0
    y_21        OBJ       23.86
    y_21        link_21     -5.0
    y_22        OBJ       49.34
    y_22        link_22     -4.0
    y_23        OBJ       32.89
    y_23        link_23     -10.0
    y_24        OBJ       30.25
    y_24        link_24     -3.0
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_0      8
    RHS       flow_1      8
    RHS       flow_2      8
    RHS       flow_3      8
    RHS       flow_4      8
    RHS       flow_5      -8
    RHS       flow_6      -8
    RHS       flow_7      -8
    RHS       flow_8      -8
    RHS       flow_9      -8
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
ENDATA
