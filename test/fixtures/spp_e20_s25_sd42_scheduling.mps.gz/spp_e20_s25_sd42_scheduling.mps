NAME          SETPACK
ROWS
 N  OBJ
 L  PACK_0
 L  PACK_1
 L  PACK_2
 L  PACK_3
 L  PACK_4
 L  PACK_5
 L  PACK_6
 L  PACK_7
 L  PACK_8
 L  PACK_9
 L  PACK_10
 L  PACK_11
 L  PACK_12
 L  PACK_13
 L  PACK_14
 L  PACK_15
 L  PACK_16
 L  PACK_17
 L  PACK_18
 L  PACK_19
COLUMNS
    x_0         OBJ       -82
    x_0         PACK_17  1.0
    x_0         PACK_18  1.0
    x_0         PACK_19  1.0
    x_1         OBJ       -15
    x_1         PACK_7  1.0
    x_1         PACK_8  1.0
    x_1         PACK_9  1.0
    x_1         PACK_10  1.0
    x_1         PACK_11  1.0
    x_2         OBJ       -4
    x_2         PACK_8  1.0
    x_2         PACK_9  1.0
    x_2         PACK_10  1.0
    x_2         PACK_11  1.0
    x_2         PACK_12  1.0
    x_3         OBJ       -95
    x_3         PACK_5  1.0
    x_3         PACK_6  1.0
    x_4         OBJ       -36
    x_4         PACK_10  1.0
    x_4         PACK_11  1.0
    x_4         PACK_12  1.0
    x_4         PACK_13  1.0
    x_4         PACK_14  1.0
    x_5         OBJ       -32
    x_5         PACK_4  1.0
    x_5         PACK_5  1.0
    x_5         PACK_6  1.0
    x_5         PACK_7  1.0
    x_6         OBJ       -29
    x_6         PACK_10  1.0
    x_6         PACK_11  1.0
    x_6         PACK_12  1.0
    x_7         OBJ       -18
    x_7         PACK_2  1.0
    x_7         PACK_3  1.0
    x_8         OBJ       -95
    x_8         PACK_3  1.0
    x_8         PACK_4  1.0
    x_8         PACK_5  1.0
    x_8         PACK_6  1.0
    x_8         PACK_7  1.0
    x_9         OBJ       -14
    x_9         PACK_11  1.0
    x_9         PACK_12  1.0
    x_9         PACK_13  1.0
    x_9         PACK_14  1.0
    x_10        OBJ       -87
    x_10        PACK_1  1.0
    x_10        PACK_2  1.0
    x_10        PACK_3  1.0
    x_10        PACK_4  1.0
    x_11        OBJ       -95
    x_11        PACK_3  1.0
    x_11        PACK_4  1.0
    x_11        PACK_5  1.0
    x_11        PACK_6  1.0
    x_11        PACK_7  1.0
    x_12        OBJ       -70
    x_12        PACK_2  1.0
    x_12        PACK_3  1.0
    x_12        PACK_4  1.0
    x_12        PACK_5  1.0
    x_12        PACK_6  1.0
    x_13        OBJ       -12
    x_13        PACK_11  1.0
    x_13        PACK_12  1.0
    x_13        PACK_13  1.0
    x_13        PACK_14  1.0
    x_14        OBJ       -76
    x_14        PACK_2  1.0
    x_14        PACK_3  1.0
    x_14        PACK_4  1.0
    x_15        OBJ       -55
    x_15        PACK_7  1.0
    x_15        PACK_8  1.0
    x_16        OBJ       -5
    x_16        PACK_2  1.0
    x_16        PACK_3  1.0
    x_16        PACK_4  1.0
    x_16        PACK_5  1.0
    x_17        OBJ       -4
    x_17        PACK_3  1.0
    x_17        PACK_4  1.0
    x_17        PACK_5  1.0
    x_18        OBJ       -12
    x_18        PACK_8  1.0
    x_18        PACK_9  1.0
    x_18        PACK_10  1.0
    x_18        PACK_11  1.0
    x_18        PACK_12  1.0
    x_19        OBJ       -28
    x_19        PACK_11  1.0
    x_19        PACK_12  1.0
    x_19        PACK_13  1.0
    x_19        PACK_14  1.0
    x_19        PACK_15  1.0
    x_20        OBJ       -30
    x_20        PACK_11  1.0
    x_20        PACK_12  1.0
    x_20        PACK_13  1.0
    x_21        OBJ       -65
    x_21        PACK_6  1.0
    x_21        PACK_7  1.0
    x_21        PACK_8  1.0
    x_21        PACK_9  1.0
    x_22        OBJ       -78
    x_22        PACK_2  1.0
    x_22        PACK_3  1.0
    x_22        PACK_4  1.0
    x_22        PACK_5  1.0
    x_23        OBJ       -4
    x_23        PACK_17  1.0
    x_23        PACK_18  1.0
    x_23        PACK_19  1.0
    x_24        OBJ       -72
    x_24        PACK_5  1.0
    x_24        PACK_6  1.0
    x_24        PACK_7  1.0
RHS
    RHS1      PACK_0  1.0
    RHS1      PACK_1  1.0
    RHS1      PACK_2  1.0
    RHS1      PACK_3  1.0
    RHS1      PACK_4  1.0
    RHS1      PACK_5  1.0
    RHS1      PACK_6  1.0
    RHS1      PACK_7  1.0
    RHS1      PACK_8  1.0
    RHS1      PACK_9  1.0
    RHS1      PACK_10  1.0
    RHS1      PACK_11  1.0
    RHS1      PACK_12  1.0
    RHS1      PACK_13  1.0
    RHS1      PACK_14  1.0
    RHS1      PACK_15  1.0
    RHS1      PACK_16  1.0
    RHS1      PACK_17  1.0
    RHS1      PACK_18  1.0
    RHS1      PACK_19  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
ENDATA
