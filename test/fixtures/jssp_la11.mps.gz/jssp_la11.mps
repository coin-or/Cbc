NAME          la11
ROWS
 N  OBJ
 G  prec_0_0
 G  prec_0_1
 G  prec_0_2
 G  prec_0_3
 G  prec_1_0
 G  prec_1_1
 G  prec_1_2
 G  prec_1_3
 G  prec_2_0
 G  prec_2_1
 G  prec_2_2
 G  prec_2_3
 G  prec_3_0
 G  prec_3_1
 G  prec_3_2
 G  prec_3_3
 G  prec_4_0
 G  prec_4_1
 G  prec_4_2
 G  prec_4_3
 G  prec_5_0
 G  prec_5_1
 G  prec_5_2
 G  prec_5_3
 G  prec_6_0
 G  prec_6_1
 G  prec_6_2
 G  prec_6_3
 G  prec_7_0
 G  prec_7_1
 G  prec_7_2
 G  prec_7_3
 G  prec_8_0
 G  prec_8_1
 G  prec_8_2
 G  prec_8_3
 G  prec_9_0
 G  prec_9_1
 G  prec_9_2
 G  prec_9_3
 G  prec_10_0
 G  prec_10_1
 G  prec_10_2
 G  prec_10_3
 G  prec_11_0
 G  prec_11_1
 G  prec_11_2
 G  prec_11_3
 G  prec_12_0
 G  prec_12_1
 G  prec_12_2
 G  prec_12_3
 G  prec_13_0
 G  prec_13_1
 G  prec_13_2
 G  prec_13_3
 G  prec_14_0
 G  prec_14_1
 G  prec_14_2
 G  prec_14_3
 G  prec_15_0
 G  prec_15_1
 G  prec_15_2
 G  prec_15_3
 G  prec_16_0
 G  prec_16_1
 G  prec_16_2
 G  prec_16_3
 G  prec_17_0
 G  prec_17_1
 G  prec_17_2
 G  prec_17_3
 G  prec_18_0
 G  prec_18_1
 G  prec_18_2
 G  prec_18_3
 G  prec_19_0
 G  prec_19_1
 G  prec_19_2
 G  prec_19_3
 G  mksp_0
 G  mksp_1
 G  mksp_2
 G  mksp_3
 G  mksp_4
 G  mksp_5
 G  mksp_6
 G  mksp_7
 G  mksp_8
 G  mksp_9
 G  mksp_10
 G  mksp_11
 G  mksp_12
 G  mksp_13
 G  mksp_14
 G  mksp_15
 G  mksp_16
 G  mksp_17
 G  mksp_18
 G  mksp_19
 G  disj1_0_1_0
 G  disj2_0_1_0
 G  disj1_0_2_0
 G  disj2_0_2_0
 G  disj1_0_3_0
 G  disj2_0_3_0
 G  disj1_0_4_0
 G  disj2_0_4_0
 G  disj1_0_5_0
 G  disj2_0_5_0
 G  disj1_0_6_0
 G  disj2_0_6_0
 G  disj1_0_7_0
 G  disj2_0_7_0
 G  disj1_0_8_0
 G  disj2_0_8_0
 G  disj1_0_9_0
 G  disj2_0_9_0
 G  disj1_0_10_0
 G  disj2_0_10_0
 G  disj1_0_11_0
 G  disj2_0_11_0
 G  disj1_0_12_0
 G  disj2_0_12_0
 G  disj1_0_13_0
 G  disj2_0_13_0
 G  disj1_0_14_0
 G  disj2_0_14_0
 G  disj1_0_15_0
 G  disj2_0_15_0
 G  disj1_0_16_0
 G  disj2_0_16_0
 G  disj1_0_17_0
 G  disj2_0_17_0
 G  disj1_0_18_0
 G  disj2_0_18_0
 G  disj1_0_19_0
 G  disj2_0_19_0
 G  disj1_1_2_0
 G  disj2_1_2_0
 G  disj1_1_3_0
 G  disj2_1_3_0
 G  disj1_1_4_0
 G  disj2_1_4_0
 G  disj1_1_5_0
 G  disj2_1_5_0
 G  disj1_1_6_0
 G  disj2_1_6_0
 G  disj1_1_7_0
 G  disj2_1_7_0
 G  disj1_1_8_0
 G  disj2_1_8_0
 G  disj1_1_9_0
 G  disj2_1_9_0
 G  disj1_1_10_0
 G  disj2_1_10_0
 G  disj1_1_11_0
 G  disj2_1_11_0
 G  disj1_1_12_0
 G  disj2_1_12_0
 G  disj1_1_13_0
 G  disj2_1_13_0
 G  disj1_1_14_0
 G  disj2_1_14_0
 G  disj1_1_15_0
 G  disj2_1_15_0
 G  disj1_1_16_0
 G  disj2_1_16_0
 G  disj1_1_17_0
 G  disj2_1_17_0
 G  disj1_1_18_0
 G  disj2_1_18_0
 G  disj1_1_19_0
 G  disj2_1_19_0
 G  disj1_2_3_0
 G  disj2_2_3_0
 G  disj1_2_4_0
 G  disj2_2_4_0
 G  disj1_2_5_0
 G  disj2_2_5_0
 G  disj1_2_6_0
 G  disj2_2_6_0
 G  disj1_2_7_0
 G  disj2_2_7_0
 G  disj1_2_8_0
 G  disj2_2_8_0
 G  disj1_2_9_0
 G  disj2_2_9_0
 G  disj1_2_10_0
 G  disj2_2_10_0
 G  disj1_2_11_0
 G  disj2_2_11_0
 G  disj1_2_12_0
 G  disj2_2_12_0
 G  disj1_2_13_0
 G  disj2_2_13_0
 G  disj1_2_14_0
 G  disj2_2_14_0
 G  disj1_2_15_0
 G  disj2_2_15_0
 G  disj1_2_16_0
 G  disj2_2_16_0
 G  disj1_2_17_0
 G  disj2_2_17_0
 G  disj1_2_18_0
 G  disj2_2_18_0
 G  disj1_2_19_0
 G  disj2_2_19_0
 G  disj1_3_4_0
 G  disj2_3_4_0
 G  disj1_3_5_0
 G  disj2_3_5_0
 G  disj1_3_6_0
 G  disj2_3_6_0
 G  disj1_3_7_0
 G  disj2_3_7_0
 G  disj1_3_8_0
 G  disj2_3_8_0
 G  disj1_3_9_0
 G  disj2_3_9_0
 G  disj1_3_10_0
 G  disj2_3_10_0
 G  disj1_3_11_0
 G  disj2_3_11_0
 G  disj1_3_12_0
 G  disj2_3_12_0
 G  disj1_3_13_0
 G  disj2_3_13_0
 G  disj1_3_14_0
 G  disj2_3_14_0
 G  disj1_3_15_0
 G  disj2_3_15_0
 G  disj1_3_16_0
 G  disj2_3_16_0
 G  disj1_3_17_0
 G  disj2_3_17_0
 G  disj1_3_18_0
 G  disj2_3_18_0
 G  disj1_3_19_0
 G  disj2_3_19_0
 G  disj1_4_5_0
 G  disj2_4_5_0
 G  disj1_4_6_0
 G  disj2_4_6_0
 G  disj1_4_7_0
 G  disj2_4_7_0
 G  disj1_4_8_0
 G  disj2_4_8_0
 G  disj1_4_9_0
 G  disj2_4_9_0
 G  disj1_4_10_0
 G  disj2_4_10_0
 G  disj1_4_11_0
 G  disj2_4_11_0
 G  disj1_4_12_0
 G  disj2_4_12_0
 G  disj1_4_13_0
 G  disj2_4_13_0
 G  disj1_4_14_0
 G  disj2_4_14_0
 G  disj1_4_15_0
 G  disj2_4_15_0
 G  disj1_4_16_0
 G  disj2_4_16_0
 G  disj1_4_17_0
 G  disj2_4_17_0
 G  disj1_4_18_0
 G  disj2_4_18_0
 G  disj1_4_19_0
 G  disj2_4_19_0
 G  disj1_5_6_0
 G  disj2_5_6_0
 G  disj1_5_7_0
 G  disj2_5_7_0
 G  disj1_5_8_0
 G  disj2_5_8_0
 G  disj1_5_9_0
 G  disj2_5_9_0
 G  disj1_5_10_0
 G  disj2_5_10_0
 G  disj1_5_11_0
 G  disj2_5_11_0
 G  disj1_5_12_0
 G  disj2_5_12_0
 G  disj1_5_13_0
 G  disj2_5_13_0
 G  disj1_5_14_0
 G  disj2_5_14_0
 G  disj1_5_15_0
 G  disj2_5_15_0
 G  disj1_5_16_0
 G  disj2_5_16_0
 G  disj1_5_17_0
 G  disj2_5_17_0
 G  disj1_5_18_0
 G  disj2_5_18_0
 G  disj1_5_19_0
 G  disj2_5_19_0
 G  disj1_6_7_0
 G  disj2_6_7_0
 G  disj1_6_8_0
 G  disj2_6_8_0
 G  disj1_6_9_0
 G  disj2_6_9_0
 G  disj1_6_10_0
 G  disj2_6_10_0
 G  disj1_6_11_0
 G  disj2_6_11_0
 G  disj1_6_12_0
 G  disj2_6_12_0
 G  disj1_6_13_0
 G  disj2_6_13_0
 G  disj1_6_14_0
 G  disj2_6_14_0
 G  disj1_6_15_0
 G  disj2_6_15_0
 G  disj1_6_16_0
 G  disj2_6_16_0
 G  disj1_6_17_0
 G  disj2_6_17_0
 G  disj1_6_18_0
 G  disj2_6_18_0
 G  disj1_6_19_0
 G  disj2_6_19_0
 G  disj1_7_8_0
 G  disj2_7_8_0
 G  disj1_7_9_0
 G  disj2_7_9_0
 G  disj1_7_10_0
 G  disj2_7_10_0
 G  disj1_7_11_0
 G  disj2_7_11_0
 G  disj1_7_12_0
 G  disj2_7_12_0
 G  disj1_7_13_0
 G  disj2_7_13_0
 G  disj1_7_14_0
 G  disj2_7_14_0
 G  disj1_7_15_0
 G  disj2_7_15_0
 G  disj1_7_16_0
 G  disj2_7_16_0
 G  disj1_7_17_0
 G  disj2_7_17_0
 G  disj1_7_18_0
 G  disj2_7_18_0
 G  disj1_7_19_0
 G  disj2_7_19_0
 G  disj1_8_9_0
 G  disj2_8_9_0
 G  disj1_8_10_0
 G  disj2_8_10_0
 G  disj1_8_11_0
 G  disj2_8_11_0
 G  disj1_8_12_0
 G  disj2_8_12_0
 G  disj1_8_13_0
 G  disj2_8_13_0
 G  disj1_8_14_0
 G  disj2_8_14_0
 G  disj1_8_15_0
 G  disj2_8_15_0
 G  disj1_8_16_0
 G  disj2_8_16_0
 G  disj1_8_17_0
 G  disj2_8_17_0
 G  disj1_8_18_0
 G  disj2_8_18_0
 G  disj1_8_19_0
 G  disj2_8_19_0
 G  disj1_9_10_0
 G  disj2_9_10_0
 G  disj1_9_11_0
 G  disj2_9_11_0
 G  disj1_9_12_0
 G  disj2_9_12_0
 G  disj1_9_13_0
 G  disj2_9_13_0
 G  disj1_9_14_0
 G  disj2_9_14_0
 G  disj1_9_15_0
 G  disj2_9_15_0
 G  disj1_9_16_0
 G  disj2_9_16_0
 G  disj1_9_17_0
 G  disj2_9_17_0
 G  disj1_9_18_0
 G  disj2_9_18_0
 G  disj1_9_19_0
 G  disj2_9_19_0
 G  disj1_10_11_0
 G  disj2_10_11_0
 G  disj1_10_12_0
 G  disj2_10_12_0
 G  disj1_10_13_0
 G  disj2_10_13_0
 G  disj1_10_14_0
 G  disj2_10_14_0
 G  disj1_10_15_0
 G  disj2_10_15_0
 G  disj1_10_16_0
 G  disj2_10_16_0
 G  disj1_10_17_0
 G  disj2_10_17_0
 G  disj1_10_18_0
 G  disj2_10_18_0
 G  disj1_10_19_0
 G  disj2_10_19_0
 G  disj1_11_12_0
 G  disj2_11_12_0
 G  disj1_11_13_0
 G  disj2_11_13_0
 G  disj1_11_14_0
 G  disj2_11_14_0
 G  disj1_11_15_0
 G  disj2_11_15_0
 G  disj1_11_16_0
 G  disj2_11_16_0
 G  disj1_11_17_0
 G  disj2_11_17_0
 G  disj1_11_18_0
 G  disj2_11_18_0
 G  disj1_11_19_0
 G  disj2_11_19_0
 G  disj1_12_13_0
 G  disj2_12_13_0
 G  disj1_12_14_0
 G  disj2_12_14_0
 G  disj1_12_15_0
 G  disj2_12_15_0
 G  disj1_12_16_0
 G  disj2_12_16_0
 G  disj1_12_17_0
 G  disj2_12_17_0
 G  disj1_12_18_0
 G  disj2_12_18_0
 G  disj1_12_19_0
 G  disj2_12_19_0
 G  disj1_13_14_0
 G  disj2_13_14_0
 G  disj1_13_15_0
 G  disj2_13_15_0
 G  disj1_13_16_0
 G  disj2_13_16_0
 G  disj1_13_17_0
 G  disj2_13_17_0
 G  disj1_13_18_0
 G  disj2_13_18_0
 G  disj1_13_19_0
 G  disj2_13_19_0
 G  disj1_14_15_0
 G  disj2_14_15_0
 G  disj1_14_16_0
 G  disj2_14_16_0
 G  disj1_14_17_0
 G  disj2_14_17_0
 G  disj1_14_18_0
 G  disj2_14_18_0
 G  disj1_14_19_0
 G  disj2_14_19_0
 G  disj1_15_16_0
 G  disj2_15_16_0
 G  disj1_15_17_0
 G  disj2_15_17_0
 G  disj1_15_18_0
 G  disj2_15_18_0
 G  disj1_15_19_0
 G  disj2_15_19_0
 G  disj1_16_17_0
 G  disj2_16_17_0
 G  disj1_16_18_0
 G  disj2_16_18_0
 G  disj1_16_19_0
 G  disj2_16_19_0
 G  disj1_17_18_0
 G  disj2_17_18_0
 G  disj1_17_19_0
 G  disj2_17_19_0
 G  disj1_18_19_0
 G  disj2_18_19_0
 G  disj1_0_1_1
 G  disj2_0_1_1
 G  disj1_0_2_1
 G  disj2_0_2_1
 G  disj1_0_3_1
 G  disj2_0_3_1
 G  disj1_0_4_1
 G  disj2_0_4_1
 G  disj1_0_5_1
 G  disj2_0_5_1
 G  disj1_0_6_1
 G  disj2_0_6_1
 G  disj1_0_7_1
 G  disj2_0_7_1
 G  disj1_0_8_1
 G  disj2_0_8_1
 G  disj1_0_9_1
 G  disj2_0_9_1
 G  disj1_0_10_1
 G  disj2_0_10_1
 G  disj1_0_11_1
 G  disj2_0_11_1
 G  disj1_0_12_1
 G  disj2_0_12_1
 G  disj1_0_13_1
 G  disj2_0_13_1
 G  disj1_0_14_1
 G  disj2_0_14_1
 G  disj1_0_15_1
 G  disj2_0_15_1
 G  disj1_0_16_1
 G  disj2_0_16_1
 G  disj1_0_17_1
 G  disj2_0_17_1
 G  disj1_0_18_1
 G  disj2_0_18_1
 G  disj1_0_19_1
 G  disj2_0_19_1
 G  disj1_1_2_1
 G  disj2_1_2_1
 G  disj1_1_3_1
 G  disj2_1_3_1
 G  disj1_1_4_1
 G  disj2_1_4_1
 G  disj1_1_5_1
 G  disj2_1_5_1
 G  disj1_1_6_1
 G  disj2_1_6_1
 G  disj1_1_7_1
 G  disj2_1_7_1
 G  disj1_1_8_1
 G  disj2_1_8_1
 G  disj1_1_9_1
 G  disj2_1_9_1
 G  disj1_1_10_1
 G  disj2_1_10_1
 G  disj1_1_11_1
 G  disj2_1_11_1
 G  disj1_1_12_1
 G  disj2_1_12_1
 G  disj1_1_13_1
 G  disj2_1_13_1
 G  disj1_1_14_1
 G  disj2_1_14_1
 G  disj1_1_15_1
 G  disj2_1_15_1
 G  disj1_1_16_1
 G  disj2_1_16_1
 G  disj1_1_17_1
 G  disj2_1_17_1
 G  disj1_1_18_1
 G  disj2_1_18_1
 G  disj1_1_19_1
 G  disj2_1_19_1
 G  disj1_2_3_1
 G  disj2_2_3_1
 G  disj1_2_4_1
 G  disj2_2_4_1
 G  disj1_2_5_1
 G  disj2_2_5_1
 G  disj1_2_6_1
 G  disj2_2_6_1
 G  disj1_2_7_1
 G  disj2_2_7_1
 G  disj1_2_8_1
 G  disj2_2_8_1
 G  disj1_2_9_1
 G  disj2_2_9_1
 G  disj1_2_10_1
 G  disj2_2_10_1
 G  disj1_2_11_1
 G  disj2_2_11_1
 G  disj1_2_12_1
 G  disj2_2_12_1
 G  disj1_2_13_1
 G  disj2_2_13_1
 G  disj1_2_14_1
 G  disj2_2_14_1
 G  disj1_2_15_1
 G  disj2_2_15_1
 G  disj1_2_16_1
 G  disj2_2_16_1
 G  disj1_2_17_1
 G  disj2_2_17_1
 G  disj1_2_18_1
 G  disj2_2_18_1
 G  disj1_2_19_1
 G  disj2_2_19_1
 G  disj1_3_4_1
 G  disj2_3_4_1
 G  disj1_3_5_1
 G  disj2_3_5_1
 G  disj1_3_6_1
 G  disj2_3_6_1
 G  disj1_3_7_1
 G  disj2_3_7_1
 G  disj1_3_8_1
 G  disj2_3_8_1
 G  disj1_3_9_1
 G  disj2_3_9_1
 G  disj1_3_10_1
 G  disj2_3_10_1
 G  disj1_3_11_1
 G  disj2_3_11_1
 G  disj1_3_12_1
 G  disj2_3_12_1
 G  disj1_3_13_1
 G  disj2_3_13_1
 G  disj1_3_14_1
 G  disj2_3_14_1
 G  disj1_3_15_1
 G  disj2_3_15_1
 G  disj1_3_16_1
 G  disj2_3_16_1
 G  disj1_3_17_1
 G  disj2_3_17_1
 G  disj1_3_18_1
 G  disj2_3_18_1
 G  disj1_3_19_1
 G  disj2_3_19_1
 G  disj1_4_5_1
 G  disj2_4_5_1
 G  disj1_4_6_1
 G  disj2_4_6_1
 G  disj1_4_7_1
 G  disj2_4_7_1
 G  disj1_4_8_1
 G  disj2_4_8_1
 G  disj1_4_9_1
 G  disj2_4_9_1
 G  disj1_4_10_1
 G  disj2_4_10_1
 G  disj1_4_11_1
 G  disj2_4_11_1
 G  disj1_4_12_1
 G  disj2_4_12_1
 G  disj1_4_13_1
 G  disj2_4_13_1
 G  disj1_4_14_1
 G  disj2_4_14_1
 G  disj1_4_15_1
 G  disj2_4_15_1
 G  disj1_4_16_1
 G  disj2_4_16_1
 G  disj1_4_17_1
 G  disj2_4_17_1
 G  disj1_4_18_1
 G  disj2_4_18_1
 G  disj1_4_19_1
 G  disj2_4_19_1
 G  disj1_5_6_1
 G  disj2_5_6_1
 G  disj1_5_7_1
 G  disj2_5_7_1
 G  disj1_5_8_1
 G  disj2_5_8_1
 G  disj1_5_9_1
 G  disj2_5_9_1
 G  disj1_5_10_1
 G  disj2_5_10_1
 G  disj1_5_11_1
 G  disj2_5_11_1
 G  disj1_5_12_1
 G  disj2_5_12_1
 G  disj1_5_13_1
 G  disj2_5_13_1
 G  disj1_5_14_1
 G  disj2_5_14_1
 G  disj1_5_15_1
 G  disj2_5_15_1
 G  disj1_5_16_1
 G  disj2_5_16_1
 G  disj1_5_17_1
 G  disj2_5_17_1
 G  disj1_5_18_1
 G  disj2_5_18_1
 G  disj1_5_19_1
 G  disj2_5_19_1
 G  disj1_6_7_1
 G  disj2_6_7_1
 G  disj1_6_8_1
 G  disj2_6_8_1
 G  disj1_6_9_1
 G  disj2_6_9_1
 G  disj1_6_10_1
 G  disj2_6_10_1
 G  disj1_6_11_1
 G  disj2_6_11_1
 G  disj1_6_12_1
 G  disj2_6_12_1
 G  disj1_6_13_1
 G  disj2_6_13_1
 G  disj1_6_14_1
 G  disj2_6_14_1
 G  disj1_6_15_1
 G  disj2_6_15_1
 G  disj1_6_16_1
 G  disj2_6_16_1
 G  disj1_6_17_1
 G  disj2_6_17_1
 G  disj1_6_18_1
 G  disj2_6_18_1
 G  disj1_6_19_1
 G  disj2_6_19_1
 G  disj1_7_8_1
 G  disj2_7_8_1
 G  disj1_7_9_1
 G  disj2_7_9_1
 G  disj1_7_10_1
 G  disj2_7_10_1
 G  disj1_7_11_1
 G  disj2_7_11_1
 G  disj1_7_12_1
 G  disj2_7_12_1
 G  disj1_7_13_1
 G  disj2_7_13_1
 G  disj1_7_14_1
 G  disj2_7_14_1
 G  disj1_7_15_1
 G  disj2_7_15_1
 G  disj1_7_16_1
 G  disj2_7_16_1
 G  disj1_7_17_1
 G  disj2_7_17_1
 G  disj1_7_18_1
 G  disj2_7_18_1
 G  disj1_7_19_1
 G  disj2_7_19_1
 G  disj1_8_9_1
 G  disj2_8_9_1
 G  disj1_8_10_1
 G  disj2_8_10_1
 G  disj1_8_11_1
 G  disj2_8_11_1
 G  disj1_8_12_1
 G  disj2_8_12_1
 G  disj1_8_13_1
 G  disj2_8_13_1
 G  disj1_8_14_1
 G  disj2_8_14_1
 G  disj1_8_15_1
 G  disj2_8_15_1
 G  disj1_8_16_1
 G  disj2_8_16_1
 G  disj1_8_17_1
 G  disj2_8_17_1
 G  disj1_8_18_1
 G  disj2_8_18_1
 G  disj1_8_19_1
 G  disj2_8_19_1
 G  disj1_9_10_1
 G  disj2_9_10_1
 G  disj1_9_11_1
 G  disj2_9_11_1
 G  disj1_9_12_1
 G  disj2_9_12_1
 G  disj1_9_13_1
 G  disj2_9_13_1
 G  disj1_9_14_1
 G  disj2_9_14_1
 G  disj1_9_15_1
 G  disj2_9_15_1
 G  disj1_9_16_1
 G  disj2_9_16_1
 G  disj1_9_17_1
 G  disj2_9_17_1
 G  disj1_9_18_1
 G  disj2_9_18_1
 G  disj1_9_19_1
 G  disj2_9_19_1
 G  disj1_10_11_1
 G  disj2_10_11_1
 G  disj1_10_12_1
 G  disj2_10_12_1
 G  disj1_10_13_1
 G  disj2_10_13_1
 G  disj1_10_14_1
 G  disj2_10_14_1
 G  disj1_10_15_1
 G  disj2_10_15_1
 G  disj1_10_16_1
 G  disj2_10_16_1
 G  disj1_10_17_1
 G  disj2_10_17_1
 G  disj1_10_18_1
 G  disj2_10_18_1
 G  disj1_10_19_1
 G  disj2_10_19_1
 G  disj1_11_12_1
 G  disj2_11_12_1
 G  disj1_11_13_1
 G  disj2_11_13_1
 G  disj1_11_14_1
 G  disj2_11_14_1
 G  disj1_11_15_1
 G  disj2_11_15_1
 G  disj1_11_16_1
 G  disj2_11_16_1
 G  disj1_11_17_1
 G  disj2_11_17_1
 G  disj1_11_18_1
 G  disj2_11_18_1
 G  disj1_11_19_1
 G  disj2_11_19_1
 G  disj1_12_13_1
 G  disj2_12_13_1
 G  disj1_12_14_1
 G  disj2_12_14_1
 G  disj1_12_15_1
 G  disj2_12_15_1
 G  disj1_12_16_1
 G  disj2_12_16_1
 G  disj1_12_17_1
 G  disj2_12_17_1
 G  disj1_12_18_1
 G  disj2_12_18_1
 G  disj1_12_19_1
 G  disj2_12_19_1
 G  disj1_13_14_1
 G  disj2_13_14_1
 G  disj1_13_15_1
 G  disj2_13_15_1
 G  disj1_13_16_1
 G  disj2_13_16_1
 G  disj1_13_17_1
 G  disj2_13_17_1
 G  disj1_13_18_1
 G  disj2_13_18_1
 G  disj1_13_19_1
 G  disj2_13_19_1
 G  disj1_14_15_1
 G  disj2_14_15_1
 G  disj1_14_16_1
 G  disj2_14_16_1
 G  disj1_14_17_1
 G  disj2_14_17_1
 G  disj1_14_18_1
 G  disj2_14_18_1
 G  disj1_14_19_1
 G  disj2_14_19_1
 G  disj1_15_16_1
 G  disj2_15_16_1
 G  disj1_15_17_1
 G  disj2_15_17_1
 G  disj1_15_18_1
 G  disj2_15_18_1
 G  disj1_15_19_1
 G  disj2_15_19_1
 G  disj1_16_17_1
 G  disj2_16_17_1
 G  disj1_16_18_1
 G  disj2_16_18_1
 G  disj1_16_19_1
 G  disj2_16_19_1
 G  disj1_17_18_1
 G  disj2_17_18_1
 G  disj1_17_19_1
 G  disj2_17_19_1
 G  disj1_18_19_1
 G  disj2_18_19_1
 G  disj1_0_1_2
 G  disj2_0_1_2
 G  disj1_0_2_2
 G  disj2_0_2_2
 G  disj1_0_3_2
 G  disj2_0_3_2
 G  disj1_0_4_2
 G  disj2_0_4_2
 G  disj1_0_5_2
 G  disj2_0_5_2
 G  disj1_0_6_2
 G  disj2_0_6_2
 G  disj1_0_7_2
 G  disj2_0_7_2
 G  disj1_0_8_2
 G  disj2_0_8_2
 G  disj1_0_9_2
 G  disj2_0_9_2
 G  disj1_0_10_2
 G  disj2_0_10_2
 G  disj1_0_11_2
 G  disj2_0_11_2
 G  disj1_0_12_2
 G  disj2_0_12_2
 G  disj1_0_13_2
 G  disj2_0_13_2
 G  disj1_0_14_2
 G  disj2_0_14_2
 G  disj1_0_15_2
 G  disj2_0_15_2
 G  disj1_0_16_2
 G  disj2_0_16_2
 G  disj1_0_17_2
 G  disj2_0_17_2
 G  disj1_0_18_2
 G  disj2_0_18_2
 G  disj1_0_19_2
 G  disj2_0_19_2
 G  disj1_1_2_2
 G  disj2_1_2_2
 G  disj1_1_3_2
 G  disj2_1_3_2
 G  disj1_1_4_2
 G  disj2_1_4_2
 G  disj1_1_5_2
 G  disj2_1_5_2
 G  disj1_1_6_2
 G  disj2_1_6_2
 G  disj1_1_7_2
 G  disj2_1_7_2
 G  disj1_1_8_2
 G  disj2_1_8_2
 G  disj1_1_9_2
 G  disj2_1_9_2
 G  disj1_1_10_2
 G  disj2_1_10_2
 G  disj1_1_11_2
 G  disj2_1_11_2
 G  disj1_1_12_2
 G  disj2_1_12_2
 G  disj1_1_13_2
 G  disj2_1_13_2
 G  disj1_1_14_2
 G  disj2_1_14_2
 G  disj1_1_15_2
 G  disj2_1_15_2
 G  disj1_1_16_2
 G  disj2_1_16_2
 G  disj1_1_17_2
 G  disj2_1_17_2
 G  disj1_1_18_2
 G  disj2_1_18_2
 G  disj1_1_19_2
 G  disj2_1_19_2
 G  disj1_2_3_2
 G  disj2_2_3_2
 G  disj1_2_4_2
 G  disj2_2_4_2
 G  disj1_2_5_2
 G  disj2_2_5_2
 G  disj1_2_6_2
 G  disj2_2_6_2
 G  disj1_2_7_2
 G  disj2_2_7_2
 G  disj1_2_8_2
 G  disj2_2_8_2
 G  disj1_2_9_2
 G  disj2_2_9_2
 G  disj1_2_10_2
 G  disj2_2_10_2
 G  disj1_2_11_2
 G  disj2_2_11_2
 G  disj1_2_12_2
 G  disj2_2_12_2
 G  disj1_2_13_2
 G  disj2_2_13_2
 G  disj1_2_14_2
 G  disj2_2_14_2
 G  disj1_2_15_2
 G  disj2_2_15_2
 G  disj1_2_16_2
 G  disj2_2_16_2
 G  disj1_2_17_2
 G  disj2_2_17_2
 G  disj1_2_18_2
 G  disj2_2_18_2
 G  disj1_2_19_2
 G  disj2_2_19_2
 G  disj1_3_4_2
 G  disj2_3_4_2
 G  disj1_3_5_2
 G  disj2_3_5_2
 G  disj1_3_6_2
 G  disj2_3_6_2
 G  disj1_3_7_2
 G  disj2_3_7_2
 G  disj1_3_8_2
 G  disj2_3_8_2
 G  disj1_3_9_2
 G  disj2_3_9_2
 G  disj1_3_10_2
 G  disj2_3_10_2
 G  disj1_3_11_2
 G  disj2_3_11_2
 G  disj1_3_12_2
 G  disj2_3_12_2
 G  disj1_3_13_2
 G  disj2_3_13_2
 G  disj1_3_14_2
 G  disj2_3_14_2
 G  disj1_3_15_2
 G  disj2_3_15_2
 G  disj1_3_16_2
 G  disj2_3_16_2
 G  disj1_3_17_2
 G  disj2_3_17_2
 G  disj1_3_18_2
 G  disj2_3_18_2
 G  disj1_3_19_2
 G  disj2_3_19_2
 G  disj1_4_5_2
 G  disj2_4_5_2
 G  disj1_4_6_2
 G  disj2_4_6_2
 G  disj1_4_7_2
 G  disj2_4_7_2
 G  disj1_4_8_2
 G  disj2_4_8_2
 G  disj1_4_9_2
 G  disj2_4_9_2
 G  disj1_4_10_2
 G  disj2_4_10_2
 G  disj1_4_11_2
 G  disj2_4_11_2
 G  disj1_4_12_2
 G  disj2_4_12_2
 G  disj1_4_13_2
 G  disj2_4_13_2
 G  disj1_4_14_2
 G  disj2_4_14_2
 G  disj1_4_15_2
 G  disj2_4_15_2
 G  disj1_4_16_2
 G  disj2_4_16_2
 G  disj1_4_17_2
 G  disj2_4_17_2
 G  disj1_4_18_2
 G  disj2_4_18_2
 G  disj1_4_19_2
 G  disj2_4_19_2
 G  disj1_5_6_2
 G  disj2_5_6_2
 G  disj1_5_7_2
 G  disj2_5_7_2
 G  disj1_5_8_2
 G  disj2_5_8_2
 G  disj1_5_9_2
 G  disj2_5_9_2
 G  disj1_5_10_2
 G  disj2_5_10_2
 G  disj1_5_11_2
 G  disj2_5_11_2
 G  disj1_5_12_2
 G  disj2_5_12_2
 G  disj1_5_13_2
 G  disj2_5_13_2
 G  disj1_5_14_2
 G  disj2_5_14_2
 G  disj1_5_15_2
 G  disj2_5_15_2
 G  disj1_5_16_2
 G  disj2_5_16_2
 G  disj1_5_17_2
 G  disj2_5_17_2
 G  disj1_5_18_2
 G  disj2_5_18_2
 G  disj1_5_19_2
 G  disj2_5_19_2
 G  disj1_6_7_2
 G  disj2_6_7_2
 G  disj1_6_8_2
 G  disj2_6_8_2
 G  disj1_6_9_2
 G  disj2_6_9_2
 G  disj1_6_10_2
 G  disj2_6_10_2
 G  disj1_6_11_2
 G  disj2_6_11_2
 G  disj1_6_12_2
 G  disj2_6_12_2
 G  disj1_6_13_2
 G  disj2_6_13_2
 G  disj1_6_14_2
 G  disj2_6_14_2
 G  disj1_6_15_2
 G  disj2_6_15_2
 G  disj1_6_16_2
 G  disj2_6_16_2
 G  disj1_6_17_2
 G  disj2_6_17_2
 G  disj1_6_18_2
 G  disj2_6_18_2
 G  disj1_6_19_2
 G  disj2_6_19_2
 G  disj1_7_8_2
 G  disj2_7_8_2
 G  disj1_7_9_2
 G  disj2_7_9_2
 G  disj1_7_10_2
 G  disj2_7_10_2
 G  disj1_7_11_2
 G  disj2_7_11_2
 G  disj1_7_12_2
 G  disj2_7_12_2
 G  disj1_7_13_2
 G  disj2_7_13_2
 G  disj1_7_14_2
 G  disj2_7_14_2
 G  disj1_7_15_2
 G  disj2_7_15_2
 G  disj1_7_16_2
 G  disj2_7_16_2
 G  disj1_7_17_2
 G  disj2_7_17_2
 G  disj1_7_18_2
 G  disj2_7_18_2
 G  disj1_7_19_2
 G  disj2_7_19_2
 G  disj1_8_9_2
 G  disj2_8_9_2
 G  disj1_8_10_2
 G  disj2_8_10_2
 G  disj1_8_11_2
 G  disj2_8_11_2
 G  disj1_8_12_2
 G  disj2_8_12_2
 G  disj1_8_13_2
 G  disj2_8_13_2
 G  disj1_8_14_2
 G  disj2_8_14_2
 G  disj1_8_15_2
 G  disj2_8_15_2
 G  disj1_8_16_2
 G  disj2_8_16_2
 G  disj1_8_17_2
 G  disj2_8_17_2
 G  disj1_8_18_2
 G  disj2_8_18_2
 G  disj1_8_19_2
 G  disj2_8_19_2
 G  disj1_9_10_2
 G  disj2_9_10_2
 G  disj1_9_11_2
 G  disj2_9_11_2
 G  disj1_9_12_2
 G  disj2_9_12_2
 G  disj1_9_13_2
 G  disj2_9_13_2
 G  disj1_9_14_2
 G  disj2_9_14_2
 G  disj1_9_15_2
 G  disj2_9_15_2
 G  disj1_9_16_2
 G  disj2_9_16_2
 G  disj1_9_17_2
 G  disj2_9_17_2
 G  disj1_9_18_2
 G  disj2_9_18_2
 G  disj1_9_19_2
 G  disj2_9_19_2
 G  disj1_10_11_2
 G  disj2_10_11_2
 G  disj1_10_12_2
 G  disj2_10_12_2
 G  disj1_10_13_2
 G  disj2_10_13_2
 G  disj1_10_14_2
 G  disj2_10_14_2
 G  disj1_10_15_2
 G  disj2_10_15_2
 G  disj1_10_16_2
 G  disj2_10_16_2
 G  disj1_10_17_2
 G  disj2_10_17_2
 G  disj1_10_18_2
 G  disj2_10_18_2
 G  disj1_10_19_2
 G  disj2_10_19_2
 G  disj1_11_12_2
 G  disj2_11_12_2
 G  disj1_11_13_2
 G  disj2_11_13_2
 G  disj1_11_14_2
 G  disj2_11_14_2
 G  disj1_11_15_2
 G  disj2_11_15_2
 G  disj1_11_16_2
 G  disj2_11_16_2
 G  disj1_11_17_2
 G  disj2_11_17_2
 G  disj1_11_18_2
 G  disj2_11_18_2
 G  disj1_11_19_2
 G  disj2_11_19_2
 G  disj1_12_13_2
 G  disj2_12_13_2
 G  disj1_12_14_2
 G  disj2_12_14_2
 G  disj1_12_15_2
 G  disj2_12_15_2
 G  disj1_12_16_2
 G  disj2_12_16_2
 G  disj1_12_17_2
 G  disj2_12_17_2
 G  disj1_12_18_2
 G  disj2_12_18_2
 G  disj1_12_19_2
 G  disj2_12_19_2
 G  disj1_13_14_2
 G  disj2_13_14_2
 G  disj1_13_15_2
 G  disj2_13_15_2
 G  disj1_13_16_2
 G  disj2_13_16_2
 G  disj1_13_17_2
 G  disj2_13_17_2
 G  disj1_13_18_2
 G  disj2_13_18_2
 G  disj1_13_19_2
 G  disj2_13_19_2
 G  disj1_14_15_2
 G  disj2_14_15_2
 G  disj1_14_16_2
 G  disj2_14_16_2
 G  disj1_14_17_2
 G  disj2_14_17_2
 G  disj1_14_18_2
 G  disj2_14_18_2
 G  disj1_14_19_2
 G  disj2_14_19_2
 G  disj1_15_16_2
 G  disj2_15_16_2
 G  disj1_15_17_2
 G  disj2_15_17_2
 G  disj1_15_18_2
 G  disj2_15_18_2
 G  disj1_15_19_2
 G  disj2_15_19_2
 G  disj1_16_17_2
 G  disj2_16_17_2
 G  disj1_16_18_2
 G  disj2_16_18_2
 G  disj1_16_19_2
 G  disj2_16_19_2
 G  disj1_17_18_2
 G  disj2_17_18_2
 G  disj1_17_19_2
 G  disj2_17_19_2
 G  disj1_18_19_2
 G  disj2_18_19_2
 G  disj1_0_1_3
 G  disj2_0_1_3
 G  disj1_0_2_3
 G  disj2_0_2_3
 G  disj1_0_3_3
 G  disj2_0_3_3
 G  disj1_0_4_3
 G  disj2_0_4_3
 G  disj1_0_5_3
 G  disj2_0_5_3
 G  disj1_0_6_3
 G  disj2_0_6_3
 G  disj1_0_7_3
 G  disj2_0_7_3
 G  disj1_0_8_3
 G  disj2_0_8_3
 G  disj1_0_9_3
 G  disj2_0_9_3
 G  disj1_0_10_3
 G  disj2_0_10_3
 G  disj1_0_11_3
 G  disj2_0_11_3
 G  disj1_0_12_3
 G  disj2_0_12_3
 G  disj1_0_13_3
 G  disj2_0_13_3
 G  disj1_0_14_3
 G  disj2_0_14_3
 G  disj1_0_15_3
 G  disj2_0_15_3
 G  disj1_0_16_3
 G  disj2_0_16_3
 G  disj1_0_17_3
 G  disj2_0_17_3
 G  disj1_0_18_3
 G  disj2_0_18_3
 G  disj1_0_19_3
 G  disj2_0_19_3
 G  disj1_1_2_3
 G  disj2_1_2_3
 G  disj1_1_3_3
 G  disj2_1_3_3
 G  disj1_1_4_3
 G  disj2_1_4_3
 G  disj1_1_5_3
 G  disj2_1_5_3
 G  disj1_1_6_3
 G  disj2_1_6_3
 G  disj1_1_7_3
 G  disj2_1_7_3
 G  disj1_1_8_3
 G  disj2_1_8_3
 G  disj1_1_9_3
 G  disj2_1_9_3
 G  disj1_1_10_3
 G  disj2_1_10_3
 G  disj1_1_11_3
 G  disj2_1_11_3
 G  disj1_1_12_3
 G  disj2_1_12_3
 G  disj1_1_13_3
 G  disj2_1_13_3
 G  disj1_1_14_3
 G  disj2_1_14_3
 G  disj1_1_15_3
 G  disj2_1_15_3
 G  disj1_1_16_3
 G  disj2_1_16_3
 G  disj1_1_17_3
 G  disj2_1_17_3
 G  disj1_1_18_3
 G  disj2_1_18_3
 G  disj1_1_19_3
 G  disj2_1_19_3
 G  disj1_2_3_3
 G  disj2_2_3_3
 G  disj1_2_4_3
 G  disj2_2_4_3
 G  disj1_2_5_3
 G  disj2_2_5_3
 G  disj1_2_6_3
 G  disj2_2_6_3
 G  disj1_2_7_3
 G  disj2_2_7_3
 G  disj1_2_8_3
 G  disj2_2_8_3
 G  disj1_2_9_3
 G  disj2_2_9_3
 G  disj1_2_10_3
 G  disj2_2_10_3
 G  disj1_2_11_3
 G  disj2_2_11_3
 G  disj1_2_12_3
 G  disj2_2_12_3
 G  disj1_2_13_3
 G  disj2_2_13_3
 G  disj1_2_14_3
 G  disj2_2_14_3
 G  disj1_2_15_3
 G  disj2_2_15_3
 G  disj1_2_16_3
 G  disj2_2_16_3
 G  disj1_2_17_3
 G  disj2_2_17_3
 G  disj1_2_18_3
 G  disj2_2_18_3
 G  disj1_2_19_3
 G  disj2_2_19_3
 G  disj1_3_4_3
 G  disj2_3_4_3
 G  disj1_3_5_3
 G  disj2_3_5_3
 G  disj1_3_6_3
 G  disj2_3_6_3
 G  disj1_3_7_3
 G  disj2_3_7_3
 G  disj1_3_8_3
 G  disj2_3_8_3
 G  disj1_3_9_3
 G  disj2_3_9_3
 G  disj1_3_10_3
 G  disj2_3_10_3
 G  disj1_3_11_3
 G  disj2_3_11_3
 G  disj1_3_12_3
 G  disj2_3_12_3
 G  disj1_3_13_3
 G  disj2_3_13_3
 G  disj1_3_14_3
 G  disj2_3_14_3
 G  disj1_3_15_3
 G  disj2_3_15_3
 G  disj1_3_16_3
 G  disj2_3_16_3
 G  disj1_3_17_3
 G  disj2_3_17_3
 G  disj1_3_18_3
 G  disj2_3_18_3
 G  disj1_3_19_3
 G  disj2_3_19_3
 G  disj1_4_5_3
 G  disj2_4_5_3
 G  disj1_4_6_3
 G  disj2_4_6_3
 G  disj1_4_7_3
 G  disj2_4_7_3
 G  disj1_4_8_3
 G  disj2_4_8_3
 G  disj1_4_9_3
 G  disj2_4_9_3
 G  disj1_4_10_3
 G  disj2_4_10_3
 G  disj1_4_11_3
 G  disj2_4_11_3
 G  disj1_4_12_3
 G  disj2_4_12_3
 G  disj1_4_13_3
 G  disj2_4_13_3
 G  disj1_4_14_3
 G  disj2_4_14_3
 G  disj1_4_15_3
 G  disj2_4_15_3
 G  disj1_4_16_3
 G  disj2_4_16_3
 G  disj1_4_17_3
 G  disj2_4_17_3
 G  disj1_4_18_3
 G  disj2_4_18_3
 G  disj1_4_19_3
 G  disj2_4_19_3
 G  disj1_5_6_3
 G  disj2_5_6_3
 G  disj1_5_7_3
 G  disj2_5_7_3
 G  disj1_5_8_3
 G  disj2_5_8_3
 G  disj1_5_9_3
 G  disj2_5_9_3
 G  disj1_5_10_3
 G  disj2_5_10_3
 G  disj1_5_11_3
 G  disj2_5_11_3
 G  disj1_5_12_3
 G  disj2_5_12_3
 G  disj1_5_13_3
 G  disj2_5_13_3
 G  disj1_5_14_3
 G  disj2_5_14_3
 G  disj1_5_15_3
 G  disj2_5_15_3
 G  disj1_5_16_3
 G  disj2_5_16_3
 G  disj1_5_17_3
 G  disj2_5_17_3
 G  disj1_5_18_3
 G  disj2_5_18_3
 G  disj1_5_19_3
 G  disj2_5_19_3
 G  disj1_6_7_3
 G  disj2_6_7_3
 G  disj1_6_8_3
 G  disj2_6_8_3
 G  disj1_6_9_3
 G  disj2_6_9_3
 G  disj1_6_10_3
 G  disj2_6_10_3
 G  disj1_6_11_3
 G  disj2_6_11_3
 G  disj1_6_12_3
 G  disj2_6_12_3
 G  disj1_6_13_3
 G  disj2_6_13_3
 G  disj1_6_14_3
 G  disj2_6_14_3
 G  disj1_6_15_3
 G  disj2_6_15_3
 G  disj1_6_16_3
 G  disj2_6_16_3
 G  disj1_6_17_3
 G  disj2_6_17_3
 G  disj1_6_18_3
 G  disj2_6_18_3
 G  disj1_6_19_3
 G  disj2_6_19_3
 G  disj1_7_8_3
 G  disj2_7_8_3
 G  disj1_7_9_3
 G  disj2_7_9_3
 G  disj1_7_10_3
 G  disj2_7_10_3
 G  disj1_7_11_3
 G  disj2_7_11_3
 G  disj1_7_12_3
 G  disj2_7_12_3
 G  disj1_7_13_3
 G  disj2_7_13_3
 G  disj1_7_14_3
 G  disj2_7_14_3
 G  disj1_7_15_3
 G  disj2_7_15_3
 G  disj1_7_16_3
 G  disj2_7_16_3
 G  disj1_7_17_3
 G  disj2_7_17_3
 G  disj1_7_18_3
 G  disj2_7_18_3
 G  disj1_7_19_3
 G  disj2_7_19_3
 G  disj1_8_9_3
 G  disj2_8_9_3
 G  disj1_8_10_3
 G  disj2_8_10_3
 G  disj1_8_11_3
 G  disj2_8_11_3
 G  disj1_8_12_3
 G  disj2_8_12_3
 G  disj1_8_13_3
 G  disj2_8_13_3
 G  disj1_8_14_3
 G  disj2_8_14_3
 G  disj1_8_15_3
 G  disj2_8_15_3
 G  disj1_8_16_3
 G  disj2_8_16_3
 G  disj1_8_17_3
 G  disj2_8_17_3
 G  disj1_8_18_3
 G  disj2_8_18_3
 G  disj1_8_19_3
 G  disj2_8_19_3
 G  disj1_9_10_3
 G  disj2_9_10_3
 G  disj1_9_11_3
 G  disj2_9_11_3
 G  disj1_9_12_3
 G  disj2_9_12_3
 G  disj1_9_13_3
 G  disj2_9_13_3
 G  disj1_9_14_3
 G  disj2_9_14_3
 G  disj1_9_15_3
 G  disj2_9_15_3
 G  disj1_9_16_3
 G  disj2_9_16_3
 G  disj1_9_17_3
 G  disj2_9_17_3
 G  disj1_9_18_3
 G  disj2_9_18_3
 G  disj1_9_19_3
 G  disj2_9_19_3
 G  disj1_10_11_3
 G  disj2_10_11_3
 G  disj1_10_12_3
 G  disj2_10_12_3
 G  disj1_10_13_3
 G  disj2_10_13_3
 G  disj1_10_14_3
 G  disj2_10_14_3
 G  disj1_10_15_3
 G  disj2_10_15_3
 G  disj1_10_16_3
 G  disj2_10_16_3
 G  disj1_10_17_3
 G  disj2_10_17_3
 G  disj1_10_18_3
 G  disj2_10_18_3
 G  disj1_10_19_3
 G  disj2_10_19_3
 G  disj1_11_12_3
 G  disj2_11_12_3
 G  disj1_11_13_3
 G  disj2_11_13_3
 G  disj1_11_14_3
 G  disj2_11_14_3
 G  disj1_11_15_3
 G  disj2_11_15_3
 G  disj1_11_16_3
 G  disj2_11_16_3
 G  disj1_11_17_3
 G  disj2_11_17_3
 G  disj1_11_18_3
 G  disj2_11_18_3
 G  disj1_11_19_3
 G  disj2_11_19_3
 G  disj1_12_13_3
 G  disj2_12_13_3
 G  disj1_12_14_3
 G  disj2_12_14_3
 G  disj1_12_15_3
 G  disj2_12_15_3
 G  disj1_12_16_3
 G  disj2_12_16_3
 G  disj1_12_17_3
 G  disj2_12_17_3
 G  disj1_12_18_3
 G  disj2_12_18_3
 G  disj1_12_19_3
 G  disj2_12_19_3
 G  disj1_13_14_3
 G  disj2_13_14_3
 G  disj1_13_15_3
 G  disj2_13_15_3
 G  disj1_13_16_3
 G  disj2_13_16_3
 G  disj1_13_17_3
 G  disj2_13_17_3
 G  disj1_13_18_3
 G  disj2_13_18_3
 G  disj1_13_19_3
 G  disj2_13_19_3
 G  disj1_14_15_3
 G  disj2_14_15_3
 G  disj1_14_16_3
 G  disj2_14_16_3
 G  disj1_14_17_3
 G  disj2_14_17_3
 G  disj1_14_18_3
 G  disj2_14_18_3
 G  disj1_14_19_3
 G  disj2_14_19_3
 G  disj1_15_16_3
 G  disj2_15_16_3
 G  disj1_15_17_3
 G  disj2_15_17_3
 G  disj1_15_18_3
 G  disj2_15_18_3
 G  disj1_15_19_3
 G  disj2_15_19_3
 G  disj1_16_17_3
 G  disj2_16_17_3
 G  disj1_16_18_3
 G  disj2_16_18_3
 G  disj1_16_19_3
 G  disj2_16_19_3
 G  disj1_17_18_3
 G  disj2_17_18_3
 G  disj1_17_19_3
 G  disj2_17_19_3
 G  disj1_18_19_3
 G  disj2_18_19_3
 G  disj1_0_1_4
 G  disj2_0_1_4
 G  disj1_0_2_4
 G  disj2_0_2_4
 G  disj1_0_3_4
 G  disj2_0_3_4
 G  disj1_0_4_4
 G  disj2_0_4_4
 G  disj1_0_5_4
 G  disj2_0_5_4
 G  disj1_0_6_4
 G  disj2_0_6_4
 G  disj1_0_7_4
 G  disj2_0_7_4
 G  disj1_0_8_4
 G  disj2_0_8_4
 G  disj1_0_9_4
 G  disj2_0_9_4
 G  disj1_0_10_4
 G  disj2_0_10_4
 G  disj1_0_11_4
 G  disj2_0_11_4
 G  disj1_0_12_4
 G  disj2_0_12_4
 G  disj1_0_13_4
 G  disj2_0_13_4
 G  disj1_0_14_4
 G  disj2_0_14_4
 G  disj1_0_15_4
 G  disj2_0_15_4
 G  disj1_0_16_4
 G  disj2_0_16_4
 G  disj1_0_17_4
 G  disj2_0_17_4
 G  disj1_0_18_4
 G  disj2_0_18_4
 G  disj1_0_19_4
 G  disj2_0_19_4
 G  disj1_1_2_4
 G  disj2_1_2_4
 G  disj1_1_3_4
 G  disj2_1_3_4
 G  disj1_1_4_4
 G  disj2_1_4_4
 G  disj1_1_5_4
 G  disj2_1_5_4
 G  disj1_1_6_4
 G  disj2_1_6_4
 G  disj1_1_7_4
 G  disj2_1_7_4
 G  disj1_1_8_4
 G  disj2_1_8_4
 G  disj1_1_9_4
 G  disj2_1_9_4
 G  disj1_1_10_4
 G  disj2_1_10_4
 G  disj1_1_11_4
 G  disj2_1_11_4
 G  disj1_1_12_4
 G  disj2_1_12_4
 G  disj1_1_13_4
 G  disj2_1_13_4
 G  disj1_1_14_4
 G  disj2_1_14_4
 G  disj1_1_15_4
 G  disj2_1_15_4
 G  disj1_1_16_4
 G  disj2_1_16_4
 G  disj1_1_17_4
 G  disj2_1_17_4
 G  disj1_1_18_4
 G  disj2_1_18_4
 G  disj1_1_19_4
 G  disj2_1_19_4
 G  disj1_2_3_4
 G  disj2_2_3_4
 G  disj1_2_4_4
 G  disj2_2_4_4
 G  disj1_2_5_4
 G  disj2_2_5_4
 G  disj1_2_6_4
 G  disj2_2_6_4
 G  disj1_2_7_4
 G  disj2_2_7_4
 G  disj1_2_8_4
 G  disj2_2_8_4
 G  disj1_2_9_4
 G  disj2_2_9_4
 G  disj1_2_10_4
 G  disj2_2_10_4
 G  disj1_2_11_4
 G  disj2_2_11_4
 G  disj1_2_12_4
 G  disj2_2_12_4
 G  disj1_2_13_4
 G  disj2_2_13_4
 G  disj1_2_14_4
 G  disj2_2_14_4
 G  disj1_2_15_4
 G  disj2_2_15_4
 G  disj1_2_16_4
 G  disj2_2_16_4
 G  disj1_2_17_4
 G  disj2_2_17_4
 G  disj1_2_18_4
 G  disj2_2_18_4
 G  disj1_2_19_4
 G  disj2_2_19_4
 G  disj1_3_4_4
 G  disj2_3_4_4
 G  disj1_3_5_4
 G  disj2_3_5_4
 G  disj1_3_6_4
 G  disj2_3_6_4
 G  disj1_3_7_4
 G  disj2_3_7_4
 G  disj1_3_8_4
 G  disj2_3_8_4
 G  disj1_3_9_4
 G  disj2_3_9_4
 G  disj1_3_10_4
 G  disj2_3_10_4
 G  disj1_3_11_4
 G  disj2_3_11_4
 G  disj1_3_12_4
 G  disj2_3_12_4
 G  disj1_3_13_4
 G  disj2_3_13_4
 G  disj1_3_14_4
 G  disj2_3_14_4
 G  disj1_3_15_4
 G  disj2_3_15_4
 G  disj1_3_16_4
 G  disj2_3_16_4
 G  disj1_3_17_4
 G  disj2_3_17_4
 G  disj1_3_18_4
 G  disj2_3_18_4
 G  disj1_3_19_4
 G  disj2_3_19_4
 G  disj1_4_5_4
 G  disj2_4_5_4
 G  disj1_4_6_4
 G  disj2_4_6_4
 G  disj1_4_7_4
 G  disj2_4_7_4
 G  disj1_4_8_4
 G  disj2_4_8_4
 G  disj1_4_9_4
 G  disj2_4_9_4
 G  disj1_4_10_4
 G  disj2_4_10_4
 G  disj1_4_11_4
 G  disj2_4_11_4
 G  disj1_4_12_4
 G  disj2_4_12_4
 G  disj1_4_13_4
 G  disj2_4_13_4
 G  disj1_4_14_4
 G  disj2_4_14_4
 G  disj1_4_15_4
 G  disj2_4_15_4
 G  disj1_4_16_4
 G  disj2_4_16_4
 G  disj1_4_17_4
 G  disj2_4_17_4
 G  disj1_4_18_4
 G  disj2_4_18_4
 G  disj1_4_19_4
 G  disj2_4_19_4
 G  disj1_5_6_4
 G  disj2_5_6_4
 G  disj1_5_7_4
 G  disj2_5_7_4
 G  disj1_5_8_4
 G  disj2_5_8_4
 G  disj1_5_9_4
 G  disj2_5_9_4
 G  disj1_5_10_4
 G  disj2_5_10_4
 G  disj1_5_11_4
 G  disj2_5_11_4
 G  disj1_5_12_4
 G  disj2_5_12_4
 G  disj1_5_13_4
 G  disj2_5_13_4
 G  disj1_5_14_4
 G  disj2_5_14_4
 G  disj1_5_15_4
 G  disj2_5_15_4
 G  disj1_5_16_4
 G  disj2_5_16_4
 G  disj1_5_17_4
 G  disj2_5_17_4
 G  disj1_5_18_4
 G  disj2_5_18_4
 G  disj1_5_19_4
 G  disj2_5_19_4
 G  disj1_6_7_4
 G  disj2_6_7_4
 G  disj1_6_8_4
 G  disj2_6_8_4
 G  disj1_6_9_4
 G  disj2_6_9_4
 G  disj1_6_10_4
 G  disj2_6_10_4
 G  disj1_6_11_4
 G  disj2_6_11_4
 G  disj1_6_12_4
 G  disj2_6_12_4
 G  disj1_6_13_4
 G  disj2_6_13_4
 G  disj1_6_14_4
 G  disj2_6_14_4
 G  disj1_6_15_4
 G  disj2_6_15_4
 G  disj1_6_16_4
 G  disj2_6_16_4
 G  disj1_6_17_4
 G  disj2_6_17_4
 G  disj1_6_18_4
 G  disj2_6_18_4
 G  disj1_6_19_4
 G  disj2_6_19_4
 G  disj1_7_8_4
 G  disj2_7_8_4
 G  disj1_7_9_4
 G  disj2_7_9_4
 G  disj1_7_10_4
 G  disj2_7_10_4
 G  disj1_7_11_4
 G  disj2_7_11_4
 G  disj1_7_12_4
 G  disj2_7_12_4
 G  disj1_7_13_4
 G  disj2_7_13_4
 G  disj1_7_14_4
 G  disj2_7_14_4
 G  disj1_7_15_4
 G  disj2_7_15_4
 G  disj1_7_16_4
 G  disj2_7_16_4
 G  disj1_7_17_4
 G  disj2_7_17_4
 G  disj1_7_18_4
 G  disj2_7_18_4
 G  disj1_7_19_4
 G  disj2_7_19_4
 G  disj1_8_9_4
 G  disj2_8_9_4
 G  disj1_8_10_4
 G  disj2_8_10_4
 G  disj1_8_11_4
 G  disj2_8_11_4
 G  disj1_8_12_4
 G  disj2_8_12_4
 G  disj1_8_13_4
 G  disj2_8_13_4
 G  disj1_8_14_4
 G  disj2_8_14_4
 G  disj1_8_15_4
 G  disj2_8_15_4
 G  disj1_8_16_4
 G  disj2_8_16_4
 G  disj1_8_17_4
 G  disj2_8_17_4
 G  disj1_8_18_4
 G  disj2_8_18_4
 G  disj1_8_19_4
 G  disj2_8_19_4
 G  disj1_9_10_4
 G  disj2_9_10_4
 G  disj1_9_11_4
 G  disj2_9_11_4
 G  disj1_9_12_4
 G  disj2_9_12_4
 G  disj1_9_13_4
 G  disj2_9_13_4
 G  disj1_9_14_4
 G  disj2_9_14_4
 G  disj1_9_15_4
 G  disj2_9_15_4
 G  disj1_9_16_4
 G  disj2_9_16_4
 G  disj1_9_17_4
 G  disj2_9_17_4
 G  disj1_9_18_4
 G  disj2_9_18_4
 G  disj1_9_19_4
 G  disj2_9_19_4
 G  disj1_10_11_4
 G  disj2_10_11_4
 G  disj1_10_12_4
 G  disj2_10_12_4
 G  disj1_10_13_4
 G  disj2_10_13_4
 G  disj1_10_14_4
 G  disj2_10_14_4
 G  disj1_10_15_4
 G  disj2_10_15_4
 G  disj1_10_16_4
 G  disj2_10_16_4
 G  disj1_10_17_4
 G  disj2_10_17_4
 G  disj1_10_18_4
 G  disj2_10_18_4
 G  disj1_10_19_4
 G  disj2_10_19_4
 G  disj1_11_12_4
 G  disj2_11_12_4
 G  disj1_11_13_4
 G  disj2_11_13_4
 G  disj1_11_14_4
 G  disj2_11_14_4
 G  disj1_11_15_4
 G  disj2_11_15_4
 G  disj1_11_16_4
 G  disj2_11_16_4
 G  disj1_11_17_4
 G  disj2_11_17_4
 G  disj1_11_18_4
 G  disj2_11_18_4
 G  disj1_11_19_4
 G  disj2_11_19_4
 G  disj1_12_13_4
 G  disj2_12_13_4
 G  disj1_12_14_4
 G  disj2_12_14_4
 G  disj1_12_15_4
 G  disj2_12_15_4
 G  disj1_12_16_4
 G  disj2_12_16_4
 G  disj1_12_17_4
 G  disj2_12_17_4
 G  disj1_12_18_4
 G  disj2_12_18_4
 G  disj1_12_19_4
 G  disj2_12_19_4
 G  disj1_13_14_4
 G  disj2_13_14_4
 G  disj1_13_15_4
 G  disj2_13_15_4
 G  disj1_13_16_4
 G  disj2_13_16_4
 G  disj1_13_17_4
 G  disj2_13_17_4
 G  disj1_13_18_4
 G  disj2_13_18_4
 G  disj1_13_19_4
 G  disj2_13_19_4
 G  disj1_14_15_4
 G  disj2_14_15_4
 G  disj1_14_16_4
 G  disj2_14_16_4
 G  disj1_14_17_4
 G  disj2_14_17_4
 G  disj1_14_18_4
 G  disj2_14_18_4
 G  disj1_14_19_4
 G  disj2_14_19_4
 G  disj1_15_16_4
 G  disj2_15_16_4
 G  disj1_15_17_4
 G  disj2_15_17_4
 G  disj1_15_18_4
 G  disj2_15_18_4
 G  disj1_15_19_4
 G  disj2_15_19_4
 G  disj1_16_17_4
 G  disj2_16_17_4
 G  disj1_16_18_4
 G  disj2_16_18_4
 G  disj1_16_19_4
 G  disj2_16_19_4
 G  disj1_17_18_4
 G  disj2_17_18_4
 G  disj1_17_19_4
 G  disj2_17_19_4
 G  disj1_18_19_4
 G  disj2_18_19_4
COLUMNS
    C         OBJ       1.0
    C         mksp_0    1.0
    C         mksp_1    1.0
    C         mksp_2    1.0
    C         mksp_3    1.0
    C         mksp_4    1.0
    C         mksp_5    1.0
    C         mksp_6    1.0
    C         mksp_7    1.0
    C         mksp_8    1.0
    C         mksp_9    1.0
    C         mksp_10   1.0
    C         mksp_11   1.0
    C         mksp_12   1.0
    C         mksp_13   1.0
    C         mksp_14   1.0
    C         mksp_15   1.0
    C         mksp_16   1.0
    C         mksp_17   1.0
    C         mksp_18   1.0
    C         mksp_19   1.0
    x_0_0     prec_0_0  -1.0
    x_0_0     disj1_0_1_3  -1.0
    x_0_0     disj2_0_1_3  1.0
    x_0_0     disj1_0_2_3  -1.0
    x_0_0     disj2_0_2_3  1.0
    x_0_0     disj1_0_3_3  -1.0
    x_0_0     disj2_0_3_3  1.0
    x_0_0     disj1_0_4_3  -1.0
    x_0_0     disj2_0_4_3  1.0
    x_0_0     disj1_0_5_3  -1.0
    x_0_0     disj2_0_5_3  1.0
    x_0_0     disj1_0_6_3  -1.0
    x_0_0     disj2_0_6_3  1.0
    x_0_0     disj1_0_7_3  -1.0
    x_0_0     disj2_0_7_3  1.0
    x_0_0     disj1_0_8_3  -1.0
    x_0_0     disj2_0_8_3  1.0
    x_0_0     disj1_0_9_3  -1.0
    x_0_0     disj2_0_9_3  1.0
    x_0_0     disj1_0_10_3  -1.0
    x_0_0     disj2_0_10_3  1.0
    x_0_0     disj1_0_11_3  -1.0
    x_0_0     disj2_0_11_3  1.0
    x_0_0     disj1_0_12_3  -1.0
    x_0_0     disj2_0_12_3  1.0
    x_0_0     disj1_0_13_3  -1.0
    x_0_0     disj2_0_13_3  1.0
    x_0_0     disj1_0_14_3  -1.0
    x_0_0     disj2_0_14_3  1.0
    x_0_0     disj1_0_15_3  -1.0
    x_0_0     disj2_0_15_3  1.0
    x_0_0     disj1_0_16_3  -1.0
    x_0_0     disj2_0_16_3  1.0
    x_0_0     disj1_0_17_3  -1.0
    x_0_0     disj2_0_17_3  1.0
    x_0_0     disj1_0_18_3  -1.0
    x_0_0     disj2_0_18_3  1.0
    x_0_0     disj1_0_19_3  -1.0
    x_0_0     disj2_0_19_3  1.0
    x_0_1     prec_0_0  1.0
    x_0_1     prec_0_1  -1.0
    x_0_1     disj1_0_1_4  -1.0
    x_0_1     disj2_0_1_4  1.0
    x_0_1     disj1_0_2_4  -1.0
    x_0_1     disj2_0_2_4  1.0
    x_0_1     disj1_0_3_4  -1.0
    x_0_1     disj2_0_3_4  1.0
    x_0_1     disj1_0_4_4  -1.0
    x_0_1     disj2_0_4_4  1.0
    x_0_1     disj1_0_5_4  -1.0
    x_0_1     disj2_0_5_4  1.0
    x_0_1     disj1_0_6_4  -1.0
    x_0_1     disj2_0_6_4  1.0
    x_0_1     disj1_0_7_4  -1.0
    x_0_1     disj2_0_7_4  1.0
    x_0_1     disj1_0_8_4  -1.0
    x_0_1     disj2_0_8_4  1.0
    x_0_1     disj1_0_9_4  -1.0
    x_0_1     disj2_0_9_4  1.0
    x_0_1     disj1_0_10_4  -1.0
    x_0_1     disj2_0_10_4  1.0
    x_0_1     disj1_0_11_4  -1.0
    x_0_1     disj2_0_11_4  1.0
    x_0_1     disj1_0_12_4  -1.0
    x_0_1     disj2_0_12_4  1.0
    x_0_1     disj1_0_13_4  -1.0
    x_0_1     disj2_0_13_4  1.0
    x_0_1     disj1_0_14_4  -1.0
    x_0_1     disj2_0_14_4  1.0
    x_0_1     disj1_0_15_4  -1.0
    x_0_1     disj2_0_15_4  1.0
    x_0_1     disj1_0_16_4  -1.0
    x_0_1     disj2_0_16_4  1.0
    x_0_1     disj1_0_17_4  -1.0
    x_0_1     disj2_0_17_4  1.0
    x_0_1     disj1_0_18_4  -1.0
    x_0_1     disj2_0_18_4  1.0
    x_0_1     disj1_0_19_4  -1.0
    x_0_1     disj2_0_19_4  1.0
    x_0_2     prec_0_1  1.0
    x_0_2     prec_0_2  -1.0
    x_0_2     disj1_0_1_0  -1.0
    x_0_2     disj2_0_1_0  1.0
    x_0_2     disj1_0_2_0  -1.0
    x_0_2     disj2_0_2_0  1.0
    x_0_2     disj1_0_3_0  -1.0
    x_0_2     disj2_0_3_0  1.0
    x_0_2     disj1_0_4_0  -1.0
    x_0_2     disj2_0_4_0  1.0
    x_0_2     disj1_0_5_0  -1.0
    x_0_2     disj2_0_5_0  1.0
    x_0_2     disj1_0_6_0  -1.0
    x_0_2     disj2_0_6_0  1.0
    x_0_2     disj1_0_7_0  -1.0
    x_0_2     disj2_0_7_0  1.0
    x_0_2     disj1_0_8_0  -1.0
    x_0_2     disj2_0_8_0  1.0
    x_0_2     disj1_0_9_0  -1.0
    x_0_2     disj2_0_9_0  1.0
    x_0_2     disj1_0_10_0  -1.0
    x_0_2     disj2_0_10_0  1.0
    x_0_2     disj1_0_11_0  -1.0
    x_0_2     disj2_0_11_0  1.0
    x_0_2     disj1_0_12_0  -1.0
    x_0_2     disj2_0_12_0  1.0
    x_0_2     disj1_0_13_0  -1.0
    x_0_2     disj2_0_13_0  1.0
    x_0_2     disj1_0_14_0  -1.0
    x_0_2     disj2_0_14_0  1.0
    x_0_2     disj1_0_15_0  -1.0
    x_0_2     disj2_0_15_0  1.0
    x_0_2     disj1_0_16_0  -1.0
    x_0_2     disj2_0_16_0  1.0
    x_0_2     disj1_0_17_0  -1.0
    x_0_2     disj2_0_17_0  1.0
    x_0_2     disj1_0_18_0  -1.0
    x_0_2     disj2_0_18_0  1.0
    x_0_2     disj1_0_19_0  -1.0
    x_0_2     disj2_0_19_0  1.0
    x_0_3     prec_0_2  1.0
    x_0_3     prec_0_3  -1.0
    x_0_3     disj1_0_1_1  -1.0
    x_0_3     disj2_0_1_1  1.0
    x_0_3     disj1_0_2_1  -1.0
    x_0_3     disj2_0_2_1  1.0
    x_0_3     disj1_0_3_1  -1.0
    x_0_3     disj2_0_3_1  1.0
    x_0_3     disj1_0_4_1  -1.0
    x_0_3     disj2_0_4_1  1.0
    x_0_3     disj1_0_5_1  -1.0
    x_0_3     disj2_0_5_1  1.0
    x_0_3     disj1_0_6_1  -1.0
    x_0_3     disj2_0_6_1  1.0
    x_0_3     disj1_0_7_1  -1.0
    x_0_3     disj2_0_7_1  1.0
    x_0_3     disj1_0_8_1  -1.0
    x_0_3     disj2_0_8_1  1.0
    x_0_3     disj1_0_9_1  -1.0
    x_0_3     disj2_0_9_1  1.0
    x_0_3     disj1_0_10_1  -1.0
    x_0_3     disj2_0_10_1  1.0
    x_0_3     disj1_0_11_1  -1.0
    x_0_3     disj2_0_11_1  1.0
    x_0_3     disj1_0_12_1  -1.0
    x_0_3     disj2_0_12_1  1.0
    x_0_3     disj1_0_13_1  -1.0
    x_0_3     disj2_0_13_1  1.0
    x_0_3     disj1_0_14_1  -1.0
    x_0_3     disj2_0_14_1  1.0
    x_0_3     disj1_0_15_1  -1.0
    x_0_3     disj2_0_15_1  1.0
    x_0_3     disj1_0_16_1  -1.0
    x_0_3     disj2_0_16_1  1.0
    x_0_3     disj1_0_17_1  -1.0
    x_0_3     disj2_0_17_1  1.0
    x_0_3     disj1_0_18_1  -1.0
    x_0_3     disj2_0_18_1  1.0
    x_0_3     disj1_0_19_1  -1.0
    x_0_3     disj2_0_19_1  1.0
    x_0_4     prec_0_3  1.0
    x_0_4     mksp_0    -1.0
    x_0_4     disj1_0_1_2  -1.0
    x_0_4     disj2_0_1_2  1.0
    x_0_4     disj1_0_2_2  -1.0
    x_0_4     disj2_0_2_2  1.0
    x_0_4     disj1_0_3_2  -1.0
    x_0_4     disj2_0_3_2  1.0
    x_0_4     disj1_0_4_2  -1.0
    x_0_4     disj2_0_4_2  1.0
    x_0_4     disj1_0_5_2  -1.0
    x_0_4     disj2_0_5_2  1.0
    x_0_4     disj1_0_6_2  -1.0
    x_0_4     disj2_0_6_2  1.0
    x_0_4     disj1_0_7_2  -1.0
    x_0_4     disj2_0_7_2  1.0
    x_0_4     disj1_0_8_2  -1.0
    x_0_4     disj2_0_8_2  1.0
    x_0_4     disj1_0_9_2  -1.0
    x_0_4     disj2_0_9_2  1.0
    x_0_4     disj1_0_10_2  -1.0
    x_0_4     disj2_0_10_2  1.0
    x_0_4     disj1_0_11_2  -1.0
    x_0_4     disj2_0_11_2  1.0
    x_0_4     disj1_0_12_2  -1.0
    x_0_4     disj2_0_12_2  1.0
    x_0_4     disj1_0_13_2  -1.0
    x_0_4     disj2_0_13_2  1.0
    x_0_4     disj1_0_14_2  -1.0
    x_0_4     disj2_0_14_2  1.0
    x_0_4     disj1_0_15_2  -1.0
    x_0_4     disj2_0_15_2  1.0
    x_0_4     disj1_0_16_2  -1.0
    x_0_4     disj2_0_16_2  1.0
    x_0_4     disj1_0_17_2  -1.0
    x_0_4     disj2_0_17_2  1.0
    x_0_4     disj1_0_18_2  -1.0
    x_0_4     disj2_0_18_2  1.0
    x_0_4     disj1_0_19_2  -1.0
    x_0_4     disj2_0_19_2  1.0
    x_1_0     prec_1_0  -1.0
    x_1_0     disj1_0_1_1  1.0
    x_1_0     disj2_0_1_1  -1.0
    x_1_0     disj1_1_2_1  -1.0
    x_1_0     disj2_1_2_1  1.0
    x_1_0     disj1_1_3_1  -1.0
    x_1_0     disj2_1_3_1  1.0
    x_1_0     disj1_1_4_1  -1.0
    x_1_0     disj2_1_4_1  1.0
    x_1_0     disj1_1_5_1  -1.0
    x_1_0     disj2_1_5_1  1.0
    x_1_0     disj1_1_6_1  -1.0
    x_1_0     disj2_1_6_1  1.0
    x_1_0     disj1_1_7_1  -1.0
    x_1_0     disj2_1_7_1  1.0
    x_1_0     disj1_1_8_1  -1.0
    x_1_0     disj2_1_8_1  1.0
    x_1_0     disj1_1_9_1  -1.0
    x_1_0     disj2_1_9_1  1.0
    x_1_0     disj1_1_10_1  -1.0
    x_1_0     disj2_1_10_1  1.0
    x_1_0     disj1_1_11_1  -1.0
    x_1_0     disj2_1_11_1  1.0
    x_1_0     disj1_1_12_1  -1.0
    x_1_0     disj2_1_12_1  1.0
    x_1_0     disj1_1_13_1  -1.0
    x_1_0     disj2_1_13_1  1.0
    x_1_0     disj1_1_14_1  -1.0
    x_1_0     disj2_1_14_1  1.0
    x_1_0     disj1_1_15_1  -1.0
    x_1_0     disj2_1_15_1  1.0
    x_1_0     disj1_1_16_1  -1.0
    x_1_0     disj2_1_16_1  1.0
    x_1_0     disj1_1_17_1  -1.0
    x_1_0     disj2_1_17_1  1.0
    x_1_0     disj1_1_18_1  -1.0
    x_1_0     disj2_1_18_1  1.0
    x_1_0     disj1_1_19_1  -1.0
    x_1_0     disj2_1_19_1  1.0
    x_1_1     prec_1_0  1.0
    x_1_1     prec_1_1  -1.0
    x_1_1     disj1_0_1_4  1.0
    x_1_1     disj2_0_1_4  -1.0
    x_1_1     disj1_1_2_4  -1.0
    x_1_1     disj2_1_2_4  1.0
    x_1_1     disj1_1_3_4  -1.0
    x_1_1     disj2_1_3_4  1.0
    x_1_1     disj1_1_4_4  -1.0
    x_1_1     disj2_1_4_4  1.0
    x_1_1     disj1_1_5_4  -1.0
    x_1_1     disj2_1_5_4  1.0
    x_1_1     disj1_1_6_4  -1.0
    x_1_1     disj2_1_6_4  1.0
    x_1_1     disj1_1_7_4  -1.0
    x_1_1     disj2_1_7_4  1.0
    x_1_1     disj1_1_8_4  -1.0
    x_1_1     disj2_1_8_4  1.0
    x_1_1     disj1_1_9_4  -1.0
    x_1_1     disj2_1_9_4  1.0
    x_1_1     disj1_1_10_4  -1.0
    x_1_1     disj2_1_10_4  1.0
    x_1_1     disj1_1_11_4  -1.0
    x_1_1     disj2_1_11_4  1.0
    x_1_1     disj1_1_12_4  -1.0
    x_1_1     disj2_1_12_4  1.0
    x_1_1     disj1_1_13_4  -1.0
    x_1_1     disj2_1_13_4  1.0
    x_1_1     disj1_1_14_4  -1.0
    x_1_1     disj2_1_14_4  1.0
    x_1_1     disj1_1_15_4  -1.0
    x_1_1     disj2_1_15_4  1.0
    x_1_1     disj1_1_16_4  -1.0
    x_1_1     disj2_1_16_4  1.0
    x_1_1     disj1_1_17_4  -1.0
    x_1_1     disj2_1_17_4  1.0
    x_1_1     disj1_1_18_4  -1.0
    x_1_1     disj2_1_18_4  1.0
    x_1_1     disj1_1_19_4  -1.0
    x_1_1     disj2_1_19_4  1.0
    x_1_2     prec_1_1  1.0
    x_1_2     prec_1_2  -1.0
    x_1_2     disj1_0_1_2  1.0
    x_1_2     disj2_0_1_2  -1.0
    x_1_2     disj1_1_2_2  -1.0
    x_1_2     disj2_1_2_2  1.0
    x_1_2     disj1_1_3_2  -1.0
    x_1_2     disj2_1_3_2  1.0
    x_1_2     disj1_1_4_2  -1.0
    x_1_2     disj2_1_4_2  1.0
    x_1_2     disj1_1_5_2  -1.0
    x_1_2     disj2_1_5_2  1.0
    x_1_2     disj1_1_6_2  -1.0
    x_1_2     disj2_1_6_2  1.0
    x_1_2     disj1_1_7_2  -1.0
    x_1_2     disj2_1_7_2  1.0
    x_1_2     disj1_1_8_2  -1.0
    x_1_2     disj2_1_8_2  1.0
    x_1_2     disj1_1_9_2  -1.0
    x_1_2     disj2_1_9_2  1.0
    x_1_2     disj1_1_10_2  -1.0
    x_1_2     disj2_1_10_2  1.0
    x_1_2     disj1_1_11_2  -1.0
    x_1_2     disj2_1_11_2  1.0
    x_1_2     disj1_1_12_2  -1.0
    x_1_2     disj2_1_12_2  1.0
    x_1_2     disj1_1_13_2  -1.0
    x_1_2     disj2_1_13_2  1.0
    x_1_2     disj1_1_14_2  -1.0
    x_1_2     disj2_1_14_2  1.0
    x_1_2     disj1_1_15_2  -1.0
    x_1_2     disj2_1_15_2  1.0
    x_1_2     disj1_1_16_2  -1.0
    x_1_2     disj2_1_16_2  1.0
    x_1_2     disj1_1_17_2  -1.0
    x_1_2     disj2_1_17_2  1.0
    x_1_2     disj1_1_18_2  -1.0
    x_1_2     disj2_1_18_2  1.0
    x_1_2     disj1_1_19_2  -1.0
    x_1_2     disj2_1_19_2  1.0
    x_1_3     prec_1_2  1.0
    x_1_3     prec_1_3  -1.0
    x_1_3     disj1_0_1_0  1.0
    x_1_3     disj2_0_1_0  -1.0
    x_1_3     disj1_1_2_0  -1.0
    x_1_3     disj2_1_2_0  1.0
    x_1_3     disj1_1_3_0  -1.0
    x_1_3     disj2_1_3_0  1.0
    x_1_3     disj1_1_4_0  -1.0
    x_1_3     disj2_1_4_0  1.0
    x_1_3     disj1_1_5_0  -1.0
    x_1_3     disj2_1_5_0  1.0
    x_1_3     disj1_1_6_0  -1.0
    x_1_3     disj2_1_6_0  1.0
    x_1_3     disj1_1_7_0  -1.0
    x_1_3     disj2_1_7_0  1.0
    x_1_3     disj1_1_8_0  -1.0
    x_1_3     disj2_1_8_0  1.0
    x_1_3     disj1_1_9_0  -1.0
    x_1_3     disj2_1_9_0  1.0
    x_1_3     disj1_1_10_0  -1.0
    x_1_3     disj2_1_10_0  1.0
    x_1_3     disj1_1_11_0  -1.0
    x_1_3     disj2_1_11_0  1.0
    x_1_3     disj1_1_12_0  -1.0
    x_1_3     disj2_1_12_0  1.0
    x_1_3     disj1_1_13_0  -1.0
    x_1_3     disj2_1_13_0  1.0
    x_1_3     disj1_1_14_0  -1.0
    x_1_3     disj2_1_14_0  1.0
    x_1_3     disj1_1_15_0  -1.0
    x_1_3     disj2_1_15_0  1.0
    x_1_3     disj1_1_16_0  -1.0
    x_1_3     disj2_1_16_0  1.0
    x_1_3     disj1_1_17_0  -1.0
    x_1_3     disj2_1_17_0  1.0
    x_1_3     disj1_1_18_0  -1.0
    x_1_3     disj2_1_18_0  1.0
    x_1_3     disj1_1_19_0  -1.0
    x_1_3     disj2_1_19_0  1.0
    x_1_4     prec_1_3  1.0
    x_1_4     mksp_1    -1.0
    x_1_4     disj1_0_1_3  1.0
    x_1_4     disj2_0_1_3  -1.0
    x_1_4     disj1_1_2_3  -1.0
    x_1_4     disj2_1_2_3  1.0
    x_1_4     disj1_1_3_3  -1.0
    x_1_4     disj2_1_3_3  1.0
    x_1_4     disj1_1_4_3  -1.0
    x_1_4     disj2_1_4_3  1.0
    x_1_4     disj1_1_5_3  -1.0
    x_1_4     disj2_1_5_3  1.0
    x_1_4     disj1_1_6_3  -1.0
    x_1_4     disj2_1_6_3  1.0
    x_1_4     disj1_1_7_3  -1.0
    x_1_4     disj2_1_7_3  1.0
    x_1_4     disj1_1_8_3  -1.0
    x_1_4     disj2_1_8_3  1.0
    x_1_4     disj1_1_9_3  -1.0
    x_1_4     disj2_1_9_3  1.0
    x_1_4     disj1_1_10_3  -1.0
    x_1_4     disj2_1_10_3  1.0
    x_1_4     disj1_1_11_3  -1.0
    x_1_4     disj2_1_11_3  1.0
    x_1_4     disj1_1_12_3  -1.0
    x_1_4     disj2_1_12_3  1.0
    x_1_4     disj1_1_13_3  -1.0
    x_1_4     disj2_1_13_3  1.0
    x_1_4     disj1_1_14_3  -1.0
    x_1_4     disj2_1_14_3  1.0
    x_1_4     disj1_1_15_3  -1.0
    x_1_4     disj2_1_15_3  1.0
    x_1_4     disj1_1_16_3  -1.0
    x_1_4     disj2_1_16_3  1.0
    x_1_4     disj1_1_17_3  -1.0
    x_1_4     disj2_1_17_3  1.0
    x_1_4     disj1_1_18_3  -1.0
    x_1_4     disj2_1_18_3  1.0
    x_1_4     disj1_1_19_3  -1.0
    x_1_4     disj2_1_19_3  1.0
    x_2_0     prec_2_0  -1.0
    x_2_0     disj1_0_2_0  1.0
    x_2_0     disj2_0_2_0  -1.0
    x_2_0     disj1_1_2_0  1.0
    x_2_0     disj2_1_2_0  -1.0
    x_2_0     disj1_2_3_0  -1.0
    x_2_0     disj2_2_3_0  1.0
    x_2_0     disj1_2_4_0  -1.0
    x_2_0     disj2_2_4_0  1.0
    x_2_0     disj1_2_5_0  -1.0
    x_2_0     disj2_2_5_0  1.0
    x_2_0     disj1_2_6_0  -1.0
    x_2_0     disj2_2_6_0  1.0
    x_2_0     disj1_2_7_0  -1.0
    x_2_0     disj2_2_7_0  1.0
    x_2_0     disj1_2_8_0  -1.0
    x_2_0     disj2_2_8_0  1.0
    x_2_0     disj1_2_9_0  -1.0
    x_2_0     disj2_2_9_0  1.0
    x_2_0     disj1_2_10_0  -1.0
    x_2_0     disj2_2_10_0  1.0
    x_2_0     disj1_2_11_0  -1.0
    x_2_0     disj2_2_11_0  1.0
    x_2_0     disj1_2_12_0  -1.0
    x_2_0     disj2_2_12_0  1.0
    x_2_0     disj1_2_13_0  -1.0
    x_2_0     disj2_2_13_0  1.0
    x_2_0     disj1_2_14_0  -1.0
    x_2_0     disj2_2_14_0  1.0
    x_2_0     disj1_2_15_0  -1.0
    x_2_0     disj2_2_15_0  1.0
    x_2_0     disj1_2_16_0  -1.0
    x_2_0     disj2_2_16_0  1.0
    x_2_0     disj1_2_17_0  -1.0
    x_2_0     disj2_2_17_0  1.0
    x_2_0     disj1_2_18_0  -1.0
    x_2_0     disj2_2_18_0  1.0
    x_2_0     disj1_2_19_0  -1.0
    x_2_0     disj2_2_19_0  1.0
    x_2_1     prec_2_0  1.0
    x_2_1     prec_2_1  -1.0
    x_2_1     disj1_0_2_3  1.0
    x_2_1     disj2_0_2_3  -1.0
    x_2_1     disj1_1_2_3  1.0
    x_2_1     disj2_1_2_3  -1.0
    x_2_1     disj1_2_3_3  -1.0
    x_2_1     disj2_2_3_3  1.0
    x_2_1     disj1_2_4_3  -1.0
    x_2_1     disj2_2_4_3  1.0
    x_2_1     disj1_2_5_3  -1.0
    x_2_1     disj2_2_5_3  1.0
    x_2_1     disj1_2_6_3  -1.0
    x_2_1     disj2_2_6_3  1.0
    x_2_1     disj1_2_7_3  -1.0
    x_2_1     disj2_2_7_3  1.0
    x_2_1     disj1_2_8_3  -1.0
    x_2_1     disj2_2_8_3  1.0
    x_2_1     disj1_2_9_3  -1.0
    x_2_1     disj2_2_9_3  1.0
    x_2_1     disj1_2_10_3  -1.0
    x_2_1     disj2_2_10_3  1.0
    x_2_1     disj1_2_11_3  -1.0
    x_2_1     disj2_2_11_3  1.0
    x_2_1     disj1_2_12_3  -1.0
    x_2_1     disj2_2_12_3  1.0
    x_2_1     disj1_2_13_3  -1.0
    x_2_1     disj2_2_13_3  1.0
    x_2_1     disj1_2_14_3  -1.0
    x_2_1     disj2_2_14_3  1.0
    x_2_1     disj1_2_15_3  -1.0
    x_2_1     disj2_2_15_3  1.0
    x_2_1     disj1_2_16_3  -1.0
    x_2_1     disj2_2_16_3  1.0
    x_2_1     disj1_2_17_3  -1.0
    x_2_1     disj2_2_17_3  1.0
    x_2_1     disj1_2_18_3  -1.0
    x_2_1     disj2_2_18_3  1.0
    x_2_1     disj1_2_19_3  -1.0
    x_2_1     disj2_2_19_3  1.0
    x_2_2     prec_2_1  1.0
    x_2_2     prec_2_2  -1.0
    x_2_2     disj1_0_2_1  1.0
    x_2_2     disj2_0_2_1  -1.0
    x_2_2     disj1_1_2_1  1.0
    x_2_2     disj2_1_2_1  -1.0
    x_2_2     disj1_2_3_1  -1.0
    x_2_2     disj2_2_3_1  1.0
    x_2_2     disj1_2_4_1  -1.0
    x_2_2     disj2_2_4_1  1.0
    x_2_2     disj1_2_5_1  -1.0
    x_2_2     disj2_2_5_1  1.0
    x_2_2     disj1_2_6_1  -1.0
    x_2_2     disj2_2_6_1  1.0
    x_2_2     disj1_2_7_1  -1.0
    x_2_2     disj2_2_7_1  1.0
    x_2_2     disj1_2_8_1  -1.0
    x_2_2     disj2_2_8_1  1.0
    x_2_2     disj1_2_9_1  -1.0
    x_2_2     disj2_2_9_1  1.0
    x_2_2     disj1_2_10_1  -1.0
    x_2_2     disj2_2_10_1  1.0
    x_2_2     disj1_2_11_1  -1.0
    x_2_2     disj2_2_11_1  1.0
    x_2_2     disj1_2_12_1  -1.0
    x_2_2     disj2_2_12_1  1.0
    x_2_2     disj1_2_13_1  -1.0
    x_2_2     disj2_2_13_1  1.0
    x_2_2     disj1_2_14_1  -1.0
    x_2_2     disj2_2_14_1  1.0
    x_2_2     disj1_2_15_1  -1.0
    x_2_2     disj2_2_15_1  1.0
    x_2_2     disj1_2_16_1  -1.0
    x_2_2     disj2_2_16_1  1.0
    x_2_2     disj1_2_17_1  -1.0
    x_2_2     disj2_2_17_1  1.0
    x_2_2     disj1_2_18_1  -1.0
    x_2_2     disj2_2_18_1  1.0
    x_2_2     disj1_2_19_1  -1.0
    x_2_2     disj2_2_19_1  1.0
    x_2_3     prec_2_2  1.0
    x_2_3     prec_2_3  -1.0
    x_2_3     disj1_0_2_4  1.0
    x_2_3     disj2_0_2_4  -1.0
    x_2_3     disj1_1_2_4  1.0
    x_2_3     disj2_1_2_4  -1.0
    x_2_3     disj1_2_3_4  -1.0
    x_2_3     disj2_2_3_4  1.0
    x_2_3     disj1_2_4_4  -1.0
    x_2_3     disj2_2_4_4  1.0
    x_2_3     disj1_2_5_4  -1.0
    x_2_3     disj2_2_5_4  1.0
    x_2_3     disj1_2_6_4  -1.0
    x_2_3     disj2_2_6_4  1.0
    x_2_3     disj1_2_7_4  -1.0
    x_2_3     disj2_2_7_4  1.0
    x_2_3     disj1_2_8_4  -1.0
    x_2_3     disj2_2_8_4  1.0
    x_2_3     disj1_2_9_4  -1.0
    x_2_3     disj2_2_9_4  1.0
    x_2_3     disj1_2_10_4  -1.0
    x_2_3     disj2_2_10_4  1.0
    x_2_3     disj1_2_11_4  -1.0
    x_2_3     disj2_2_11_4  1.0
    x_2_3     disj1_2_12_4  -1.0
    x_2_3     disj2_2_12_4  1.0
    x_2_3     disj1_2_13_4  -1.0
    x_2_3     disj2_2_13_4  1.0
    x_2_3     disj1_2_14_4  -1.0
    x_2_3     disj2_2_14_4  1.0
    x_2_3     disj1_2_15_4  -1.0
    x_2_3     disj2_2_15_4  1.0
    x_2_3     disj1_2_16_4  -1.0
    x_2_3     disj2_2_16_4  1.0
    x_2_3     disj1_2_17_4  -1.0
    x_2_3     disj2_2_17_4  1.0
    x_2_3     disj1_2_18_4  -1.0
    x_2_3     disj2_2_18_4  1.0
    x_2_3     disj1_2_19_4  -1.0
    x_2_3     disj2_2_19_4  1.0
    x_2_4     prec_2_3  1.0
    x_2_4     mksp_2    -1.0
    x_2_4     disj1_0_2_2  1.0
    x_2_4     disj2_0_2_2  -1.0
    x_2_4     disj1_1_2_2  1.0
    x_2_4     disj2_1_2_2  -1.0
    x_2_4     disj1_2_3_2  -1.0
    x_2_4     disj2_2_3_2  1.0
    x_2_4     disj1_2_4_2  -1.0
    x_2_4     disj2_2_4_2  1.0
    x_2_4     disj1_2_5_2  -1.0
    x_2_4     disj2_2_5_2  1.0
    x_2_4     disj1_2_6_2  -1.0
    x_2_4     disj2_2_6_2  1.0
    x_2_4     disj1_2_7_2  -1.0
    x_2_4     disj2_2_7_2  1.0
    x_2_4     disj1_2_8_2  -1.0
    x_2_4     disj2_2_8_2  1.0
    x_2_4     disj1_2_9_2  -1.0
    x_2_4     disj2_2_9_2  1.0
    x_2_4     disj1_2_10_2  -1.0
    x_2_4     disj2_2_10_2  1.0
    x_2_4     disj1_2_11_2  -1.0
    x_2_4     disj2_2_11_2  1.0
    x_2_4     disj1_2_12_2  -1.0
    x_2_4     disj2_2_12_2  1.0
    x_2_4     disj1_2_13_2  -1.0
    x_2_4     disj2_2_13_2  1.0
    x_2_4     disj1_2_14_2  -1.0
    x_2_4     disj2_2_14_2  1.0
    x_2_4     disj1_2_15_2  -1.0
    x_2_4     disj2_2_15_2  1.0
    x_2_4     disj1_2_16_2  -1.0
    x_2_4     disj2_2_16_2  1.0
    x_2_4     disj1_2_17_2  -1.0
    x_2_4     disj2_2_17_2  1.0
    x_2_4     disj1_2_18_2  -1.0
    x_2_4     disj2_2_18_2  1.0
    x_2_4     disj1_2_19_2  -1.0
    x_2_4     disj2_2_19_2  1.0
    x_3_0     prec_3_0  -1.0
    x_3_0     disj1_0_3_4  1.0
    x_3_0     disj2_0_3_4  -1.0
    x_3_0     disj1_1_3_4  1.0
    x_3_0     disj2_1_3_4  -1.0
    x_3_0     disj1_2_3_4  1.0
    x_3_0     disj2_2_3_4  -1.0
    x_3_0     disj1_3_4_4  -1.0
    x_3_0     disj2_3_4_4  1.0
    x_3_0     disj1_3_5_4  -1.0
    x_3_0     disj2_3_5_4  1.0
    x_3_0     disj1_3_6_4  -1.0
    x_3_0     disj2_3_6_4  1.0
    x_3_0     disj1_3_7_4  -1.0
    x_3_0     disj2_3_7_4  1.0
    x_3_0     disj1_3_8_4  -1.0
    x_3_0     disj2_3_8_4  1.0
    x_3_0     disj1_3_9_4  -1.0
    x_3_0     disj2_3_9_4  1.0
    x_3_0     disj1_3_10_4  -1.0
    x_3_0     disj2_3_10_4  1.0
    x_3_0     disj1_3_11_4  -1.0
    x_3_0     disj2_3_11_4  1.0
    x_3_0     disj1_3_12_4  -1.0
    x_3_0     disj2_3_12_4  1.0
    x_3_0     disj1_3_13_4  -1.0
    x_3_0     disj2_3_13_4  1.0
    x_3_0     disj1_3_14_4  -1.0
    x_3_0     disj2_3_14_4  1.0
    x_3_0     disj1_3_15_4  -1.0
    x_3_0     disj2_3_15_4  1.0
    x_3_0     disj1_3_16_4  -1.0
    x_3_0     disj2_3_16_4  1.0
    x_3_0     disj1_3_17_4  -1.0
    x_3_0     disj2_3_17_4  1.0
    x_3_0     disj1_3_18_4  -1.0
    x_3_0     disj2_3_18_4  1.0
    x_3_0     disj1_3_19_4  -1.0
    x_3_0     disj2_3_19_4  1.0
    x_3_1     prec_3_0  1.0
    x_3_1     prec_3_1  -1.0
    x_3_1     disj1_0_3_0  1.0
    x_3_1     disj2_0_3_0  -1.0
    x_3_1     disj1_1_3_0  1.0
    x_3_1     disj2_1_3_0  -1.0
    x_3_1     disj1_2_3_0  1.0
    x_3_1     disj2_2_3_0  -1.0
    x_3_1     disj1_3_4_0  -1.0
    x_3_1     disj2_3_4_0  1.0
    x_3_1     disj1_3_5_0  -1.0
    x_3_1     disj2_3_5_0  1.0
    x_3_1     disj1_3_6_0  -1.0
    x_3_1     disj2_3_6_0  1.0
    x_3_1     disj1_3_7_0  -1.0
    x_3_1     disj2_3_7_0  1.0
    x_3_1     disj1_3_8_0  -1.0
    x_3_1     disj2_3_8_0  1.0
    x_3_1     disj1_3_9_0  -1.0
    x_3_1     disj2_3_9_0  1.0
    x_3_1     disj1_3_10_0  -1.0
    x_3_1     disj2_3_10_0  1.0
    x_3_1     disj1_3_11_0  -1.0
    x_3_1     disj2_3_11_0  1.0
    x_3_1     disj1_3_12_0  -1.0
    x_3_1     disj2_3_12_0  1.0
    x_3_1     disj1_3_13_0  -1.0
    x_3_1     disj2_3_13_0  1.0
    x_3_1     disj1_3_14_0  -1.0
    x_3_1     disj2_3_14_0  1.0
    x_3_1     disj1_3_15_0  -1.0
    x_3_1     disj2_3_15_0  1.0
    x_3_1     disj1_3_16_0  -1.0
    x_3_1     disj2_3_16_0  1.0
    x_3_1     disj1_3_17_0  -1.0
    x_3_1     disj2_3_17_0  1.0
    x_3_1     disj1_3_18_0  -1.0
    x_3_1     disj2_3_18_0  1.0
    x_3_1     disj1_3_19_0  -1.0
    x_3_1     disj2_3_19_0  1.0
    x_3_2     prec_3_1  1.0
    x_3_2     prec_3_2  -1.0
    x_3_2     disj1_0_3_1  1.0
    x_3_2     disj2_0_3_1  -1.0
    x_3_2     disj1_1_3_1  1.0
    x_3_2     disj2_1_3_1  -1.0
    x_3_2     disj1_2_3_1  1.0
    x_3_2     disj2_2_3_1  -1.0
    x_3_2     disj1_3_4_1  -1.0
    x_3_2     disj2_3_4_1  1.0
    x_3_2     disj1_3_5_1  -1.0
    x_3_2     disj2_3_5_1  1.0
    x_3_2     disj1_3_6_1  -1.0
    x_3_2     disj2_3_6_1  1.0
    x_3_2     disj1_3_7_1  -1.0
    x_3_2     disj2_3_7_1  1.0
    x_3_2     disj1_3_8_1  -1.0
    x_3_2     disj2_3_8_1  1.0
    x_3_2     disj1_3_9_1  -1.0
    x_3_2     disj2_3_9_1  1.0
    x_3_2     disj1_3_10_1  -1.0
    x_3_2     disj2_3_10_1  1.0
    x_3_2     disj1_3_11_1  -1.0
    x_3_2     disj2_3_11_1  1.0
    x_3_2     disj1_3_12_1  -1.0
    x_3_2     disj2_3_12_1  1.0
    x_3_2     disj1_3_13_1  -1.0
    x_3_2     disj2_3_13_1  1.0
    x_3_2     disj1_3_14_1  -1.0
    x_3_2     disj2_3_14_1  1.0
    x_3_2     disj1_3_15_1  -1.0
    x_3_2     disj2_3_15_1  1.0
    x_3_2     disj1_3_16_1  -1.0
    x_3_2     disj2_3_16_1  1.0
    x_3_2     disj1_3_17_1  -1.0
    x_3_2     disj2_3_17_1  1.0
    x_3_2     disj1_3_18_1  -1.0
    x_3_2     disj2_3_18_1  1.0
    x_3_2     disj1_3_19_1  -1.0
    x_3_2     disj2_3_19_1  1.0
    x_3_3     prec_3_2  1.0
    x_3_3     prec_3_3  -1.0
    x_3_3     disj1_0_3_2  1.0
    x_3_3     disj2_0_3_2  -1.0
    x_3_3     disj1_1_3_2  1.0
    x_3_3     disj2_1_3_2  -1.0
    x_3_3     disj1_2_3_2  1.0
    x_3_3     disj2_2_3_2  -1.0
    x_3_3     disj1_3_4_2  -1.0
    x_3_3     disj2_3_4_2  1.0
    x_3_3     disj1_3_5_2  -1.0
    x_3_3     disj2_3_5_2  1.0
    x_3_3     disj1_3_6_2  -1.0
    x_3_3     disj2_3_6_2  1.0
    x_3_3     disj1_3_7_2  -1.0
    x_3_3     disj2_3_7_2  1.0
    x_3_3     disj1_3_8_2  -1.0
    x_3_3     disj2_3_8_2  1.0
    x_3_3     disj1_3_9_2  -1.0
    x_3_3     disj2_3_9_2  1.0
    x_3_3     disj1_3_10_2  -1.0
    x_3_3     disj2_3_10_2  1.0
    x_3_3     disj1_3_11_2  -1.0
    x_3_3     disj2_3_11_2  1.0
    x_3_3     disj1_3_12_2  -1.0
    x_3_3     disj2_3_12_2  1.0
    x_3_3     disj1_3_13_2  -1.0
    x_3_3     disj2_3_13_2  1.0
    x_3_3     disj1_3_14_2  -1.0
    x_3_3     disj2_3_14_2  1.0
    x_3_3     disj1_3_15_2  -1.0
    x_3_3     disj2_3_15_2  1.0
    x_3_3     disj1_3_16_2  -1.0
    x_3_3     disj2_3_16_2  1.0
    x_3_3     disj1_3_17_2  -1.0
    x_3_3     disj2_3_17_2  1.0
    x_3_3     disj1_3_18_2  -1.0
    x_3_3     disj2_3_18_2  1.0
    x_3_3     disj1_3_19_2  -1.0
    x_3_3     disj2_3_19_2  1.0
    x_3_4     prec_3_3  1.0
    x_3_4     mksp_3    -1.0
    x_3_4     disj1_0_3_3  1.0
    x_3_4     disj2_0_3_3  -1.0
    x_3_4     disj1_1_3_3  1.0
    x_3_4     disj2_1_3_3  -1.0
    x_3_4     disj1_2_3_3  1.0
    x_3_4     disj2_2_3_3  -1.0
    x_3_4     disj1_3_4_3  -1.0
    x_3_4     disj2_3_4_3  1.0
    x_3_4     disj1_3_5_3  -1.0
    x_3_4     disj2_3_5_3  1.0
    x_3_4     disj1_3_6_3  -1.0
    x_3_4     disj2_3_6_3  1.0
    x_3_4     disj1_3_7_3  -1.0
    x_3_4     disj2_3_7_3  1.0
    x_3_4     disj1_3_8_3  -1.0
    x_3_4     disj2_3_8_3  1.0
    x_3_4     disj1_3_9_3  -1.0
    x_3_4     disj2_3_9_3  1.0
    x_3_4     disj1_3_10_3  -1.0
    x_3_4     disj2_3_10_3  1.0
    x_3_4     disj1_3_11_3  -1.0
    x_3_4     disj2_3_11_3  1.0
    x_3_4     disj1_3_12_3  -1.0
    x_3_4     disj2_3_12_3  1.0
    x_3_4     disj1_3_13_3  -1.0
    x_3_4     disj2_3_13_3  1.0
    x_3_4     disj1_3_14_3  -1.0
    x_3_4     disj2_3_14_3  1.0
    x_3_4     disj1_3_15_3  -1.0
    x_3_4     disj2_3_15_3  1.0
    x_3_4     disj1_3_16_3  -1.0
    x_3_4     disj2_3_16_3  1.0
    x_3_4     disj1_3_17_3  -1.0
    x_3_4     disj2_3_17_3  1.0
    x_3_4     disj1_3_18_3  -1.0
    x_3_4     disj2_3_18_3  1.0
    x_3_4     disj1_3_19_3  -1.0
    x_3_4     disj2_3_19_3  1.0
    x_4_0     prec_4_0  -1.0
    x_4_0     disj1_0_4_0  1.0
    x_4_0     disj2_0_4_0  -1.0
    x_4_0     disj1_1_4_0  1.0
    x_4_0     disj2_1_4_0  -1.0
    x_4_0     disj1_2_4_0  1.0
    x_4_0     disj2_2_4_0  -1.0
    x_4_0     disj1_3_4_0  1.0
    x_4_0     disj2_3_4_0  -1.0
    x_4_0     disj1_4_5_0  -1.0
    x_4_0     disj2_4_5_0  1.0
    x_4_0     disj1_4_6_0  -1.0
    x_4_0     disj2_4_6_0  1.0
    x_4_0     disj1_4_7_0  -1.0
    x_4_0     disj2_4_7_0  1.0
    x_4_0     disj1_4_8_0  -1.0
    x_4_0     disj2_4_8_0  1.0
    x_4_0     disj1_4_9_0  -1.0
    x_4_0     disj2_4_9_0  1.0
    x_4_0     disj1_4_10_0  -1.0
    x_4_0     disj2_4_10_0  1.0
    x_4_0     disj1_4_11_0  -1.0
    x_4_0     disj2_4_11_0  1.0
    x_4_0     disj1_4_12_0  -1.0
    x_4_0     disj2_4_12_0  1.0
    x_4_0     disj1_4_13_0  -1.0
    x_4_0     disj2_4_13_0  1.0
    x_4_0     disj1_4_14_0  -1.0
    x_4_0     disj2_4_14_0  1.0
    x_4_0     disj1_4_15_0  -1.0
    x_4_0     disj2_4_15_0  1.0
    x_4_0     disj1_4_16_0  -1.0
    x_4_0     disj2_4_16_0  1.0
    x_4_0     disj1_4_17_0  -1.0
    x_4_0     disj2_4_17_0  1.0
    x_4_0     disj1_4_18_0  -1.0
    x_4_0     disj2_4_18_0  1.0
    x_4_0     disj1_4_19_0  -1.0
    x_4_0     disj2_4_19_0  1.0
    x_4_1     prec_4_0  1.0
    x_4_1     prec_4_1  -1.0
    x_4_1     disj1_0_4_4  1.0
    x_4_1     disj2_0_4_4  -1.0
    x_4_1     disj1_1_4_4  1.0
    x_4_1     disj2_1_4_4  -1.0
    x_4_1     disj1_2_4_4  1.0
    x_4_1     disj2_2_4_4  -1.0
    x_4_1     disj1_3_4_4  1.0
    x_4_1     disj2_3_4_4  -1.0
    x_4_1     disj1_4_5_4  -1.0
    x_4_1     disj2_4_5_4  1.0
    x_4_1     disj1_4_6_4  -1.0
    x_4_1     disj2_4_6_4  1.0
    x_4_1     disj1_4_7_4  -1.0
    x_4_1     disj2_4_7_4  1.0
    x_4_1     disj1_4_8_4  -1.0
    x_4_1     disj2_4_8_4  1.0
    x_4_1     disj1_4_9_4  -1.0
    x_4_1     disj2_4_9_4  1.0
    x_4_1     disj1_4_10_4  -1.0
    x_4_1     disj2_4_10_4  1.0
    x_4_1     disj1_4_11_4  -1.0
    x_4_1     disj2_4_11_4  1.0
    x_4_1     disj1_4_12_4  -1.0
    x_4_1     disj2_4_12_4  1.0
    x_4_1     disj1_4_13_4  -1.0
    x_4_1     disj2_4_13_4  1.0
    x_4_1     disj1_4_14_4  -1.0
    x_4_1     disj2_4_14_4  1.0
    x_4_1     disj1_4_15_4  -1.0
    x_4_1     disj2_4_15_4  1.0
    x_4_1     disj1_4_16_4  -1.0
    x_4_1     disj2_4_16_4  1.0
    x_4_1     disj1_4_17_4  -1.0
    x_4_1     disj2_4_17_4  1.0
    x_4_1     disj1_4_18_4  -1.0
    x_4_1     disj2_4_18_4  1.0
    x_4_1     disj1_4_19_4  -1.0
    x_4_1     disj2_4_19_4  1.0
    x_4_2     prec_4_1  1.0
    x_4_2     prec_4_2  -1.0
    x_4_2     disj1_0_4_2  1.0
    x_4_2     disj2_0_4_2  -1.0
    x_4_2     disj1_1_4_2  1.0
    x_4_2     disj2_1_4_2  -1.0
    x_4_2     disj1_2_4_2  1.0
    x_4_2     disj2_2_4_2  -1.0
    x_4_2     disj1_3_4_2  1.0
    x_4_2     disj2_3_4_2  -1.0
    x_4_2     disj1_4_5_2  -1.0
    x_4_2     disj2_4_5_2  1.0
    x_4_2     disj1_4_6_2  -1.0
    x_4_2     disj2_4_6_2  1.0
    x_4_2     disj1_4_7_2  -1.0
    x_4_2     disj2_4_7_2  1.0
    x_4_2     disj1_4_8_2  -1.0
    x_4_2     disj2_4_8_2  1.0
    x_4_2     disj1_4_9_2  -1.0
    x_4_2     disj2_4_9_2  1.0
    x_4_2     disj1_4_10_2  -1.0
    x_4_2     disj2_4_10_2  1.0
    x_4_2     disj1_4_11_2  -1.0
    x_4_2     disj2_4_11_2  1.0
    x_4_2     disj1_4_12_2  -1.0
    x_4_2     disj2_4_12_2  1.0
    x_4_2     disj1_4_13_2  -1.0
    x_4_2     disj2_4_13_2  1.0
    x_4_2     disj1_4_14_2  -1.0
    x_4_2     disj2_4_14_2  1.0
    x_4_2     disj1_4_15_2  -1.0
    x_4_2     disj2_4_15_2  1.0
    x_4_2     disj1_4_16_2  -1.0
    x_4_2     disj2_4_16_2  1.0
    x_4_2     disj1_4_17_2  -1.0
    x_4_2     disj2_4_17_2  1.0
    x_4_2     disj1_4_18_2  -1.0
    x_4_2     disj2_4_18_2  1.0
    x_4_2     disj1_4_19_2  -1.0
    x_4_2     disj2_4_19_2  1.0
    x_4_3     prec_4_2  1.0
    x_4_3     prec_4_3  -1.0
    x_4_3     disj1_0_4_1  1.0
    x_4_3     disj2_0_4_1  -1.0
    x_4_3     disj1_1_4_1  1.0
    x_4_3     disj2_1_4_1  -1.0
    x_4_3     disj1_2_4_1  1.0
    x_4_3     disj2_2_4_1  -1.0
    x_4_3     disj1_3_4_1  1.0
    x_4_3     disj2_3_4_1  -1.0
    x_4_3     disj1_4_5_1  -1.0
    x_4_3     disj2_4_5_1  1.0
    x_4_3     disj1_4_6_1  -1.0
    x_4_3     disj2_4_6_1  1.0
    x_4_3     disj1_4_7_1  -1.0
    x_4_3     disj2_4_7_1  1.0
    x_4_3     disj1_4_8_1  -1.0
    x_4_3     disj2_4_8_1  1.0
    x_4_3     disj1_4_9_1  -1.0
    x_4_3     disj2_4_9_1  1.0
    x_4_3     disj1_4_10_1  -1.0
    x_4_3     disj2_4_10_1  1.0
    x_4_3     disj1_4_11_1  -1.0
    x_4_3     disj2_4_11_1  1.0
    x_4_3     disj1_4_12_1  -1.0
    x_4_3     disj2_4_12_1  1.0
    x_4_3     disj1_4_13_1  -1.0
    x_4_3     disj2_4_13_1  1.0
    x_4_3     disj1_4_14_1  -1.0
    x_4_3     disj2_4_14_1  1.0
    x_4_3     disj1_4_15_1  -1.0
    x_4_3     disj2_4_15_1  1.0
    x_4_3     disj1_4_16_1  -1.0
    x_4_3     disj2_4_16_1  1.0
    x_4_3     disj1_4_17_1  -1.0
    x_4_3     disj2_4_17_1  1.0
    x_4_3     disj1_4_18_1  -1.0
    x_4_3     disj2_4_18_1  1.0
    x_4_3     disj1_4_19_1  -1.0
    x_4_3     disj2_4_19_1  1.0
    x_4_4     prec_4_3  1.0
    x_4_4     mksp_4    -1.0
    x_4_4     disj1_0_4_3  1.0
    x_4_4     disj2_0_4_3  -1.0
    x_4_4     disj1_1_4_3  1.0
    x_4_4     disj2_1_4_3  -1.0
    x_4_4     disj1_2_4_3  1.0
    x_4_4     disj2_2_4_3  -1.0
    x_4_4     disj1_3_4_3  1.0
    x_4_4     disj2_3_4_3  -1.0
    x_4_4     disj1_4_5_3  -1.0
    x_4_4     disj2_4_5_3  1.0
    x_4_4     disj1_4_6_3  -1.0
    x_4_4     disj2_4_6_3  1.0
    x_4_4     disj1_4_7_3  -1.0
    x_4_4     disj2_4_7_3  1.0
    x_4_4     disj1_4_8_3  -1.0
    x_4_4     disj2_4_8_3  1.0
    x_4_4     disj1_4_9_3  -1.0
    x_4_4     disj2_4_9_3  1.0
    x_4_4     disj1_4_10_3  -1.0
    x_4_4     disj2_4_10_3  1.0
    x_4_4     disj1_4_11_3  -1.0
    x_4_4     disj2_4_11_3  1.0
    x_4_4     disj1_4_12_3  -1.0
    x_4_4     disj2_4_12_3  1.0
    x_4_4     disj1_4_13_3  -1.0
    x_4_4     disj2_4_13_3  1.0
    x_4_4     disj1_4_14_3  -1.0
    x_4_4     disj2_4_14_3  1.0
    x_4_4     disj1_4_15_3  -1.0
    x_4_4     disj2_4_15_3  1.0
    x_4_4     disj1_4_16_3  -1.0
    x_4_4     disj2_4_16_3  1.0
    x_4_4     disj1_4_17_3  -1.0
    x_4_4     disj2_4_17_3  1.0
    x_4_4     disj1_4_18_3  -1.0
    x_4_4     disj2_4_18_3  1.0
    x_4_4     disj1_4_19_3  -1.0
    x_4_4     disj2_4_19_3  1.0
    x_5_0     prec_5_0  -1.0
    x_5_0     disj1_0_5_1  1.0
    x_5_0     disj2_0_5_1  -1.0
    x_5_0     disj1_1_5_1  1.0
    x_5_0     disj2_1_5_1  -1.0
    x_5_0     disj1_2_5_1  1.0
    x_5_0     disj2_2_5_1  -1.0
    x_5_0     disj1_3_5_1  1.0
    x_5_0     disj2_3_5_1  -1.0
    x_5_0     disj1_4_5_1  1.0
    x_5_0     disj2_4_5_1  -1.0
    x_5_0     disj1_5_6_1  -1.0
    x_5_0     disj2_5_6_1  1.0
    x_5_0     disj1_5_7_1  -1.0
    x_5_0     disj2_5_7_1  1.0
    x_5_0     disj1_5_8_1  -1.0
    x_5_0     disj2_5_8_1  1.0
    x_5_0     disj1_5_9_1  -1.0
    x_5_0     disj2_5_9_1  1.0
    x_5_0     disj1_5_10_1  -1.0
    x_5_0     disj2_5_10_1  1.0
    x_5_0     disj1_5_11_1  -1.0
    x_5_0     disj2_5_11_1  1.0
    x_5_0     disj1_5_12_1  -1.0
    x_5_0     disj2_5_12_1  1.0
    x_5_0     disj1_5_13_1  -1.0
    x_5_0     disj2_5_13_1  1.0
    x_5_0     disj1_5_14_1  -1.0
    x_5_0     disj2_5_14_1  1.0
    x_5_0     disj1_5_15_1  -1.0
    x_5_0     disj2_5_15_1  1.0
    x_5_0     disj1_5_16_1  -1.0
    x_5_0     disj2_5_16_1  1.0
    x_5_0     disj1_5_17_1  -1.0
    x_5_0     disj2_5_17_1  1.0
    x_5_0     disj1_5_18_1  -1.0
    x_5_0     disj2_5_18_1  1.0
    x_5_0     disj1_5_19_1  -1.0
    x_5_0     disj2_5_19_1  1.0
    x_5_1     prec_5_0  1.0
    x_5_1     prec_5_1  -1.0
    x_5_1     disj1_0_5_4  1.0
    x_5_1     disj2_0_5_4  -1.0
    x_5_1     disj1_1_5_4  1.0
    x_5_1     disj2_1_5_4  -1.0
    x_5_1     disj1_2_5_4  1.0
    x_5_1     disj2_2_5_4  -1.0
    x_5_1     disj1_3_5_4  1.0
    x_5_1     disj2_3_5_4  -1.0
    x_5_1     disj1_4_5_4  1.0
    x_5_1     disj2_4_5_4  -1.0
    x_5_1     disj1_5_6_4  -1.0
    x_5_1     disj2_5_6_4  1.0
    x_5_1     disj1_5_7_4  -1.0
    x_5_1     disj2_5_7_4  1.0
    x_5_1     disj1_5_8_4  -1.0
    x_5_1     disj2_5_8_4  1.0
    x_5_1     disj1_5_9_4  -1.0
    x_5_1     disj2_5_9_4  1.0
    x_5_1     disj1_5_10_4  -1.0
    x_5_1     disj2_5_10_4  1.0
    x_5_1     disj1_5_11_4  -1.0
    x_5_1     disj2_5_11_4  1.0
    x_5_1     disj1_5_12_4  -1.0
    x_5_1     disj2_5_12_4  1.0
    x_5_1     disj1_5_13_4  -1.0
    x_5_1     disj2_5_13_4  1.0
    x_5_1     disj1_5_14_4  -1.0
    x_5_1     disj2_5_14_4  1.0
    x_5_1     disj1_5_15_4  -1.0
    x_5_1     disj2_5_15_4  1.0
    x_5_1     disj1_5_16_4  -1.0
    x_5_1     disj2_5_16_4  1.0
    x_5_1     disj1_5_17_4  -1.0
    x_5_1     disj2_5_17_4  1.0
    x_5_1     disj1_5_18_4  -1.0
    x_5_1     disj2_5_18_4  1.0
    x_5_1     disj1_5_19_4  -1.0
    x_5_1     disj2_5_19_4  1.0
    x_5_2     prec_5_1  1.0
    x_5_2     prec_5_2  -1.0
    x_5_2     disj1_0_5_0  1.0
    x_5_2     disj2_0_5_0  -1.0
    x_5_2     disj1_1_5_0  1.0
    x_5_2     disj2_1_5_0  -1.0
    x_5_2     disj1_2_5_0  1.0
    x_5_2     disj2_2_5_0  -1.0
    x_5_2     disj1_3_5_0  1.0
    x_5_2     disj2_3_5_0  -1.0
    x_5_2     disj1_4_5_0  1.0
    x_5_2     disj2_4_5_0  -1.0
    x_5_2     disj1_5_6_0  -1.0
    x_5_2     disj2_5_6_0  1.0
    x_5_2     disj1_5_7_0  -1.0
    x_5_2     disj2_5_7_0  1.0
    x_5_2     disj1_5_8_0  -1.0
    x_5_2     disj2_5_8_0  1.0
    x_5_2     disj1_5_9_0  -1.0
    x_5_2     disj2_5_9_0  1.0
    x_5_2     disj1_5_10_0  -1.0
    x_5_2     disj2_5_10_0  1.0
    x_5_2     disj1_5_11_0  -1.0
    x_5_2     disj2_5_11_0  1.0
    x_5_2     disj1_5_12_0  -1.0
    x_5_2     disj2_5_12_0  1.0
    x_5_2     disj1_5_13_0  -1.0
    x_5_2     disj2_5_13_0  1.0
    x_5_2     disj1_5_14_0  -1.0
    x_5_2     disj2_5_14_0  1.0
    x_5_2     disj1_5_15_0  -1.0
    x_5_2     disj2_5_15_0  1.0
    x_5_2     disj1_5_16_0  -1.0
    x_5_2     disj2_5_16_0  1.0
    x_5_2     disj1_5_17_0  -1.0
    x_5_2     disj2_5_17_0  1.0
    x_5_2     disj1_5_18_0  -1.0
    x_5_2     disj2_5_18_0  1.0
    x_5_2     disj1_5_19_0  -1.0
    x_5_2     disj2_5_19_0  1.0
    x_5_3     prec_5_2  1.0
    x_5_3     prec_5_3  -1.0
    x_5_3     disj1_0_5_3  1.0
    x_5_3     disj2_0_5_3  -1.0
    x_5_3     disj1_1_5_3  1.0
    x_5_3     disj2_1_5_3  -1.0
    x_5_3     disj1_2_5_3  1.0
    x_5_3     disj2_2_5_3  -1.0
    x_5_3     disj1_3_5_3  1.0
    x_5_3     disj2_3_5_3  -1.0
    x_5_3     disj1_4_5_3  1.0
    x_5_3     disj2_4_5_3  -1.0
    x_5_3     disj1_5_6_3  -1.0
    x_5_3     disj2_5_6_3  1.0
    x_5_3     disj1_5_7_3  -1.0
    x_5_3     disj2_5_7_3  1.0
    x_5_3     disj1_5_8_3  -1.0
    x_5_3     disj2_5_8_3  1.0
    x_5_3     disj1_5_9_3  -1.0
    x_5_3     disj2_5_9_3  1.0
    x_5_3     disj1_5_10_3  -1.0
    x_5_3     disj2_5_10_3  1.0
    x_5_3     disj1_5_11_3  -1.0
    x_5_3     disj2_5_11_3  1.0
    x_5_3     disj1_5_12_3  -1.0
    x_5_3     disj2_5_12_3  1.0
    x_5_3     disj1_5_13_3  -1.0
    x_5_3     disj2_5_13_3  1.0
    x_5_3     disj1_5_14_3  -1.0
    x_5_3     disj2_5_14_3  1.0
    x_5_3     disj1_5_15_3  -1.0
    x_5_3     disj2_5_15_3  1.0
    x_5_3     disj1_5_16_3  -1.0
    x_5_3     disj2_5_16_3  1.0
    x_5_3     disj1_5_17_3  -1.0
    x_5_3     disj2_5_17_3  1.0
    x_5_3     disj1_5_18_3  -1.0
    x_5_3     disj2_5_18_3  1.0
    x_5_3     disj1_5_19_3  -1.0
    x_5_3     disj2_5_19_3  1.0
    x_5_4     prec_5_3  1.0
    x_5_4     mksp_5    -1.0
    x_5_4     disj1_0_5_2  1.0
    x_5_4     disj2_0_5_2  -1.0
    x_5_4     disj1_1_5_2  1.0
    x_5_4     disj2_1_5_2  -1.0
    x_5_4     disj1_2_5_2  1.0
    x_5_4     disj2_2_5_2  -1.0
    x_5_4     disj1_3_5_2  1.0
    x_5_4     disj2_3_5_2  -1.0
    x_5_4     disj1_4_5_2  1.0
    x_5_4     disj2_4_5_2  -1.0
    x_5_4     disj1_5_6_2  -1.0
    x_5_4     disj2_5_6_2  1.0
    x_5_4     disj1_5_7_2  -1.0
    x_5_4     disj2_5_7_2  1.0
    x_5_4     disj1_5_8_2  -1.0
    x_5_4     disj2_5_8_2  1.0
    x_5_4     disj1_5_9_2  -1.0
    x_5_4     disj2_5_9_2  1.0
    x_5_4     disj1_5_10_2  -1.0
    x_5_4     disj2_5_10_2  1.0
    x_5_4     disj1_5_11_2  -1.0
    x_5_4     disj2_5_11_2  1.0
    x_5_4     disj1_5_12_2  -1.0
    x_5_4     disj2_5_12_2  1.0
    x_5_4     disj1_5_13_2  -1.0
    x_5_4     disj2_5_13_2  1.0
    x_5_4     disj1_5_14_2  -1.0
    x_5_4     disj2_5_14_2  1.0
    x_5_4     disj1_5_15_2  -1.0
    x_5_4     disj2_5_15_2  1.0
    x_5_4     disj1_5_16_2  -1.0
    x_5_4     disj2_5_16_2  1.0
    x_5_4     disj1_5_17_2  -1.0
    x_5_4     disj2_5_17_2  1.0
    x_5_4     disj1_5_18_2  -1.0
    x_5_4     disj2_5_18_2  1.0
    x_5_4     disj1_5_19_2  -1.0
    x_5_4     disj2_5_19_2  1.0
    x_6_0     prec_6_0  -1.0
    x_6_0     disj1_0_6_3  1.0
    x_6_0     disj2_0_6_3  -1.0
    x_6_0     disj1_1_6_3  1.0
    x_6_0     disj2_1_6_3  -1.0
    x_6_0     disj1_2_6_3  1.0
    x_6_0     disj2_2_6_3  -1.0
    x_6_0     disj1_3_6_3  1.0
    x_6_0     disj2_3_6_3  -1.0
    x_6_0     disj1_4_6_3  1.0
    x_6_0     disj2_4_6_3  -1.0
    x_6_0     disj1_5_6_3  1.0
    x_6_0     disj2_5_6_3  -1.0
    x_6_0     disj1_6_7_3  -1.0
    x_6_0     disj2_6_7_3  1.0
    x_6_0     disj1_6_8_3  -1.0
    x_6_0     disj2_6_8_3  1.0
    x_6_0     disj1_6_9_3  -1.0
    x_6_0     disj2_6_9_3  1.0
    x_6_0     disj1_6_10_3  -1.0
    x_6_0     disj2_6_10_3  1.0
    x_6_0     disj1_6_11_3  -1.0
    x_6_0     disj2_6_11_3  1.0
    x_6_0     disj1_6_12_3  -1.0
    x_6_0     disj2_6_12_3  1.0
    x_6_0     disj1_6_13_3  -1.0
    x_6_0     disj2_6_13_3  1.0
    x_6_0     disj1_6_14_3  -1.0
    x_6_0     disj2_6_14_3  1.0
    x_6_0     disj1_6_15_3  -1.0
    x_6_0     disj2_6_15_3  1.0
    x_6_0     disj1_6_16_3  -1.0
    x_6_0     disj2_6_16_3  1.0
    x_6_0     disj1_6_17_3  -1.0
    x_6_0     disj2_6_17_3  1.0
    x_6_0     disj1_6_18_3  -1.0
    x_6_0     disj2_6_18_3  1.0
    x_6_0     disj1_6_19_3  -1.0
    x_6_0     disj2_6_19_3  1.0
    x_6_1     prec_6_0  1.0
    x_6_1     prec_6_1  -1.0
    x_6_1     disj1_0_6_1  1.0
    x_6_1     disj2_0_6_1  -1.0
    x_6_1     disj1_1_6_1  1.0
    x_6_1     disj2_1_6_1  -1.0
    x_6_1     disj1_2_6_1  1.0
    x_6_1     disj2_2_6_1  -1.0
    x_6_1     disj1_3_6_1  1.0
    x_6_1     disj2_3_6_1  -1.0
    x_6_1     disj1_4_6_1  1.0
    x_6_1     disj2_4_6_1  -1.0
    x_6_1     disj1_5_6_1  1.0
    x_6_1     disj2_5_6_1  -1.0
    x_6_1     disj1_6_7_1  -1.0
    x_6_1     disj2_6_7_1  1.0
    x_6_1     disj1_6_8_1  -1.0
    x_6_1     disj2_6_8_1  1.0
    x_6_1     disj1_6_9_1  -1.0
    x_6_1     disj2_6_9_1  1.0
    x_6_1     disj1_6_10_1  -1.0
    x_6_1     disj2_6_10_1  1.0
    x_6_1     disj1_6_11_1  -1.0
    x_6_1     disj2_6_11_1  1.0
    x_6_1     disj1_6_12_1  -1.0
    x_6_1     disj2_6_12_1  1.0
    x_6_1     disj1_6_13_1  -1.0
    x_6_1     disj2_6_13_1  1.0
    x_6_1     disj1_6_14_1  -1.0
    x_6_1     disj2_6_14_1  1.0
    x_6_1     disj1_6_15_1  -1.0
    x_6_1     disj2_6_15_1  1.0
    x_6_1     disj1_6_16_1  -1.0
    x_6_1     disj2_6_16_1  1.0
    x_6_1     disj1_6_17_1  -1.0
    x_6_1     disj2_6_17_1  1.0
    x_6_1     disj1_6_18_1  -1.0
    x_6_1     disj2_6_18_1  1.0
    x_6_1     disj1_6_19_1  -1.0
    x_6_1     disj2_6_19_1  1.0
    x_6_2     prec_6_1  1.0
    x_6_2     prec_6_2  -1.0
    x_6_2     disj1_0_6_4  1.0
    x_6_2     disj2_0_6_4  -1.0
    x_6_2     disj1_1_6_4  1.0
    x_6_2     disj2_1_6_4  -1.0
    x_6_2     disj1_2_6_4  1.0
    x_6_2     disj2_2_6_4  -1.0
    x_6_2     disj1_3_6_4  1.0
    x_6_2     disj2_3_6_4  -1.0
    x_6_2     disj1_4_6_4  1.0
    x_6_2     disj2_4_6_4  -1.0
    x_6_2     disj1_5_6_4  1.0
    x_6_2     disj2_5_6_4  -1.0
    x_6_2     disj1_6_7_4  -1.0
    x_6_2     disj2_6_7_4  1.0
    x_6_2     disj1_6_8_4  -1.0
    x_6_2     disj2_6_8_4  1.0
    x_6_2     disj1_6_9_4  -1.0
    x_6_2     disj2_6_9_4  1.0
    x_6_2     disj1_6_10_4  -1.0
    x_6_2     disj2_6_10_4  1.0
    x_6_2     disj1_6_11_4  -1.0
    x_6_2     disj2_6_11_4  1.0
    x_6_2     disj1_6_12_4  -1.0
    x_6_2     disj2_6_12_4  1.0
    x_6_2     disj1_6_13_4  -1.0
    x_6_2     disj2_6_13_4  1.0
    x_6_2     disj1_6_14_4  -1.0
    x_6_2     disj2_6_14_4  1.0
    x_6_2     disj1_6_15_4  -1.0
    x_6_2     disj2_6_15_4  1.0
    x_6_2     disj1_6_16_4  -1.0
    x_6_2     disj2_6_16_4  1.0
    x_6_2     disj1_6_17_4  -1.0
    x_6_2     disj2_6_17_4  1.0
    x_6_2     disj1_6_18_4  -1.0
    x_6_2     disj2_6_18_4  1.0
    x_6_2     disj1_6_19_4  -1.0
    x_6_2     disj2_6_19_4  1.0
    x_6_3     prec_6_2  1.0
    x_6_3     prec_6_3  -1.0
    x_6_3     disj1_0_6_0  1.0
    x_6_3     disj2_0_6_0  -1.0
    x_6_3     disj1_1_6_0  1.0
    x_6_3     disj2_1_6_0  -1.0
    x_6_3     disj1_2_6_0  1.0
    x_6_3     disj2_2_6_0  -1.0
    x_6_3     disj1_3_6_0  1.0
    x_6_3     disj2_3_6_0  -1.0
    x_6_3     disj1_4_6_0  1.0
    x_6_3     disj2_4_6_0  -1.0
    x_6_3     disj1_5_6_0  1.0
    x_6_3     disj2_5_6_0  -1.0
    x_6_3     disj1_6_7_0  -1.0
    x_6_3     disj2_6_7_0  1.0
    x_6_3     disj1_6_8_0  -1.0
    x_6_3     disj2_6_8_0  1.0
    x_6_3     disj1_6_9_0  -1.0
    x_6_3     disj2_6_9_0  1.0
    x_6_3     disj1_6_10_0  -1.0
    x_6_3     disj2_6_10_0  1.0
    x_6_3     disj1_6_11_0  -1.0
    x_6_3     disj2_6_11_0  1.0
    x_6_3     disj1_6_12_0  -1.0
    x_6_3     disj2_6_12_0  1.0
    x_6_3     disj1_6_13_0  -1.0
    x_6_3     disj2_6_13_0  1.0
    x_6_3     disj1_6_14_0  -1.0
    x_6_3     disj2_6_14_0  1.0
    x_6_3     disj1_6_15_0  -1.0
    x_6_3     disj2_6_15_0  1.0
    x_6_3     disj1_6_16_0  -1.0
    x_6_3     disj2_6_16_0  1.0
    x_6_3     disj1_6_17_0  -1.0
    x_6_3     disj2_6_17_0  1.0
    x_6_3     disj1_6_18_0  -1.0
    x_6_3     disj2_6_18_0  1.0
    x_6_3     disj1_6_19_0  -1.0
    x_6_3     disj2_6_19_0  1.0
    x_6_4     prec_6_3  1.0
    x_6_4     mksp_6    -1.0
    x_6_4     disj1_0_6_2  1.0
    x_6_4     disj2_0_6_2  -1.0
    x_6_4     disj1_1_6_2  1.0
    x_6_4     disj2_1_6_2  -1.0
    x_6_4     disj1_2_6_2  1.0
    x_6_4     disj2_2_6_2  -1.0
    x_6_4     disj1_3_6_2  1.0
    x_6_4     disj2_3_6_2  -1.0
    x_6_4     disj1_4_6_2  1.0
    x_6_4     disj2_4_6_2  -1.0
    x_6_4     disj1_5_6_2  1.0
    x_6_4     disj2_5_6_2  -1.0
    x_6_4     disj1_6_7_2  -1.0
    x_6_4     disj2_6_7_2  1.0
    x_6_4     disj1_6_8_2  -1.0
    x_6_4     disj2_6_8_2  1.0
    x_6_4     disj1_6_9_2  -1.0
    x_6_4     disj2_6_9_2  1.0
    x_6_4     disj1_6_10_2  -1.0
    x_6_4     disj2_6_10_2  1.0
    x_6_4     disj1_6_11_2  -1.0
    x_6_4     disj2_6_11_2  1.0
    x_6_4     disj1_6_12_2  -1.0
    x_6_4     disj2_6_12_2  1.0
    x_6_4     disj1_6_13_2  -1.0
    x_6_4     disj2_6_13_2  1.0
    x_6_4     disj1_6_14_2  -1.0
    x_6_4     disj2_6_14_2  1.0
    x_6_4     disj1_6_15_2  -1.0
    x_6_4     disj2_6_15_2  1.0
    x_6_4     disj1_6_16_2  -1.0
    x_6_4     disj2_6_16_2  1.0
    x_6_4     disj1_6_17_2  -1.0
    x_6_4     disj2_6_17_2  1.0
    x_6_4     disj1_6_18_2  -1.0
    x_6_4     disj2_6_18_2  1.0
    x_6_4     disj1_6_19_2  -1.0
    x_6_4     disj2_6_19_2  1.0
    x_7_0     prec_7_0  -1.0
    x_7_0     disj1_0_7_4  1.0
    x_7_0     disj2_0_7_4  -1.0
    x_7_0     disj1_1_7_4  1.0
    x_7_0     disj2_1_7_4  -1.0
    x_7_0     disj1_2_7_4  1.0
    x_7_0     disj2_2_7_4  -1.0
    x_7_0     disj1_3_7_4  1.0
    x_7_0     disj2_3_7_4  -1.0
    x_7_0     disj1_4_7_4  1.0
    x_7_0     disj2_4_7_4  -1.0
    x_7_0     disj1_5_7_4  1.0
    x_7_0     disj2_5_7_4  -1.0
    x_7_0     disj1_6_7_4  1.0
    x_7_0     disj2_6_7_4  -1.0
    x_7_0     disj1_7_8_4  -1.0
    x_7_0     disj2_7_8_4  1.0
    x_7_0     disj1_7_9_4  -1.0
    x_7_0     disj2_7_9_4  1.0
    x_7_0     disj1_7_10_4  -1.0
    x_7_0     disj2_7_10_4  1.0
    x_7_0     disj1_7_11_4  -1.0
    x_7_0     disj2_7_11_4  1.0
    x_7_0     disj1_7_12_4  -1.0
    x_7_0     disj2_7_12_4  1.0
    x_7_0     disj1_7_13_4  -1.0
    x_7_0     disj2_7_13_4  1.0
    x_7_0     disj1_7_14_4  -1.0
    x_7_0     disj2_7_14_4  1.0
    x_7_0     disj1_7_15_4  -1.0
    x_7_0     disj2_7_15_4  1.0
    x_7_0     disj1_7_16_4  -1.0
    x_7_0     disj2_7_16_4  1.0
    x_7_0     disj1_7_17_4  -1.0
    x_7_0     disj2_7_17_4  1.0
    x_7_0     disj1_7_18_4  -1.0
    x_7_0     disj2_7_18_4  1.0
    x_7_0     disj1_7_19_4  -1.0
    x_7_0     disj2_7_19_4  1.0
    x_7_1     prec_7_0  1.0
    x_7_1     prec_7_1  -1.0
    x_7_1     disj1_0_7_3  1.0
    x_7_1     disj2_0_7_3  -1.0
    x_7_1     disj1_1_7_3  1.0
    x_7_1     disj2_1_7_3  -1.0
    x_7_1     disj1_2_7_3  1.0
    x_7_1     disj2_2_7_3  -1.0
    x_7_1     disj1_3_7_3  1.0
    x_7_1     disj2_3_7_3  -1.0
    x_7_1     disj1_4_7_3  1.0
    x_7_1     disj2_4_7_3  -1.0
    x_7_1     disj1_5_7_3  1.0
    x_7_1     disj2_5_7_3  -1.0
    x_7_1     disj1_6_7_3  1.0
    x_7_1     disj2_6_7_3  -1.0
    x_7_1     disj1_7_8_3  -1.0
    x_7_1     disj2_7_8_3  1.0
    x_7_1     disj1_7_9_3  -1.0
    x_7_1     disj2_7_9_3  1.0
    x_7_1     disj1_7_10_3  -1.0
    x_7_1     disj2_7_10_3  1.0
    x_7_1     disj1_7_11_3  -1.0
    x_7_1     disj2_7_11_3  1.0
    x_7_1     disj1_7_12_3  -1.0
    x_7_1     disj2_7_12_3  1.0
    x_7_1     disj1_7_13_3  -1.0
    x_7_1     disj2_7_13_3  1.0
    x_7_1     disj1_7_14_3  -1.0
    x_7_1     disj2_7_14_3  1.0
    x_7_1     disj1_7_15_3  -1.0
    x_7_1     disj2_7_15_3  1.0
    x_7_1     disj1_7_16_3  -1.0
    x_7_1     disj2_7_16_3  1.0
    x_7_1     disj1_7_17_3  -1.0
    x_7_1     disj2_7_17_3  1.0
    x_7_1     disj1_7_18_3  -1.0
    x_7_1     disj2_7_18_3  1.0
    x_7_1     disj1_7_19_3  -1.0
    x_7_1     disj2_7_19_3  1.0
    x_7_2     prec_7_1  1.0
    x_7_2     prec_7_2  -1.0
    x_7_2     disj1_0_7_1  1.0
    x_7_2     disj2_0_7_1  -1.0
    x_7_2     disj1_1_7_1  1.0
    x_7_2     disj2_1_7_1  -1.0
    x_7_2     disj1_2_7_1  1.0
    x_7_2     disj2_2_7_1  -1.0
    x_7_2     disj1_3_7_1  1.0
    x_7_2     disj2_3_7_1  -1.0
    x_7_2     disj1_4_7_1  1.0
    x_7_2     disj2_4_7_1  -1.0
    x_7_2     disj1_5_7_1  1.0
    x_7_2     disj2_5_7_1  -1.0
    x_7_2     disj1_6_7_1  1.0
    x_7_2     disj2_6_7_1  -1.0
    x_7_2     disj1_7_8_1  -1.0
    x_7_2     disj2_7_8_1  1.0
    x_7_2     disj1_7_9_1  -1.0
    x_7_2     disj2_7_9_1  1.0
    x_7_2     disj1_7_10_1  -1.0
    x_7_2     disj2_7_10_1  1.0
    x_7_2     disj1_7_11_1  -1.0
    x_7_2     disj2_7_11_1  1.0
    x_7_2     disj1_7_12_1  -1.0
    x_7_2     disj2_7_12_1  1.0
    x_7_2     disj1_7_13_1  -1.0
    x_7_2     disj2_7_13_1  1.0
    x_7_2     disj1_7_14_1  -1.0
    x_7_2     disj2_7_14_1  1.0
    x_7_2     disj1_7_15_1  -1.0
    x_7_2     disj2_7_15_1  1.0
    x_7_2     disj1_7_16_1  -1.0
    x_7_2     disj2_7_16_1  1.0
    x_7_2     disj1_7_17_1  -1.0
    x_7_2     disj2_7_17_1  1.0
    x_7_2     disj1_7_18_1  -1.0
    x_7_2     disj2_7_18_1  1.0
    x_7_2     disj1_7_19_1  -1.0
    x_7_2     disj2_7_19_1  1.0
    x_7_3     prec_7_2  1.0
    x_7_3     prec_7_3  -1.0
    x_7_3     disj1_0_7_2  1.0
    x_7_3     disj2_0_7_2  -1.0
    x_7_3     disj1_1_7_2  1.0
    x_7_3     disj2_1_7_2  -1.0
    x_7_3     disj1_2_7_2  1.0
    x_7_3     disj2_2_7_2  -1.0
    x_7_3     disj1_3_7_2  1.0
    x_7_3     disj2_3_7_2  -1.0
    x_7_3     disj1_4_7_2  1.0
    x_7_3     disj2_4_7_2  -1.0
    x_7_3     disj1_5_7_2  1.0
    x_7_3     disj2_5_7_2  -1.0
    x_7_3     disj1_6_7_2  1.0
    x_7_3     disj2_6_7_2  -1.0
    x_7_3     disj1_7_8_2  -1.0
    x_7_3     disj2_7_8_2  1.0
    x_7_3     disj1_7_9_2  -1.0
    x_7_3     disj2_7_9_2  1.0
    x_7_3     disj1_7_10_2  -1.0
    x_7_3     disj2_7_10_2  1.0
    x_7_3     disj1_7_11_2  -1.0
    x_7_3     disj2_7_11_2  1.0
    x_7_3     disj1_7_12_2  -1.0
    x_7_3     disj2_7_12_2  1.0
    x_7_3     disj1_7_13_2  -1.0
    x_7_3     disj2_7_13_2  1.0
    x_7_3     disj1_7_14_2  -1.0
    x_7_3     disj2_7_14_2  1.0
    x_7_3     disj1_7_15_2  -1.0
    x_7_3     disj2_7_15_2  1.0
    x_7_3     disj1_7_16_2  -1.0
    x_7_3     disj2_7_16_2  1.0
    x_7_3     disj1_7_17_2  -1.0
    x_7_3     disj2_7_17_2  1.0
    x_7_3     disj1_7_18_2  -1.0
    x_7_3     disj2_7_18_2  1.0
    x_7_3     disj1_7_19_2  -1.0
    x_7_3     disj2_7_19_2  1.0
    x_7_4     prec_7_3  1.0
    x_7_4     mksp_7    -1.0
    x_7_4     disj1_0_7_0  1.0
    x_7_4     disj2_0_7_0  -1.0
    x_7_4     disj1_1_7_0  1.0
    x_7_4     disj2_1_7_0  -1.0
    x_7_4     disj1_2_7_0  1.0
    x_7_4     disj2_2_7_0  -1.0
    x_7_4     disj1_3_7_0  1.0
    x_7_4     disj2_3_7_0  -1.0
    x_7_4     disj1_4_7_0  1.0
    x_7_4     disj2_4_7_0  -1.0
    x_7_4     disj1_5_7_0  1.0
    x_7_4     disj2_5_7_0  -1.0
    x_7_4     disj1_6_7_0  1.0
    x_7_4     disj2_6_7_0  -1.0
    x_7_4     disj1_7_8_0  -1.0
    x_7_4     disj2_7_8_0  1.0
    x_7_4     disj1_7_9_0  -1.0
    x_7_4     disj2_7_9_0  1.0
    x_7_4     disj1_7_10_0  -1.0
    x_7_4     disj2_7_10_0  1.0
    x_7_4     disj1_7_11_0  -1.0
    x_7_4     disj2_7_11_0  1.0
    x_7_4     disj1_7_12_0  -1.0
    x_7_4     disj2_7_12_0  1.0
    x_7_4     disj1_7_13_0  -1.0
    x_7_4     disj2_7_13_0  1.0
    x_7_4     disj1_7_14_0  -1.0
    x_7_4     disj2_7_14_0  1.0
    x_7_4     disj1_7_15_0  -1.0
    x_7_4     disj2_7_15_0  1.0
    x_7_4     disj1_7_16_0  -1.0
    x_7_4     disj2_7_16_0  1.0
    x_7_4     disj1_7_17_0  -1.0
    x_7_4     disj2_7_17_0  1.0
    x_7_4     disj1_7_18_0  -1.0
    x_7_4     disj2_7_18_0  1.0
    x_7_4     disj1_7_19_0  -1.0
    x_7_4     disj2_7_19_0  1.0
    x_8_0     prec_8_0  -1.0
    x_8_0     disj1_0_8_0  1.0
    x_8_0     disj2_0_8_0  -1.0
    x_8_0     disj1_1_8_0  1.0
    x_8_0     disj2_1_8_0  -1.0
    x_8_0     disj1_2_8_0  1.0
    x_8_0     disj2_2_8_0  -1.0
    x_8_0     disj1_3_8_0  1.0
    x_8_0     disj2_3_8_0  -1.0
    x_8_0     disj1_4_8_0  1.0
    x_8_0     disj2_4_8_0  -1.0
    x_8_0     disj1_5_8_0  1.0
    x_8_0     disj2_5_8_0  -1.0
    x_8_0     disj1_6_8_0  1.0
    x_8_0     disj2_6_8_0  -1.0
    x_8_0     disj1_7_8_0  1.0
    x_8_0     disj2_7_8_0  -1.0
    x_8_0     disj1_8_9_0  -1.0
    x_8_0     disj2_8_9_0  1.0
    x_8_0     disj1_8_10_0  -1.0
    x_8_0     disj2_8_10_0  1.0
    x_8_0     disj1_8_11_0  -1.0
    x_8_0     disj2_8_11_0  1.0
    x_8_0     disj1_8_12_0  -1.0
    x_8_0     disj2_8_12_0  1.0
    x_8_0     disj1_8_13_0  -1.0
    x_8_0     disj2_8_13_0  1.0
    x_8_0     disj1_8_14_0  -1.0
    x_8_0     disj2_8_14_0  1.0
    x_8_0     disj1_8_15_0  -1.0
    x_8_0     disj2_8_15_0  1.0
    x_8_0     disj1_8_16_0  -1.0
    x_8_0     disj2_8_16_0  1.0
    x_8_0     disj1_8_17_0  -1.0
    x_8_0     disj2_8_17_0  1.0
    x_8_0     disj1_8_18_0  -1.0
    x_8_0     disj2_8_18_0  1.0
    x_8_0     disj1_8_19_0  -1.0
    x_8_0     disj2_8_19_0  1.0
    x_8_1     prec_8_0  1.0
    x_8_1     prec_8_1  -1.0
    x_8_1     disj1_0_8_4  1.0
    x_8_1     disj2_0_8_4  -1.0
    x_8_1     disj1_1_8_4  1.0
    x_8_1     disj2_1_8_4  -1.0
    x_8_1     disj1_2_8_4  1.0
    x_8_1     disj2_2_8_4  -1.0
    x_8_1     disj1_3_8_4  1.0
    x_8_1     disj2_3_8_4  -1.0
    x_8_1     disj1_4_8_4  1.0
    x_8_1     disj2_4_8_4  -1.0
    x_8_1     disj1_5_8_4  1.0
    x_8_1     disj2_5_8_4  -1.0
    x_8_1     disj1_6_8_4  1.0
    x_8_1     disj2_6_8_4  -1.0
    x_8_1     disj1_7_8_4  1.0
    x_8_1     disj2_7_8_4  -1.0
    x_8_1     disj1_8_9_4  -1.0
    x_8_1     disj2_8_9_4  1.0
    x_8_1     disj1_8_10_4  -1.0
    x_8_1     disj2_8_10_4  1.0
    x_8_1     disj1_8_11_4  -1.0
    x_8_1     disj2_8_11_4  1.0
    x_8_1     disj1_8_12_4  -1.0
    x_8_1     disj2_8_12_4  1.0
    x_8_1     disj1_8_13_4  -1.0
    x_8_1     disj2_8_13_4  1.0
    x_8_1     disj1_8_14_4  -1.0
    x_8_1     disj2_8_14_4  1.0
    x_8_1     disj1_8_15_4  -1.0
    x_8_1     disj2_8_15_4  1.0
    x_8_1     disj1_8_16_4  -1.0
    x_8_1     disj2_8_16_4  1.0
    x_8_1     disj1_8_17_4  -1.0
    x_8_1     disj2_8_17_4  1.0
    x_8_1     disj1_8_18_4  -1.0
    x_8_1     disj2_8_18_4  1.0
    x_8_1     disj1_8_19_4  -1.0
    x_8_1     disj2_8_19_4  1.0
    x_8_2     prec_8_1  1.0
    x_8_2     prec_8_2  -1.0
    x_8_2     disj1_0_8_2  1.0
    x_8_2     disj2_0_8_2  -1.0
    x_8_2     disj1_1_8_2  1.0
    x_8_2     disj2_1_8_2  -1.0
    x_8_2     disj1_2_8_2  1.0
    x_8_2     disj2_2_8_2  -1.0
    x_8_2     disj1_3_8_2  1.0
    x_8_2     disj2_3_8_2  -1.0
    x_8_2     disj1_4_8_2  1.0
    x_8_2     disj2_4_8_2  -1.0
    x_8_2     disj1_5_8_2  1.0
    x_8_2     disj2_5_8_2  -1.0
    x_8_2     disj1_6_8_2  1.0
    x_8_2     disj2_6_8_2  -1.0
    x_8_2     disj1_7_8_2  1.0
    x_8_2     disj2_7_8_2  -1.0
    x_8_2     disj1_8_9_2  -1.0
    x_8_2     disj2_8_9_2  1.0
    x_8_2     disj1_8_10_2  -1.0
    x_8_2     disj2_8_10_2  1.0
    x_8_2     disj1_8_11_2  -1.0
    x_8_2     disj2_8_11_2  1.0
    x_8_2     disj1_8_12_2  -1.0
    x_8_2     disj2_8_12_2  1.0
    x_8_2     disj1_8_13_2  -1.0
    x_8_2     disj2_8_13_2  1.0
    x_8_2     disj1_8_14_2  -1.0
    x_8_2     disj2_8_14_2  1.0
    x_8_2     disj1_8_15_2  -1.0
    x_8_2     disj2_8_15_2  1.0
    x_8_2     disj1_8_16_2  -1.0
    x_8_2     disj2_8_16_2  1.0
    x_8_2     disj1_8_17_2  -1.0
    x_8_2     disj2_8_17_2  1.0
    x_8_2     disj1_8_18_2  -1.0
    x_8_2     disj2_8_18_2  1.0
    x_8_2     disj1_8_19_2  -1.0
    x_8_2     disj2_8_19_2  1.0
    x_8_3     prec_8_2  1.0
    x_8_3     prec_8_3  -1.0
    x_8_3     disj1_0_8_1  1.0
    x_8_3     disj2_0_8_1  -1.0
    x_8_3     disj1_1_8_1  1.0
    x_8_3     disj2_1_8_1  -1.0
    x_8_3     disj1_2_8_1  1.0
    x_8_3     disj2_2_8_1  -1.0
    x_8_3     disj1_3_8_1  1.0
    x_8_3     disj2_3_8_1  -1.0
    x_8_3     disj1_4_8_1  1.0
    x_8_3     disj2_4_8_1  -1.0
    x_8_3     disj1_5_8_1  1.0
    x_8_3     disj2_5_8_1  -1.0
    x_8_3     disj1_6_8_1  1.0
    x_8_3     disj2_6_8_1  -1.0
    x_8_3     disj1_7_8_1  1.0
    x_8_3     disj2_7_8_1  -1.0
    x_8_3     disj1_8_9_1  -1.0
    x_8_3     disj2_8_9_1  1.0
    x_8_3     disj1_8_10_1  -1.0
    x_8_3     disj2_8_10_1  1.0
    x_8_3     disj1_8_11_1  -1.0
    x_8_3     disj2_8_11_1  1.0
    x_8_3     disj1_8_12_1  -1.0
    x_8_3     disj2_8_12_1  1.0
    x_8_3     disj1_8_13_1  -1.0
    x_8_3     disj2_8_13_1  1.0
    x_8_3     disj1_8_14_1  -1.0
    x_8_3     disj2_8_14_1  1.0
    x_8_3     disj1_8_15_1  -1.0
    x_8_3     disj2_8_15_1  1.0
    x_8_3     disj1_8_16_1  -1.0
    x_8_3     disj2_8_16_1  1.0
    x_8_3     disj1_8_17_1  -1.0
    x_8_3     disj2_8_17_1  1.0
    x_8_3     disj1_8_18_1  -1.0
    x_8_3     disj2_8_18_1  1.0
    x_8_3     disj1_8_19_1  -1.0
    x_8_3     disj2_8_19_1  1.0
    x_8_4     prec_8_3  1.0
    x_8_4     mksp_8    -1.0
    x_8_4     disj1_0_8_3  1.0
    x_8_4     disj2_0_8_3  -1.0
    x_8_4     disj1_1_8_3  1.0
    x_8_4     disj2_1_8_3  -1.0
    x_8_4     disj1_2_8_3  1.0
    x_8_4     disj2_2_8_3  -1.0
    x_8_4     disj1_3_8_3  1.0
    x_8_4     disj2_3_8_3  -1.0
    x_8_4     disj1_4_8_3  1.0
    x_8_4     disj2_4_8_3  -1.0
    x_8_4     disj1_5_8_3  1.0
    x_8_4     disj2_5_8_3  -1.0
    x_8_4     disj1_6_8_3  1.0
    x_8_4     disj2_6_8_3  -1.0
    x_8_4     disj1_7_8_3  1.0
    x_8_4     disj2_7_8_3  -1.0
    x_8_4     disj1_8_9_3  -1.0
    x_8_4     disj2_8_9_3  1.0
    x_8_4     disj1_8_10_3  -1.0
    x_8_4     disj2_8_10_3  1.0
    x_8_4     disj1_8_11_3  -1.0
    x_8_4     disj2_8_11_3  1.0
    x_8_4     disj1_8_12_3  -1.0
    x_8_4     disj2_8_12_3  1.0
    x_8_4     disj1_8_13_3  -1.0
    x_8_4     disj2_8_13_3  1.0
    x_8_4     disj1_8_14_3  -1.0
    x_8_4     disj2_8_14_3  1.0
    x_8_4     disj1_8_15_3  -1.0
    x_8_4     disj2_8_15_3  1.0
    x_8_4     disj1_8_16_3  -1.0
    x_8_4     disj2_8_16_3  1.0
    x_8_4     disj1_8_17_3  -1.0
    x_8_4     disj2_8_17_3  1.0
    x_8_4     disj1_8_18_3  -1.0
    x_8_4     disj2_8_18_3  1.0
    x_8_4     disj1_8_19_3  -1.0
    x_8_4     disj2_8_19_3  1.0
    x_9_0     prec_9_0  -1.0
    x_9_0     disj1_0_9_1  1.0
    x_9_0     disj2_0_9_1  -1.0
    x_9_0     disj1_1_9_1  1.0
    x_9_0     disj2_1_9_1  -1.0
    x_9_0     disj1_2_9_1  1.0
    x_9_0     disj2_2_9_1  -1.0
    x_9_0     disj1_3_9_1  1.0
    x_9_0     disj2_3_9_1  -1.0
    x_9_0     disj1_4_9_1  1.0
    x_9_0     disj2_4_9_1  -1.0
    x_9_0     disj1_5_9_1  1.0
    x_9_0     disj2_5_9_1  -1.0
    x_9_0     disj1_6_9_1  1.0
    x_9_0     disj2_6_9_1  -1.0
    x_9_0     disj1_7_9_1  1.0
    x_9_0     disj2_7_9_1  -1.0
    x_9_0     disj1_8_9_1  1.0
    x_9_0     disj2_8_9_1  -1.0
    x_9_0     disj1_9_10_1  -1.0
    x_9_0     disj2_9_10_1  1.0
    x_9_0     disj1_9_11_1  -1.0
    x_9_0     disj2_9_11_1  1.0
    x_9_0     disj1_9_12_1  -1.0
    x_9_0     disj2_9_12_1  1.0
    x_9_0     disj1_9_13_1  -1.0
    x_9_0     disj2_9_13_1  1.0
    x_9_0     disj1_9_14_1  -1.0
    x_9_0     disj2_9_14_1  1.0
    x_9_0     disj1_9_15_1  -1.0
    x_9_0     disj2_9_15_1  1.0
    x_9_0     disj1_9_16_1  -1.0
    x_9_0     disj2_9_16_1  1.0
    x_9_0     disj1_9_17_1  -1.0
    x_9_0     disj2_9_17_1  1.0
    x_9_0     disj1_9_18_1  -1.0
    x_9_0     disj2_9_18_1  1.0
    x_9_0     disj1_9_19_1  -1.0
    x_9_0     disj2_9_19_1  1.0
    x_9_1     prec_9_0  1.0
    x_9_1     prec_9_1  -1.0
    x_9_1     disj1_0_9_0  1.0
    x_9_1     disj2_0_9_0  -1.0
    x_9_1     disj1_1_9_0  1.0
    x_9_1     disj2_1_9_0  -1.0
    x_9_1     disj1_2_9_0  1.0
    x_9_1     disj2_2_9_0  -1.0
    x_9_1     disj1_3_9_0  1.0
    x_9_1     disj2_3_9_0  -1.0
    x_9_1     disj1_4_9_0  1.0
    x_9_1     disj2_4_9_0  -1.0
    x_9_1     disj1_5_9_0  1.0
    x_9_1     disj2_5_9_0  -1.0
    x_9_1     disj1_6_9_0  1.0
    x_9_1     disj2_6_9_0  -1.0
    x_9_1     disj1_7_9_0  1.0
    x_9_1     disj2_7_9_0  -1.0
    x_9_1     disj1_8_9_0  1.0
    x_9_1     disj2_8_9_0  -1.0
    x_9_1     disj1_9_10_0  -1.0
    x_9_1     disj2_9_10_0  1.0
    x_9_1     disj1_9_11_0  -1.0
    x_9_1     disj2_9_11_0  1.0
    x_9_1     disj1_9_12_0  -1.0
    x_9_1     disj2_9_12_0  1.0
    x_9_1     disj1_9_13_0  -1.0
    x_9_1     disj2_9_13_0  1.0
    x_9_1     disj1_9_14_0  -1.0
    x_9_1     disj2_9_14_0  1.0
    x_9_1     disj1_9_15_0  -1.0
    x_9_1     disj2_9_15_0  1.0
    x_9_1     disj1_9_16_0  -1.0
    x_9_1     disj2_9_16_0  1.0
    x_9_1     disj1_9_17_0  -1.0
    x_9_1     disj2_9_17_0  1.0
    x_9_1     disj1_9_18_0  -1.0
    x_9_1     disj2_9_18_0  1.0
    x_9_1     disj1_9_19_0  -1.0
    x_9_1     disj2_9_19_0  1.0
    x_9_2     prec_9_1  1.0
    x_9_2     prec_9_2  -1.0
    x_9_2     disj1_0_9_3  1.0
    x_9_2     disj2_0_9_3  -1.0
    x_9_2     disj1_1_9_3  1.0
    x_9_2     disj2_1_9_3  -1.0
    x_9_2     disj1_2_9_3  1.0
    x_9_2     disj2_2_9_3  -1.0
    x_9_2     disj1_3_9_3  1.0
    x_9_2     disj2_3_9_3  -1.0
    x_9_2     disj1_4_9_3  1.0
    x_9_2     disj2_4_9_3  -1.0
    x_9_2     disj1_5_9_3  1.0
    x_9_2     disj2_5_9_3  -1.0
    x_9_2     disj1_6_9_3  1.0
    x_9_2     disj2_6_9_3  -1.0
    x_9_2     disj1_7_9_3  1.0
    x_9_2     disj2_7_9_3  -1.0
    x_9_2     disj1_8_9_3  1.0
    x_9_2     disj2_8_9_3  -1.0
    x_9_2     disj1_9_10_3  -1.0
    x_9_2     disj2_9_10_3  1.0
    x_9_2     disj1_9_11_3  -1.0
    x_9_2     disj2_9_11_3  1.0
    x_9_2     disj1_9_12_3  -1.0
    x_9_2     disj2_9_12_3  1.0
    x_9_2     disj1_9_13_3  -1.0
    x_9_2     disj2_9_13_3  1.0
    x_9_2     disj1_9_14_3  -1.0
    x_9_2     disj2_9_14_3  1.0
    x_9_2     disj1_9_15_3  -1.0
    x_9_2     disj2_9_15_3  1.0
    x_9_2     disj1_9_16_3  -1.0
    x_9_2     disj2_9_16_3  1.0
    x_9_2     disj1_9_17_3  -1.0
    x_9_2     disj2_9_17_3  1.0
    x_9_2     disj1_9_18_3  -1.0
    x_9_2     disj2_9_18_3  1.0
    x_9_2     disj1_9_19_3  -1.0
    x_9_2     disj2_9_19_3  1.0
    x_9_3     prec_9_2  1.0
    x_9_3     prec_9_3  -1.0
    x_9_3     disj1_0_9_2  1.0
    x_9_3     disj2_0_9_2  -1.0
    x_9_3     disj1_1_9_2  1.0
    x_9_3     disj2_1_9_2  -1.0
    x_9_3     disj1_2_9_2  1.0
    x_9_3     disj2_2_9_2  -1.0
    x_9_3     disj1_3_9_2  1.0
    x_9_3     disj2_3_9_2  -1.0
    x_9_3     disj1_4_9_2  1.0
    x_9_3     disj2_4_9_2  -1.0
    x_9_3     disj1_5_9_2  1.0
    x_9_3     disj2_5_9_2  -1.0
    x_9_3     disj1_6_9_2  1.0
    x_9_3     disj2_6_9_2  -1.0
    x_9_3     disj1_7_9_2  1.0
    x_9_3     disj2_7_9_2  -1.0
    x_9_3     disj1_8_9_2  1.0
    x_9_3     disj2_8_9_2  -1.0
    x_9_3     disj1_9_10_2  -1.0
    x_9_3     disj2_9_10_2  1.0
    x_9_3     disj1_9_11_2  -1.0
    x_9_3     disj2_9_11_2  1.0
    x_9_3     disj1_9_12_2  -1.0
    x_9_3     disj2_9_12_2  1.0
    x_9_3     disj1_9_13_2  -1.0
    x_9_3     disj2_9_13_2  1.0
    x_9_3     disj1_9_14_2  -1.0
    x_9_3     disj2_9_14_2  1.0
    x_9_3     disj1_9_15_2  -1.0
    x_9_3     disj2_9_15_2  1.0
    x_9_3     disj1_9_16_2  -1.0
    x_9_3     disj2_9_16_2  1.0
    x_9_3     disj1_9_17_2  -1.0
    x_9_3     disj2_9_17_2  1.0
    x_9_3     disj1_9_18_2  -1.0
    x_9_3     disj2_9_18_2  1.0
    x_9_3     disj1_9_19_2  -1.0
    x_9_3     disj2_9_19_2  1.0
    x_9_4     prec_9_3  1.0
    x_9_4     mksp_9    -1.0
    x_9_4     disj1_0_9_4  1.0
    x_9_4     disj2_0_9_4  -1.0
    x_9_4     disj1_1_9_4  1.0
    x_9_4     disj2_1_9_4  -1.0
    x_9_4     disj1_2_9_4  1.0
    x_9_4     disj2_2_9_4  -1.0
    x_9_4     disj1_3_9_4  1.0
    x_9_4     disj2_3_9_4  -1.0
    x_9_4     disj1_4_9_4  1.0
    x_9_4     disj2_4_9_4  -1.0
    x_9_4     disj1_5_9_4  1.0
    x_9_4     disj2_5_9_4  -1.0
    x_9_4     disj1_6_9_4  1.0
    x_9_4     disj2_6_9_4  -1.0
    x_9_4     disj1_7_9_4  1.0
    x_9_4     disj2_7_9_4  -1.0
    x_9_4     disj1_8_9_4  1.0
    x_9_4     disj2_8_9_4  -1.0
    x_9_4     disj1_9_10_4  -1.0
    x_9_4     disj2_9_10_4  1.0
    x_9_4     disj1_9_11_4  -1.0
    x_9_4     disj2_9_11_4  1.0
    x_9_4     disj1_9_12_4  -1.0
    x_9_4     disj2_9_12_4  1.0
    x_9_4     disj1_9_13_4  -1.0
    x_9_4     disj2_9_13_4  1.0
    x_9_4     disj1_9_14_4  -1.0
    x_9_4     disj2_9_14_4  1.0
    x_9_4     disj1_9_15_4  -1.0
    x_9_4     disj2_9_15_4  1.0
    x_9_4     disj1_9_16_4  -1.0
    x_9_4     disj2_9_16_4  1.0
    x_9_4     disj1_9_17_4  -1.0
    x_9_4     disj2_9_17_4  1.0
    x_9_4     disj1_9_18_4  -1.0
    x_9_4     disj2_9_18_4  1.0
    x_9_4     disj1_9_19_4  -1.0
    x_9_4     disj2_9_19_4  1.0
    x_10_0    prec_10_0  -1.0
    x_10_0    disj1_0_10_3  1.0
    x_10_0    disj2_0_10_3  -1.0
    x_10_0    disj1_1_10_3  1.0
    x_10_0    disj2_1_10_3  -1.0
    x_10_0    disj1_2_10_3  1.0
    x_10_0    disj2_2_10_3  -1.0
    x_10_0    disj1_3_10_3  1.0
    x_10_0    disj2_3_10_3  -1.0
    x_10_0    disj1_4_10_3  1.0
    x_10_0    disj2_4_10_3  -1.0
    x_10_0    disj1_5_10_3  1.0
    x_10_0    disj2_5_10_3  -1.0
    x_10_0    disj1_6_10_3  1.0
    x_10_0    disj2_6_10_3  -1.0
    x_10_0    disj1_7_10_3  1.0
    x_10_0    disj2_7_10_3  -1.0
    x_10_0    disj1_8_10_3  1.0
    x_10_0    disj2_8_10_3  -1.0
    x_10_0    disj1_9_10_3  1.0
    x_10_0    disj2_9_10_3  -1.0
    x_10_0    disj1_10_11_3  -1.0
    x_10_0    disj2_10_11_3  1.0
    x_10_0    disj1_10_12_3  -1.0
    x_10_0    disj2_10_12_3  1.0
    x_10_0    disj1_10_13_3  -1.0
    x_10_0    disj2_10_13_3  1.0
    x_10_0    disj1_10_14_3  -1.0
    x_10_0    disj2_10_14_3  1.0
    x_10_0    disj1_10_15_3  -1.0
    x_10_0    disj2_10_15_3  1.0
    x_10_0    disj1_10_16_3  -1.0
    x_10_0    disj2_10_16_3  1.0
    x_10_0    disj1_10_17_3  -1.0
    x_10_0    disj2_10_17_3  1.0
    x_10_0    disj1_10_18_3  -1.0
    x_10_0    disj2_10_18_3  1.0
    x_10_0    disj1_10_19_3  -1.0
    x_10_0    disj2_10_19_3  1.0
    x_10_1    prec_10_0  1.0
    x_10_1    prec_10_1  -1.0
    x_10_1    disj1_0_10_2  1.0
    x_10_1    disj2_0_10_2  -1.0
    x_10_1    disj1_1_10_2  1.0
    x_10_1    disj2_1_10_2  -1.0
    x_10_1    disj1_2_10_2  1.0
    x_10_1    disj2_2_10_2  -1.0
    x_10_1    disj1_3_10_2  1.0
    x_10_1    disj2_3_10_2  -1.0
    x_10_1    disj1_4_10_2  1.0
    x_10_1    disj2_4_10_2  -1.0
    x_10_1    disj1_5_10_2  1.0
    x_10_1    disj2_5_10_2  -1.0
    x_10_1    disj1_6_10_2  1.0
    x_10_1    disj2_6_10_2  -1.0
    x_10_1    disj1_7_10_2  1.0
    x_10_1    disj2_7_10_2  -1.0
    x_10_1    disj1_8_10_2  1.0
    x_10_1    disj2_8_10_2  -1.0
    x_10_1    disj1_9_10_2  1.0
    x_10_1    disj2_9_10_2  -1.0
    x_10_1    disj1_10_11_2  -1.0
    x_10_1    disj2_10_11_2  1.0
    x_10_1    disj1_10_12_2  -1.0
    x_10_1    disj2_10_12_2  1.0
    x_10_1    disj1_10_13_2  -1.0
    x_10_1    disj2_10_13_2  1.0
    x_10_1    disj1_10_14_2  -1.0
    x_10_1    disj2_10_14_2  1.0
    x_10_1    disj1_10_15_2  -1.0
    x_10_1    disj2_10_15_2  1.0
    x_10_1    disj1_10_16_2  -1.0
    x_10_1    disj2_10_16_2  1.0
    x_10_1    disj1_10_17_2  -1.0
    x_10_1    disj2_10_17_2  1.0
    x_10_1    disj1_10_18_2  -1.0
    x_10_1    disj2_10_18_2  1.0
    x_10_1    disj1_10_19_2  -1.0
    x_10_1    disj2_10_19_2  1.0
    x_10_2    prec_10_1  1.0
    x_10_2    prec_10_2  -1.0
    x_10_2    disj1_0_10_4  1.0
    x_10_2    disj2_0_10_4  -1.0
    x_10_2    disj1_1_10_4  1.0
    x_10_2    disj2_1_10_4  -1.0
    x_10_2    disj1_2_10_4  1.0
    x_10_2    disj2_2_10_4  -1.0
    x_10_2    disj1_3_10_4  1.0
    x_10_2    disj2_3_10_4  -1.0
    x_10_2    disj1_4_10_4  1.0
    x_10_2    disj2_4_10_4  -1.0
    x_10_2    disj1_5_10_4  1.0
    x_10_2    disj2_5_10_4  -1.0
    x_10_2    disj1_6_10_4  1.0
    x_10_2    disj2_6_10_4  -1.0
    x_10_2    disj1_7_10_4  1.0
    x_10_2    disj2_7_10_4  -1.0
    x_10_2    disj1_8_10_4  1.0
    x_10_2    disj2_8_10_4  -1.0
    x_10_2    disj1_9_10_4  1.0
    x_10_2    disj2_9_10_4  -1.0
    x_10_2    disj1_10_11_4  -1.0
    x_10_2    disj2_10_11_4  1.0
    x_10_2    disj1_10_12_4  -1.0
    x_10_2    disj2_10_12_4  1.0
    x_10_2    disj1_10_13_4  -1.0
    x_10_2    disj2_10_13_4  1.0
    x_10_2    disj1_10_14_4  -1.0
    x_10_2    disj2_10_14_4  1.0
    x_10_2    disj1_10_15_4  -1.0
    x_10_2    disj2_10_15_4  1.0
    x_10_2    disj1_10_16_4  -1.0
    x_10_2    disj2_10_16_4  1.0
    x_10_2    disj1_10_17_4  -1.0
    x_10_2    disj2_10_17_4  1.0
    x_10_2    disj1_10_18_4  -1.0
    x_10_2    disj2_10_18_4  1.0
    x_10_2    disj1_10_19_4  -1.0
    x_10_2    disj2_10_19_4  1.0
    x_10_3    prec_10_2  1.0
    x_10_3    prec_10_3  -1.0
    x_10_3    disj1_0_10_1  1.0
    x_10_3    disj2_0_10_1  -1.0
    x_10_3    disj1_1_10_1  1.0
    x_10_3    disj2_1_10_1  -1.0
    x_10_3    disj1_2_10_1  1.0
    x_10_3    disj2_2_10_1  -1.0
    x_10_3    disj1_3_10_1  1.0
    x_10_3    disj2_3_10_1  -1.0
    x_10_3    disj1_4_10_1  1.0
    x_10_3    disj2_4_10_1  -1.0
    x_10_3    disj1_5_10_1  1.0
    x_10_3    disj2_5_10_1  -1.0
    x_10_3    disj1_6_10_1  1.0
    x_10_3    disj2_6_10_1  -1.0
    x_10_3    disj1_7_10_1  1.0
    x_10_3    disj2_7_10_1  -1.0
    x_10_3    disj1_8_10_1  1.0
    x_10_3    disj2_8_10_1  -1.0
    x_10_3    disj1_9_10_1  1.0
    x_10_3    disj2_9_10_1  -1.0
    x_10_3    disj1_10_11_1  -1.0
    x_10_3    disj2_10_11_1  1.0
    x_10_3    disj1_10_12_1  -1.0
    x_10_3    disj2_10_12_1  1.0
    x_10_3    disj1_10_13_1  -1.0
    x_10_3    disj2_10_13_1  1.0
    x_10_3    disj1_10_14_1  -1.0
    x_10_3    disj2_10_14_1  1.0
    x_10_3    disj1_10_15_1  -1.0
    x_10_3    disj2_10_15_1  1.0
    x_10_3    disj1_10_16_1  -1.0
    x_10_3    disj2_10_16_1  1.0
    x_10_3    disj1_10_17_1  -1.0
    x_10_3    disj2_10_17_1  1.0
    x_10_3    disj1_10_18_1  -1.0
    x_10_3    disj2_10_18_1  1.0
    x_10_3    disj1_10_19_1  -1.0
    x_10_3    disj2_10_19_1  1.0
    x_10_4    prec_10_3  1.0
    x_10_4    mksp_10   -1.0
    x_10_4    disj1_0_10_0  1.0
    x_10_4    disj2_0_10_0  -1.0
    x_10_4    disj1_1_10_0  1.0
    x_10_4    disj2_1_10_0  -1.0
    x_10_4    disj1_2_10_0  1.0
    x_10_4    disj2_2_10_0  -1.0
    x_10_4    disj1_3_10_0  1.0
    x_10_4    disj2_3_10_0  -1.0
    x_10_4    disj1_4_10_0  1.0
    x_10_4    disj2_4_10_0  -1.0
    x_10_4    disj1_5_10_0  1.0
    x_10_4    disj2_5_10_0  -1.0
    x_10_4    disj1_6_10_0  1.0
    x_10_4    disj2_6_10_0  -1.0
    x_10_4    disj1_7_10_0  1.0
    x_10_4    disj2_7_10_0  -1.0
    x_10_4    disj1_8_10_0  1.0
    x_10_4    disj2_8_10_0  -1.0
    x_10_4    disj1_9_10_0  1.0
    x_10_4    disj2_9_10_0  -1.0
    x_10_4    disj1_10_11_0  -1.0
    x_10_4    disj2_10_11_0  1.0
    x_10_4    disj1_10_12_0  -1.0
    x_10_4    disj2_10_12_0  1.0
    x_10_4    disj1_10_13_0  -1.0
    x_10_4    disj2_10_13_0  1.0
    x_10_4    disj1_10_14_0  -1.0
    x_10_4    disj2_10_14_0  1.0
    x_10_4    disj1_10_15_0  -1.0
    x_10_4    disj2_10_15_0  1.0
    x_10_4    disj1_10_16_0  -1.0
    x_10_4    disj2_10_16_0  1.0
    x_10_4    disj1_10_17_0  -1.0
    x_10_4    disj2_10_17_0  1.0
    x_10_4    disj1_10_18_0  -1.0
    x_10_4    disj2_10_18_0  1.0
    x_10_4    disj1_10_19_0  -1.0
    x_10_4    disj2_10_19_0  1.0
    x_11_0    prec_11_0  -1.0
    x_11_0    disj1_0_11_2  1.0
    x_11_0    disj2_0_11_2  -1.0
    x_11_0    disj1_1_11_2  1.0
    x_11_0    disj2_1_11_2  -1.0
    x_11_0    disj1_2_11_2  1.0
    x_11_0    disj2_2_11_2  -1.0
    x_11_0    disj1_3_11_2  1.0
    x_11_0    disj2_3_11_2  -1.0
    x_11_0    disj1_4_11_2  1.0
    x_11_0    disj2_4_11_2  -1.0
    x_11_0    disj1_5_11_2  1.0
    x_11_0    disj2_5_11_2  -1.0
    x_11_0    disj1_6_11_2  1.0
    x_11_0    disj2_6_11_2  -1.0
    x_11_0    disj1_7_11_2  1.0
    x_11_0    disj2_7_11_2  -1.0
    x_11_0    disj1_8_11_2  1.0
    x_11_0    disj2_8_11_2  -1.0
    x_11_0    disj1_9_11_2  1.0
    x_11_0    disj2_9_11_2  -1.0
    x_11_0    disj1_10_11_2  1.0
    x_11_0    disj2_10_11_2  -1.0
    x_11_0    disj1_11_12_2  -1.0
    x_11_0    disj2_11_12_2  1.0
    x_11_0    disj1_11_13_2  -1.0
    x_11_0    disj2_11_13_2  1.0
    x_11_0    disj1_11_14_2  -1.0
    x_11_0    disj2_11_14_2  1.0
    x_11_0    disj1_11_15_2  -1.0
    x_11_0    disj2_11_15_2  1.0
    x_11_0    disj1_11_16_2  -1.0
    x_11_0    disj2_11_16_2  1.0
    x_11_0    disj1_11_17_2  -1.0
    x_11_0    disj2_11_17_2  1.0
    x_11_0    disj1_11_18_2  -1.0
    x_11_0    disj2_11_18_2  1.0
    x_11_0    disj1_11_19_2  -1.0
    x_11_0    disj2_11_19_2  1.0
    x_11_1    prec_11_0  1.0
    x_11_1    prec_11_1  -1.0
    x_11_1    disj1_0_11_0  1.0
    x_11_1    disj2_0_11_0  -1.0
    x_11_1    disj1_1_11_0  1.0
    x_11_1    disj2_1_11_0  -1.0
    x_11_1    disj1_2_11_0  1.0
    x_11_1    disj2_2_11_0  -1.0
    x_11_1    disj1_3_11_0  1.0
    x_11_1    disj2_3_11_0  -1.0
    x_11_1    disj1_4_11_0  1.0
    x_11_1    disj2_4_11_0  -1.0
    x_11_1    disj1_5_11_0  1.0
    x_11_1    disj2_5_11_0  -1.0
    x_11_1    disj1_6_11_0  1.0
    x_11_1    disj2_6_11_0  -1.0
    x_11_1    disj1_7_11_0  1.0
    x_11_1    disj2_7_11_0  -1.0
    x_11_1    disj1_8_11_0  1.0
    x_11_1    disj2_8_11_0  -1.0
    x_11_1    disj1_9_11_0  1.0
    x_11_1    disj2_9_11_0  -1.0
    x_11_1    disj1_10_11_0  1.0
    x_11_1    disj2_10_11_0  -1.0
    x_11_1    disj1_11_12_0  -1.0
    x_11_1    disj2_11_12_0  1.0
    x_11_1    disj1_11_13_0  -1.0
    x_11_1    disj2_11_13_0  1.0
    x_11_1    disj1_11_14_0  -1.0
    x_11_1    disj2_11_14_0  1.0
    x_11_1    disj1_11_15_0  -1.0
    x_11_1    disj2_11_15_0  1.0
    x_11_1    disj1_11_16_0  -1.0
    x_11_1    disj2_11_16_0  1.0
    x_11_1    disj1_11_17_0  -1.0
    x_11_1    disj2_11_17_0  1.0
    x_11_1    disj1_11_18_0  -1.0
    x_11_1    disj2_11_18_0  1.0
    x_11_1    disj1_11_19_0  -1.0
    x_11_1    disj2_11_19_0  1.0
    x_11_2    prec_11_1  1.0
    x_11_2    prec_11_2  -1.0
    x_11_2    disj1_0_11_1  1.0
    x_11_2    disj2_0_11_1  -1.0
    x_11_2    disj1_1_11_1  1.0
    x_11_2    disj2_1_11_1  -1.0
    x_11_2    disj1_2_11_1  1.0
    x_11_2    disj2_2_11_1  -1.0
    x_11_2    disj1_3_11_1  1.0
    x_11_2    disj2_3_11_1  -1.0
    x_11_2    disj1_4_11_1  1.0
    x_11_2    disj2_4_11_1  -1.0
    x_11_2    disj1_5_11_1  1.0
    x_11_2    disj2_5_11_1  -1.0
    x_11_2    disj1_6_11_1  1.0
    x_11_2    disj2_6_11_1  -1.0
    x_11_2    disj1_7_11_1  1.0
    x_11_2    disj2_7_11_1  -1.0
    x_11_2    disj1_8_11_1  1.0
    x_11_2    disj2_8_11_1  -1.0
    x_11_2    disj1_9_11_1  1.0
    x_11_2    disj2_9_11_1  -1.0
    x_11_2    disj1_10_11_1  1.0
    x_11_2    disj2_10_11_1  -1.0
    x_11_2    disj1_11_12_1  -1.0
    x_11_2    disj2_11_12_1  1.0
    x_11_2    disj1_11_13_1  -1.0
    x_11_2    disj2_11_13_1  1.0
    x_11_2    disj1_11_14_1  -1.0
    x_11_2    disj2_11_14_1  1.0
    x_11_2    disj1_11_15_1  -1.0
    x_11_2    disj2_11_15_1  1.0
    x_11_2    disj1_11_16_1  -1.0
    x_11_2    disj2_11_16_1  1.0
    x_11_2    disj1_11_17_1  -1.0
    x_11_2    disj2_11_17_1  1.0
    x_11_2    disj1_11_18_1  -1.0
    x_11_2    disj2_11_18_1  1.0
    x_11_2    disj1_11_19_1  -1.0
    x_11_2    disj2_11_19_1  1.0
    x_11_3    prec_11_2  1.0
    x_11_3    prec_11_3  -1.0
    x_11_3    disj1_0_11_3  1.0
    x_11_3    disj2_0_11_3  -1.0
    x_11_3    disj1_1_11_3  1.0
    x_11_3    disj2_1_11_3  -1.0
    x_11_3    disj1_2_11_3  1.0
    x_11_3    disj2_2_11_3  -1.0
    x_11_3    disj1_3_11_3  1.0
    x_11_3    disj2_3_11_3  -1.0
    x_11_3    disj1_4_11_3  1.0
    x_11_3    disj2_4_11_3  -1.0
    x_11_3    disj1_5_11_3  1.0
    x_11_3    disj2_5_11_3  -1.0
    x_11_3    disj1_6_11_3  1.0
    x_11_3    disj2_6_11_3  -1.0
    x_11_3    disj1_7_11_3  1.0
    x_11_3    disj2_7_11_3  -1.0
    x_11_3    disj1_8_11_3  1.0
    x_11_3    disj2_8_11_3  -1.0
    x_11_3    disj1_9_11_3  1.0
    x_11_3    disj2_9_11_3  -1.0
    x_11_3    disj1_10_11_3  1.0
    x_11_3    disj2_10_11_3  -1.0
    x_11_3    disj1_11_12_3  -1.0
    x_11_3    disj2_11_12_3  1.0
    x_11_3    disj1_11_13_3  -1.0
    x_11_3    disj2_11_13_3  1.0
    x_11_3    disj1_11_14_3  -1.0
    x_11_3    disj2_11_14_3  1.0
    x_11_3    disj1_11_15_3  -1.0
    x_11_3    disj2_11_15_3  1.0
    x_11_3    disj1_11_16_3  -1.0
    x_11_3    disj2_11_16_3  1.0
    x_11_3    disj1_11_17_3  -1.0
    x_11_3    disj2_11_17_3  1.0
    x_11_3    disj1_11_18_3  -1.0
    x_11_3    disj2_11_18_3  1.0
    x_11_3    disj1_11_19_3  -1.0
    x_11_3    disj2_11_19_3  1.0
    x_11_4    prec_11_3  1.0
    x_11_4    mksp_11   -1.0
    x_11_4    disj1_0_11_4  1.0
    x_11_4    disj2_0_11_4  -1.0
    x_11_4    disj1_1_11_4  1.0
    x_11_4    disj2_1_11_4  -1.0
    x_11_4    disj1_2_11_4  1.0
    x_11_4    disj2_2_11_4  -1.0
    x_11_4    disj1_3_11_4  1.0
    x_11_4    disj2_3_11_4  -1.0
    x_11_4    disj1_4_11_4  1.0
    x_11_4    disj2_4_11_4  -1.0
    x_11_4    disj1_5_11_4  1.0
    x_11_4    disj2_5_11_4  -1.0
    x_11_4    disj1_6_11_4  1.0
    x_11_4    disj2_6_11_4  -1.0
    x_11_4    disj1_7_11_4  1.0
    x_11_4    disj2_7_11_4  -1.0
    x_11_4    disj1_8_11_4  1.0
    x_11_4    disj2_8_11_4  -1.0
    x_11_4    disj1_9_11_4  1.0
    x_11_4    disj2_9_11_4  -1.0
    x_11_4    disj1_10_11_4  1.0
    x_11_4    disj2_10_11_4  -1.0
    x_11_4    disj1_11_12_4  -1.0
    x_11_4    disj2_11_12_4  1.0
    x_11_4    disj1_11_13_4  -1.0
    x_11_4    disj2_11_13_4  1.0
    x_11_4    disj1_11_14_4  -1.0
    x_11_4    disj2_11_14_4  1.0
    x_11_4    disj1_11_15_4  -1.0
    x_11_4    disj2_11_15_4  1.0
    x_11_4    disj1_11_16_4  -1.0
    x_11_4    disj2_11_16_4  1.0
    x_11_4    disj1_11_17_4  -1.0
    x_11_4    disj2_11_17_4  1.0
    x_11_4    disj1_11_18_4  -1.0
    x_11_4    disj2_11_18_4  1.0
    x_11_4    disj1_11_19_4  -1.0
    x_11_4    disj2_11_19_4  1.0
    x_12_0    prec_12_0  -1.0
    x_12_0    disj1_0_12_4  1.0
    x_12_0    disj2_0_12_4  -1.0
    x_12_0    disj1_1_12_4  1.0
    x_12_0    disj2_1_12_4  -1.0
    x_12_0    disj1_2_12_4  1.0
    x_12_0    disj2_2_12_4  -1.0
    x_12_0    disj1_3_12_4  1.0
    x_12_0    disj2_3_12_4  -1.0
    x_12_0    disj1_4_12_4  1.0
    x_12_0    disj2_4_12_4  -1.0
    x_12_0    disj1_5_12_4  1.0
    x_12_0    disj2_5_12_4  -1.0
    x_12_0    disj1_6_12_4  1.0
    x_12_0    disj2_6_12_4  -1.0
    x_12_0    disj1_7_12_4  1.0
    x_12_0    disj2_7_12_4  -1.0
    x_12_0    disj1_8_12_4  1.0
    x_12_0    disj2_8_12_4  -1.0
    x_12_0    disj1_9_12_4  1.0
    x_12_0    disj2_9_12_4  -1.0
    x_12_0    disj1_10_12_4  1.0
    x_12_0    disj2_10_12_4  -1.0
    x_12_0    disj1_11_12_4  1.0
    x_12_0    disj2_11_12_4  -1.0
    x_12_0    disj1_12_13_4  -1.0
    x_12_0    disj2_12_13_4  1.0
    x_12_0    disj1_12_14_4  -1.0
    x_12_0    disj2_12_14_4  1.0
    x_12_0    disj1_12_15_4  -1.0
    x_12_0    disj2_12_15_4  1.0
    x_12_0    disj1_12_16_4  -1.0
    x_12_0    disj2_12_16_4  1.0
    x_12_0    disj1_12_17_4  -1.0
    x_12_0    disj2_12_17_4  1.0
    x_12_0    disj1_12_18_4  -1.0
    x_12_0    disj2_12_18_4  1.0
    x_12_0    disj1_12_19_4  -1.0
    x_12_0    disj2_12_19_4  1.0
    x_12_1    prec_12_0  1.0
    x_12_1    prec_12_1  -1.0
    x_12_1    disj1_0_12_2  1.0
    x_12_1    disj2_0_12_2  -1.0
    x_12_1    disj1_1_12_2  1.0
    x_12_1    disj2_1_12_2  -1.0
    x_12_1    disj1_2_12_2  1.0
    x_12_1    disj2_2_12_2  -1.0
    x_12_1    disj1_3_12_2  1.0
    x_12_1    disj2_3_12_2  -1.0
    x_12_1    disj1_4_12_2  1.0
    x_12_1    disj2_4_12_2  -1.0
    x_12_1    disj1_5_12_2  1.0
    x_12_1    disj2_5_12_2  -1.0
    x_12_1    disj1_6_12_2  1.0
    x_12_1    disj2_6_12_2  -1.0
    x_12_1    disj1_7_12_2  1.0
    x_12_1    disj2_7_12_2  -1.0
    x_12_1    disj1_8_12_2  1.0
    x_12_1    disj2_8_12_2  -1.0
    x_12_1    disj1_9_12_2  1.0
    x_12_1    disj2_9_12_2  -1.0
    x_12_1    disj1_10_12_2  1.0
    x_12_1    disj2_10_12_2  -1.0
    x_12_1    disj1_11_12_2  1.0
    x_12_1    disj2_11_12_2  -1.0
    x_12_1    disj1_12_13_2  -1.0
    x_12_1    disj2_12_13_2  1.0
    x_12_1    disj1_12_14_2  -1.0
    x_12_1    disj2_12_14_2  1.0
    x_12_1    disj1_12_15_2  -1.0
    x_12_1    disj2_12_15_2  1.0
    x_12_1    disj1_12_16_2  -1.0
    x_12_1    disj2_12_16_2  1.0
    x_12_1    disj1_12_17_2  -1.0
    x_12_1    disj2_12_17_2  1.0
    x_12_1    disj1_12_18_2  -1.0
    x_12_1    disj2_12_18_2  1.0
    x_12_1    disj1_12_19_2  -1.0
    x_12_1    disj2_12_19_2  1.0
    x_12_2    prec_12_1  1.0
    x_12_2    prec_12_2  -1.0
    x_12_2    disj1_0_12_3  1.0
    x_12_2    disj2_0_12_3  -1.0
    x_12_2    disj1_1_12_3  1.0
    x_12_2    disj2_1_12_3  -1.0
    x_12_2    disj1_2_12_3  1.0
    x_12_2    disj2_2_12_3  -1.0
    x_12_2    disj1_3_12_3  1.0
    x_12_2    disj2_3_12_3  -1.0
    x_12_2    disj1_4_12_3  1.0
    x_12_2    disj2_4_12_3  -1.0
    x_12_2    disj1_5_12_3  1.0
    x_12_2    disj2_5_12_3  -1.0
    x_12_2    disj1_6_12_3  1.0
    x_12_2    disj2_6_12_3  -1.0
    x_12_2    disj1_7_12_3  1.0
    x_12_2    disj2_7_12_3  -1.0
    x_12_2    disj1_8_12_3  1.0
    x_12_2    disj2_8_12_3  -1.0
    x_12_2    disj1_9_12_3  1.0
    x_12_2    disj2_9_12_3  -1.0
    x_12_2    disj1_10_12_3  1.0
    x_12_2    disj2_10_12_3  -1.0
    x_12_2    disj1_11_12_3  1.0
    x_12_2    disj2_11_12_3  -1.0
    x_12_2    disj1_12_13_3  -1.0
    x_12_2    disj2_12_13_3  1.0
    x_12_2    disj1_12_14_3  -1.0
    x_12_2    disj2_12_14_3  1.0
    x_12_2    disj1_12_15_3  -1.0
    x_12_2    disj2_12_15_3  1.0
    x_12_2    disj1_12_16_3  -1.0
    x_12_2    disj2_12_16_3  1.0
    x_12_2    disj1_12_17_3  -1.0
    x_12_2    disj2_12_17_3  1.0
    x_12_2    disj1_12_18_3  -1.0
    x_12_2    disj2_12_18_3  1.0
    x_12_2    disj1_12_19_3  -1.0
    x_12_2    disj2_12_19_3  1.0
    x_12_3    prec_12_2  1.0
    x_12_3    prec_12_3  -1.0
    x_12_3    disj1_0_12_1  1.0
    x_12_3    disj2_0_12_1  -1.0
    x_12_3    disj1_1_12_1  1.0
    x_12_3    disj2_1_12_1  -1.0
    x_12_3    disj1_2_12_1  1.0
    x_12_3    disj2_2_12_1  -1.0
    x_12_3    disj1_3_12_1  1.0
    x_12_3    disj2_3_12_1  -1.0
    x_12_3    disj1_4_12_1  1.0
    x_12_3    disj2_4_12_1  -1.0
    x_12_3    disj1_5_12_1  1.0
    x_12_3    disj2_5_12_1  -1.0
    x_12_3    disj1_6_12_1  1.0
    x_12_3    disj2_6_12_1  -1.0
    x_12_3    disj1_7_12_1  1.0
    x_12_3    disj2_7_12_1  -1.0
    x_12_3    disj1_8_12_1  1.0
    x_12_3    disj2_8_12_1  -1.0
    x_12_3    disj1_9_12_1  1.0
    x_12_3    disj2_9_12_1  -1.0
    x_12_3    disj1_10_12_1  1.0
    x_12_3    disj2_10_12_1  -1.0
    x_12_3    disj1_11_12_1  1.0
    x_12_3    disj2_11_12_1  -1.0
    x_12_3    disj1_12_13_1  -1.0
    x_12_3    disj2_12_13_1  1.0
    x_12_3    disj1_12_14_1  -1.0
    x_12_3    disj2_12_14_1  1.0
    x_12_3    disj1_12_15_1  -1.0
    x_12_3    disj2_12_15_1  1.0
    x_12_3    disj1_12_16_1  -1.0
    x_12_3    disj2_12_16_1  1.0
    x_12_3    disj1_12_17_1  -1.0
    x_12_3    disj2_12_17_1  1.0
    x_12_3    disj1_12_18_1  -1.0
    x_12_3    disj2_12_18_1  1.0
    x_12_3    disj1_12_19_1  -1.0
    x_12_3    disj2_12_19_1  1.0
    x_12_4    prec_12_3  1.0
    x_12_4    mksp_12   -1.0
    x_12_4    disj1_0_12_0  1.0
    x_12_4    disj2_0_12_0  -1.0
    x_12_4    disj1_1_12_0  1.0
    x_12_4    disj2_1_12_0  -1.0
    x_12_4    disj1_2_12_0  1.0
    x_12_4    disj2_2_12_0  -1.0
    x_12_4    disj1_3_12_0  1.0
    x_12_4    disj2_3_12_0  -1.0
    x_12_4    disj1_4_12_0  1.0
    x_12_4    disj2_4_12_0  -1.0
    x_12_4    disj1_5_12_0  1.0
    x_12_4    disj2_5_12_0  -1.0
    x_12_4    disj1_6_12_0  1.0
    x_12_4    disj2_6_12_0  -1.0
    x_12_4    disj1_7_12_0  1.0
    x_12_4    disj2_7_12_0  -1.0
    x_12_4    disj1_8_12_0  1.0
    x_12_4    disj2_8_12_0  -1.0
    x_12_4    disj1_9_12_0  1.0
    x_12_4    disj2_9_12_0  -1.0
    x_12_4    disj1_10_12_0  1.0
    x_12_4    disj2_10_12_0  -1.0
    x_12_4    disj1_11_12_0  1.0
    x_12_4    disj2_11_12_0  -1.0
    x_12_4    disj1_12_13_0  -1.0
    x_12_4    disj2_12_13_0  1.0
    x_12_4    disj1_12_14_0  -1.0
    x_12_4    disj2_12_14_0  1.0
    x_12_4    disj1_12_15_0  -1.0
    x_12_4    disj2_12_15_0  1.0
    x_12_4    disj1_12_16_0  -1.0
    x_12_4    disj2_12_16_0  1.0
    x_12_4    disj1_12_17_0  -1.0
    x_12_4    disj2_12_17_0  1.0
    x_12_4    disj1_12_18_0  -1.0
    x_12_4    disj2_12_18_0  1.0
    x_12_4    disj1_12_19_0  -1.0
    x_12_4    disj2_12_19_0  1.0
    x_13_0    prec_13_0  -1.0
    x_13_0    disj1_0_13_1  1.0
    x_13_0    disj2_0_13_1  -1.0
    x_13_0    disj1_1_13_1  1.0
    x_13_0    disj2_1_13_1  -1.0
    x_13_0    disj1_2_13_1  1.0
    x_13_0    disj2_2_13_1  -1.0
    x_13_0    disj1_3_13_1  1.0
    x_13_0    disj2_3_13_1  -1.0
    x_13_0    disj1_4_13_1  1.0
    x_13_0    disj2_4_13_1  -1.0
    x_13_0    disj1_5_13_1  1.0
    x_13_0    disj2_5_13_1  -1.0
    x_13_0    disj1_6_13_1  1.0
    x_13_0    disj2_6_13_1  -1.0
    x_13_0    disj1_7_13_1  1.0
    x_13_0    disj2_7_13_1  -1.0
    x_13_0    disj1_8_13_1  1.0
    x_13_0    disj2_8_13_1  -1.0
    x_13_0    disj1_9_13_1  1.0
    x_13_0    disj2_9_13_1  -1.0
    x_13_0    disj1_10_13_1  1.0
    x_13_0    disj2_10_13_1  -1.0
    x_13_0    disj1_11_13_1  1.0
    x_13_0    disj2_11_13_1  -1.0
    x_13_0    disj1_12_13_1  1.0
    x_13_0    disj2_12_13_1  -1.0
    x_13_0    disj1_13_14_1  -1.0
    x_13_0    disj2_13_14_1  1.0
    x_13_0    disj1_13_15_1  -1.0
    x_13_0    disj2_13_15_1  1.0
    x_13_0    disj1_13_16_1  -1.0
    x_13_0    disj2_13_16_1  1.0
    x_13_0    disj1_13_17_1  -1.0
    x_13_0    disj2_13_17_1  1.0
    x_13_0    disj1_13_18_1  -1.0
    x_13_0    disj2_13_18_1  1.0
    x_13_0    disj1_13_19_1  -1.0
    x_13_0    disj2_13_19_1  1.0
    x_13_1    prec_13_0  1.0
    x_13_1    prec_13_1  -1.0
    x_13_1    disj1_0_13_4  1.0
    x_13_1    disj2_0_13_4  -1.0
    x_13_1    disj1_1_13_4  1.0
    x_13_1    disj2_1_13_4  -1.0
    x_13_1    disj1_2_13_4  1.0
    x_13_1    disj2_2_13_4  -1.0
    x_13_1    disj1_3_13_4  1.0
    x_13_1    disj2_3_13_4  -1.0
    x_13_1    disj1_4_13_4  1.0
    x_13_1    disj2_4_13_4  -1.0
    x_13_1    disj1_5_13_4  1.0
    x_13_1    disj2_5_13_4  -1.0
    x_13_1    disj1_6_13_4  1.0
    x_13_1    disj2_6_13_4  -1.0
    x_13_1    disj1_7_13_4  1.0
    x_13_1    disj2_7_13_4  -1.0
    x_13_1    disj1_8_13_4  1.0
    x_13_1    disj2_8_13_4  -1.0
    x_13_1    disj1_9_13_4  1.0
    x_13_1    disj2_9_13_4  -1.0
    x_13_1    disj1_10_13_4  1.0
    x_13_1    disj2_10_13_4  -1.0
    x_13_1    disj1_11_13_4  1.0
    x_13_1    disj2_11_13_4  -1.0
    x_13_1    disj1_12_13_4  1.0
    x_13_1    disj2_12_13_4  -1.0
    x_13_1    disj1_13_14_4  -1.0
    x_13_1    disj2_13_14_4  1.0
    x_13_1    disj1_13_15_4  -1.0
    x_13_1    disj2_13_15_4  1.0
    x_13_1    disj1_13_16_4  -1.0
    x_13_1    disj2_13_16_4  1.0
    x_13_1    disj1_13_17_4  -1.0
    x_13_1    disj2_13_17_4  1.0
    x_13_1    disj1_13_18_4  -1.0
    x_13_1    disj2_13_18_4  1.0
    x_13_1    disj1_13_19_4  -1.0
    x_13_1    disj2_13_19_4  1.0
    x_13_2    prec_13_1  1.0
    x_13_2    prec_13_2  -1.0
    x_13_2    disj1_0_13_0  1.0
    x_13_2    disj2_0_13_0  -1.0
    x_13_2    disj1_1_13_0  1.0
    x_13_2    disj2_1_13_0  -1.0
    x_13_2    disj1_2_13_0  1.0
    x_13_2    disj2_2_13_0  -1.0
    x_13_2    disj1_3_13_0  1.0
    x_13_2    disj2_3_13_0  -1.0
    x_13_2    disj1_4_13_0  1.0
    x_13_2    disj2_4_13_0  -1.0
    x_13_2    disj1_5_13_0  1.0
    x_13_2    disj2_5_13_0  -1.0
    x_13_2    disj1_6_13_0  1.0
    x_13_2    disj2_6_13_0  -1.0
    x_13_2    disj1_7_13_0  1.0
    x_13_2    disj2_7_13_0  -1.0
    x_13_2    disj1_8_13_0  1.0
    x_13_2    disj2_8_13_0  -1.0
    x_13_2    disj1_9_13_0  1.0
    x_13_2    disj2_9_13_0  -1.0
    x_13_2    disj1_10_13_0  1.0
    x_13_2    disj2_10_13_0  -1.0
    x_13_2    disj1_11_13_0  1.0
    x_13_2    disj2_11_13_0  -1.0
    x_13_2    disj1_12_13_0  1.0
    x_13_2    disj2_12_13_0  -1.0
    x_13_2    disj1_13_14_0  -1.0
    x_13_2    disj2_13_14_0  1.0
    x_13_2    disj1_13_15_0  -1.0
    x_13_2    disj2_13_15_0  1.0
    x_13_2    disj1_13_16_0  -1.0
    x_13_2    disj2_13_16_0  1.0
    x_13_2    disj1_13_17_0  -1.0
    x_13_2    disj2_13_17_0  1.0
    x_13_2    disj1_13_18_0  -1.0
    x_13_2    disj2_13_18_0  1.0
    x_13_2    disj1_13_19_0  -1.0
    x_13_2    disj2_13_19_0  1.0
    x_13_3    prec_13_2  1.0
    x_13_3    prec_13_3  -1.0
    x_13_3    disj1_0_13_2  1.0
    x_13_3    disj2_0_13_2  -1.0
    x_13_3    disj1_1_13_2  1.0
    x_13_3    disj2_1_13_2  -1.0
    x_13_3    disj1_2_13_2  1.0
    x_13_3    disj2_2_13_2  -1.0
    x_13_3    disj1_3_13_2  1.0
    x_13_3    disj2_3_13_2  -1.0
    x_13_3    disj1_4_13_2  1.0
    x_13_3    disj2_4_13_2  -1.0
    x_13_3    disj1_5_13_2  1.0
    x_13_3    disj2_5_13_2  -1.0
    x_13_3    disj1_6_13_2  1.0
    x_13_3    disj2_6_13_2  -1.0
    x_13_3    disj1_7_13_2  1.0
    x_13_3    disj2_7_13_2  -1.0
    x_13_3    disj1_8_13_2  1.0
    x_13_3    disj2_8_13_2  -1.0
    x_13_3    disj1_9_13_2  1.0
    x_13_3    disj2_9_13_2  -1.0
    x_13_3    disj1_10_13_2  1.0
    x_13_3    disj2_10_13_2  -1.0
    x_13_3    disj1_11_13_2  1.0
    x_13_3    disj2_11_13_2  -1.0
    x_13_3    disj1_12_13_2  1.0
    x_13_3    disj2_12_13_2  -1.0
    x_13_3    disj1_13_14_2  -1.0
    x_13_3    disj2_13_14_2  1.0
    x_13_3    disj1_13_15_2  -1.0
    x_13_3    disj2_13_15_2  1.0
    x_13_3    disj1_13_16_2  -1.0
    x_13_3    disj2_13_16_2  1.0
    x_13_3    disj1_13_17_2  -1.0
    x_13_3    disj2_13_17_2  1.0
    x_13_3    disj1_13_18_2  -1.0
    x_13_3    disj2_13_18_2  1.0
    x_13_3    disj1_13_19_2  -1.0
    x_13_3    disj2_13_19_2  1.0
    x_13_4    prec_13_3  1.0
    x_13_4    mksp_13   -1.0
    x_13_4    disj1_0_13_3  1.0
    x_13_4    disj2_0_13_3  -1.0
    x_13_4    disj1_1_13_3  1.0
    x_13_4    disj2_1_13_3  -1.0
    x_13_4    disj1_2_13_3  1.0
    x_13_4    disj2_2_13_3  -1.0
    x_13_4    disj1_3_13_3  1.0
    x_13_4    disj2_3_13_3  -1.0
    x_13_4    disj1_4_13_3  1.0
    x_13_4    disj2_4_13_3  -1.0
    x_13_4    disj1_5_13_3  1.0
    x_13_4    disj2_5_13_3  -1.0
    x_13_4    disj1_6_13_3  1.0
    x_13_4    disj2_6_13_3  -1.0
    x_13_4    disj1_7_13_3  1.0
    x_13_4    disj2_7_13_3  -1.0
    x_13_4    disj1_8_13_3  1.0
    x_13_4    disj2_8_13_3  -1.0
    x_13_4    disj1_9_13_3  1.0
    x_13_4    disj2_9_13_3  -1.0
    x_13_4    disj1_10_13_3  1.0
    x_13_4    disj2_10_13_3  -1.0
    x_13_4    disj1_11_13_3  1.0
    x_13_4    disj2_11_13_3  -1.0
    x_13_4    disj1_12_13_3  1.0
    x_13_4    disj2_12_13_3  -1.0
    x_13_4    disj1_13_14_3  -1.0
    x_13_4    disj2_13_14_3  1.0
    x_13_4    disj1_13_15_3  -1.0
    x_13_4    disj2_13_15_3  1.0
    x_13_4    disj1_13_16_3  -1.0
    x_13_4    disj2_13_16_3  1.0
    x_13_4    disj1_13_17_3  -1.0
    x_13_4    disj2_13_17_3  1.0
    x_13_4    disj1_13_18_3  -1.0
    x_13_4    disj2_13_18_3  1.0
    x_13_4    disj1_13_19_3  -1.0
    x_13_4    disj2_13_19_3  1.0
    x_14_0    prec_14_0  -1.0
    x_14_0    disj1_0_14_0  1.0
    x_14_0    disj2_0_14_0  -1.0
    x_14_0    disj1_1_14_0  1.0
    x_14_0    disj2_1_14_0  -1.0
    x_14_0    disj1_2_14_0  1.0
    x_14_0    disj2_2_14_0  -1.0
    x_14_0    disj1_3_14_0  1.0
    x_14_0    disj2_3_14_0  -1.0
    x_14_0    disj1_4_14_0  1.0
    x_14_0    disj2_4_14_0  -1.0
    x_14_0    disj1_5_14_0  1.0
    x_14_0    disj2_5_14_0  -1.0
    x_14_0    disj1_6_14_0  1.0
    x_14_0    disj2_6_14_0  -1.0
    x_14_0    disj1_7_14_0  1.0
    x_14_0    disj2_7_14_0  -1.0
    x_14_0    disj1_8_14_0  1.0
    x_14_0    disj2_8_14_0  -1.0
    x_14_0    disj1_9_14_0  1.0
    x_14_0    disj2_9_14_0  -1.0
    x_14_0    disj1_10_14_0  1.0
    x_14_0    disj2_10_14_0  -1.0
    x_14_0    disj1_11_14_0  1.0
    x_14_0    disj2_11_14_0  -1.0
    x_14_0    disj1_12_14_0  1.0
    x_14_0    disj2_12_14_0  -1.0
    x_14_0    disj1_13_14_0  1.0
    x_14_0    disj2_13_14_0  -1.0
    x_14_0    disj1_14_15_0  -1.0
    x_14_0    disj2_14_15_0  1.0
    x_14_0    disj1_14_16_0  -1.0
    x_14_0    disj2_14_16_0  1.0
    x_14_0    disj1_14_17_0  -1.0
    x_14_0    disj2_14_17_0  1.0
    x_14_0    disj1_14_18_0  -1.0
    x_14_0    disj2_14_18_0  1.0
    x_14_0    disj1_14_19_0  -1.0
    x_14_0    disj2_14_19_0  1.0
    x_14_1    prec_14_0  1.0
    x_14_1    prec_14_1  -1.0
    x_14_1    disj1_0_14_2  1.0
    x_14_1    disj2_0_14_2  -1.0
    x_14_1    disj1_1_14_2  1.0
    x_14_1    disj2_1_14_2  -1.0
    x_14_1    disj1_2_14_2  1.0
    x_14_1    disj2_2_14_2  -1.0
    x_14_1    disj1_3_14_2  1.0
    x_14_1    disj2_3_14_2  -1.0
    x_14_1    disj1_4_14_2  1.0
    x_14_1    disj2_4_14_2  -1.0
    x_14_1    disj1_5_14_2  1.0
    x_14_1    disj2_5_14_2  -1.0
    x_14_1    disj1_6_14_2  1.0
    x_14_1    disj2_6_14_2  -1.0
    x_14_1    disj1_7_14_2  1.0
    x_14_1    disj2_7_14_2  -1.0
    x_14_1    disj1_8_14_2  1.0
    x_14_1    disj2_8_14_2  -1.0
    x_14_1    disj1_9_14_2  1.0
    x_14_1    disj2_9_14_2  -1.0
    x_14_1    disj1_10_14_2  1.0
    x_14_1    disj2_10_14_2  -1.0
    x_14_1    disj1_11_14_2  1.0
    x_14_1    disj2_11_14_2  -1.0
    x_14_1    disj1_12_14_2  1.0
    x_14_1    disj2_12_14_2  -1.0
    x_14_1    disj1_13_14_2  1.0
    x_14_1    disj2_13_14_2  -1.0
    x_14_1    disj1_14_15_2  -1.0
    x_14_1    disj2_14_15_2  1.0
    x_14_1    disj1_14_16_2  -1.0
    x_14_1    disj2_14_16_2  1.0
    x_14_1    disj1_14_17_2  -1.0
    x_14_1    disj2_14_17_2  1.0
    x_14_1    disj1_14_18_2  -1.0
    x_14_1    disj2_14_18_2  1.0
    x_14_1    disj1_14_19_2  -1.0
    x_14_1    disj2_14_19_2  1.0
    x_14_2    prec_14_1  1.0
    x_14_2    prec_14_2  -1.0
    x_14_2    disj1_0_14_1  1.0
    x_14_2    disj2_0_14_1  -1.0
    x_14_2    disj1_1_14_1  1.0
    x_14_2    disj2_1_14_1  -1.0
    x_14_2    disj1_2_14_1  1.0
    x_14_2    disj2_2_14_1  -1.0
    x_14_2    disj1_3_14_1  1.0
    x_14_2    disj2_3_14_1  -1.0
    x_14_2    disj1_4_14_1  1.0
    x_14_2    disj2_4_14_1  -1.0
    x_14_2    disj1_5_14_1  1.0
    x_14_2    disj2_5_14_1  -1.0
    x_14_2    disj1_6_14_1  1.0
    x_14_2    disj2_6_14_1  -1.0
    x_14_2    disj1_7_14_1  1.0
    x_14_2    disj2_7_14_1  -1.0
    x_14_2    disj1_8_14_1  1.0
    x_14_2    disj2_8_14_1  -1.0
    x_14_2    disj1_9_14_1  1.0
    x_14_2    disj2_9_14_1  -1.0
    x_14_2    disj1_10_14_1  1.0
    x_14_2    disj2_10_14_1  -1.0
    x_14_2    disj1_11_14_1  1.0
    x_14_2    disj2_11_14_1  -1.0
    x_14_2    disj1_12_14_1  1.0
    x_14_2    disj2_12_14_1  -1.0
    x_14_2    disj1_13_14_1  1.0
    x_14_2    disj2_13_14_1  -1.0
    x_14_2    disj1_14_15_1  -1.0
    x_14_2    disj2_14_15_1  1.0
    x_14_2    disj1_14_16_1  -1.0
    x_14_2    disj2_14_16_1  1.0
    x_14_2    disj1_14_17_1  -1.0
    x_14_2    disj2_14_17_1  1.0
    x_14_2    disj1_14_18_1  -1.0
    x_14_2    disj2_14_18_1  1.0
    x_14_2    disj1_14_19_1  -1.0
    x_14_2    disj2_14_19_1  1.0
    x_14_3    prec_14_2  1.0
    x_14_3    prec_14_3  -1.0
    x_14_3    disj1_0_14_3  1.0
    x_14_3    disj2_0_14_3  -1.0
    x_14_3    disj1_1_14_3  1.0
    x_14_3    disj2_1_14_3  -1.0
    x_14_3    disj1_2_14_3  1.0
    x_14_3    disj2_2_14_3  -1.0
    x_14_3    disj1_3_14_3  1.0
    x_14_3    disj2_3_14_3  -1.0
    x_14_3    disj1_4_14_3  1.0
    x_14_3    disj2_4_14_3  -1.0
    x_14_3    disj1_5_14_3  1.0
    x_14_3    disj2_5_14_3  -1.0
    x_14_3    disj1_6_14_3  1.0
    x_14_3    disj2_6_14_3  -1.0
    x_14_3    disj1_7_14_3  1.0
    x_14_3    disj2_7_14_3  -1.0
    x_14_3    disj1_8_14_3  1.0
    x_14_3    disj2_8_14_3  -1.0
    x_14_3    disj1_9_14_3  1.0
    x_14_3    disj2_9_14_3  -1.0
    x_14_3    disj1_10_14_3  1.0
    x_14_3    disj2_10_14_3  -1.0
    x_14_3    disj1_11_14_3  1.0
    x_14_3    disj2_11_14_3  -1.0
    x_14_3    disj1_12_14_3  1.0
    x_14_3    disj2_12_14_3  -1.0
    x_14_3    disj1_13_14_3  1.0
    x_14_3    disj2_13_14_3  -1.0
    x_14_3    disj1_14_15_3  -1.0
    x_14_3    disj2_14_15_3  1.0
    x_14_3    disj1_14_16_3  -1.0
    x_14_3    disj2_14_16_3  1.0
    x_14_3    disj1_14_17_3  -1.0
    x_14_3    disj2_14_17_3  1.0
    x_14_3    disj1_14_18_3  -1.0
    x_14_3    disj2_14_18_3  1.0
    x_14_3    disj1_14_19_3  -1.0
    x_14_3    disj2_14_19_3  1.0
    x_14_4    prec_14_3  1.0
    x_14_4    mksp_14   -1.0
    x_14_4    disj1_0_14_4  1.0
    x_14_4    disj2_0_14_4  -1.0
    x_14_4    disj1_1_14_4  1.0
    x_14_4    disj2_1_14_4  -1.0
    x_14_4    disj1_2_14_4  1.0
    x_14_4    disj2_2_14_4  -1.0
    x_14_4    disj1_3_14_4  1.0
    x_14_4    disj2_3_14_4  -1.0
    x_14_4    disj1_4_14_4  1.0
    x_14_4    disj2_4_14_4  -1.0
    x_14_4    disj1_5_14_4  1.0
    x_14_4    disj2_5_14_4  -1.0
    x_14_4    disj1_6_14_4  1.0
    x_14_4    disj2_6_14_4  -1.0
    x_14_4    disj1_7_14_4  1.0
    x_14_4    disj2_7_14_4  -1.0
    x_14_4    disj1_8_14_4  1.0
    x_14_4    disj2_8_14_4  -1.0
    x_14_4    disj1_9_14_4  1.0
    x_14_4    disj2_9_14_4  -1.0
    x_14_4    disj1_10_14_4  1.0
    x_14_4    disj2_10_14_4  -1.0
    x_14_4    disj1_11_14_4  1.0
    x_14_4    disj2_11_14_4  -1.0
    x_14_4    disj1_12_14_4  1.0
    x_14_4    disj2_12_14_4  -1.0
    x_14_4    disj1_13_14_4  1.0
    x_14_4    disj2_13_14_4  -1.0
    x_14_4    disj1_14_15_4  -1.0
    x_14_4    disj2_14_15_4  1.0
    x_14_4    disj1_14_16_4  -1.0
    x_14_4    disj2_14_16_4  1.0
    x_14_4    disj1_14_17_4  -1.0
    x_14_4    disj2_14_17_4  1.0
    x_14_4    disj1_14_18_4  -1.0
    x_14_4    disj2_14_18_4  1.0
    x_14_4    disj1_14_19_4  -1.0
    x_14_4    disj2_14_19_4  1.0
    x_15_0    prec_15_0  -1.0
    x_15_0    disj1_0_15_2  1.0
    x_15_0    disj2_0_15_2  -1.0
    x_15_0    disj1_1_15_2  1.0
    x_15_0    disj2_1_15_2  -1.0
    x_15_0    disj1_2_15_2  1.0
    x_15_0    disj2_2_15_2  -1.0
    x_15_0    disj1_3_15_2  1.0
    x_15_0    disj2_3_15_2  -1.0
    x_15_0    disj1_4_15_2  1.0
    x_15_0    disj2_4_15_2  -1.0
    x_15_0    disj1_5_15_2  1.0
    x_15_0    disj2_5_15_2  -1.0
    x_15_0    disj1_6_15_2  1.0
    x_15_0    disj2_6_15_2  -1.0
    x_15_0    disj1_7_15_2  1.0
    x_15_0    disj2_7_15_2  -1.0
    x_15_0    disj1_8_15_2  1.0
    x_15_0    disj2_8_15_2  -1.0
    x_15_0    disj1_9_15_2  1.0
    x_15_0    disj2_9_15_2  -1.0
    x_15_0    disj1_10_15_2  1.0
    x_15_0    disj2_10_15_2  -1.0
    x_15_0    disj1_11_15_2  1.0
    x_15_0    disj2_11_15_2  -1.0
    x_15_0    disj1_12_15_2  1.0
    x_15_0    disj2_12_15_2  -1.0
    x_15_0    disj1_13_15_2  1.0
    x_15_0    disj2_13_15_2  -1.0
    x_15_0    disj1_14_15_2  1.0
    x_15_0    disj2_14_15_2  -1.0
    x_15_0    disj1_15_16_2  -1.0
    x_15_0    disj2_15_16_2  1.0
    x_15_0    disj1_15_17_2  -1.0
    x_15_0    disj2_15_17_2  1.0
    x_15_0    disj1_15_18_2  -1.0
    x_15_0    disj2_15_18_2  1.0
    x_15_0    disj1_15_19_2  -1.0
    x_15_0    disj2_15_19_2  1.0
    x_15_1    prec_15_0  1.0
    x_15_1    prec_15_1  -1.0
    x_15_1    disj1_0_15_3  1.0
    x_15_1    disj2_0_15_3  -1.0
    x_15_1    disj1_1_15_3  1.0
    x_15_1    disj2_1_15_3  -1.0
    x_15_1    disj1_2_15_3  1.0
    x_15_1    disj2_2_15_3  -1.0
    x_15_1    disj1_3_15_3  1.0
    x_15_1    disj2_3_15_3  -1.0
    x_15_1    disj1_4_15_3  1.0
    x_15_1    disj2_4_15_3  -1.0
    x_15_1    disj1_5_15_3  1.0
    x_15_1    disj2_5_15_3  -1.0
    x_15_1    disj1_6_15_3  1.0
    x_15_1    disj2_6_15_3  -1.0
    x_15_1    disj1_7_15_3  1.0
    x_15_1    disj2_7_15_3  -1.0
    x_15_1    disj1_8_15_3  1.0
    x_15_1    disj2_8_15_3  -1.0
    x_15_1    disj1_9_15_3  1.0
    x_15_1    disj2_9_15_3  -1.0
    x_15_1    disj1_10_15_3  1.0
    x_15_1    disj2_10_15_3  -1.0
    x_15_1    disj1_11_15_3  1.0
    x_15_1    disj2_11_15_3  -1.0
    x_15_1    disj1_12_15_3  1.0
    x_15_1    disj2_12_15_3  -1.0
    x_15_1    disj1_13_15_3  1.0
    x_15_1    disj2_13_15_3  -1.0
    x_15_1    disj1_14_15_3  1.0
    x_15_1    disj2_14_15_3  -1.0
    x_15_1    disj1_15_16_3  -1.0
    x_15_1    disj2_15_16_3  1.0
    x_15_1    disj1_15_17_3  -1.0
    x_15_1    disj2_15_17_3  1.0
    x_15_1    disj1_15_18_3  -1.0
    x_15_1    disj2_15_18_3  1.0
    x_15_1    disj1_15_19_3  -1.0
    x_15_1    disj2_15_19_3  1.0
    x_15_2    prec_15_1  1.0
    x_15_2    prec_15_2  -1.0
    x_15_2    disj1_0_15_1  1.0
    x_15_2    disj2_0_15_1  -1.0
    x_15_2    disj1_1_15_1  1.0
    x_15_2    disj2_1_15_1  -1.0
    x_15_2    disj1_2_15_1  1.0
    x_15_2    disj2_2_15_1  -1.0
    x_15_2    disj1_3_15_1  1.0
    x_15_2    disj2_3_15_1  -1.0
    x_15_2    disj1_4_15_1  1.0
    x_15_2    disj2_4_15_1  -1.0
    x_15_2    disj1_5_15_1  1.0
    x_15_2    disj2_5_15_1  -1.0
    x_15_2    disj1_6_15_1  1.0
    x_15_2    disj2_6_15_1  -1.0
    x_15_2    disj1_7_15_1  1.0
    x_15_2    disj2_7_15_1  -1.0
    x_15_2    disj1_8_15_1  1.0
    x_15_2    disj2_8_15_1  -1.0
    x_15_2    disj1_9_15_1  1.0
    x_15_2    disj2_9_15_1  -1.0
    x_15_2    disj1_10_15_1  1.0
    x_15_2    disj2_10_15_1  -1.0
    x_15_2    disj1_11_15_1  1.0
    x_15_2    disj2_11_15_1  -1.0
    x_15_2    disj1_12_15_1  1.0
    x_15_2    disj2_12_15_1  -1.0
    x_15_2    disj1_13_15_1  1.0
    x_15_2    disj2_13_15_1  -1.0
    x_15_2    disj1_14_15_1  1.0
    x_15_2    disj2_14_15_1  -1.0
    x_15_2    disj1_15_16_1  -1.0
    x_15_2    disj2_15_16_1  1.0
    x_15_2    disj1_15_17_1  -1.0
    x_15_2    disj2_15_17_1  1.0
    x_15_2    disj1_15_18_1  -1.0
    x_15_2    disj2_15_18_1  1.0
    x_15_2    disj1_15_19_1  -1.0
    x_15_2    disj2_15_19_1  1.0
    x_15_3    prec_15_2  1.0
    x_15_3    prec_15_3  -1.0
    x_15_3    disj1_0_15_4  1.0
    x_15_3    disj2_0_15_4  -1.0
    x_15_3    disj1_1_15_4  1.0
    x_15_3    disj2_1_15_4  -1.0
    x_15_3    disj1_2_15_4  1.0
    x_15_3    disj2_2_15_4  -1.0
    x_15_3    disj1_3_15_4  1.0
    x_15_3    disj2_3_15_4  -1.0
    x_15_3    disj1_4_15_4  1.0
    x_15_3    disj2_4_15_4  -1.0
    x_15_3    disj1_5_15_4  1.0
    x_15_3    disj2_5_15_4  -1.0
    x_15_3    disj1_6_15_4  1.0
    x_15_3    disj2_6_15_4  -1.0
    x_15_3    disj1_7_15_4  1.0
    x_15_3    disj2_7_15_4  -1.0
    x_15_3    disj1_8_15_4  1.0
    x_15_3    disj2_8_15_4  -1.0
    x_15_3    disj1_9_15_4  1.0
    x_15_3    disj2_9_15_4  -1.0
    x_15_3    disj1_10_15_4  1.0
    x_15_3    disj2_10_15_4  -1.0
    x_15_3    disj1_11_15_4  1.0
    x_15_3    disj2_11_15_4  -1.0
    x_15_3    disj1_12_15_4  1.0
    x_15_3    disj2_12_15_4  -1.0
    x_15_3    disj1_13_15_4  1.0
    x_15_3    disj2_13_15_4  -1.0
    x_15_3    disj1_14_15_4  1.0
    x_15_3    disj2_14_15_4  -1.0
    x_15_3    disj1_15_16_4  -1.0
    x_15_3    disj2_15_16_4  1.0
    x_15_3    disj1_15_17_4  -1.0
    x_15_3    disj2_15_17_4  1.0
    x_15_3    disj1_15_18_4  -1.0
    x_15_3    disj2_15_18_4  1.0
    x_15_3    disj1_15_19_4  -1.0
    x_15_3    disj2_15_19_4  1.0
    x_15_4    prec_15_3  1.0
    x_15_4    mksp_15   -1.0
    x_15_4    disj1_0_15_0  1.0
    x_15_4    disj2_0_15_0  -1.0
    x_15_4    disj1_1_15_0  1.0
    x_15_4    disj2_1_15_0  -1.0
    x_15_4    disj1_2_15_0  1.0
    x_15_4    disj2_2_15_0  -1.0
    x_15_4    disj1_3_15_0  1.0
    x_15_4    disj2_3_15_0  -1.0
    x_15_4    disj1_4_15_0  1.0
    x_15_4    disj2_4_15_0  -1.0
    x_15_4    disj1_5_15_0  1.0
    x_15_4    disj2_5_15_0  -1.0
    x_15_4    disj1_6_15_0  1.0
    x_15_4    disj2_6_15_0  -1.0
    x_15_4    disj1_7_15_0  1.0
    x_15_4    disj2_7_15_0  -1.0
    x_15_4    disj1_8_15_0  1.0
    x_15_4    disj2_8_15_0  -1.0
    x_15_4    disj1_9_15_0  1.0
    x_15_4    disj2_9_15_0  -1.0
    x_15_4    disj1_10_15_0  1.0
    x_15_4    disj2_10_15_0  -1.0
    x_15_4    disj1_11_15_0  1.0
    x_15_4    disj2_11_15_0  -1.0
    x_15_4    disj1_12_15_0  1.0
    x_15_4    disj2_12_15_0  -1.0
    x_15_4    disj1_13_15_0  1.0
    x_15_4    disj2_13_15_0  -1.0
    x_15_4    disj1_14_15_0  1.0
    x_15_4    disj2_14_15_0  -1.0
    x_15_4    disj1_15_16_0  -1.0
    x_15_4    disj2_15_16_0  1.0
    x_15_4    disj1_15_17_0  -1.0
    x_15_4    disj2_15_17_0  1.0
    x_15_4    disj1_15_18_0  -1.0
    x_15_4    disj2_15_18_0  1.0
    x_15_4    disj1_15_19_0  -1.0
    x_15_4    disj2_15_19_0  1.0
    x_16_0    prec_16_0  -1.0
    x_16_0    disj1_0_16_1  1.0
    x_16_0    disj2_0_16_1  -1.0
    x_16_0    disj1_1_16_1  1.0
    x_16_0    disj2_1_16_1  -1.0
    x_16_0    disj1_2_16_1  1.0
    x_16_0    disj2_2_16_1  -1.0
    x_16_0    disj1_3_16_1  1.0
    x_16_0    disj2_3_16_1  -1.0
    x_16_0    disj1_4_16_1  1.0
    x_16_0    disj2_4_16_1  -1.0
    x_16_0    disj1_5_16_1  1.0
    x_16_0    disj2_5_16_1  -1.0
    x_16_0    disj1_6_16_1  1.0
    x_16_0    disj2_6_16_1  -1.0
    x_16_0    disj1_7_16_1  1.0
    x_16_0    disj2_7_16_1  -1.0
    x_16_0    disj1_8_16_1  1.0
    x_16_0    disj2_8_16_1  -1.0
    x_16_0    disj1_9_16_1  1.0
    x_16_0    disj2_9_16_1  -1.0
    x_16_0    disj1_10_16_1  1.0
    x_16_0    disj2_10_16_1  -1.0
    x_16_0    disj1_11_16_1  1.0
    x_16_0    disj2_11_16_1  -1.0
    x_16_0    disj1_12_16_1  1.0
    x_16_0    disj2_12_16_1  -1.0
    x_16_0    disj1_13_16_1  1.0
    x_16_0    disj2_13_16_1  -1.0
    x_16_0    disj1_14_16_1  1.0
    x_16_0    disj2_14_16_1  -1.0
    x_16_0    disj1_15_16_1  1.0
    x_16_0    disj2_15_16_1  -1.0
    x_16_0    disj1_16_17_1  -1.0
    x_16_0    disj2_16_17_1  1.0
    x_16_0    disj1_16_18_1  -1.0
    x_16_0    disj2_16_18_1  1.0
    x_16_0    disj1_16_19_1  -1.0
    x_16_0    disj2_16_19_1  1.0
    x_16_1    prec_16_0  1.0
    x_16_1    prec_16_1  -1.0
    x_16_1    disj1_0_16_0  1.0
    x_16_1    disj2_0_16_0  -1.0
    x_16_1    disj1_1_16_0  1.0
    x_16_1    disj2_1_16_0  -1.0
    x_16_1    disj1_2_16_0  1.0
    x_16_1    disj2_2_16_0  -1.0
    x_16_1    disj1_3_16_0  1.0
    x_16_1    disj2_3_16_0  -1.0
    x_16_1    disj1_4_16_0  1.0
    x_16_1    disj2_4_16_0  -1.0
    x_16_1    disj1_5_16_0  1.0
    x_16_1    disj2_5_16_0  -1.0
    x_16_1    disj1_6_16_0  1.0
    x_16_1    disj2_6_16_0  -1.0
    x_16_1    disj1_7_16_0  1.0
    x_16_1    disj2_7_16_0  -1.0
    x_16_1    disj1_8_16_0  1.0
    x_16_1    disj2_8_16_0  -1.0
    x_16_1    disj1_9_16_0  1.0
    x_16_1    disj2_9_16_0  -1.0
    x_16_1    disj1_10_16_0  1.0
    x_16_1    disj2_10_16_0  -1.0
    x_16_1    disj1_11_16_0  1.0
    x_16_1    disj2_11_16_0  -1.0
    x_16_1    disj1_12_16_0  1.0
    x_16_1    disj2_12_16_0  -1.0
    x_16_1    disj1_13_16_0  1.0
    x_16_1    disj2_13_16_0  -1.0
    x_16_1    disj1_14_16_0  1.0
    x_16_1    disj2_14_16_0  -1.0
    x_16_1    disj1_15_16_0  1.0
    x_16_1    disj2_15_16_0  -1.0
    x_16_1    disj1_16_17_0  -1.0
    x_16_1    disj2_16_17_0  1.0
    x_16_1    disj1_16_18_0  -1.0
    x_16_1    disj2_16_18_0  1.0
    x_16_1    disj1_16_19_0  -1.0
    x_16_1    disj2_16_19_0  1.0
    x_16_2    prec_16_1  1.0
    x_16_2    prec_16_2  -1.0
    x_16_2    disj1_0_16_4  1.0
    x_16_2    disj2_0_16_4  -1.0
    x_16_2    disj1_1_16_4  1.0
    x_16_2    disj2_1_16_4  -1.0
    x_16_2    disj1_2_16_4  1.0
    x_16_2    disj2_2_16_4  -1.0
    x_16_2    disj1_3_16_4  1.0
    x_16_2    disj2_3_16_4  -1.0
    x_16_2    disj1_4_16_4  1.0
    x_16_2    disj2_4_16_4  -1.0
    x_16_2    disj1_5_16_4  1.0
    x_16_2    disj2_5_16_4  -1.0
    x_16_2    disj1_6_16_4  1.0
    x_16_2    disj2_6_16_4  -1.0
    x_16_2    disj1_7_16_4  1.0
    x_16_2    disj2_7_16_4  -1.0
    x_16_2    disj1_8_16_4  1.0
    x_16_2    disj2_8_16_4  -1.0
    x_16_2    disj1_9_16_4  1.0
    x_16_2    disj2_9_16_4  -1.0
    x_16_2    disj1_10_16_4  1.0
    x_16_2    disj2_10_16_4  -1.0
    x_16_2    disj1_11_16_4  1.0
    x_16_2    disj2_11_16_4  -1.0
    x_16_2    disj1_12_16_4  1.0
    x_16_2    disj2_12_16_4  -1.0
    x_16_2    disj1_13_16_4  1.0
    x_16_2    disj2_13_16_4  -1.0
    x_16_2    disj1_14_16_4  1.0
    x_16_2    disj2_14_16_4  -1.0
    x_16_2    disj1_15_16_4  1.0
    x_16_2    disj2_15_16_4  -1.0
    x_16_2    disj1_16_17_4  -1.0
    x_16_2    disj2_16_17_4  1.0
    x_16_2    disj1_16_18_4  -1.0
    x_16_2    disj2_16_18_4  1.0
    x_16_2    disj1_16_19_4  -1.0
    x_16_2    disj2_16_19_4  1.0
    x_16_3    prec_16_2  1.0
    x_16_3    prec_16_3  -1.0
    x_16_3    disj1_0_16_2  1.0
    x_16_3    disj2_0_16_2  -1.0
    x_16_3    disj1_1_16_2  1.0
    x_16_3    disj2_1_16_2  -1.0
    x_16_3    disj1_2_16_2  1.0
    x_16_3    disj2_2_16_2  -1.0
    x_16_3    disj1_3_16_2  1.0
    x_16_3    disj2_3_16_2  -1.0
    x_16_3    disj1_4_16_2  1.0
    x_16_3    disj2_4_16_2  -1.0
    x_16_3    disj1_5_16_2  1.0
    x_16_3    disj2_5_16_2  -1.0
    x_16_3    disj1_6_16_2  1.0
    x_16_3    disj2_6_16_2  -1.0
    x_16_3    disj1_7_16_2  1.0
    x_16_3    disj2_7_16_2  -1.0
    x_16_3    disj1_8_16_2  1.0
    x_16_3    disj2_8_16_2  -1.0
    x_16_3    disj1_9_16_2  1.0
    x_16_3    disj2_9_16_2  -1.0
    x_16_3    disj1_10_16_2  1.0
    x_16_3    disj2_10_16_2  -1.0
    x_16_3    disj1_11_16_2  1.0
    x_16_3    disj2_11_16_2  -1.0
    x_16_3    disj1_12_16_2  1.0
    x_16_3    disj2_12_16_2  -1.0
    x_16_3    disj1_13_16_2  1.0
    x_16_3    disj2_13_16_2  -1.0
    x_16_3    disj1_14_16_2  1.0
    x_16_3    disj2_14_16_2  -1.0
    x_16_3    disj1_15_16_2  1.0
    x_16_3    disj2_15_16_2  -1.0
    x_16_3    disj1_16_17_2  -1.0
    x_16_3    disj2_16_17_2  1.0
    x_16_3    disj1_16_18_2  -1.0
    x_16_3    disj2_16_18_2  1.0
    x_16_3    disj1_16_19_2  -1.0
    x_16_3    disj2_16_19_2  1.0
    x_16_4    prec_16_3  1.0
    x_16_4    mksp_16   -1.0
    x_16_4    disj1_0_16_3  1.0
    x_16_4    disj2_0_16_3  -1.0
    x_16_4    disj1_1_16_3  1.0
    x_16_4    disj2_1_16_3  -1.0
    x_16_4    disj1_2_16_3  1.0
    x_16_4    disj2_2_16_3  -1.0
    x_16_4    disj1_3_16_3  1.0
    x_16_4    disj2_3_16_3  -1.0
    x_16_4    disj1_4_16_3  1.0
    x_16_4    disj2_4_16_3  -1.0
    x_16_4    disj1_5_16_3  1.0
    x_16_4    disj2_5_16_3  -1.0
    x_16_4    disj1_6_16_3  1.0
    x_16_4    disj2_6_16_3  -1.0
    x_16_4    disj1_7_16_3  1.0
    x_16_4    disj2_7_16_3  -1.0
    x_16_4    disj1_8_16_3  1.0
    x_16_4    disj2_8_16_3  -1.0
    x_16_4    disj1_9_16_3  1.0
    x_16_4    disj2_9_16_3  -1.0
    x_16_4    disj1_10_16_3  1.0
    x_16_4    disj2_10_16_3  -1.0
    x_16_4    disj1_11_16_3  1.0
    x_16_4    disj2_11_16_3  -1.0
    x_16_4    disj1_12_16_3  1.0
    x_16_4    disj2_12_16_3  -1.0
    x_16_4    disj1_13_16_3  1.0
    x_16_4    disj2_13_16_3  -1.0
    x_16_4    disj1_14_16_3  1.0
    x_16_4    disj2_14_16_3  -1.0
    x_16_4    disj1_15_16_3  1.0
    x_16_4    disj2_15_16_3  -1.0
    x_16_4    disj1_16_17_3  -1.0
    x_16_4    disj2_16_17_3  1.0
    x_16_4    disj1_16_18_3  -1.0
    x_16_4    disj2_16_18_3  1.0
    x_16_4    disj1_16_19_3  -1.0
    x_16_4    disj2_16_19_3  1.0
    x_17_0    prec_17_0  -1.0
    x_17_0    disj1_0_17_3  1.0
    x_17_0    disj2_0_17_3  -1.0
    x_17_0    disj1_1_17_3  1.0
    x_17_0    disj2_1_17_3  -1.0
    x_17_0    disj1_2_17_3  1.0
    x_17_0    disj2_2_17_3  -1.0
    x_17_0    disj1_3_17_3  1.0
    x_17_0    disj2_3_17_3  -1.0
    x_17_0    disj1_4_17_3  1.0
    x_17_0    disj2_4_17_3  -1.0
    x_17_0    disj1_5_17_3  1.0
    x_17_0    disj2_5_17_3  -1.0
    x_17_0    disj1_6_17_3  1.0
    x_17_0    disj2_6_17_3  -1.0
    x_17_0    disj1_7_17_3  1.0
    x_17_0    disj2_7_17_3  -1.0
    x_17_0    disj1_8_17_3  1.0
    x_17_0    disj2_8_17_3  -1.0
    x_17_0    disj1_9_17_3  1.0
    x_17_0    disj2_9_17_3  -1.0
    x_17_0    disj1_10_17_3  1.0
    x_17_0    disj2_10_17_3  -1.0
    x_17_0    disj1_11_17_3  1.0
    x_17_0    disj2_11_17_3  -1.0
    x_17_0    disj1_12_17_3  1.0
    x_17_0    disj2_12_17_3  -1.0
    x_17_0    disj1_13_17_3  1.0
    x_17_0    disj2_13_17_3  -1.0
    x_17_0    disj1_14_17_3  1.0
    x_17_0    disj2_14_17_3  -1.0
    x_17_0    disj1_15_17_3  1.0
    x_17_0    disj2_15_17_3  -1.0
    x_17_0    disj1_16_17_3  1.0
    x_17_0    disj2_16_17_3  -1.0
    x_17_0    disj1_17_18_3  -1.0
    x_17_0    disj2_17_18_3  1.0
    x_17_0    disj1_17_19_3  -1.0
    x_17_0    disj2_17_19_3  1.0
    x_17_1    prec_17_0  1.0
    x_17_1    prec_17_1  -1.0
    x_17_1    disj1_0_17_2  1.0
    x_17_1    disj2_0_17_2  -1.0
    x_17_1    disj1_1_17_2  1.0
    x_17_1    disj2_1_17_2  -1.0
    x_17_1    disj1_2_17_2  1.0
    x_17_1    disj2_2_17_2  -1.0
    x_17_1    disj1_3_17_2  1.0
    x_17_1    disj2_3_17_2  -1.0
    x_17_1    disj1_4_17_2  1.0
    x_17_1    disj2_4_17_2  -1.0
    x_17_1    disj1_5_17_2  1.0
    x_17_1    disj2_5_17_2  -1.0
    x_17_1    disj1_6_17_2  1.0
    x_17_1    disj2_6_17_2  -1.0
    x_17_1    disj1_7_17_2  1.0
    x_17_1    disj2_7_17_2  -1.0
    x_17_1    disj1_8_17_2  1.0
    x_17_1    disj2_8_17_2  -1.0
    x_17_1    disj1_9_17_2  1.0
    x_17_1    disj2_9_17_2  -1.0
    x_17_1    disj1_10_17_2  1.0
    x_17_1    disj2_10_17_2  -1.0
    x_17_1    disj1_11_17_2  1.0
    x_17_1    disj2_11_17_2  -1.0
    x_17_1    disj1_12_17_2  1.0
    x_17_1    disj2_12_17_2  -1.0
    x_17_1    disj1_13_17_2  1.0
    x_17_1    disj2_13_17_2  -1.0
    x_17_1    disj1_14_17_2  1.0
    x_17_1    disj2_14_17_2  -1.0
    x_17_1    disj1_15_17_2  1.0
    x_17_1    disj2_15_17_2  -1.0
    x_17_1    disj1_16_17_2  1.0
    x_17_1    disj2_16_17_2  -1.0
    x_17_1    disj1_17_18_2  -1.0
    x_17_1    disj2_17_18_2  1.0
    x_17_1    disj1_17_19_2  -1.0
    x_17_1    disj2_17_19_2  1.0
    x_17_2    prec_17_1  1.0
    x_17_2    prec_17_2  -1.0
    x_17_2    disj1_0_17_0  1.0
    x_17_2    disj2_0_17_0  -1.0
    x_17_2    disj1_1_17_0  1.0
    x_17_2    disj2_1_17_0  -1.0
    x_17_2    disj1_2_17_0  1.0
    x_17_2    disj2_2_17_0  -1.0
    x_17_2    disj1_3_17_0  1.0
    x_17_2    disj2_3_17_0  -1.0
    x_17_2    disj1_4_17_0  1.0
    x_17_2    disj2_4_17_0  -1.0
    x_17_2    disj1_5_17_0  1.0
    x_17_2    disj2_5_17_0  -1.0
    x_17_2    disj1_6_17_0  1.0
    x_17_2    disj2_6_17_0  -1.0
    x_17_2    disj1_7_17_0  1.0
    x_17_2    disj2_7_17_0  -1.0
    x_17_2    disj1_8_17_0  1.0
    x_17_2    disj2_8_17_0  -1.0
    x_17_2    disj1_9_17_0  1.0
    x_17_2    disj2_9_17_0  -1.0
    x_17_2    disj1_10_17_0  1.0
    x_17_2    disj2_10_17_0  -1.0
    x_17_2    disj1_11_17_0  1.0
    x_17_2    disj2_11_17_0  -1.0
    x_17_2    disj1_12_17_0  1.0
    x_17_2    disj2_12_17_0  -1.0
    x_17_2    disj1_13_17_0  1.0
    x_17_2    disj2_13_17_0  -1.0
    x_17_2    disj1_14_17_0  1.0
    x_17_2    disj2_14_17_0  -1.0
    x_17_2    disj1_15_17_0  1.0
    x_17_2    disj2_15_17_0  -1.0
    x_17_2    disj1_16_17_0  1.0
    x_17_2    disj2_16_17_0  -1.0
    x_17_2    disj1_17_18_0  -1.0
    x_17_2    disj2_17_18_0  1.0
    x_17_2    disj1_17_19_0  -1.0
    x_17_2    disj2_17_19_0  1.0
    x_17_3    prec_17_2  1.0
    x_17_3    prec_17_3  -1.0
    x_17_3    disj1_0_17_4  1.0
    x_17_3    disj2_0_17_4  -1.0
    x_17_3    disj1_1_17_4  1.0
    x_17_3    disj2_1_17_4  -1.0
    x_17_3    disj1_2_17_4  1.0
    x_17_3    disj2_2_17_4  -1.0
    x_17_3    disj1_3_17_4  1.0
    x_17_3    disj2_3_17_4  -1.0
    x_17_3    disj1_4_17_4  1.0
    x_17_3    disj2_4_17_4  -1.0
    x_17_3    disj1_5_17_4  1.0
    x_17_3    disj2_5_17_4  -1.0
    x_17_3    disj1_6_17_4  1.0
    x_17_3    disj2_6_17_4  -1.0
    x_17_3    disj1_7_17_4  1.0
    x_17_3    disj2_7_17_4  -1.0
    x_17_3    disj1_8_17_4  1.0
    x_17_3    disj2_8_17_4  -1.0
    x_17_3    disj1_9_17_4  1.0
    x_17_3    disj2_9_17_4  -1.0
    x_17_3    disj1_10_17_4  1.0
    x_17_3    disj2_10_17_4  -1.0
    x_17_3    disj1_11_17_4  1.0
    x_17_3    disj2_11_17_4  -1.0
    x_17_3    disj1_12_17_4  1.0
    x_17_3    disj2_12_17_4  -1.0
    x_17_3    disj1_13_17_4  1.0
    x_17_3    disj2_13_17_4  -1.0
    x_17_3    disj1_14_17_4  1.0
    x_17_3    disj2_14_17_4  -1.0
    x_17_3    disj1_15_17_4  1.0
    x_17_3    disj2_15_17_4  -1.0
    x_17_3    disj1_16_17_4  1.0
    x_17_3    disj2_16_17_4  -1.0
    x_17_3    disj1_17_18_4  -1.0
    x_17_3    disj2_17_18_4  1.0
    x_17_3    disj1_17_19_4  -1.0
    x_17_3    disj2_17_19_4  1.0
    x_17_4    prec_17_3  1.0
    x_17_4    mksp_17   -1.0
    x_17_4    disj1_0_17_1  1.0
    x_17_4    disj2_0_17_1  -1.0
    x_17_4    disj1_1_17_1  1.0
    x_17_4    disj2_1_17_1  -1.0
    x_17_4    disj1_2_17_1  1.0
    x_17_4    disj2_2_17_1  -1.0
    x_17_4    disj1_3_17_1  1.0
    x_17_4    disj2_3_17_1  -1.0
    x_17_4    disj1_4_17_1  1.0
    x_17_4    disj2_4_17_1  -1.0
    x_17_4    disj1_5_17_1  1.0
    x_17_4    disj2_5_17_1  -1.0
    x_17_4    disj1_6_17_1  1.0
    x_17_4    disj2_6_17_1  -1.0
    x_17_4    disj1_7_17_1  1.0
    x_17_4    disj2_7_17_1  -1.0
    x_17_4    disj1_8_17_1  1.0
    x_17_4    disj2_8_17_1  -1.0
    x_17_4    disj1_9_17_1  1.0
    x_17_4    disj2_9_17_1  -1.0
    x_17_4    disj1_10_17_1  1.0
    x_17_4    disj2_10_17_1  -1.0
    x_17_4    disj1_11_17_1  1.0
    x_17_4    disj2_11_17_1  -1.0
    x_17_4    disj1_12_17_1  1.0
    x_17_4    disj2_12_17_1  -1.0
    x_17_4    disj1_13_17_1  1.0
    x_17_4    disj2_13_17_1  -1.0
    x_17_4    disj1_14_17_1  1.0
    x_17_4    disj2_14_17_1  -1.0
    x_17_4    disj1_15_17_1  1.0
    x_17_4    disj2_15_17_1  -1.0
    x_17_4    disj1_16_17_1  1.0
    x_17_4    disj2_16_17_1  -1.0
    x_17_4    disj1_17_18_1  -1.0
    x_17_4    disj2_17_18_1  1.0
    x_17_4    disj1_17_19_1  -1.0
    x_17_4    disj2_17_19_1  1.0
    x_18_0    prec_18_0  -1.0
    x_18_0    disj1_0_18_4  1.0
    x_18_0    disj2_0_18_4  -1.0
    x_18_0    disj1_1_18_4  1.0
    x_18_0    disj2_1_18_4  -1.0
    x_18_0    disj1_2_18_4  1.0
    x_18_0    disj2_2_18_4  -1.0
    x_18_0    disj1_3_18_4  1.0
    x_18_0    disj2_3_18_4  -1.0
    x_18_0    disj1_4_18_4  1.0
    x_18_0    disj2_4_18_4  -1.0
    x_18_0    disj1_5_18_4  1.0
    x_18_0    disj2_5_18_4  -1.0
    x_18_0    disj1_6_18_4  1.0
    x_18_0    disj2_6_18_4  -1.0
    x_18_0    disj1_7_18_4  1.0
    x_18_0    disj2_7_18_4  -1.0
    x_18_0    disj1_8_18_4  1.0
    x_18_0    disj2_8_18_4  -1.0
    x_18_0    disj1_9_18_4  1.0
    x_18_0    disj2_9_18_4  -1.0
    x_18_0    disj1_10_18_4  1.0
    x_18_0    disj2_10_18_4  -1.0
    x_18_0    disj1_11_18_4  1.0
    x_18_0    disj2_11_18_4  -1.0
    x_18_0    disj1_12_18_4  1.0
    x_18_0    disj2_12_18_4  -1.0
    x_18_0    disj1_13_18_4  1.0
    x_18_0    disj2_13_18_4  -1.0
    x_18_0    disj1_14_18_4  1.0
    x_18_0    disj2_14_18_4  -1.0
    x_18_0    disj1_15_18_4  1.0
    x_18_0    disj2_15_18_4  -1.0
    x_18_0    disj1_16_18_4  1.0
    x_18_0    disj2_16_18_4  -1.0
    x_18_0    disj1_17_18_4  1.0
    x_18_0    disj2_17_18_4  -1.0
    x_18_0    disj1_18_19_4  -1.0
    x_18_0    disj2_18_19_4  1.0
    x_18_1    prec_18_0  1.0
    x_18_1    prec_18_1  -1.0
    x_18_1    disj1_0_18_1  1.0
    x_18_1    disj2_0_18_1  -1.0
    x_18_1    disj1_1_18_1  1.0
    x_18_1    disj2_1_18_1  -1.0
    x_18_1    disj1_2_18_1  1.0
    x_18_1    disj2_2_18_1  -1.0
    x_18_1    disj1_3_18_1  1.0
    x_18_1    disj2_3_18_1  -1.0
    x_18_1    disj1_4_18_1  1.0
    x_18_1    disj2_4_18_1  -1.0
    x_18_1    disj1_5_18_1  1.0
    x_18_1    disj2_5_18_1  -1.0
    x_18_1    disj1_6_18_1  1.0
    x_18_1    disj2_6_18_1  -1.0
    x_18_1    disj1_7_18_1  1.0
    x_18_1    disj2_7_18_1  -1.0
    x_18_1    disj1_8_18_1  1.0
    x_18_1    disj2_8_18_1  -1.0
    x_18_1    disj1_9_18_1  1.0
    x_18_1    disj2_9_18_1  -1.0
    x_18_1    disj1_10_18_1  1.0
    x_18_1    disj2_10_18_1  -1.0
    x_18_1    disj1_11_18_1  1.0
    x_18_1    disj2_11_18_1  -1.0
    x_18_1    disj1_12_18_1  1.0
    x_18_1    disj2_12_18_1  -1.0
    x_18_1    disj1_13_18_1  1.0
    x_18_1    disj2_13_18_1  -1.0
    x_18_1    disj1_14_18_1  1.0
    x_18_1    disj2_14_18_1  -1.0
    x_18_1    disj1_15_18_1  1.0
    x_18_1    disj2_15_18_1  -1.0
    x_18_1    disj1_16_18_1  1.0
    x_18_1    disj2_16_18_1  -1.0
    x_18_1    disj1_17_18_1  1.0
    x_18_1    disj2_17_18_1  -1.0
    x_18_1    disj1_18_19_1  -1.0
    x_18_1    disj2_18_19_1  1.0
    x_18_2    prec_18_1  1.0
    x_18_2    prec_18_2  -1.0
    x_18_2    disj1_0_18_3  1.0
    x_18_2    disj2_0_18_3  -1.0
    x_18_2    disj1_1_18_3  1.0
    x_18_2    disj2_1_18_3  -1.0
    x_18_2    disj1_2_18_3  1.0
    x_18_2    disj2_2_18_3  -1.0
    x_18_2    disj1_3_18_3  1.0
    x_18_2    disj2_3_18_3  -1.0
    x_18_2    disj1_4_18_3  1.0
    x_18_2    disj2_4_18_3  -1.0
    x_18_2    disj1_5_18_3  1.0
    x_18_2    disj2_5_18_3  -1.0
    x_18_2    disj1_6_18_3  1.0
    x_18_2    disj2_6_18_3  -1.0
    x_18_2    disj1_7_18_3  1.0
    x_18_2    disj2_7_18_3  -1.0
    x_18_2    disj1_8_18_3  1.0
    x_18_2    disj2_8_18_3  -1.0
    x_18_2    disj1_9_18_3  1.0
    x_18_2    disj2_9_18_3  -1.0
    x_18_2    disj1_10_18_3  1.0
    x_18_2    disj2_10_18_3  -1.0
    x_18_2    disj1_11_18_3  1.0
    x_18_2    disj2_11_18_3  -1.0
    x_18_2    disj1_12_18_3  1.0
    x_18_2    disj2_12_18_3  -1.0
    x_18_2    disj1_13_18_3  1.0
    x_18_2    disj2_13_18_3  -1.0
    x_18_2    disj1_14_18_3  1.0
    x_18_2    disj2_14_18_3  -1.0
    x_18_2    disj1_15_18_3  1.0
    x_18_2    disj2_15_18_3  -1.0
    x_18_2    disj1_16_18_3  1.0
    x_18_2    disj2_16_18_3  -1.0
    x_18_2    disj1_17_18_3  1.0
    x_18_2    disj2_17_18_3  -1.0
    x_18_2    disj1_18_19_3  -1.0
    x_18_2    disj2_18_19_3  1.0
    x_18_3    prec_18_2  1.0
    x_18_3    prec_18_3  -1.0
    x_18_3    disj1_0_18_0  1.0
    x_18_3    disj2_0_18_0  -1.0
    x_18_3    disj1_1_18_0  1.0
    x_18_3    disj2_1_18_0  -1.0
    x_18_3    disj1_2_18_0  1.0
    x_18_3    disj2_2_18_0  -1.0
    x_18_3    disj1_3_18_0  1.0
    x_18_3    disj2_3_18_0  -1.0
    x_18_3    disj1_4_18_0  1.0
    x_18_3    disj2_4_18_0  -1.0
    x_18_3    disj1_5_18_0  1.0
    x_18_3    disj2_5_18_0  -1.0
    x_18_3    disj1_6_18_0  1.0
    x_18_3    disj2_6_18_0  -1.0
    x_18_3    disj1_7_18_0  1.0
    x_18_3    disj2_7_18_0  -1.0
    x_18_3    disj1_8_18_0  1.0
    x_18_3    disj2_8_18_0  -1.0
    x_18_3    disj1_9_18_0  1.0
    x_18_3    disj2_9_18_0  -1.0
    x_18_3    disj1_10_18_0  1.0
    x_18_3    disj2_10_18_0  -1.0
    x_18_3    disj1_11_18_0  1.0
    x_18_3    disj2_11_18_0  -1.0
    x_18_3    disj1_12_18_0  1.0
    x_18_3    disj2_12_18_0  -1.0
    x_18_3    disj1_13_18_0  1.0
    x_18_3    disj2_13_18_0  -1.0
    x_18_3    disj1_14_18_0  1.0
    x_18_3    disj2_14_18_0  -1.0
    x_18_3    disj1_15_18_0  1.0
    x_18_3    disj2_15_18_0  -1.0
    x_18_3    disj1_16_18_0  1.0
    x_18_3    disj2_16_18_0  -1.0
    x_18_3    disj1_17_18_0  1.0
    x_18_3    disj2_17_18_0  -1.0
    x_18_3    disj1_18_19_0  -1.0
    x_18_3    disj2_18_19_0  1.0
    x_18_4    prec_18_3  1.0
    x_18_4    mksp_18   -1.0
    x_18_4    disj1_0_18_2  1.0
    x_18_4    disj2_0_18_2  -1.0
    x_18_4    disj1_1_18_2  1.0
    x_18_4    disj2_1_18_2  -1.0
    x_18_4    disj1_2_18_2  1.0
    x_18_4    disj2_2_18_2  -1.0
    x_18_4    disj1_3_18_2  1.0
    x_18_4    disj2_3_18_2  -1.0
    x_18_4    disj1_4_18_2  1.0
    x_18_4    disj2_4_18_2  -1.0
    x_18_4    disj1_5_18_2  1.0
    x_18_4    disj2_5_18_2  -1.0
    x_18_4    disj1_6_18_2  1.0
    x_18_4    disj2_6_18_2  -1.0
    x_18_4    disj1_7_18_2  1.0
    x_18_4    disj2_7_18_2  -1.0
    x_18_4    disj1_8_18_2  1.0
    x_18_4    disj2_8_18_2  -1.0
    x_18_4    disj1_9_18_2  1.0
    x_18_4    disj2_9_18_2  -1.0
    x_18_4    disj1_10_18_2  1.0
    x_18_4    disj2_10_18_2  -1.0
    x_18_4    disj1_11_18_2  1.0
    x_18_4    disj2_11_18_2  -1.0
    x_18_4    disj1_12_18_2  1.0
    x_18_4    disj2_12_18_2  -1.0
    x_18_4    disj1_13_18_2  1.0
    x_18_4    disj2_13_18_2  -1.0
    x_18_4    disj1_14_18_2  1.0
    x_18_4    disj2_14_18_2  -1.0
    x_18_4    disj1_15_18_2  1.0
    x_18_4    disj2_15_18_2  -1.0
    x_18_4    disj1_16_18_2  1.0
    x_18_4    disj2_16_18_2  -1.0
    x_18_4    disj1_17_18_2  1.0
    x_18_4    disj2_17_18_2  -1.0
    x_18_4    disj1_18_19_2  -1.0
    x_18_4    disj2_18_19_2  1.0
    x_19_0    prec_19_0  -1.0
    x_19_0    disj1_0_19_0  1.0
    x_19_0    disj2_0_19_0  -1.0
    x_19_0    disj1_1_19_0  1.0
    x_19_0    disj2_1_19_0  -1.0
    x_19_0    disj1_2_19_0  1.0
    x_19_0    disj2_2_19_0  -1.0
    x_19_0    disj1_3_19_0  1.0
    x_19_0    disj2_3_19_0  -1.0
    x_19_0    disj1_4_19_0  1.0
    x_19_0    disj2_4_19_0  -1.0
    x_19_0    disj1_5_19_0  1.0
    x_19_0    disj2_5_19_0  -1.0
    x_19_0    disj1_6_19_0  1.0
    x_19_0    disj2_6_19_0  -1.0
    x_19_0    disj1_7_19_0  1.0
    x_19_0    disj2_7_19_0  -1.0
    x_19_0    disj1_8_19_0  1.0
    x_19_0    disj2_8_19_0  -1.0
    x_19_0    disj1_9_19_0  1.0
    x_19_0    disj2_9_19_0  -1.0
    x_19_0    disj1_10_19_0  1.0
    x_19_0    disj2_10_19_0  -1.0
    x_19_0    disj1_11_19_0  1.0
    x_19_0    disj2_11_19_0  -1.0
    x_19_0    disj1_12_19_0  1.0
    x_19_0    disj2_12_19_0  -1.0
    x_19_0    disj1_13_19_0  1.0
    x_19_0    disj2_13_19_0  -1.0
    x_19_0    disj1_14_19_0  1.0
    x_19_0    disj2_14_19_0  -1.0
    x_19_0    disj1_15_19_0  1.0
    x_19_0    disj2_15_19_0  -1.0
    x_19_0    disj1_16_19_0  1.0
    x_19_0    disj2_16_19_0  -1.0
    x_19_0    disj1_17_19_0  1.0
    x_19_0    disj2_17_19_0  -1.0
    x_19_0    disj1_18_19_0  1.0
    x_19_0    disj2_18_19_0  -1.0
    x_19_1    prec_19_0  1.0
    x_19_1    prec_19_1  -1.0
    x_19_1    disj1_0_19_2  1.0
    x_19_1    disj2_0_19_2  -1.0
    x_19_1    disj1_1_19_2  1.0
    x_19_1    disj2_1_19_2  -1.0
    x_19_1    disj1_2_19_2  1.0
    x_19_1    disj2_2_19_2  -1.0
    x_19_1    disj1_3_19_2  1.0
    x_19_1    disj2_3_19_2  -1.0
    x_19_1    disj1_4_19_2  1.0
    x_19_1    disj2_4_19_2  -1.0
    x_19_1    disj1_5_19_2  1.0
    x_19_1    disj2_5_19_2  -1.0
    x_19_1    disj1_6_19_2  1.0
    x_19_1    disj2_6_19_2  -1.0
    x_19_1    disj1_7_19_2  1.0
    x_19_1    disj2_7_19_2  -1.0
    x_19_1    disj1_8_19_2  1.0
    x_19_1    disj2_8_19_2  -1.0
    x_19_1    disj1_9_19_2  1.0
    x_19_1    disj2_9_19_2  -1.0
    x_19_1    disj1_10_19_2  1.0
    x_19_1    disj2_10_19_2  -1.0
    x_19_1    disj1_11_19_2  1.0
    x_19_1    disj2_11_19_2  -1.0
    x_19_1    disj1_12_19_2  1.0
    x_19_1    disj2_12_19_2  -1.0
    x_19_1    disj1_13_19_2  1.0
    x_19_1    disj2_13_19_2  -1.0
    x_19_1    disj1_14_19_2  1.0
    x_19_1    disj2_14_19_2  -1.0
    x_19_1    disj1_15_19_2  1.0
    x_19_1    disj2_15_19_2  -1.0
    x_19_1    disj1_16_19_2  1.0
    x_19_1    disj2_16_19_2  -1.0
    x_19_1    disj1_17_19_2  1.0
    x_19_1    disj2_17_19_2  -1.0
    x_19_1    disj1_18_19_2  1.0
    x_19_1    disj2_18_19_2  -1.0
    x_19_2    prec_19_1  1.0
    x_19_2    prec_19_2  -1.0
    x_19_2    disj1_0_19_4  1.0
    x_19_2    disj2_0_19_4  -1.0
    x_19_2    disj1_1_19_4  1.0
    x_19_2    disj2_1_19_4  -1.0
    x_19_2    disj1_2_19_4  1.0
    x_19_2    disj2_2_19_4  -1.0
    x_19_2    disj1_3_19_4  1.0
    x_19_2    disj2_3_19_4  -1.0
    x_19_2    disj1_4_19_4  1.0
    x_19_2    disj2_4_19_4  -1.0
    x_19_2    disj1_5_19_4  1.0
    x_19_2    disj2_5_19_4  -1.0
    x_19_2    disj1_6_19_4  1.0
    x_19_2    disj2_6_19_4  -1.0
    x_19_2    disj1_7_19_4  1.0
    x_19_2    disj2_7_19_4  -1.0
    x_19_2    disj1_8_19_4  1.0
    x_19_2    disj2_8_19_4  -1.0
    x_19_2    disj1_9_19_4  1.0
    x_19_2    disj2_9_19_4  -1.0
    x_19_2    disj1_10_19_4  1.0
    x_19_2    disj2_10_19_4  -1.0
    x_19_2    disj1_11_19_4  1.0
    x_19_2    disj2_11_19_4  -1.0
    x_19_2    disj1_12_19_4  1.0
    x_19_2    disj2_12_19_4  -1.0
    x_19_2    disj1_13_19_4  1.0
    x_19_2    disj2_13_19_4  -1.0
    x_19_2    disj1_14_19_4  1.0
    x_19_2    disj2_14_19_4  -1.0
    x_19_2    disj1_15_19_4  1.0
    x_19_2    disj2_15_19_4  -1.0
    x_19_2    disj1_16_19_4  1.0
    x_19_2    disj2_16_19_4  -1.0
    x_19_2    disj1_17_19_4  1.0
    x_19_2    disj2_17_19_4  -1.0
    x_19_2    disj1_18_19_4  1.0
    x_19_2    disj2_18_19_4  -1.0
    x_19_3    prec_19_2  1.0
    x_19_3    prec_19_3  -1.0
    x_19_3    disj1_0_19_3  1.0
    x_19_3    disj2_0_19_3  -1.0
    x_19_3    disj1_1_19_3  1.0
    x_19_3    disj2_1_19_3  -1.0
    x_19_3    disj1_2_19_3  1.0
    x_19_3    disj2_2_19_3  -1.0
    x_19_3    disj1_3_19_3  1.0
    x_19_3    disj2_3_19_3  -1.0
    x_19_3    disj1_4_19_3  1.0
    x_19_3    disj2_4_19_3  -1.0
    x_19_3    disj1_5_19_3  1.0
    x_19_3    disj2_5_19_3  -1.0
    x_19_3    disj1_6_19_3  1.0
    x_19_3    disj2_6_19_3  -1.0
    x_19_3    disj1_7_19_3  1.0
    x_19_3    disj2_7_19_3  -1.0
    x_19_3    disj1_8_19_3  1.0
    x_19_3    disj2_8_19_3  -1.0
    x_19_3    disj1_9_19_3  1.0
    x_19_3    disj2_9_19_3  -1.0
    x_19_3    disj1_10_19_3  1.0
    x_19_3    disj2_10_19_3  -1.0
    x_19_3    disj1_11_19_3  1.0
    x_19_3    disj2_11_19_3  -1.0
    x_19_3    disj1_12_19_3  1.0
    x_19_3    disj2_12_19_3  -1.0
    x_19_3    disj1_13_19_3  1.0
    x_19_3    disj2_13_19_3  -1.0
    x_19_3    disj1_14_19_3  1.0
    x_19_3    disj2_14_19_3  -1.0
    x_19_3    disj1_15_19_3  1.0
    x_19_3    disj2_15_19_3  -1.0
    x_19_3    disj1_16_19_3  1.0
    x_19_3    disj2_16_19_3  -1.0
    x_19_3    disj1_17_19_3  1.0
    x_19_3    disj2_17_19_3  -1.0
    x_19_3    disj1_18_19_3  1.0
    x_19_3    disj2_18_19_3  -1.0
    x_19_4    prec_19_3  1.0
    x_19_4    mksp_19   -1.0
    x_19_4    disj1_0_19_1  1.0
    x_19_4    disj2_0_19_1  -1.0
    x_19_4    disj1_1_19_1  1.0
    x_19_4    disj2_1_19_1  -1.0
    x_19_4    disj1_2_19_1  1.0
    x_19_4    disj2_2_19_1  -1.0
    x_19_4    disj1_3_19_1  1.0
    x_19_4    disj2_3_19_1  -1.0
    x_19_4    disj1_4_19_1  1.0
    x_19_4    disj2_4_19_1  -1.0
    x_19_4    disj1_5_19_1  1.0
    x_19_4    disj2_5_19_1  -1.0
    x_19_4    disj1_6_19_1  1.0
    x_19_4    disj2_6_19_1  -1.0
    x_19_4    disj1_7_19_1  1.0
    x_19_4    disj2_7_19_1  -1.0
    x_19_4    disj1_8_19_1  1.0
    x_19_4    disj2_8_19_1  -1.0
    x_19_4    disj1_9_19_1  1.0
    x_19_4    disj2_9_19_1  -1.0
    x_19_4    disj1_10_19_1  1.0
    x_19_4    disj2_10_19_1  -1.0
    x_19_4    disj1_11_19_1  1.0
    x_19_4    disj2_11_19_1  -1.0
    x_19_4    disj1_12_19_1  1.0
    x_19_4    disj2_12_19_1  -1.0
    x_19_4    disj1_13_19_1  1.0
    x_19_4    disj2_13_19_1  -1.0
    x_19_4    disj1_14_19_1  1.0
    x_19_4    disj2_14_19_1  -1.0
    x_19_4    disj1_15_19_1  1.0
    x_19_4    disj2_15_19_1  -1.0
    x_19_4    disj1_16_19_1  1.0
    x_19_4    disj2_16_19_1  -1.0
    x_19_4    disj1_17_19_1  1.0
    x_19_4    disj2_17_19_1  -1.0
    x_19_4    disj1_18_19_1  1.0
    x_19_4    disj2_18_19_1  -1.0
    MARK0000  'MARKER'                 'INTORG'
    y_0_1_0   disj1_0_1_0  5251
    y_0_1_0   disj2_0_1_0  -5251
    y_0_1_1   disj1_0_1_1  5251
    y_0_1_1   disj2_0_1_1  -5251
    y_0_1_2   disj1_0_1_2  5251
    y_0_1_2   disj2_0_1_2  -5251
    y_0_1_3   disj1_0_1_3  5251
    y_0_1_3   disj2_0_1_3  -5251
    y_0_1_4   disj1_0_1_4  5251
    y_0_1_4   disj2_0_1_4  -5251
    y_0_2_0   disj1_0_2_0  5251
    y_0_2_0   disj2_0_2_0  -5251
    y_0_2_1   disj1_0_2_1  5251
    y_0_2_1   disj2_0_2_1  -5251
    y_0_2_2   disj1_0_2_2  5251
    y_0_2_2   disj2_0_2_2  -5251
    y_0_2_3   disj1_0_2_3  5251
    y_0_2_3   disj2_0_2_3  -5251
    y_0_2_4   disj1_0_2_4  5251
    y_0_2_4   disj2_0_2_4  -5251
    y_0_3_0   disj1_0_3_0  5251
    y_0_3_0   disj2_0_3_0  -5251
    y_0_3_1   disj1_0_3_1  5251
    y_0_3_1   disj2_0_3_1  -5251
    y_0_3_2   disj1_0_3_2  5251
    y_0_3_2   disj2_0_3_2  -5251
    y_0_3_3   disj1_0_3_3  5251
    y_0_3_3   disj2_0_3_3  -5251
    y_0_3_4   disj1_0_3_4  5251
    y_0_3_4   disj2_0_3_4  -5251
    y_0_4_0   disj1_0_4_0  5251
    y_0_4_0   disj2_0_4_0  -5251
    y_0_4_1   disj1_0_4_1  5251
    y_0_4_1   disj2_0_4_1  -5251
    y_0_4_2   disj1_0_4_2  5251
    y_0_4_2   disj2_0_4_2  -5251
    y_0_4_3   disj1_0_4_3  5251
    y_0_4_3   disj2_0_4_3  -5251
    y_0_4_4   disj1_0_4_4  5251
    y_0_4_4   disj2_0_4_4  -5251
    y_0_5_0   disj1_0_5_0  5251
    y_0_5_0   disj2_0_5_0  -5251
    y_0_5_1   disj1_0_5_1  5251
    y_0_5_1   disj2_0_5_1  -5251
    y_0_5_2   disj1_0_5_2  5251
    y_0_5_2   disj2_0_5_2  -5251
    y_0_5_3   disj1_0_5_3  5251
    y_0_5_3   disj2_0_5_3  -5251
    y_0_5_4   disj1_0_5_4  5251
    y_0_5_4   disj2_0_5_4  -5251
    y_0_6_0   disj1_0_6_0  5251
    y_0_6_0   disj2_0_6_0  -5251
    y_0_6_1   disj1_0_6_1  5251
    y_0_6_1   disj2_0_6_1  -5251
    y_0_6_2   disj1_0_6_2  5251
    y_0_6_2   disj2_0_6_2  -5251
    y_0_6_3   disj1_0_6_3  5251
    y_0_6_3   disj2_0_6_3  -5251
    y_0_6_4   disj1_0_6_4  5251
    y_0_6_4   disj2_0_6_4  -5251
    y_0_7_0   disj1_0_7_0  5251
    y_0_7_0   disj2_0_7_0  -5251
    y_0_7_1   disj1_0_7_1  5251
    y_0_7_1   disj2_0_7_1  -5251
    y_0_7_2   disj1_0_7_2  5251
    y_0_7_2   disj2_0_7_2  -5251
    y_0_7_3   disj1_0_7_3  5251
    y_0_7_3   disj2_0_7_3  -5251
    y_0_7_4   disj1_0_7_4  5251
    y_0_7_4   disj2_0_7_4  -5251
    y_0_8_0   disj1_0_8_0  5251
    y_0_8_0   disj2_0_8_0  -5251
    y_0_8_1   disj1_0_8_1  5251
    y_0_8_1   disj2_0_8_1  -5251
    y_0_8_2   disj1_0_8_2  5251
    y_0_8_2   disj2_0_8_2  -5251
    y_0_8_3   disj1_0_8_3  5251
    y_0_8_3   disj2_0_8_3  -5251
    y_0_8_4   disj1_0_8_4  5251
    y_0_8_4   disj2_0_8_4  -5251
    y_0_9_0   disj1_0_9_0  5251
    y_0_9_0   disj2_0_9_0  -5251
    y_0_9_1   disj1_0_9_1  5251
    y_0_9_1   disj2_0_9_1  -5251
    y_0_9_2   disj1_0_9_2  5251
    y_0_9_2   disj2_0_9_2  -5251
    y_0_9_3   disj1_0_9_3  5251
    y_0_9_3   disj2_0_9_3  -5251
    y_0_9_4   disj1_0_9_4  5251
    y_0_9_4   disj2_0_9_4  -5251
    y_0_10_0  disj1_0_10_0  5251
    y_0_10_0  disj2_0_10_0  -5251
    y_0_10_1  disj1_0_10_1  5251
    y_0_10_1  disj2_0_10_1  -5251
    y_0_10_2  disj1_0_10_2  5251
    y_0_10_2  disj2_0_10_2  -5251
    y_0_10_3  disj1_0_10_3  5251
    y_0_10_3  disj2_0_10_3  -5251
    y_0_10_4  disj1_0_10_4  5251
    y_0_10_4  disj2_0_10_4  -5251
    y_0_11_0  disj1_0_11_0  5251
    y_0_11_0  disj2_0_11_0  -5251
    y_0_11_1  disj1_0_11_1  5251
    y_0_11_1  disj2_0_11_1  -5251
    y_0_11_2  disj1_0_11_2  5251
    y_0_11_2  disj2_0_11_2  -5251
    y_0_11_3  disj1_0_11_3  5251
    y_0_11_3  disj2_0_11_3  -5251
    y_0_11_4  disj1_0_11_4  5251
    y_0_11_4  disj2_0_11_4  -5251
    y_0_12_0  disj1_0_12_0  5251
    y_0_12_0  disj2_0_12_0  -5251
    y_0_12_1  disj1_0_12_1  5251
    y_0_12_1  disj2_0_12_1  -5251
    y_0_12_2  disj1_0_12_2  5251
    y_0_12_2  disj2_0_12_2  -5251
    y_0_12_3  disj1_0_12_3  5251
    y_0_12_3  disj2_0_12_3  -5251
    y_0_12_4  disj1_0_12_4  5251
    y_0_12_4  disj2_0_12_4  -5251
    y_0_13_0  disj1_0_13_0  5251
    y_0_13_0  disj2_0_13_0  -5251
    y_0_13_1  disj1_0_13_1  5251
    y_0_13_1  disj2_0_13_1  -5251
    y_0_13_2  disj1_0_13_2  5251
    y_0_13_2  disj2_0_13_2  -5251
    y_0_13_3  disj1_0_13_3  5251
    y_0_13_3  disj2_0_13_3  -5251
    y_0_13_4  disj1_0_13_4  5251
    y_0_13_4  disj2_0_13_4  -5251
    y_0_14_0  disj1_0_14_0  5251
    y_0_14_0  disj2_0_14_0  -5251
    y_0_14_1  disj1_0_14_1  5251
    y_0_14_1  disj2_0_14_1  -5251
    y_0_14_2  disj1_0_14_2  5251
    y_0_14_2  disj2_0_14_2  -5251
    y_0_14_3  disj1_0_14_3  5251
    y_0_14_3  disj2_0_14_3  -5251
    y_0_14_4  disj1_0_14_4  5251
    y_0_14_4  disj2_0_14_4  -5251
    y_0_15_0  disj1_0_15_0  5251
    y_0_15_0  disj2_0_15_0  -5251
    y_0_15_1  disj1_0_15_1  5251
    y_0_15_1  disj2_0_15_1  -5251
    y_0_15_2  disj1_0_15_2  5251
    y_0_15_2  disj2_0_15_2  -5251
    y_0_15_3  disj1_0_15_3  5251
    y_0_15_3  disj2_0_15_3  -5251
    y_0_15_4  disj1_0_15_4  5251
    y_0_15_4  disj2_0_15_4  -5251
    y_0_16_0  disj1_0_16_0  5251
    y_0_16_0  disj2_0_16_0  -5251
    y_0_16_1  disj1_0_16_1  5251
    y_0_16_1  disj2_0_16_1  -5251
    y_0_16_2  disj1_0_16_2  5251
    y_0_16_2  disj2_0_16_2  -5251
    y_0_16_3  disj1_0_16_3  5251
    y_0_16_3  disj2_0_16_3  -5251
    y_0_16_4  disj1_0_16_4  5251
    y_0_16_4  disj2_0_16_4  -5251
    y_0_17_0  disj1_0_17_0  5251
    y_0_17_0  disj2_0_17_0  -5251
    y_0_17_1  disj1_0_17_1  5251
    y_0_17_1  disj2_0_17_1  -5251
    y_0_17_2  disj1_0_17_2  5251
    y_0_17_2  disj2_0_17_2  -5251
    y_0_17_3  disj1_0_17_3  5251
    y_0_17_3  disj2_0_17_3  -5251
    y_0_17_4  disj1_0_17_4  5251
    y_0_17_4  disj2_0_17_4  -5251
    y_0_18_0  disj1_0_18_0  5251
    y_0_18_0  disj2_0_18_0  -5251
    y_0_18_1  disj1_0_18_1  5251
    y_0_18_1  disj2_0_18_1  -5251
    y_0_18_2  disj1_0_18_2  5251
    y_0_18_2  disj2_0_18_2  -5251
    y_0_18_3  disj1_0_18_3  5251
    y_0_18_3  disj2_0_18_3  -5251
    y_0_18_4  disj1_0_18_4  5251
    y_0_18_4  disj2_0_18_4  -5251
    y_0_19_0  disj1_0_19_0  5251
    y_0_19_0  disj2_0_19_0  -5251
    y_0_19_1  disj1_0_19_1  5251
    y_0_19_1  disj2_0_19_1  -5251
    y_0_19_2  disj1_0_19_2  5251
    y_0_19_2  disj2_0_19_2  -5251
    y_0_19_3  disj1_0_19_3  5251
    y_0_19_3  disj2_0_19_3  -5251
    y_0_19_4  disj1_0_19_4  5251
    y_0_19_4  disj2_0_19_4  -5251
    y_1_2_0   disj1_1_2_0  5251
    y_1_2_0   disj2_1_2_0  -5251
    y_1_2_1   disj1_1_2_1  5251
    y_1_2_1   disj2_1_2_1  -5251
    y_1_2_2   disj1_1_2_2  5251
    y_1_2_2   disj2_1_2_2  -5251
    y_1_2_3   disj1_1_2_3  5251
    y_1_2_3   disj2_1_2_3  -5251
    y_1_2_4   disj1_1_2_4  5251
    y_1_2_4   disj2_1_2_4  -5251
    y_1_3_0   disj1_1_3_0  5251
    y_1_3_0   disj2_1_3_0  -5251
    y_1_3_1   disj1_1_3_1  5251
    y_1_3_1   disj2_1_3_1  -5251
    y_1_3_2   disj1_1_3_2  5251
    y_1_3_2   disj2_1_3_2  -5251
    y_1_3_3   disj1_1_3_3  5251
    y_1_3_3   disj2_1_3_3  -5251
    y_1_3_4   disj1_1_3_4  5251
    y_1_3_4   disj2_1_3_4  -5251
    y_1_4_0   disj1_1_4_0  5251
    y_1_4_0   disj2_1_4_0  -5251
    y_1_4_1   disj1_1_4_1  5251
    y_1_4_1   disj2_1_4_1  -5251
    y_1_4_2   disj1_1_4_2  5251
    y_1_4_2   disj2_1_4_2  -5251
    y_1_4_3   disj1_1_4_3  5251
    y_1_4_3   disj2_1_4_3  -5251
    y_1_4_4   disj1_1_4_4  5251
    y_1_4_4   disj2_1_4_4  -5251
    y_1_5_0   disj1_1_5_0  5251
    y_1_5_0   disj2_1_5_0  -5251
    y_1_5_1   disj1_1_5_1  5251
    y_1_5_1   disj2_1_5_1  -5251
    y_1_5_2   disj1_1_5_2  5251
    y_1_5_2   disj2_1_5_2  -5251
    y_1_5_3   disj1_1_5_3  5251
    y_1_5_3   disj2_1_5_3  -5251
    y_1_5_4   disj1_1_5_4  5251
    y_1_5_4   disj2_1_5_4  -5251
    y_1_6_0   disj1_1_6_0  5251
    y_1_6_0   disj2_1_6_0  -5251
    y_1_6_1   disj1_1_6_1  5251
    y_1_6_1   disj2_1_6_1  -5251
    y_1_6_2   disj1_1_6_2  5251
    y_1_6_2   disj2_1_6_2  -5251
    y_1_6_3   disj1_1_6_3  5251
    y_1_6_3   disj2_1_6_3  -5251
    y_1_6_4   disj1_1_6_4  5251
    y_1_6_4   disj2_1_6_4  -5251
    y_1_7_0   disj1_1_7_0  5251
    y_1_7_0   disj2_1_7_0  -5251
    y_1_7_1   disj1_1_7_1  5251
    y_1_7_1   disj2_1_7_1  -5251
    y_1_7_2   disj1_1_7_2  5251
    y_1_7_2   disj2_1_7_2  -5251
    y_1_7_3   disj1_1_7_3  5251
    y_1_7_3   disj2_1_7_3  -5251
    y_1_7_4   disj1_1_7_4  5251
    y_1_7_4   disj2_1_7_4  -5251
    y_1_8_0   disj1_1_8_0  5251
    y_1_8_0   disj2_1_8_0  -5251
    y_1_8_1   disj1_1_8_1  5251
    y_1_8_1   disj2_1_8_1  -5251
    y_1_8_2   disj1_1_8_2  5251
    y_1_8_2   disj2_1_8_2  -5251
    y_1_8_3   disj1_1_8_3  5251
    y_1_8_3   disj2_1_8_3  -5251
    y_1_8_4   disj1_1_8_4  5251
    y_1_8_4   disj2_1_8_4  -5251
    y_1_9_0   disj1_1_9_0  5251
    y_1_9_0   disj2_1_9_0  -5251
    y_1_9_1   disj1_1_9_1  5251
    y_1_9_1   disj2_1_9_1  -5251
    y_1_9_2   disj1_1_9_2  5251
    y_1_9_2   disj2_1_9_2  -5251
    y_1_9_3   disj1_1_9_3  5251
    y_1_9_3   disj2_1_9_3  -5251
    y_1_9_4   disj1_1_9_4  5251
    y_1_9_4   disj2_1_9_4  -5251
    y_1_10_0  disj1_1_10_0  5251
    y_1_10_0  disj2_1_10_0  -5251
    y_1_10_1  disj1_1_10_1  5251
    y_1_10_1  disj2_1_10_1  -5251
    y_1_10_2  disj1_1_10_2  5251
    y_1_10_2  disj2_1_10_2  -5251
    y_1_10_3  disj1_1_10_3  5251
    y_1_10_3  disj2_1_10_3  -5251
    y_1_10_4  disj1_1_10_4  5251
    y_1_10_4  disj2_1_10_4  -5251
    y_1_11_0  disj1_1_11_0  5251
    y_1_11_0  disj2_1_11_0  -5251
    y_1_11_1  disj1_1_11_1  5251
    y_1_11_1  disj2_1_11_1  -5251
    y_1_11_2  disj1_1_11_2  5251
    y_1_11_2  disj2_1_11_2  -5251
    y_1_11_3  disj1_1_11_3  5251
    y_1_11_3  disj2_1_11_3  -5251
    y_1_11_4  disj1_1_11_4  5251
    y_1_11_4  disj2_1_11_4  -5251
    y_1_12_0  disj1_1_12_0  5251
    y_1_12_0  disj2_1_12_0  -5251
    y_1_12_1  disj1_1_12_1  5251
    y_1_12_1  disj2_1_12_1  -5251
    y_1_12_2  disj1_1_12_2  5251
    y_1_12_2  disj2_1_12_2  -5251
    y_1_12_3  disj1_1_12_3  5251
    y_1_12_3  disj2_1_12_3  -5251
    y_1_12_4  disj1_1_12_4  5251
    y_1_12_4  disj2_1_12_4  -5251
    y_1_13_0  disj1_1_13_0  5251
    y_1_13_0  disj2_1_13_0  -5251
    y_1_13_1  disj1_1_13_1  5251
    y_1_13_1  disj2_1_13_1  -5251
    y_1_13_2  disj1_1_13_2  5251
    y_1_13_2  disj2_1_13_2  -5251
    y_1_13_3  disj1_1_13_3  5251
    y_1_13_3  disj2_1_13_3  -5251
    y_1_13_4  disj1_1_13_4  5251
    y_1_13_4  disj2_1_13_4  -5251
    y_1_14_0  disj1_1_14_0  5251
    y_1_14_0  disj2_1_14_0  -5251
    y_1_14_1  disj1_1_14_1  5251
    y_1_14_1  disj2_1_14_1  -5251
    y_1_14_2  disj1_1_14_2  5251
    y_1_14_2  disj2_1_14_2  -5251
    y_1_14_3  disj1_1_14_3  5251
    y_1_14_3  disj2_1_14_3  -5251
    y_1_14_4  disj1_1_14_4  5251
    y_1_14_4  disj2_1_14_4  -5251
    y_1_15_0  disj1_1_15_0  5251
    y_1_15_0  disj2_1_15_0  -5251
    y_1_15_1  disj1_1_15_1  5251
    y_1_15_1  disj2_1_15_1  -5251
    y_1_15_2  disj1_1_15_2  5251
    y_1_15_2  disj2_1_15_2  -5251
    y_1_15_3  disj1_1_15_3  5251
    y_1_15_3  disj2_1_15_3  -5251
    y_1_15_4  disj1_1_15_4  5251
    y_1_15_4  disj2_1_15_4  -5251
    y_1_16_0  disj1_1_16_0  5251
    y_1_16_0  disj2_1_16_0  -5251
    y_1_16_1  disj1_1_16_1  5251
    y_1_16_1  disj2_1_16_1  -5251
    y_1_16_2  disj1_1_16_2  5251
    y_1_16_2  disj2_1_16_2  -5251
    y_1_16_3  disj1_1_16_3  5251
    y_1_16_3  disj2_1_16_3  -5251
    y_1_16_4  disj1_1_16_4  5251
    y_1_16_4  disj2_1_16_4  -5251
    y_1_17_0  disj1_1_17_0  5251
    y_1_17_0  disj2_1_17_0  -5251
    y_1_17_1  disj1_1_17_1  5251
    y_1_17_1  disj2_1_17_1  -5251
    y_1_17_2  disj1_1_17_2  5251
    y_1_17_2  disj2_1_17_2  -5251
    y_1_17_3  disj1_1_17_3  5251
    y_1_17_3  disj2_1_17_3  -5251
    y_1_17_4  disj1_1_17_4  5251
    y_1_17_4  disj2_1_17_4  -5251
    y_1_18_0  disj1_1_18_0  5251
    y_1_18_0  disj2_1_18_0  -5251
    y_1_18_1  disj1_1_18_1  5251
    y_1_18_1  disj2_1_18_1  -5251
    y_1_18_2  disj1_1_18_2  5251
    y_1_18_2  disj2_1_18_2  -5251
    y_1_18_3  disj1_1_18_3  5251
    y_1_18_3  disj2_1_18_3  -5251
    y_1_18_4  disj1_1_18_4  5251
    y_1_18_4  disj2_1_18_4  -5251
    y_1_19_0  disj1_1_19_0  5251
    y_1_19_0  disj2_1_19_0  -5251
    y_1_19_1  disj1_1_19_1  5251
    y_1_19_1  disj2_1_19_1  -5251
    y_1_19_2  disj1_1_19_2  5251
    y_1_19_2  disj2_1_19_2  -5251
    y_1_19_3  disj1_1_19_3  5251
    y_1_19_3  disj2_1_19_3  -5251
    y_1_19_4  disj1_1_19_4  5251
    y_1_19_4  disj2_1_19_4  -5251
    y_2_3_0   disj1_2_3_0  5251
    y_2_3_0   disj2_2_3_0  -5251
    y_2_3_1   disj1_2_3_1  5251
    y_2_3_1   disj2_2_3_1  -5251
    y_2_3_2   disj1_2_3_2  5251
    y_2_3_2   disj2_2_3_2  -5251
    y_2_3_3   disj1_2_3_3  5251
    y_2_3_3   disj2_2_3_3  -5251
    y_2_3_4   disj1_2_3_4  5251
    y_2_3_4   disj2_2_3_4  -5251
    y_2_4_0   disj1_2_4_0  5251
    y_2_4_0   disj2_2_4_0  -5251
    y_2_4_1   disj1_2_4_1  5251
    y_2_4_1   disj2_2_4_1  -5251
    y_2_4_2   disj1_2_4_2  5251
    y_2_4_2   disj2_2_4_2  -5251
    y_2_4_3   disj1_2_4_3  5251
    y_2_4_3   disj2_2_4_3  -5251
    y_2_4_4   disj1_2_4_4  5251
    y_2_4_4   disj2_2_4_4  -5251
    y_2_5_0   disj1_2_5_0  5251
    y_2_5_0   disj2_2_5_0  -5251
    y_2_5_1   disj1_2_5_1  5251
    y_2_5_1   disj2_2_5_1  -5251
    y_2_5_2   disj1_2_5_2  5251
    y_2_5_2   disj2_2_5_2  -5251
    y_2_5_3   disj1_2_5_3  5251
    y_2_5_3   disj2_2_5_3  -5251
    y_2_5_4   disj1_2_5_4  5251
    y_2_5_4   disj2_2_5_4  -5251
    y_2_6_0   disj1_2_6_0  5251
    y_2_6_0   disj2_2_6_0  -5251
    y_2_6_1   disj1_2_6_1  5251
    y_2_6_1   disj2_2_6_1  -5251
    y_2_6_2   disj1_2_6_2  5251
    y_2_6_2   disj2_2_6_2  -5251
    y_2_6_3   disj1_2_6_3  5251
    y_2_6_3   disj2_2_6_3  -5251
    y_2_6_4   disj1_2_6_4  5251
    y_2_6_4   disj2_2_6_4  -5251
    y_2_7_0   disj1_2_7_0  5251
    y_2_7_0   disj2_2_7_0  -5251
    y_2_7_1   disj1_2_7_1  5251
    y_2_7_1   disj2_2_7_1  -5251
    y_2_7_2   disj1_2_7_2  5251
    y_2_7_2   disj2_2_7_2  -5251
    y_2_7_3   disj1_2_7_3  5251
    y_2_7_3   disj2_2_7_3  -5251
    y_2_7_4   disj1_2_7_4  5251
    y_2_7_4   disj2_2_7_4  -5251
    y_2_8_0   disj1_2_8_0  5251
    y_2_8_0   disj2_2_8_0  -5251
    y_2_8_1   disj1_2_8_1  5251
    y_2_8_1   disj2_2_8_1  -5251
    y_2_8_2   disj1_2_8_2  5251
    y_2_8_2   disj2_2_8_2  -5251
    y_2_8_3   disj1_2_8_3  5251
    y_2_8_3   disj2_2_8_3  -5251
    y_2_8_4   disj1_2_8_4  5251
    y_2_8_4   disj2_2_8_4  -5251
    y_2_9_0   disj1_2_9_0  5251
    y_2_9_0   disj2_2_9_0  -5251
    y_2_9_1   disj1_2_9_1  5251
    y_2_9_1   disj2_2_9_1  -5251
    y_2_9_2   disj1_2_9_2  5251
    y_2_9_2   disj2_2_9_2  -5251
    y_2_9_3   disj1_2_9_3  5251
    y_2_9_3   disj2_2_9_3  -5251
    y_2_9_4   disj1_2_9_4  5251
    y_2_9_4   disj2_2_9_4  -5251
    y_2_10_0  disj1_2_10_0  5251
    y_2_10_0  disj2_2_10_0  -5251
    y_2_10_1  disj1_2_10_1  5251
    y_2_10_1  disj2_2_10_1  -5251
    y_2_10_2  disj1_2_10_2  5251
    y_2_10_2  disj2_2_10_2  -5251
    y_2_10_3  disj1_2_10_3  5251
    y_2_10_3  disj2_2_10_3  -5251
    y_2_10_4  disj1_2_10_4  5251
    y_2_10_4  disj2_2_10_4  -5251
    y_2_11_0  disj1_2_11_0  5251
    y_2_11_0  disj2_2_11_0  -5251
    y_2_11_1  disj1_2_11_1  5251
    y_2_11_1  disj2_2_11_1  -5251
    y_2_11_2  disj1_2_11_2  5251
    y_2_11_2  disj2_2_11_2  -5251
    y_2_11_3  disj1_2_11_3  5251
    y_2_11_3  disj2_2_11_3  -5251
    y_2_11_4  disj1_2_11_4  5251
    y_2_11_4  disj2_2_11_4  -5251
    y_2_12_0  disj1_2_12_0  5251
    y_2_12_0  disj2_2_12_0  -5251
    y_2_12_1  disj1_2_12_1  5251
    y_2_12_1  disj2_2_12_1  -5251
    y_2_12_2  disj1_2_12_2  5251
    y_2_12_2  disj2_2_12_2  -5251
    y_2_12_3  disj1_2_12_3  5251
    y_2_12_3  disj2_2_12_3  -5251
    y_2_12_4  disj1_2_12_4  5251
    y_2_12_4  disj2_2_12_4  -5251
    y_2_13_0  disj1_2_13_0  5251
    y_2_13_0  disj2_2_13_0  -5251
    y_2_13_1  disj1_2_13_1  5251
    y_2_13_1  disj2_2_13_1  -5251
    y_2_13_2  disj1_2_13_2  5251
    y_2_13_2  disj2_2_13_2  -5251
    y_2_13_3  disj1_2_13_3  5251
    y_2_13_3  disj2_2_13_3  -5251
    y_2_13_4  disj1_2_13_4  5251
    y_2_13_4  disj2_2_13_4  -5251
    y_2_14_0  disj1_2_14_0  5251
    y_2_14_0  disj2_2_14_0  -5251
    y_2_14_1  disj1_2_14_1  5251
    y_2_14_1  disj2_2_14_1  -5251
    y_2_14_2  disj1_2_14_2  5251
    y_2_14_2  disj2_2_14_2  -5251
    y_2_14_3  disj1_2_14_3  5251
    y_2_14_3  disj2_2_14_3  -5251
    y_2_14_4  disj1_2_14_4  5251
    y_2_14_4  disj2_2_14_4  -5251
    y_2_15_0  disj1_2_15_0  5251
    y_2_15_0  disj2_2_15_0  -5251
    y_2_15_1  disj1_2_15_1  5251
    y_2_15_1  disj2_2_15_1  -5251
    y_2_15_2  disj1_2_15_2  5251
    y_2_15_2  disj2_2_15_2  -5251
    y_2_15_3  disj1_2_15_3  5251
    y_2_15_3  disj2_2_15_3  -5251
    y_2_15_4  disj1_2_15_4  5251
    y_2_15_4  disj2_2_15_4  -5251
    y_2_16_0  disj1_2_16_0  5251
    y_2_16_0  disj2_2_16_0  -5251
    y_2_16_1  disj1_2_16_1  5251
    y_2_16_1  disj2_2_16_1  -5251
    y_2_16_2  disj1_2_16_2  5251
    y_2_16_2  disj2_2_16_2  -5251
    y_2_16_3  disj1_2_16_3  5251
    y_2_16_3  disj2_2_16_3  -5251
    y_2_16_4  disj1_2_16_4  5251
    y_2_16_4  disj2_2_16_4  -5251
    y_2_17_0  disj1_2_17_0  5251
    y_2_17_0  disj2_2_17_0  -5251
    y_2_17_1  disj1_2_17_1  5251
    y_2_17_1  disj2_2_17_1  -5251
    y_2_17_2  disj1_2_17_2  5251
    y_2_17_2  disj2_2_17_2  -5251
    y_2_17_3  disj1_2_17_3  5251
    y_2_17_3  disj2_2_17_3  -5251
    y_2_17_4  disj1_2_17_4  5251
    y_2_17_4  disj2_2_17_4  -5251
    y_2_18_0  disj1_2_18_0  5251
    y_2_18_0  disj2_2_18_0  -5251
    y_2_18_1  disj1_2_18_1  5251
    y_2_18_1  disj2_2_18_1  -5251
    y_2_18_2  disj1_2_18_2  5251
    y_2_18_2  disj2_2_18_2  -5251
    y_2_18_3  disj1_2_18_3  5251
    y_2_18_3  disj2_2_18_3  -5251
    y_2_18_4  disj1_2_18_4  5251
    y_2_18_4  disj2_2_18_4  -5251
    y_2_19_0  disj1_2_19_0  5251
    y_2_19_0  disj2_2_19_0  -5251
    y_2_19_1  disj1_2_19_1  5251
    y_2_19_1  disj2_2_19_1  -5251
    y_2_19_2  disj1_2_19_2  5251
    y_2_19_2  disj2_2_19_2  -5251
    y_2_19_3  disj1_2_19_3  5251
    y_2_19_3  disj2_2_19_3  -5251
    y_2_19_4  disj1_2_19_4  5251
    y_2_19_4  disj2_2_19_4  -5251
    y_3_4_0   disj1_3_4_0  5251
    y_3_4_0   disj2_3_4_0  -5251
    y_3_4_1   disj1_3_4_1  5251
    y_3_4_1   disj2_3_4_1  -5251
    y_3_4_2   disj1_3_4_2  5251
    y_3_4_2   disj2_3_4_2  -5251
    y_3_4_3   disj1_3_4_3  5251
    y_3_4_3   disj2_3_4_3  -5251
    y_3_4_4   disj1_3_4_4  5251
    y_3_4_4   disj2_3_4_4  -5251
    y_3_5_0   disj1_3_5_0  5251
    y_3_5_0   disj2_3_5_0  -5251
    y_3_5_1   disj1_3_5_1  5251
    y_3_5_1   disj2_3_5_1  -5251
    y_3_5_2   disj1_3_5_2  5251
    y_3_5_2   disj2_3_5_2  -5251
    y_3_5_3   disj1_3_5_3  5251
    y_3_5_3   disj2_3_5_3  -5251
    y_3_5_4   disj1_3_5_4  5251
    y_3_5_4   disj2_3_5_4  -5251
    y_3_6_0   disj1_3_6_0  5251
    y_3_6_0   disj2_3_6_0  -5251
    y_3_6_1   disj1_3_6_1  5251
    y_3_6_1   disj2_3_6_1  -5251
    y_3_6_2   disj1_3_6_2  5251
    y_3_6_2   disj2_3_6_2  -5251
    y_3_6_3   disj1_3_6_3  5251
    y_3_6_3   disj2_3_6_3  -5251
    y_3_6_4   disj1_3_6_4  5251
    y_3_6_4   disj2_3_6_4  -5251
    y_3_7_0   disj1_3_7_0  5251
    y_3_7_0   disj2_3_7_0  -5251
    y_3_7_1   disj1_3_7_1  5251
    y_3_7_1   disj2_3_7_1  -5251
    y_3_7_2   disj1_3_7_2  5251
    y_3_7_2   disj2_3_7_2  -5251
    y_3_7_3   disj1_3_7_3  5251
    y_3_7_3   disj2_3_7_3  -5251
    y_3_7_4   disj1_3_7_4  5251
    y_3_7_4   disj2_3_7_4  -5251
    y_3_8_0   disj1_3_8_0  5251
    y_3_8_0   disj2_3_8_0  -5251
    y_3_8_1   disj1_3_8_1  5251
    y_3_8_1   disj2_3_8_1  -5251
    y_3_8_2   disj1_3_8_2  5251
    y_3_8_2   disj2_3_8_2  -5251
    y_3_8_3   disj1_3_8_3  5251
    y_3_8_3   disj2_3_8_3  -5251
    y_3_8_4   disj1_3_8_4  5251
    y_3_8_4   disj2_3_8_4  -5251
    y_3_9_0   disj1_3_9_0  5251
    y_3_9_0   disj2_3_9_0  -5251
    y_3_9_1   disj1_3_9_1  5251
    y_3_9_1   disj2_3_9_1  -5251
    y_3_9_2   disj1_3_9_2  5251
    y_3_9_2   disj2_3_9_2  -5251
    y_3_9_3   disj1_3_9_3  5251
    y_3_9_3   disj2_3_9_3  -5251
    y_3_9_4   disj1_3_9_4  5251
    y_3_9_4   disj2_3_9_4  -5251
    y_3_10_0  disj1_3_10_0  5251
    y_3_10_0  disj2_3_10_0  -5251
    y_3_10_1  disj1_3_10_1  5251
    y_3_10_1  disj2_3_10_1  -5251
    y_3_10_2  disj1_3_10_2  5251
    y_3_10_2  disj2_3_10_2  -5251
    y_3_10_3  disj1_3_10_3  5251
    y_3_10_3  disj2_3_10_3  -5251
    y_3_10_4  disj1_3_10_4  5251
    y_3_10_4  disj2_3_10_4  -5251
    y_3_11_0  disj1_3_11_0  5251
    y_3_11_0  disj2_3_11_0  -5251
    y_3_11_1  disj1_3_11_1  5251
    y_3_11_1  disj2_3_11_1  -5251
    y_3_11_2  disj1_3_11_2  5251
    y_3_11_2  disj2_3_11_2  -5251
    y_3_11_3  disj1_3_11_3  5251
    y_3_11_3  disj2_3_11_3  -5251
    y_3_11_4  disj1_3_11_4  5251
    y_3_11_4  disj2_3_11_4  -5251
    y_3_12_0  disj1_3_12_0  5251
    y_3_12_0  disj2_3_12_0  -5251
    y_3_12_1  disj1_3_12_1  5251
    y_3_12_1  disj2_3_12_1  -5251
    y_3_12_2  disj1_3_12_2  5251
    y_3_12_2  disj2_3_12_2  -5251
    y_3_12_3  disj1_3_12_3  5251
    y_3_12_3  disj2_3_12_3  -5251
    y_3_12_4  disj1_3_12_4  5251
    y_3_12_4  disj2_3_12_4  -5251
    y_3_13_0  disj1_3_13_0  5251
    y_3_13_0  disj2_3_13_0  -5251
    y_3_13_1  disj1_3_13_1  5251
    y_3_13_1  disj2_3_13_1  -5251
    y_3_13_2  disj1_3_13_2  5251
    y_3_13_2  disj2_3_13_2  -5251
    y_3_13_3  disj1_3_13_3  5251
    y_3_13_3  disj2_3_13_3  -5251
    y_3_13_4  disj1_3_13_4  5251
    y_3_13_4  disj2_3_13_4  -5251
    y_3_14_0  disj1_3_14_0  5251
    y_3_14_0  disj2_3_14_0  -5251
    y_3_14_1  disj1_3_14_1  5251
    y_3_14_1  disj2_3_14_1  -5251
    y_3_14_2  disj1_3_14_2  5251
    y_3_14_2  disj2_3_14_2  -5251
    y_3_14_3  disj1_3_14_3  5251
    y_3_14_3  disj2_3_14_3  -5251
    y_3_14_4  disj1_3_14_4  5251
    y_3_14_4  disj2_3_14_4  -5251
    y_3_15_0  disj1_3_15_0  5251
    y_3_15_0  disj2_3_15_0  -5251
    y_3_15_1  disj1_3_15_1  5251
    y_3_15_1  disj2_3_15_1  -5251
    y_3_15_2  disj1_3_15_2  5251
    y_3_15_2  disj2_3_15_2  -5251
    y_3_15_3  disj1_3_15_3  5251
    y_3_15_3  disj2_3_15_3  -5251
    y_3_15_4  disj1_3_15_4  5251
    y_3_15_4  disj2_3_15_4  -5251
    y_3_16_0  disj1_3_16_0  5251
    y_3_16_0  disj2_3_16_0  -5251
    y_3_16_1  disj1_3_16_1  5251
    y_3_16_1  disj2_3_16_1  -5251
    y_3_16_2  disj1_3_16_2  5251
    y_3_16_2  disj2_3_16_2  -5251
    y_3_16_3  disj1_3_16_3  5251
    y_3_16_3  disj2_3_16_3  -5251
    y_3_16_4  disj1_3_16_4  5251
    y_3_16_4  disj2_3_16_4  -5251
    y_3_17_0  disj1_3_17_0  5251
    y_3_17_0  disj2_3_17_0  -5251
    y_3_17_1  disj1_3_17_1  5251
    y_3_17_1  disj2_3_17_1  -5251
    y_3_17_2  disj1_3_17_2  5251
    y_3_17_2  disj2_3_17_2  -5251
    y_3_17_3  disj1_3_17_3  5251
    y_3_17_3  disj2_3_17_3  -5251
    y_3_17_4  disj1_3_17_4  5251
    y_3_17_4  disj2_3_17_4  -5251
    y_3_18_0  disj1_3_18_0  5251
    y_3_18_0  disj2_3_18_0  -5251
    y_3_18_1  disj1_3_18_1  5251
    y_3_18_1  disj2_3_18_1  -5251
    y_3_18_2  disj1_3_18_2  5251
    y_3_18_2  disj2_3_18_2  -5251
    y_3_18_3  disj1_3_18_3  5251
    y_3_18_3  disj2_3_18_3  -5251
    y_3_18_4  disj1_3_18_4  5251
    y_3_18_4  disj2_3_18_4  -5251
    y_3_19_0  disj1_3_19_0  5251
    y_3_19_0  disj2_3_19_0  -5251
    y_3_19_1  disj1_3_19_1  5251
    y_3_19_1  disj2_3_19_1  -5251
    y_3_19_2  disj1_3_19_2  5251
    y_3_19_2  disj2_3_19_2  -5251
    y_3_19_3  disj1_3_19_3  5251
    y_3_19_3  disj2_3_19_3  -5251
    y_3_19_4  disj1_3_19_4  5251
    y_3_19_4  disj2_3_19_4  -5251
    y_4_5_0   disj1_4_5_0  5251
    y_4_5_0   disj2_4_5_0  -5251
    y_4_5_1   disj1_4_5_1  5251
    y_4_5_1   disj2_4_5_1  -5251
    y_4_5_2   disj1_4_5_2  5251
    y_4_5_2   disj2_4_5_2  -5251
    y_4_5_3   disj1_4_5_3  5251
    y_4_5_3   disj2_4_5_3  -5251
    y_4_5_4   disj1_4_5_4  5251
    y_4_5_4   disj2_4_5_4  -5251
    y_4_6_0   disj1_4_6_0  5251
    y_4_6_0   disj2_4_6_0  -5251
    y_4_6_1   disj1_4_6_1  5251
    y_4_6_1   disj2_4_6_1  -5251
    y_4_6_2   disj1_4_6_2  5251
    y_4_6_2   disj2_4_6_2  -5251
    y_4_6_3   disj1_4_6_3  5251
    y_4_6_3   disj2_4_6_3  -5251
    y_4_6_4   disj1_4_6_4  5251
    y_4_6_4   disj2_4_6_4  -5251
    y_4_7_0   disj1_4_7_0  5251
    y_4_7_0   disj2_4_7_0  -5251
    y_4_7_1   disj1_4_7_1  5251
    y_4_7_1   disj2_4_7_1  -5251
    y_4_7_2   disj1_4_7_2  5251
    y_4_7_2   disj2_4_7_2  -5251
    y_4_7_3   disj1_4_7_3  5251
    y_4_7_3   disj2_4_7_3  -5251
    y_4_7_4   disj1_4_7_4  5251
    y_4_7_4   disj2_4_7_4  -5251
    y_4_8_0   disj1_4_8_0  5251
    y_4_8_0   disj2_4_8_0  -5251
    y_4_8_1   disj1_4_8_1  5251
    y_4_8_1   disj2_4_8_1  -5251
    y_4_8_2   disj1_4_8_2  5251
    y_4_8_2   disj2_4_8_2  -5251
    y_4_8_3   disj1_4_8_3  5251
    y_4_8_3   disj2_4_8_3  -5251
    y_4_8_4   disj1_4_8_4  5251
    y_4_8_4   disj2_4_8_4  -5251
    y_4_9_0   disj1_4_9_0  5251
    y_4_9_0   disj2_4_9_0  -5251
    y_4_9_1   disj1_4_9_1  5251
    y_4_9_1   disj2_4_9_1  -5251
    y_4_9_2   disj1_4_9_2  5251
    y_4_9_2   disj2_4_9_2  -5251
    y_4_9_3   disj1_4_9_3  5251
    y_4_9_3   disj2_4_9_3  -5251
    y_4_9_4   disj1_4_9_4  5251
    y_4_9_4   disj2_4_9_4  -5251
    y_4_10_0  disj1_4_10_0  5251
    y_4_10_0  disj2_4_10_0  -5251
    y_4_10_1  disj1_4_10_1  5251
    y_4_10_1  disj2_4_10_1  -5251
    y_4_10_2  disj1_4_10_2  5251
    y_4_10_2  disj2_4_10_2  -5251
    y_4_10_3  disj1_4_10_3  5251
    y_4_10_3  disj2_4_10_3  -5251
    y_4_10_4  disj1_4_10_4  5251
    y_4_10_4  disj2_4_10_4  -5251
    y_4_11_0  disj1_4_11_0  5251
    y_4_11_0  disj2_4_11_0  -5251
    y_4_11_1  disj1_4_11_1  5251
    y_4_11_1  disj2_4_11_1  -5251
    y_4_11_2  disj1_4_11_2  5251
    y_4_11_2  disj2_4_11_2  -5251
    y_4_11_3  disj1_4_11_3  5251
    y_4_11_3  disj2_4_11_3  -5251
    y_4_11_4  disj1_4_11_4  5251
    y_4_11_4  disj2_4_11_4  -5251
    y_4_12_0  disj1_4_12_0  5251
    y_4_12_0  disj2_4_12_0  -5251
    y_4_12_1  disj1_4_12_1  5251
    y_4_12_1  disj2_4_12_1  -5251
    y_4_12_2  disj1_4_12_2  5251
    y_4_12_2  disj2_4_12_2  -5251
    y_4_12_3  disj1_4_12_3  5251
    y_4_12_3  disj2_4_12_3  -5251
    y_4_12_4  disj1_4_12_4  5251
    y_4_12_4  disj2_4_12_4  -5251
    y_4_13_0  disj1_4_13_0  5251
    y_4_13_0  disj2_4_13_0  -5251
    y_4_13_1  disj1_4_13_1  5251
    y_4_13_1  disj2_4_13_1  -5251
    y_4_13_2  disj1_4_13_2  5251
    y_4_13_2  disj2_4_13_2  -5251
    y_4_13_3  disj1_4_13_3  5251
    y_4_13_3  disj2_4_13_3  -5251
    y_4_13_4  disj1_4_13_4  5251
    y_4_13_4  disj2_4_13_4  -5251
    y_4_14_0  disj1_4_14_0  5251
    y_4_14_0  disj2_4_14_0  -5251
    y_4_14_1  disj1_4_14_1  5251
    y_4_14_1  disj2_4_14_1  -5251
    y_4_14_2  disj1_4_14_2  5251
    y_4_14_2  disj2_4_14_2  -5251
    y_4_14_3  disj1_4_14_3  5251
    y_4_14_3  disj2_4_14_3  -5251
    y_4_14_4  disj1_4_14_4  5251
    y_4_14_4  disj2_4_14_4  -5251
    y_4_15_0  disj1_4_15_0  5251
    y_4_15_0  disj2_4_15_0  -5251
    y_4_15_1  disj1_4_15_1  5251
    y_4_15_1  disj2_4_15_1  -5251
    y_4_15_2  disj1_4_15_2  5251
    y_4_15_2  disj2_4_15_2  -5251
    y_4_15_3  disj1_4_15_3  5251
    y_4_15_3  disj2_4_15_3  -5251
    y_4_15_4  disj1_4_15_4  5251
    y_4_15_4  disj2_4_15_4  -5251
    y_4_16_0  disj1_4_16_0  5251
    y_4_16_0  disj2_4_16_0  -5251
    y_4_16_1  disj1_4_16_1  5251
    y_4_16_1  disj2_4_16_1  -5251
    y_4_16_2  disj1_4_16_2  5251
    y_4_16_2  disj2_4_16_2  -5251
    y_4_16_3  disj1_4_16_3  5251
    y_4_16_3  disj2_4_16_3  -5251
    y_4_16_4  disj1_4_16_4  5251
    y_4_16_4  disj2_4_16_4  -5251
    y_4_17_0  disj1_4_17_0  5251
    y_4_17_0  disj2_4_17_0  -5251
    y_4_17_1  disj1_4_17_1  5251
    y_4_17_1  disj2_4_17_1  -5251
    y_4_17_2  disj1_4_17_2  5251
    y_4_17_2  disj2_4_17_2  -5251
    y_4_17_3  disj1_4_17_3  5251
    y_4_17_3  disj2_4_17_3  -5251
    y_4_17_4  disj1_4_17_4  5251
    y_4_17_4  disj2_4_17_4  -5251
    y_4_18_0  disj1_4_18_0  5251
    y_4_18_0  disj2_4_18_0  -5251
    y_4_18_1  disj1_4_18_1  5251
    y_4_18_1  disj2_4_18_1  -5251
    y_4_18_2  disj1_4_18_2  5251
    y_4_18_2  disj2_4_18_2  -5251
    y_4_18_3  disj1_4_18_3  5251
    y_4_18_3  disj2_4_18_3  -5251
    y_4_18_4  disj1_4_18_4  5251
    y_4_18_4  disj2_4_18_4  -5251
    y_4_19_0  disj1_4_19_0  5251
    y_4_19_0  disj2_4_19_0  -5251
    y_4_19_1  disj1_4_19_1  5251
    y_4_19_1  disj2_4_19_1  -5251
    y_4_19_2  disj1_4_19_2  5251
    y_4_19_2  disj2_4_19_2  -5251
    y_4_19_3  disj1_4_19_3  5251
    y_4_19_3  disj2_4_19_3  -5251
    y_4_19_4  disj1_4_19_4  5251
    y_4_19_4  disj2_4_19_4  -5251
    y_5_6_0   disj1_5_6_0  5251
    y_5_6_0   disj2_5_6_0  -5251
    y_5_6_1   disj1_5_6_1  5251
    y_5_6_1   disj2_5_6_1  -5251
    y_5_6_2   disj1_5_6_2  5251
    y_5_6_2   disj2_5_6_2  -5251
    y_5_6_3   disj1_5_6_3  5251
    y_5_6_3   disj2_5_6_3  -5251
    y_5_6_4   disj1_5_6_4  5251
    y_5_6_4   disj2_5_6_4  -5251
    y_5_7_0   disj1_5_7_0  5251
    y_5_7_0   disj2_5_7_0  -5251
    y_5_7_1   disj1_5_7_1  5251
    y_5_7_1   disj2_5_7_1  -5251
    y_5_7_2   disj1_5_7_2  5251
    y_5_7_2   disj2_5_7_2  -5251
    y_5_7_3   disj1_5_7_3  5251
    y_5_7_3   disj2_5_7_3  -5251
    y_5_7_4   disj1_5_7_4  5251
    y_5_7_4   disj2_5_7_4  -5251
    y_5_8_0   disj1_5_8_0  5251
    y_5_8_0   disj2_5_8_0  -5251
    y_5_8_1   disj1_5_8_1  5251
    y_5_8_1   disj2_5_8_1  -5251
    y_5_8_2   disj1_5_8_2  5251
    y_5_8_2   disj2_5_8_2  -5251
    y_5_8_3   disj1_5_8_3  5251
    y_5_8_3   disj2_5_8_3  -5251
    y_5_8_4   disj1_5_8_4  5251
    y_5_8_4   disj2_5_8_4  -5251
    y_5_9_0   disj1_5_9_0  5251
    y_5_9_0   disj2_5_9_0  -5251
    y_5_9_1   disj1_5_9_1  5251
    y_5_9_1   disj2_5_9_1  -5251
    y_5_9_2   disj1_5_9_2  5251
    y_5_9_2   disj2_5_9_2  -5251
    y_5_9_3   disj1_5_9_3  5251
    y_5_9_3   disj2_5_9_3  -5251
    y_5_9_4   disj1_5_9_4  5251
    y_5_9_4   disj2_5_9_4  -5251
    y_5_10_0  disj1_5_10_0  5251
    y_5_10_0  disj2_5_10_0  -5251
    y_5_10_1  disj1_5_10_1  5251
    y_5_10_1  disj2_5_10_1  -5251
    y_5_10_2  disj1_5_10_2  5251
    y_5_10_2  disj2_5_10_2  -5251
    y_5_10_3  disj1_5_10_3  5251
    y_5_10_3  disj2_5_10_3  -5251
    y_5_10_4  disj1_5_10_4  5251
    y_5_10_4  disj2_5_10_4  -5251
    y_5_11_0  disj1_5_11_0  5251
    y_5_11_0  disj2_5_11_0  -5251
    y_5_11_1  disj1_5_11_1  5251
    y_5_11_1  disj2_5_11_1  -5251
    y_5_11_2  disj1_5_11_2  5251
    y_5_11_2  disj2_5_11_2  -5251
    y_5_11_3  disj1_5_11_3  5251
    y_5_11_3  disj2_5_11_3  -5251
    y_5_11_4  disj1_5_11_4  5251
    y_5_11_4  disj2_5_11_4  -5251
    y_5_12_0  disj1_5_12_0  5251
    y_5_12_0  disj2_5_12_0  -5251
    y_5_12_1  disj1_5_12_1  5251
    y_5_12_1  disj2_5_12_1  -5251
    y_5_12_2  disj1_5_12_2  5251
    y_5_12_2  disj2_5_12_2  -5251
    y_5_12_3  disj1_5_12_3  5251
    y_5_12_3  disj2_5_12_3  -5251
    y_5_12_4  disj1_5_12_4  5251
    y_5_12_4  disj2_5_12_4  -5251
    y_5_13_0  disj1_5_13_0  5251
    y_5_13_0  disj2_5_13_0  -5251
    y_5_13_1  disj1_5_13_1  5251
    y_5_13_1  disj2_5_13_1  -5251
    y_5_13_2  disj1_5_13_2  5251
    y_5_13_2  disj2_5_13_2  -5251
    y_5_13_3  disj1_5_13_3  5251
    y_5_13_3  disj2_5_13_3  -5251
    y_5_13_4  disj1_5_13_4  5251
    y_5_13_4  disj2_5_13_4  -5251
    y_5_14_0  disj1_5_14_0  5251
    y_5_14_0  disj2_5_14_0  -5251
    y_5_14_1  disj1_5_14_1  5251
    y_5_14_1  disj2_5_14_1  -5251
    y_5_14_2  disj1_5_14_2  5251
    y_5_14_2  disj2_5_14_2  -5251
    y_5_14_3  disj1_5_14_3  5251
    y_5_14_3  disj2_5_14_3  -5251
    y_5_14_4  disj1_5_14_4  5251
    y_5_14_4  disj2_5_14_4  -5251
    y_5_15_0  disj1_5_15_0  5251
    y_5_15_0  disj2_5_15_0  -5251
    y_5_15_1  disj1_5_15_1  5251
    y_5_15_1  disj2_5_15_1  -5251
    y_5_15_2  disj1_5_15_2  5251
    y_5_15_2  disj2_5_15_2  -5251
    y_5_15_3  disj1_5_15_3  5251
    y_5_15_3  disj2_5_15_3  -5251
    y_5_15_4  disj1_5_15_4  5251
    y_5_15_4  disj2_5_15_4  -5251
    y_5_16_0  disj1_5_16_0  5251
    y_5_16_0  disj2_5_16_0  -5251
    y_5_16_1  disj1_5_16_1  5251
    y_5_16_1  disj2_5_16_1  -5251
    y_5_16_2  disj1_5_16_2  5251
    y_5_16_2  disj2_5_16_2  -5251
    y_5_16_3  disj1_5_16_3  5251
    y_5_16_3  disj2_5_16_3  -5251
    y_5_16_4  disj1_5_16_4  5251
    y_5_16_4  disj2_5_16_4  -5251
    y_5_17_0  disj1_5_17_0  5251
    y_5_17_0  disj2_5_17_0  -5251
    y_5_17_1  disj1_5_17_1  5251
    y_5_17_1  disj2_5_17_1  -5251
    y_5_17_2  disj1_5_17_2  5251
    y_5_17_2  disj2_5_17_2  -5251
    y_5_17_3  disj1_5_17_3  5251
    y_5_17_3  disj2_5_17_3  -5251
    y_5_17_4  disj1_5_17_4  5251
    y_5_17_4  disj2_5_17_4  -5251
    y_5_18_0  disj1_5_18_0  5251
    y_5_18_0  disj2_5_18_0  -5251
    y_5_18_1  disj1_5_18_1  5251
    y_5_18_1  disj2_5_18_1  -5251
    y_5_18_2  disj1_5_18_2  5251
    y_5_18_2  disj2_5_18_2  -5251
    y_5_18_3  disj1_5_18_3  5251
    y_5_18_3  disj2_5_18_3  -5251
    y_5_18_4  disj1_5_18_4  5251
    y_5_18_4  disj2_5_18_4  -5251
    y_5_19_0  disj1_5_19_0  5251
    y_5_19_0  disj2_5_19_0  -5251
    y_5_19_1  disj1_5_19_1  5251
    y_5_19_1  disj2_5_19_1  -5251
    y_5_19_2  disj1_5_19_2  5251
    y_5_19_2  disj2_5_19_2  -5251
    y_5_19_3  disj1_5_19_3  5251
    y_5_19_3  disj2_5_19_3  -5251
    y_5_19_4  disj1_5_19_4  5251
    y_5_19_4  disj2_5_19_4  -5251
    y_6_7_0   disj1_6_7_0  5251
    y_6_7_0   disj2_6_7_0  -5251
    y_6_7_1   disj1_6_7_1  5251
    y_6_7_1   disj2_6_7_1  -5251
    y_6_7_2   disj1_6_7_2  5251
    y_6_7_2   disj2_6_7_2  -5251
    y_6_7_3   disj1_6_7_3  5251
    y_6_7_3   disj2_6_7_3  -5251
    y_6_7_4   disj1_6_7_4  5251
    y_6_7_4   disj2_6_7_4  -5251
    y_6_8_0   disj1_6_8_0  5251
    y_6_8_0   disj2_6_8_0  -5251
    y_6_8_1   disj1_6_8_1  5251
    y_6_8_1   disj2_6_8_1  -5251
    y_6_8_2   disj1_6_8_2  5251
    y_6_8_2   disj2_6_8_2  -5251
    y_6_8_3   disj1_6_8_3  5251
    y_6_8_3   disj2_6_8_3  -5251
    y_6_8_4   disj1_6_8_4  5251
    y_6_8_4   disj2_6_8_4  -5251
    y_6_9_0   disj1_6_9_0  5251
    y_6_9_0   disj2_6_9_0  -5251
    y_6_9_1   disj1_6_9_1  5251
    y_6_9_1   disj2_6_9_1  -5251
    y_6_9_2   disj1_6_9_2  5251
    y_6_9_2   disj2_6_9_2  -5251
    y_6_9_3   disj1_6_9_3  5251
    y_6_9_3   disj2_6_9_3  -5251
    y_6_9_4   disj1_6_9_4  5251
    y_6_9_4   disj2_6_9_4  -5251
    y_6_10_0  disj1_6_10_0  5251
    y_6_10_0  disj2_6_10_0  -5251
    y_6_10_1  disj1_6_10_1  5251
    y_6_10_1  disj2_6_10_1  -5251
    y_6_10_2  disj1_6_10_2  5251
    y_6_10_2  disj2_6_10_2  -5251
    y_6_10_3  disj1_6_10_3  5251
    y_6_10_3  disj2_6_10_3  -5251
    y_6_10_4  disj1_6_10_4  5251
    y_6_10_4  disj2_6_10_4  -5251
    y_6_11_0  disj1_6_11_0  5251
    y_6_11_0  disj2_6_11_0  -5251
    y_6_11_1  disj1_6_11_1  5251
    y_6_11_1  disj2_6_11_1  -5251
    y_6_11_2  disj1_6_11_2  5251
    y_6_11_2  disj2_6_11_2  -5251
    y_6_11_3  disj1_6_11_3  5251
    y_6_11_3  disj2_6_11_3  -5251
    y_6_11_4  disj1_6_11_4  5251
    y_6_11_4  disj2_6_11_4  -5251
    y_6_12_0  disj1_6_12_0  5251
    y_6_12_0  disj2_6_12_0  -5251
    y_6_12_1  disj1_6_12_1  5251
    y_6_12_1  disj2_6_12_1  -5251
    y_6_12_2  disj1_6_12_2  5251
    y_6_12_2  disj2_6_12_2  -5251
    y_6_12_3  disj1_6_12_3  5251
    y_6_12_3  disj2_6_12_3  -5251
    y_6_12_4  disj1_6_12_4  5251
    y_6_12_4  disj2_6_12_4  -5251
    y_6_13_0  disj1_6_13_0  5251
    y_6_13_0  disj2_6_13_0  -5251
    y_6_13_1  disj1_6_13_1  5251
    y_6_13_1  disj2_6_13_1  -5251
    y_6_13_2  disj1_6_13_2  5251
    y_6_13_2  disj2_6_13_2  -5251
    y_6_13_3  disj1_6_13_3  5251
    y_6_13_3  disj2_6_13_3  -5251
    y_6_13_4  disj1_6_13_4  5251
    y_6_13_4  disj2_6_13_4  -5251
    y_6_14_0  disj1_6_14_0  5251
    y_6_14_0  disj2_6_14_0  -5251
    y_6_14_1  disj1_6_14_1  5251
    y_6_14_1  disj2_6_14_1  -5251
    y_6_14_2  disj1_6_14_2  5251
    y_6_14_2  disj2_6_14_2  -5251
    y_6_14_3  disj1_6_14_3  5251
    y_6_14_3  disj2_6_14_3  -5251
    y_6_14_4  disj1_6_14_4  5251
    y_6_14_4  disj2_6_14_4  -5251
    y_6_15_0  disj1_6_15_0  5251
    y_6_15_0  disj2_6_15_0  -5251
    y_6_15_1  disj1_6_15_1  5251
    y_6_15_1  disj2_6_15_1  -5251
    y_6_15_2  disj1_6_15_2  5251
    y_6_15_2  disj2_6_15_2  -5251
    y_6_15_3  disj1_6_15_3  5251
    y_6_15_3  disj2_6_15_3  -5251
    y_6_15_4  disj1_6_15_4  5251
    y_6_15_4  disj2_6_15_4  -5251
    y_6_16_0  disj1_6_16_0  5251
    y_6_16_0  disj2_6_16_0  -5251
    y_6_16_1  disj1_6_16_1  5251
    y_6_16_1  disj2_6_16_1  -5251
    y_6_16_2  disj1_6_16_2  5251
    y_6_16_2  disj2_6_16_2  -5251
    y_6_16_3  disj1_6_16_3  5251
    y_6_16_3  disj2_6_16_3  -5251
    y_6_16_4  disj1_6_16_4  5251
    y_6_16_4  disj2_6_16_4  -5251
    y_6_17_0  disj1_6_17_0  5251
    y_6_17_0  disj2_6_17_0  -5251
    y_6_17_1  disj1_6_17_1  5251
    y_6_17_1  disj2_6_17_1  -5251
    y_6_17_2  disj1_6_17_2  5251
    y_6_17_2  disj2_6_17_2  -5251
    y_6_17_3  disj1_6_17_3  5251
    y_6_17_3  disj2_6_17_3  -5251
    y_6_17_4  disj1_6_17_4  5251
    y_6_17_4  disj2_6_17_4  -5251
    y_6_18_0  disj1_6_18_0  5251
    y_6_18_0  disj2_6_18_0  -5251
    y_6_18_1  disj1_6_18_1  5251
    y_6_18_1  disj2_6_18_1  -5251
    y_6_18_2  disj1_6_18_2  5251
    y_6_18_2  disj2_6_18_2  -5251
    y_6_18_3  disj1_6_18_3  5251
    y_6_18_3  disj2_6_18_3  -5251
    y_6_18_4  disj1_6_18_4  5251
    y_6_18_4  disj2_6_18_4  -5251
    y_6_19_0  disj1_6_19_0  5251
    y_6_19_0  disj2_6_19_0  -5251
    y_6_19_1  disj1_6_19_1  5251
    y_6_19_1  disj2_6_19_1  -5251
    y_6_19_2  disj1_6_19_2  5251
    y_6_19_2  disj2_6_19_2  -5251
    y_6_19_3  disj1_6_19_3  5251
    y_6_19_3  disj2_6_19_3  -5251
    y_6_19_4  disj1_6_19_4  5251
    y_6_19_4  disj2_6_19_4  -5251
    y_7_8_0   disj1_7_8_0  5251
    y_7_8_0   disj2_7_8_0  -5251
    y_7_8_1   disj1_7_8_1  5251
    y_7_8_1   disj2_7_8_1  -5251
    y_7_8_2   disj1_7_8_2  5251
    y_7_8_2   disj2_7_8_2  -5251
    y_7_8_3   disj1_7_8_3  5251
    y_7_8_3   disj2_7_8_3  -5251
    y_7_8_4   disj1_7_8_4  5251
    y_7_8_4   disj2_7_8_4  -5251
    y_7_9_0   disj1_7_9_0  5251
    y_7_9_0   disj2_7_9_0  -5251
    y_7_9_1   disj1_7_9_1  5251
    y_7_9_1   disj2_7_9_1  -5251
    y_7_9_2   disj1_7_9_2  5251
    y_7_9_2   disj2_7_9_2  -5251
    y_7_9_3   disj1_7_9_3  5251
    y_7_9_3   disj2_7_9_3  -5251
    y_7_9_4   disj1_7_9_4  5251
    y_7_9_4   disj2_7_9_4  -5251
    y_7_10_0  disj1_7_10_0  5251
    y_7_10_0  disj2_7_10_0  -5251
    y_7_10_1  disj1_7_10_1  5251
    y_7_10_1  disj2_7_10_1  -5251
    y_7_10_2  disj1_7_10_2  5251
    y_7_10_2  disj2_7_10_2  -5251
    y_7_10_3  disj1_7_10_3  5251
    y_7_10_3  disj2_7_10_3  -5251
    y_7_10_4  disj1_7_10_4  5251
    y_7_10_4  disj2_7_10_4  -5251
    y_7_11_0  disj1_7_11_0  5251
    y_7_11_0  disj2_7_11_0  -5251
    y_7_11_1  disj1_7_11_1  5251
    y_7_11_1  disj2_7_11_1  -5251
    y_7_11_2  disj1_7_11_2  5251
    y_7_11_2  disj2_7_11_2  -5251
    y_7_11_3  disj1_7_11_3  5251
    y_7_11_3  disj2_7_11_3  -5251
    y_7_11_4  disj1_7_11_4  5251
    y_7_11_4  disj2_7_11_4  -5251
    y_7_12_0  disj1_7_12_0  5251
    y_7_12_0  disj2_7_12_0  -5251
    y_7_12_1  disj1_7_12_1  5251
    y_7_12_1  disj2_7_12_1  -5251
    y_7_12_2  disj1_7_12_2  5251
    y_7_12_2  disj2_7_12_2  -5251
    y_7_12_3  disj1_7_12_3  5251
    y_7_12_3  disj2_7_12_3  -5251
    y_7_12_4  disj1_7_12_4  5251
    y_7_12_4  disj2_7_12_4  -5251
    y_7_13_0  disj1_7_13_0  5251
    y_7_13_0  disj2_7_13_0  -5251
    y_7_13_1  disj1_7_13_1  5251
    y_7_13_1  disj2_7_13_1  -5251
    y_7_13_2  disj1_7_13_2  5251
    y_7_13_2  disj2_7_13_2  -5251
    y_7_13_3  disj1_7_13_3  5251
    y_7_13_3  disj2_7_13_3  -5251
    y_7_13_4  disj1_7_13_4  5251
    y_7_13_4  disj2_7_13_4  -5251
    y_7_14_0  disj1_7_14_0  5251
    y_7_14_0  disj2_7_14_0  -5251
    y_7_14_1  disj1_7_14_1  5251
    y_7_14_1  disj2_7_14_1  -5251
    y_7_14_2  disj1_7_14_2  5251
    y_7_14_2  disj2_7_14_2  -5251
    y_7_14_3  disj1_7_14_3  5251
    y_7_14_3  disj2_7_14_3  -5251
    y_7_14_4  disj1_7_14_4  5251
    y_7_14_4  disj2_7_14_4  -5251
    y_7_15_0  disj1_7_15_0  5251
    y_7_15_0  disj2_7_15_0  -5251
    y_7_15_1  disj1_7_15_1  5251
    y_7_15_1  disj2_7_15_1  -5251
    y_7_15_2  disj1_7_15_2  5251
    y_7_15_2  disj2_7_15_2  -5251
    y_7_15_3  disj1_7_15_3  5251
    y_7_15_3  disj2_7_15_3  -5251
    y_7_15_4  disj1_7_15_4  5251
    y_7_15_4  disj2_7_15_4  -5251
    y_7_16_0  disj1_7_16_0  5251
    y_7_16_0  disj2_7_16_0  -5251
    y_7_16_1  disj1_7_16_1  5251
    y_7_16_1  disj2_7_16_1  -5251
    y_7_16_2  disj1_7_16_2  5251
    y_7_16_2  disj2_7_16_2  -5251
    y_7_16_3  disj1_7_16_3  5251
    y_7_16_3  disj2_7_16_3  -5251
    y_7_16_4  disj1_7_16_4  5251
    y_7_16_4  disj2_7_16_4  -5251
    y_7_17_0  disj1_7_17_0  5251
    y_7_17_0  disj2_7_17_0  -5251
    y_7_17_1  disj1_7_17_1  5251
    y_7_17_1  disj2_7_17_1  -5251
    y_7_17_2  disj1_7_17_2  5251
    y_7_17_2  disj2_7_17_2  -5251
    y_7_17_3  disj1_7_17_3  5251
    y_7_17_3  disj2_7_17_3  -5251
    y_7_17_4  disj1_7_17_4  5251
    y_7_17_4  disj2_7_17_4  -5251
    y_7_18_0  disj1_7_18_0  5251
    y_7_18_0  disj2_7_18_0  -5251
    y_7_18_1  disj1_7_18_1  5251
    y_7_18_1  disj2_7_18_1  -5251
    y_7_18_2  disj1_7_18_2  5251
    y_7_18_2  disj2_7_18_2  -5251
    y_7_18_3  disj1_7_18_3  5251
    y_7_18_3  disj2_7_18_3  -5251
    y_7_18_4  disj1_7_18_4  5251
    y_7_18_4  disj2_7_18_4  -5251
    y_7_19_0  disj1_7_19_0  5251
    y_7_19_0  disj2_7_19_0  -5251
    y_7_19_1  disj1_7_19_1  5251
    y_7_19_1  disj2_7_19_1  -5251
    y_7_19_2  disj1_7_19_2  5251
    y_7_19_2  disj2_7_19_2  -5251
    y_7_19_3  disj1_7_19_3  5251
    y_7_19_3  disj2_7_19_3  -5251
    y_7_19_4  disj1_7_19_4  5251
    y_7_19_4  disj2_7_19_4  -5251
    y_8_9_0   disj1_8_9_0  5251
    y_8_9_0   disj2_8_9_0  -5251
    y_8_9_1   disj1_8_9_1  5251
    y_8_9_1   disj2_8_9_1  -5251
    y_8_9_2   disj1_8_9_2  5251
    y_8_9_2   disj2_8_9_2  -5251
    y_8_9_3   disj1_8_9_3  5251
    y_8_9_3   disj2_8_9_3  -5251
    y_8_9_4   disj1_8_9_4  5251
    y_8_9_4   disj2_8_9_4  -5251
    y_8_10_0  disj1_8_10_0  5251
    y_8_10_0  disj2_8_10_0  -5251
    y_8_10_1  disj1_8_10_1  5251
    y_8_10_1  disj2_8_10_1  -5251
    y_8_10_2  disj1_8_10_2  5251
    y_8_10_2  disj2_8_10_2  -5251
    y_8_10_3  disj1_8_10_3  5251
    y_8_10_3  disj2_8_10_3  -5251
    y_8_10_4  disj1_8_10_4  5251
    y_8_10_4  disj2_8_10_4  -5251
    y_8_11_0  disj1_8_11_0  5251
    y_8_11_0  disj2_8_11_0  -5251
    y_8_11_1  disj1_8_11_1  5251
    y_8_11_1  disj2_8_11_1  -5251
    y_8_11_2  disj1_8_11_2  5251
    y_8_11_2  disj2_8_11_2  -5251
    y_8_11_3  disj1_8_11_3  5251
    y_8_11_3  disj2_8_11_3  -5251
    y_8_11_4  disj1_8_11_4  5251
    y_8_11_4  disj2_8_11_4  -5251
    y_8_12_0  disj1_8_12_0  5251
    y_8_12_0  disj2_8_12_0  -5251
    y_8_12_1  disj1_8_12_1  5251
    y_8_12_1  disj2_8_12_1  -5251
    y_8_12_2  disj1_8_12_2  5251
    y_8_12_2  disj2_8_12_2  -5251
    y_8_12_3  disj1_8_12_3  5251
    y_8_12_3  disj2_8_12_3  -5251
    y_8_12_4  disj1_8_12_4  5251
    y_8_12_4  disj2_8_12_4  -5251
    y_8_13_0  disj1_8_13_0  5251
    y_8_13_0  disj2_8_13_0  -5251
    y_8_13_1  disj1_8_13_1  5251
    y_8_13_1  disj2_8_13_1  -5251
    y_8_13_2  disj1_8_13_2  5251
    y_8_13_2  disj2_8_13_2  -5251
    y_8_13_3  disj1_8_13_3  5251
    y_8_13_3  disj2_8_13_3  -5251
    y_8_13_4  disj1_8_13_4  5251
    y_8_13_4  disj2_8_13_4  -5251
    y_8_14_0  disj1_8_14_0  5251
    y_8_14_0  disj2_8_14_0  -5251
    y_8_14_1  disj1_8_14_1  5251
    y_8_14_1  disj2_8_14_1  -5251
    y_8_14_2  disj1_8_14_2  5251
    y_8_14_2  disj2_8_14_2  -5251
    y_8_14_3  disj1_8_14_3  5251
    y_8_14_3  disj2_8_14_3  -5251
    y_8_14_4  disj1_8_14_4  5251
    y_8_14_4  disj2_8_14_4  -5251
    y_8_15_0  disj1_8_15_0  5251
    y_8_15_0  disj2_8_15_0  -5251
    y_8_15_1  disj1_8_15_1  5251
    y_8_15_1  disj2_8_15_1  -5251
    y_8_15_2  disj1_8_15_2  5251
    y_8_15_2  disj2_8_15_2  -5251
    y_8_15_3  disj1_8_15_3  5251
    y_8_15_3  disj2_8_15_3  -5251
    y_8_15_4  disj1_8_15_4  5251
    y_8_15_4  disj2_8_15_4  -5251
    y_8_16_0  disj1_8_16_0  5251
    y_8_16_0  disj2_8_16_0  -5251
    y_8_16_1  disj1_8_16_1  5251
    y_8_16_1  disj2_8_16_1  -5251
    y_8_16_2  disj1_8_16_2  5251
    y_8_16_2  disj2_8_16_2  -5251
    y_8_16_3  disj1_8_16_3  5251
    y_8_16_3  disj2_8_16_3  -5251
    y_8_16_4  disj1_8_16_4  5251
    y_8_16_4  disj2_8_16_4  -5251
    y_8_17_0  disj1_8_17_0  5251
    y_8_17_0  disj2_8_17_0  -5251
    y_8_17_1  disj1_8_17_1  5251
    y_8_17_1  disj2_8_17_1  -5251
    y_8_17_2  disj1_8_17_2  5251
    y_8_17_2  disj2_8_17_2  -5251
    y_8_17_3  disj1_8_17_3  5251
    y_8_17_3  disj2_8_17_3  -5251
    y_8_17_4  disj1_8_17_4  5251
    y_8_17_4  disj2_8_17_4  -5251
    y_8_18_0  disj1_8_18_0  5251
    y_8_18_0  disj2_8_18_0  -5251
    y_8_18_1  disj1_8_18_1  5251
    y_8_18_1  disj2_8_18_1  -5251
    y_8_18_2  disj1_8_18_2  5251
    y_8_18_2  disj2_8_18_2  -5251
    y_8_18_3  disj1_8_18_3  5251
    y_8_18_3  disj2_8_18_3  -5251
    y_8_18_4  disj1_8_18_4  5251
    y_8_18_4  disj2_8_18_4  -5251
    y_8_19_0  disj1_8_19_0  5251
    y_8_19_0  disj2_8_19_0  -5251
    y_8_19_1  disj1_8_19_1  5251
    y_8_19_1  disj2_8_19_1  -5251
    y_8_19_2  disj1_8_19_2  5251
    y_8_19_2  disj2_8_19_2  -5251
    y_8_19_3  disj1_8_19_3  5251
    y_8_19_3  disj2_8_19_3  -5251
    y_8_19_4  disj1_8_19_4  5251
    y_8_19_4  disj2_8_19_4  -5251
    y_9_10_0  disj1_9_10_0  5251
    y_9_10_0  disj2_9_10_0  -5251
    y_9_10_1  disj1_9_10_1  5251
    y_9_10_1  disj2_9_10_1  -5251
    y_9_10_2  disj1_9_10_2  5251
    y_9_10_2  disj2_9_10_2  -5251
    y_9_10_3  disj1_9_10_3  5251
    y_9_10_3  disj2_9_10_3  -5251
    y_9_10_4  disj1_9_10_4  5251
    y_9_10_4  disj2_9_10_4  -5251
    y_9_11_0  disj1_9_11_0  5251
    y_9_11_0  disj2_9_11_0  -5251
    y_9_11_1  disj1_9_11_1  5251
    y_9_11_1  disj2_9_11_1  -5251
    y_9_11_2  disj1_9_11_2  5251
    y_9_11_2  disj2_9_11_2  -5251
    y_9_11_3  disj1_9_11_3  5251
    y_9_11_3  disj2_9_11_3  -5251
    y_9_11_4  disj1_9_11_4  5251
    y_9_11_4  disj2_9_11_4  -5251
    y_9_12_0  disj1_9_12_0  5251
    y_9_12_0  disj2_9_12_0  -5251
    y_9_12_1  disj1_9_12_1  5251
    y_9_12_1  disj2_9_12_1  -5251
    y_9_12_2  disj1_9_12_2  5251
    y_9_12_2  disj2_9_12_2  -5251
    y_9_12_3  disj1_9_12_3  5251
    y_9_12_3  disj2_9_12_3  -5251
    y_9_12_4  disj1_9_12_4  5251
    y_9_12_4  disj2_9_12_4  -5251
    y_9_13_0  disj1_9_13_0  5251
    y_9_13_0  disj2_9_13_0  -5251
    y_9_13_1  disj1_9_13_1  5251
    y_9_13_1  disj2_9_13_1  -5251
    y_9_13_2  disj1_9_13_2  5251
    y_9_13_2  disj2_9_13_2  -5251
    y_9_13_3  disj1_9_13_3  5251
    y_9_13_3  disj2_9_13_3  -5251
    y_9_13_4  disj1_9_13_4  5251
    y_9_13_4  disj2_9_13_4  -5251
    y_9_14_0  disj1_9_14_0  5251
    y_9_14_0  disj2_9_14_0  -5251
    y_9_14_1  disj1_9_14_1  5251
    y_9_14_1  disj2_9_14_1  -5251
    y_9_14_2  disj1_9_14_2  5251
    y_9_14_2  disj2_9_14_2  -5251
    y_9_14_3  disj1_9_14_3  5251
    y_9_14_3  disj2_9_14_3  -5251
    y_9_14_4  disj1_9_14_4  5251
    y_9_14_4  disj2_9_14_4  -5251
    y_9_15_0  disj1_9_15_0  5251
    y_9_15_0  disj2_9_15_0  -5251
    y_9_15_1  disj1_9_15_1  5251
    y_9_15_1  disj2_9_15_1  -5251
    y_9_15_2  disj1_9_15_2  5251
    y_9_15_2  disj2_9_15_2  -5251
    y_9_15_3  disj1_9_15_3  5251
    y_9_15_3  disj2_9_15_3  -5251
    y_9_15_4  disj1_9_15_4  5251
    y_9_15_4  disj2_9_15_4  -5251
    y_9_16_0  disj1_9_16_0  5251
    y_9_16_0  disj2_9_16_0  -5251
    y_9_16_1  disj1_9_16_1  5251
    y_9_16_1  disj2_9_16_1  -5251
    y_9_16_2  disj1_9_16_2  5251
    y_9_16_2  disj2_9_16_2  -5251
    y_9_16_3  disj1_9_16_3  5251
    y_9_16_3  disj2_9_16_3  -5251
    y_9_16_4  disj1_9_16_4  5251
    y_9_16_4  disj2_9_16_4  -5251
    y_9_17_0  disj1_9_17_0  5251
    y_9_17_0  disj2_9_17_0  -5251
    y_9_17_1  disj1_9_17_1  5251
    y_9_17_1  disj2_9_17_1  -5251
    y_9_17_2  disj1_9_17_2  5251
    y_9_17_2  disj2_9_17_2  -5251
    y_9_17_3  disj1_9_17_3  5251
    y_9_17_3  disj2_9_17_3  -5251
    y_9_17_4  disj1_9_17_4  5251
    y_9_17_4  disj2_9_17_4  -5251
    y_9_18_0  disj1_9_18_0  5251
    y_9_18_0  disj2_9_18_0  -5251
    y_9_18_1  disj1_9_18_1  5251
    y_9_18_1  disj2_9_18_1  -5251
    y_9_18_2  disj1_9_18_2  5251
    y_9_18_2  disj2_9_18_2  -5251
    y_9_18_3  disj1_9_18_3  5251
    y_9_18_3  disj2_9_18_3  -5251
    y_9_18_4  disj1_9_18_4  5251
    y_9_18_4  disj2_9_18_4  -5251
    y_9_19_0  disj1_9_19_0  5251
    y_9_19_0  disj2_9_19_0  -5251
    y_9_19_1  disj1_9_19_1  5251
    y_9_19_1  disj2_9_19_1  -5251
    y_9_19_2  disj1_9_19_2  5251
    y_9_19_2  disj2_9_19_2  -5251
    y_9_19_3  disj1_9_19_3  5251
    y_9_19_3  disj2_9_19_3  -5251
    y_9_19_4  disj1_9_19_4  5251
    y_9_19_4  disj2_9_19_4  -5251
    y_10_11_0  disj1_10_11_0  5251
    y_10_11_0  disj2_10_11_0  -5251
    y_10_11_1  disj1_10_11_1  5251
    y_10_11_1  disj2_10_11_1  -5251
    y_10_11_2  disj1_10_11_2  5251
    y_10_11_2  disj2_10_11_2  -5251
    y_10_11_3  disj1_10_11_3  5251
    y_10_11_3  disj2_10_11_3  -5251
    y_10_11_4  disj1_10_11_4  5251
    y_10_11_4  disj2_10_11_4  -5251
    y_10_12_0  disj1_10_12_0  5251
    y_10_12_0  disj2_10_12_0  -5251
    y_10_12_1  disj1_10_12_1  5251
    y_10_12_1  disj2_10_12_1  -5251
    y_10_12_2  disj1_10_12_2  5251
    y_10_12_2  disj2_10_12_2  -5251
    y_10_12_3  disj1_10_12_3  5251
    y_10_12_3  disj2_10_12_3  -5251
    y_10_12_4  disj1_10_12_4  5251
    y_10_12_4  disj2_10_12_4  -5251
    y_10_13_0  disj1_10_13_0  5251
    y_10_13_0  disj2_10_13_0  -5251
    y_10_13_1  disj1_10_13_1  5251
    y_10_13_1  disj2_10_13_1  -5251
    y_10_13_2  disj1_10_13_2  5251
    y_10_13_2  disj2_10_13_2  -5251
    y_10_13_3  disj1_10_13_3  5251
    y_10_13_3  disj2_10_13_3  -5251
    y_10_13_4  disj1_10_13_4  5251
    y_10_13_4  disj2_10_13_4  -5251
    y_10_14_0  disj1_10_14_0  5251
    y_10_14_0  disj2_10_14_0  -5251
    y_10_14_1  disj1_10_14_1  5251
    y_10_14_1  disj2_10_14_1  -5251
    y_10_14_2  disj1_10_14_2  5251
    y_10_14_2  disj2_10_14_2  -5251
    y_10_14_3  disj1_10_14_3  5251
    y_10_14_3  disj2_10_14_3  -5251
    y_10_14_4  disj1_10_14_4  5251
    y_10_14_4  disj2_10_14_4  -5251
    y_10_15_0  disj1_10_15_0  5251
    y_10_15_0  disj2_10_15_0  -5251
    y_10_15_1  disj1_10_15_1  5251
    y_10_15_1  disj2_10_15_1  -5251
    y_10_15_2  disj1_10_15_2  5251
    y_10_15_2  disj2_10_15_2  -5251
    y_10_15_3  disj1_10_15_3  5251
    y_10_15_3  disj2_10_15_3  -5251
    y_10_15_4  disj1_10_15_4  5251
    y_10_15_4  disj2_10_15_4  -5251
    y_10_16_0  disj1_10_16_0  5251
    y_10_16_0  disj2_10_16_0  -5251
    y_10_16_1  disj1_10_16_1  5251
    y_10_16_1  disj2_10_16_1  -5251
    y_10_16_2  disj1_10_16_2  5251
    y_10_16_2  disj2_10_16_2  -5251
    y_10_16_3  disj1_10_16_3  5251
    y_10_16_3  disj2_10_16_3  -5251
    y_10_16_4  disj1_10_16_4  5251
    y_10_16_4  disj2_10_16_4  -5251
    y_10_17_0  disj1_10_17_0  5251
    y_10_17_0  disj2_10_17_0  -5251
    y_10_17_1  disj1_10_17_1  5251
    y_10_17_1  disj2_10_17_1  -5251
    y_10_17_2  disj1_10_17_2  5251
    y_10_17_2  disj2_10_17_2  -5251
    y_10_17_3  disj1_10_17_3  5251
    y_10_17_3  disj2_10_17_3  -5251
    y_10_17_4  disj1_10_17_4  5251
    y_10_17_4  disj2_10_17_4  -5251
    y_10_18_0  disj1_10_18_0  5251
    y_10_18_0  disj2_10_18_0  -5251
    y_10_18_1  disj1_10_18_1  5251
    y_10_18_1  disj2_10_18_1  -5251
    y_10_18_2  disj1_10_18_2  5251
    y_10_18_2  disj2_10_18_2  -5251
    y_10_18_3  disj1_10_18_3  5251
    y_10_18_3  disj2_10_18_3  -5251
    y_10_18_4  disj1_10_18_4  5251
    y_10_18_4  disj2_10_18_4  -5251
    y_10_19_0  disj1_10_19_0  5251
    y_10_19_0  disj2_10_19_0  -5251
    y_10_19_1  disj1_10_19_1  5251
    y_10_19_1  disj2_10_19_1  -5251
    y_10_19_2  disj1_10_19_2  5251
    y_10_19_2  disj2_10_19_2  -5251
    y_10_19_3  disj1_10_19_3  5251
    y_10_19_3  disj2_10_19_3  -5251
    y_10_19_4  disj1_10_19_4  5251
    y_10_19_4  disj2_10_19_4  -5251
    y_11_12_0  disj1_11_12_0  5251
    y_11_12_0  disj2_11_12_0  -5251
    y_11_12_1  disj1_11_12_1  5251
    y_11_12_1  disj2_11_12_1  -5251
    y_11_12_2  disj1_11_12_2  5251
    y_11_12_2  disj2_11_12_2  -5251
    y_11_12_3  disj1_11_12_3  5251
    y_11_12_3  disj2_11_12_3  -5251
    y_11_12_4  disj1_11_12_4  5251
    y_11_12_4  disj2_11_12_4  -5251
    y_11_13_0  disj1_11_13_0  5251
    y_11_13_0  disj2_11_13_0  -5251
    y_11_13_1  disj1_11_13_1  5251
    y_11_13_1  disj2_11_13_1  -5251
    y_11_13_2  disj1_11_13_2  5251
    y_11_13_2  disj2_11_13_2  -5251
    y_11_13_3  disj1_11_13_3  5251
    y_11_13_3  disj2_11_13_3  -5251
    y_11_13_4  disj1_11_13_4  5251
    y_11_13_4  disj2_11_13_4  -5251
    y_11_14_0  disj1_11_14_0  5251
    y_11_14_0  disj2_11_14_0  -5251
    y_11_14_1  disj1_11_14_1  5251
    y_11_14_1  disj2_11_14_1  -5251
    y_11_14_2  disj1_11_14_2  5251
    y_11_14_2  disj2_11_14_2  -5251
    y_11_14_3  disj1_11_14_3  5251
    y_11_14_3  disj2_11_14_3  -5251
    y_11_14_4  disj1_11_14_4  5251
    y_11_14_4  disj2_11_14_4  -5251
    y_11_15_0  disj1_11_15_0  5251
    y_11_15_0  disj2_11_15_0  -5251
    y_11_15_1  disj1_11_15_1  5251
    y_11_15_1  disj2_11_15_1  -5251
    y_11_15_2  disj1_11_15_2  5251
    y_11_15_2  disj2_11_15_2  -5251
    y_11_15_3  disj1_11_15_3  5251
    y_11_15_3  disj2_11_15_3  -5251
    y_11_15_4  disj1_11_15_4  5251
    y_11_15_4  disj2_11_15_4  -5251
    y_11_16_0  disj1_11_16_0  5251
    y_11_16_0  disj2_11_16_0  -5251
    y_11_16_1  disj1_11_16_1  5251
    y_11_16_1  disj2_11_16_1  -5251
    y_11_16_2  disj1_11_16_2  5251
    y_11_16_2  disj2_11_16_2  -5251
    y_11_16_3  disj1_11_16_3  5251
    y_11_16_3  disj2_11_16_3  -5251
    y_11_16_4  disj1_11_16_4  5251
    y_11_16_4  disj2_11_16_4  -5251
    y_11_17_0  disj1_11_17_0  5251
    y_11_17_0  disj2_11_17_0  -5251
    y_11_17_1  disj1_11_17_1  5251
    y_11_17_1  disj2_11_17_1  -5251
    y_11_17_2  disj1_11_17_2  5251
    y_11_17_2  disj2_11_17_2  -5251
    y_11_17_3  disj1_11_17_3  5251
    y_11_17_3  disj2_11_17_3  -5251
    y_11_17_4  disj1_11_17_4  5251
    y_11_17_4  disj2_11_17_4  -5251
    y_11_18_0  disj1_11_18_0  5251
    y_11_18_0  disj2_11_18_0  -5251
    y_11_18_1  disj1_11_18_1  5251
    y_11_18_1  disj2_11_18_1  -5251
    y_11_18_2  disj1_11_18_2  5251
    y_11_18_2  disj2_11_18_2  -5251
    y_11_18_3  disj1_11_18_3  5251
    y_11_18_3  disj2_11_18_3  -5251
    y_11_18_4  disj1_11_18_4  5251
    y_11_18_4  disj2_11_18_4  -5251
    y_11_19_0  disj1_11_19_0  5251
    y_11_19_0  disj2_11_19_0  -5251
    y_11_19_1  disj1_11_19_1  5251
    y_11_19_1  disj2_11_19_1  -5251
    y_11_19_2  disj1_11_19_2  5251
    y_11_19_2  disj2_11_19_2  -5251
    y_11_19_3  disj1_11_19_3  5251
    y_11_19_3  disj2_11_19_3  -5251
    y_11_19_4  disj1_11_19_4  5251
    y_11_19_4  disj2_11_19_4  -5251
    y_12_13_0  disj1_12_13_0  5251
    y_12_13_0  disj2_12_13_0  -5251
    y_12_13_1  disj1_12_13_1  5251
    y_12_13_1  disj2_12_13_1  -5251
    y_12_13_2  disj1_12_13_2  5251
    y_12_13_2  disj2_12_13_2  -5251
    y_12_13_3  disj1_12_13_3  5251
    y_12_13_3  disj2_12_13_3  -5251
    y_12_13_4  disj1_12_13_4  5251
    y_12_13_4  disj2_12_13_4  -5251
    y_12_14_0  disj1_12_14_0  5251
    y_12_14_0  disj2_12_14_0  -5251
    y_12_14_1  disj1_12_14_1  5251
    y_12_14_1  disj2_12_14_1  -5251
    y_12_14_2  disj1_12_14_2  5251
    y_12_14_2  disj2_12_14_2  -5251
    y_12_14_3  disj1_12_14_3  5251
    y_12_14_3  disj2_12_14_3  -5251
    y_12_14_4  disj1_12_14_4  5251
    y_12_14_4  disj2_12_14_4  -5251
    y_12_15_0  disj1_12_15_0  5251
    y_12_15_0  disj2_12_15_0  -5251
    y_12_15_1  disj1_12_15_1  5251
    y_12_15_1  disj2_12_15_1  -5251
    y_12_15_2  disj1_12_15_2  5251
    y_12_15_2  disj2_12_15_2  -5251
    y_12_15_3  disj1_12_15_3  5251
    y_12_15_3  disj2_12_15_3  -5251
    y_12_15_4  disj1_12_15_4  5251
    y_12_15_4  disj2_12_15_4  -5251
    y_12_16_0  disj1_12_16_0  5251
    y_12_16_0  disj2_12_16_0  -5251
    y_12_16_1  disj1_12_16_1  5251
    y_12_16_1  disj2_12_16_1  -5251
    y_12_16_2  disj1_12_16_2  5251
    y_12_16_2  disj2_12_16_2  -5251
    y_12_16_3  disj1_12_16_3  5251
    y_12_16_3  disj2_12_16_3  -5251
    y_12_16_4  disj1_12_16_4  5251
    y_12_16_4  disj2_12_16_4  -5251
    y_12_17_0  disj1_12_17_0  5251
    y_12_17_0  disj2_12_17_0  -5251
    y_12_17_1  disj1_12_17_1  5251
    y_12_17_1  disj2_12_17_1  -5251
    y_12_17_2  disj1_12_17_2  5251
    y_12_17_2  disj2_12_17_2  -5251
    y_12_17_3  disj1_12_17_3  5251
    y_12_17_3  disj2_12_17_3  -5251
    y_12_17_4  disj1_12_17_4  5251
    y_12_17_4  disj2_12_17_4  -5251
    y_12_18_0  disj1_12_18_0  5251
    y_12_18_0  disj2_12_18_0  -5251
    y_12_18_1  disj1_12_18_1  5251
    y_12_18_1  disj2_12_18_1  -5251
    y_12_18_2  disj1_12_18_2  5251
    y_12_18_2  disj2_12_18_2  -5251
    y_12_18_3  disj1_12_18_3  5251
    y_12_18_3  disj2_12_18_3  -5251
    y_12_18_4  disj1_12_18_4  5251
    y_12_18_4  disj2_12_18_4  -5251
    y_12_19_0  disj1_12_19_0  5251
    y_12_19_0  disj2_12_19_0  -5251
    y_12_19_1  disj1_12_19_1  5251
    y_12_19_1  disj2_12_19_1  -5251
    y_12_19_2  disj1_12_19_2  5251
    y_12_19_2  disj2_12_19_2  -5251
    y_12_19_3  disj1_12_19_3  5251
    y_12_19_3  disj2_12_19_3  -5251
    y_12_19_4  disj1_12_19_4  5251
    y_12_19_4  disj2_12_19_4  -5251
    y_13_14_0  disj1_13_14_0  5251
    y_13_14_0  disj2_13_14_0  -5251
    y_13_14_1  disj1_13_14_1  5251
    y_13_14_1  disj2_13_14_1  -5251
    y_13_14_2  disj1_13_14_2  5251
    y_13_14_2  disj2_13_14_2  -5251
    y_13_14_3  disj1_13_14_3  5251
    y_13_14_3  disj2_13_14_3  -5251
    y_13_14_4  disj1_13_14_4  5251
    y_13_14_4  disj2_13_14_4  -5251
    y_13_15_0  disj1_13_15_0  5251
    y_13_15_0  disj2_13_15_0  -5251
    y_13_15_1  disj1_13_15_1  5251
    y_13_15_1  disj2_13_15_1  -5251
    y_13_15_2  disj1_13_15_2  5251
    y_13_15_2  disj2_13_15_2  -5251
    y_13_15_3  disj1_13_15_3  5251
    y_13_15_3  disj2_13_15_3  -5251
    y_13_15_4  disj1_13_15_4  5251
    y_13_15_4  disj2_13_15_4  -5251
    y_13_16_0  disj1_13_16_0  5251
    y_13_16_0  disj2_13_16_0  -5251
    y_13_16_1  disj1_13_16_1  5251
    y_13_16_1  disj2_13_16_1  -5251
    y_13_16_2  disj1_13_16_2  5251
    y_13_16_2  disj2_13_16_2  -5251
    y_13_16_3  disj1_13_16_3  5251
    y_13_16_3  disj2_13_16_3  -5251
    y_13_16_4  disj1_13_16_4  5251
    y_13_16_4  disj2_13_16_4  -5251
    y_13_17_0  disj1_13_17_0  5251
    y_13_17_0  disj2_13_17_0  -5251
    y_13_17_1  disj1_13_17_1  5251
    y_13_17_1  disj2_13_17_1  -5251
    y_13_17_2  disj1_13_17_2  5251
    y_13_17_2  disj2_13_17_2  -5251
    y_13_17_3  disj1_13_17_3  5251
    y_13_17_3  disj2_13_17_3  -5251
    y_13_17_4  disj1_13_17_4  5251
    y_13_17_4  disj2_13_17_4  -5251
    y_13_18_0  disj1_13_18_0  5251
    y_13_18_0  disj2_13_18_0  -5251
    y_13_18_1  disj1_13_18_1  5251
    y_13_18_1  disj2_13_18_1  -5251
    y_13_18_2  disj1_13_18_2  5251
    y_13_18_2  disj2_13_18_2  -5251
    y_13_18_3  disj1_13_18_3  5251
    y_13_18_3  disj2_13_18_3  -5251
    y_13_18_4  disj1_13_18_4  5251
    y_13_18_4  disj2_13_18_4  -5251
    y_13_19_0  disj1_13_19_0  5251
    y_13_19_0  disj2_13_19_0  -5251
    y_13_19_1  disj1_13_19_1  5251
    y_13_19_1  disj2_13_19_1  -5251
    y_13_19_2  disj1_13_19_2  5251
    y_13_19_2  disj2_13_19_2  -5251
    y_13_19_3  disj1_13_19_3  5251
    y_13_19_3  disj2_13_19_3  -5251
    y_13_19_4  disj1_13_19_4  5251
    y_13_19_4  disj2_13_19_4  -5251
    y_14_15_0  disj1_14_15_0  5251
    y_14_15_0  disj2_14_15_0  -5251
    y_14_15_1  disj1_14_15_1  5251
    y_14_15_1  disj2_14_15_1  -5251
    y_14_15_2  disj1_14_15_2  5251
    y_14_15_2  disj2_14_15_2  -5251
    y_14_15_3  disj1_14_15_3  5251
    y_14_15_3  disj2_14_15_3  -5251
    y_14_15_4  disj1_14_15_4  5251
    y_14_15_4  disj2_14_15_4  -5251
    y_14_16_0  disj1_14_16_0  5251
    y_14_16_0  disj2_14_16_0  -5251
    y_14_16_1  disj1_14_16_1  5251
    y_14_16_1  disj2_14_16_1  -5251
    y_14_16_2  disj1_14_16_2  5251
    y_14_16_2  disj2_14_16_2  -5251
    y_14_16_3  disj1_14_16_3  5251
    y_14_16_3  disj2_14_16_3  -5251
    y_14_16_4  disj1_14_16_4  5251
    y_14_16_4  disj2_14_16_4  -5251
    y_14_17_0  disj1_14_17_0  5251
    y_14_17_0  disj2_14_17_0  -5251
    y_14_17_1  disj1_14_17_1  5251
    y_14_17_1  disj2_14_17_1  -5251
    y_14_17_2  disj1_14_17_2  5251
    y_14_17_2  disj2_14_17_2  -5251
    y_14_17_3  disj1_14_17_3  5251
    y_14_17_3  disj2_14_17_3  -5251
    y_14_17_4  disj1_14_17_4  5251
    y_14_17_4  disj2_14_17_4  -5251
    y_14_18_0  disj1_14_18_0  5251
    y_14_18_0  disj2_14_18_0  -5251
    y_14_18_1  disj1_14_18_1  5251
    y_14_18_1  disj2_14_18_1  -5251
    y_14_18_2  disj1_14_18_2  5251
    y_14_18_2  disj2_14_18_2  -5251
    y_14_18_3  disj1_14_18_3  5251
    y_14_18_3  disj2_14_18_3  -5251
    y_14_18_4  disj1_14_18_4  5251
    y_14_18_4  disj2_14_18_4  -5251
    y_14_19_0  disj1_14_19_0  5251
    y_14_19_0  disj2_14_19_0  -5251
    y_14_19_1  disj1_14_19_1  5251
    y_14_19_1  disj2_14_19_1  -5251
    y_14_19_2  disj1_14_19_2  5251
    y_14_19_2  disj2_14_19_2  -5251
    y_14_19_3  disj1_14_19_3  5251
    y_14_19_3  disj2_14_19_3  -5251
    y_14_19_4  disj1_14_19_4  5251
    y_14_19_4  disj2_14_19_4  -5251
    y_15_16_0  disj1_15_16_0  5251
    y_15_16_0  disj2_15_16_0  -5251
    y_15_16_1  disj1_15_16_1  5251
    y_15_16_1  disj2_15_16_1  -5251
    y_15_16_2  disj1_15_16_2  5251
    y_15_16_2  disj2_15_16_2  -5251
    y_15_16_3  disj1_15_16_3  5251
    y_15_16_3  disj2_15_16_3  -5251
    y_15_16_4  disj1_15_16_4  5251
    y_15_16_4  disj2_15_16_4  -5251
    y_15_17_0  disj1_15_17_0  5251
    y_15_17_0  disj2_15_17_0  -5251
    y_15_17_1  disj1_15_17_1  5251
    y_15_17_1  disj2_15_17_1  -5251
    y_15_17_2  disj1_15_17_2  5251
    y_15_17_2  disj2_15_17_2  -5251
    y_15_17_3  disj1_15_17_3  5251
    y_15_17_3  disj2_15_17_3  -5251
    y_15_17_4  disj1_15_17_4  5251
    y_15_17_4  disj2_15_17_4  -5251
    y_15_18_0  disj1_15_18_0  5251
    y_15_18_0  disj2_15_18_0  -5251
    y_15_18_1  disj1_15_18_1  5251
    y_15_18_1  disj2_15_18_1  -5251
    y_15_18_2  disj1_15_18_2  5251
    y_15_18_2  disj2_15_18_2  -5251
    y_15_18_3  disj1_15_18_3  5251
    y_15_18_3  disj2_15_18_3  -5251
    y_15_18_4  disj1_15_18_4  5251
    y_15_18_4  disj2_15_18_4  -5251
    y_15_19_0  disj1_15_19_0  5251
    y_15_19_0  disj2_15_19_0  -5251
    y_15_19_1  disj1_15_19_1  5251
    y_15_19_1  disj2_15_19_1  -5251
    y_15_19_2  disj1_15_19_2  5251
    y_15_19_2  disj2_15_19_2  -5251
    y_15_19_3  disj1_15_19_3  5251
    y_15_19_3  disj2_15_19_3  -5251
    y_15_19_4  disj1_15_19_4  5251
    y_15_19_4  disj2_15_19_4  -5251
    y_16_17_0  disj1_16_17_0  5251
    y_16_17_0  disj2_16_17_0  -5251
    y_16_17_1  disj1_16_17_1  5251
    y_16_17_1  disj2_16_17_1  -5251
    y_16_17_2  disj1_16_17_2  5251
    y_16_17_2  disj2_16_17_2  -5251
    y_16_17_3  disj1_16_17_3  5251
    y_16_17_3  disj2_16_17_3  -5251
    y_16_17_4  disj1_16_17_4  5251
    y_16_17_4  disj2_16_17_4  -5251
    y_16_18_0  disj1_16_18_0  5251
    y_16_18_0  disj2_16_18_0  -5251
    y_16_18_1  disj1_16_18_1  5251
    y_16_18_1  disj2_16_18_1  -5251
    y_16_18_2  disj1_16_18_2  5251
    y_16_18_2  disj2_16_18_2  -5251
    y_16_18_3  disj1_16_18_3  5251
    y_16_18_3  disj2_16_18_3  -5251
    y_16_18_4  disj1_16_18_4  5251
    y_16_18_4  disj2_16_18_4  -5251
    y_16_19_0  disj1_16_19_0  5251
    y_16_19_0  disj2_16_19_0  -5251
    y_16_19_1  disj1_16_19_1  5251
    y_16_19_1  disj2_16_19_1  -5251
    y_16_19_2  disj1_16_19_2  5251
    y_16_19_2  disj2_16_19_2  -5251
    y_16_19_3  disj1_16_19_3  5251
    y_16_19_3  disj2_16_19_3  -5251
    y_16_19_4  disj1_16_19_4  5251
    y_16_19_4  disj2_16_19_4  -5251
    y_17_18_0  disj1_17_18_0  5251
    y_17_18_0  disj2_17_18_0  -5251
    y_17_18_1  disj1_17_18_1  5251
    y_17_18_1  disj2_17_18_1  -5251
    y_17_18_2  disj1_17_18_2  5251
    y_17_18_2  disj2_17_18_2  -5251
    y_17_18_3  disj1_17_18_3  5251
    y_17_18_3  disj2_17_18_3  -5251
    y_17_18_4  disj1_17_18_4  5251
    y_17_18_4  disj2_17_18_4  -5251
    y_17_19_0  disj1_17_19_0  5251
    y_17_19_0  disj2_17_19_0  -5251
    y_17_19_1  disj1_17_19_1  5251
    y_17_19_1  disj2_17_19_1  -5251
    y_17_19_2  disj1_17_19_2  5251
    y_17_19_2  disj2_17_19_2  -5251
    y_17_19_3  disj1_17_19_3  5251
    y_17_19_3  disj2_17_19_3  -5251
    y_17_19_4  disj1_17_19_4  5251
    y_17_19_4  disj2_17_19_4  -5251
    y_18_19_0  disj1_18_19_0  5251
    y_18_19_0  disj2_18_19_0  -5251
    y_18_19_1  disj1_18_19_1  5251
    y_18_19_1  disj2_18_19_1  -5251
    y_18_19_2  disj1_18_19_2  5251
    y_18_19_2  disj2_18_19_2  -5251
    y_18_19_3  disj1_18_19_3  5251
    y_18_19_3  disj2_18_19_3  -5251
    y_18_19_4  disj1_18_19_4  5251
    y_18_19_4  disj2_18_19_4  -5251
    MARK9999  'MARKER'                 'INTEND'
RHS
    RHS       prec_0_0  21
    RHS       prec_0_1  34
    RHS       prec_0_2  95
    RHS       prec_0_3  41
    RHS       prec_1_0  52
    RHS       prec_1_1  16
    RHS       prec_1_2  31
    RHS       prec_1_3  21
    RHS       prec_2_0  42
    RHS       prec_2_1  39
    RHS       prec_2_2  98
    RHS       prec_2_3  54
    RHS       prec_3_0  55
    RHS       prec_3_1  79
    RHS       prec_3_2  77
    RHS       prec_3_3  98
    RHS       prec_4_0  34
    RHS       prec_4_1  64
    RHS       prec_4_2  30
    RHS       prec_4_3  83
    RHS       prec_5_0  92
    RHS       prec_5_1  62
    RHS       prec_5_2  54
    RHS       prec_5_3  43
    RHS       prec_6_0  69
    RHS       prec_6_1  77
    RHS       prec_6_2  87
    RHS       prec_6_3  93
    RHS       prec_7_0  38
    RHS       prec_7_1  60
    RHS       prec_7_2  41
    RHS       prec_7_3  83
    RHS       prec_8_0  17
    RHS       prec_8_1  49
    RHS       prec_8_2  25
    RHS       prec_8_3  44
    RHS       prec_9_0  96
    RHS       prec_9_1  77
    RHS       prec_9_2  79
    RHS       prec_9_3  75
    RHS       prec_10_0  28
    RHS       prec_10_1  35
    RHS       prec_10_2  95
    RHS       prec_10_3  76
    RHS       prec_11_0  9
    RHS       prec_11_1  10
    RHS       prec_11_2  91
    RHS       prec_11_3  59
    RHS       prec_12_0  46
    RHS       prec_12_1  28
    RHS       prec_12_2  52
    RHS       prec_12_3  16
    RHS       prec_13_0  91
    RHS       prec_13_1  50
    RHS       prec_13_2  59
    RHS       prec_13_3  43
    RHS       prec_14_0  27
    RHS       prec_14_1  59
    RHS       prec_14_2  46
    RHS       prec_14_3  45
    RHS       prec_15_0  59
    RHS       prec_15_1  46
    RHS       prec_15_2  74
    RHS       prec_15_3  43
    RHS       prec_16_0  45
    RHS       prec_16_1  78
    RHS       prec_16_2  28
    RHS       prec_16_3  28
    RHS       prec_17_0  28
    RHS       prec_17_1  23
    RHS       prec_17_2  62
    RHS       prec_17_3  45
    RHS       prec_18_0  54
    RHS       prec_18_1  21
    RHS       prec_18_2  20
    RHS       prec_18_3  43
    RHS       prec_19_0  87
    RHS       prec_19_1  60
    RHS       prec_19_2  54
    RHS       prec_19_3  43
    RHS       mksp_0    66
    RHS       mksp_1    26
    RHS       mksp_2    16
    RHS       mksp_3    77
    RHS       mksp_4    19
    RHS       mksp_5    79
    RHS       mksp_6    87
    RHS       mksp_7    24
    RHS       mksp_8    98
    RHS       mksp_9    43
    RHS       mksp_10   7
    RHS       mksp_11   59
    RHS       mksp_12   59
    RHS       mksp_13   50
    RHS       mksp_14   90
    RHS       mksp_15   45
    RHS       mksp_16   23
    RHS       mksp_17   45
    RHS       mksp_18   98
    RHS       mksp_19   9
    RHS       disj1_0_1_0  95
    RHS       disj2_0_1_0  -5230
    RHS       disj1_0_2_0  95
    RHS       disj2_0_2_0  -5209
    RHS       disj1_0_3_0  95
    RHS       disj2_0_3_0  -5172
    RHS       disj1_0_4_0  95
    RHS       disj2_0_4_0  -5217
    RHS       disj1_0_5_0  95
    RHS       disj2_0_5_0  -5197
    RHS       disj1_0_6_0  95
    RHS       disj2_0_6_0  -5158
    RHS       disj1_0_7_0  95
    RHS       disj2_0_7_0  -5227
    RHS       disj1_0_8_0  95
    RHS       disj2_0_8_0  -5234
    RHS       disj1_0_9_0  95
    RHS       disj2_0_9_0  -5174
    RHS       disj1_0_10_0  95
    RHS       disj2_0_10_0  -5244
    RHS       disj1_0_11_0  95
    RHS       disj2_0_11_0  -5241
    RHS       disj1_0_12_0  95
    RHS       disj2_0_12_0  -5192
    RHS       disj1_0_13_0  95
    RHS       disj2_0_13_0  -5192
    RHS       disj1_0_14_0  95
    RHS       disj2_0_14_0  -5224
    RHS       disj1_0_15_0  95
    RHS       disj2_0_15_0  -5206
    RHS       disj1_0_16_0  95
    RHS       disj2_0_16_0  -5173
    RHS       disj1_0_17_0  95
    RHS       disj2_0_17_0  -5189
    RHS       disj1_0_18_0  95
    RHS       disj2_0_18_0  -5208
    RHS       disj1_0_19_0  95
    RHS       disj2_0_19_0  -5164
    RHS       disj1_1_2_0  21
    RHS       disj2_1_2_0  -5209
    RHS       disj1_1_3_0  21
    RHS       disj2_1_3_0  -5172
    RHS       disj1_1_4_0  21
    RHS       disj2_1_4_0  -5217
    RHS       disj1_1_5_0  21
    RHS       disj2_1_5_0  -5197
    RHS       disj1_1_6_0  21
    RHS       disj2_1_6_0  -5158
    RHS       disj1_1_7_0  21
    RHS       disj2_1_7_0  -5227
    RHS       disj1_1_8_0  21
    RHS       disj2_1_8_0  -5234
    RHS       disj1_1_9_0  21
    RHS       disj2_1_9_0  -5174
    RHS       disj1_1_10_0  21
    RHS       disj2_1_10_0  -5244
    RHS       disj1_1_11_0  21
    RHS       disj2_1_11_0  -5241
    RHS       disj1_1_12_0  21
    RHS       disj2_1_12_0  -5192
    RHS       disj1_1_13_0  21
    RHS       disj2_1_13_0  -5192
    RHS       disj1_1_14_0  21
    RHS       disj2_1_14_0  -5224
    RHS       disj1_1_15_0  21
    RHS       disj2_1_15_0  -5206
    RHS       disj1_1_16_0  21
    RHS       disj2_1_16_0  -5173
    RHS       disj1_1_17_0  21
    RHS       disj2_1_17_0  -5189
    RHS       disj1_1_18_0  21
    RHS       disj2_1_18_0  -5208
    RHS       disj1_1_19_0  21
    RHS       disj2_1_19_0  -5164
    RHS       disj1_2_3_0  42
    RHS       disj2_2_3_0  -5172
    RHS       disj1_2_4_0  42
    RHS       disj2_2_4_0  -5217
    RHS       disj1_2_5_0  42
    RHS       disj2_2_5_0  -5197
    RHS       disj1_2_6_0  42
    RHS       disj2_2_6_0  -5158
    RHS       disj1_2_7_0  42
    RHS       disj2_2_7_0  -5227
    RHS       disj1_2_8_0  42
    RHS       disj2_2_8_0  -5234
    RHS       disj1_2_9_0  42
    RHS       disj2_2_9_0  -5174
    RHS       disj1_2_10_0  42
    RHS       disj2_2_10_0  -5244
    RHS       disj1_2_11_0  42
    RHS       disj2_2_11_0  -5241
    RHS       disj1_2_12_0  42
    RHS       disj2_2_12_0  -5192
    RHS       disj1_2_13_0  42
    RHS       disj2_2_13_0  -5192
    RHS       disj1_2_14_0  42
    RHS       disj2_2_14_0  -5224
    RHS       disj1_2_15_0  42
    RHS       disj2_2_15_0  -5206
    RHS       disj1_2_16_0  42
    RHS       disj2_2_16_0  -5173
    RHS       disj1_2_17_0  42
    RHS       disj2_2_17_0  -5189
    RHS       disj1_2_18_0  42
    RHS       disj2_2_18_0  -5208
    RHS       disj1_2_19_0  42
    RHS       disj2_2_19_0  -5164
    RHS       disj1_3_4_0  79
    RHS       disj2_3_4_0  -5217
    RHS       disj1_3_5_0  79
    RHS       disj2_3_5_0  -5197
    RHS       disj1_3_6_0  79
    RHS       disj2_3_6_0  -5158
    RHS       disj1_3_7_0  79
    RHS       disj2_3_7_0  -5227
    RHS       disj1_3_8_0  79
    RHS       disj2_3_8_0  -5234
    RHS       disj1_3_9_0  79
    RHS       disj2_3_9_0  -5174
    RHS       disj1_3_10_0  79
    RHS       disj2_3_10_0  -5244
    RHS       disj1_3_11_0  79
    RHS       disj2_3_11_0  -5241
    RHS       disj1_3_12_0  79
    RHS       disj2_3_12_0  -5192
    RHS       disj1_3_13_0  79
    RHS       disj2_3_13_0  -5192
    RHS       disj1_3_14_0  79
    RHS       disj2_3_14_0  -5224
    RHS       disj1_3_15_0  79
    RHS       disj2_3_15_0  -5206
    RHS       disj1_3_16_0  79
    RHS       disj2_3_16_0  -5173
    RHS       disj1_3_17_0  79
    RHS       disj2_3_17_0  -5189
    RHS       disj1_3_18_0  79
    RHS       disj2_3_18_0  -5208
    RHS       disj1_3_19_0  79
    RHS       disj2_3_19_0  -5164
    RHS       disj1_4_5_0  34
    RHS       disj2_4_5_0  -5197
    RHS       disj1_4_6_0  34
    RHS       disj2_4_6_0  -5158
    RHS       disj1_4_7_0  34
    RHS       disj2_4_7_0  -5227
    RHS       disj1_4_8_0  34
    RHS       disj2_4_8_0  -5234
    RHS       disj1_4_9_0  34
    RHS       disj2_4_9_0  -5174
    RHS       disj1_4_10_0  34
    RHS       disj2_4_10_0  -5244
    RHS       disj1_4_11_0  34
    RHS       disj2_4_11_0  -5241
    RHS       disj1_4_12_0  34
    RHS       disj2_4_12_0  -5192
    RHS       disj1_4_13_0  34
    RHS       disj2_4_13_0  -5192
    RHS       disj1_4_14_0  34
    RHS       disj2_4_14_0  -5224
    RHS       disj1_4_15_0  34
    RHS       disj2_4_15_0  -5206
    RHS       disj1_4_16_0  34
    RHS       disj2_4_16_0  -5173
    RHS       disj1_4_17_0  34
    RHS       disj2_4_17_0  -5189
    RHS       disj1_4_18_0  34
    RHS       disj2_4_18_0  -5208
    RHS       disj1_4_19_0  34
    RHS       disj2_4_19_0  -5164
    RHS       disj1_5_6_0  54
    RHS       disj2_5_6_0  -5158
    RHS       disj1_5_7_0  54
    RHS       disj2_5_7_0  -5227
    RHS       disj1_5_8_0  54
    RHS       disj2_5_8_0  -5234
    RHS       disj1_5_9_0  54
    RHS       disj2_5_9_0  -5174
    RHS       disj1_5_10_0  54
    RHS       disj2_5_10_0  -5244
    RHS       disj1_5_11_0  54
    RHS       disj2_5_11_0  -5241
    RHS       disj1_5_12_0  54
    RHS       disj2_5_12_0  -5192
    RHS       disj1_5_13_0  54
    RHS       disj2_5_13_0  -5192
    RHS       disj1_5_14_0  54
    RHS       disj2_5_14_0  -5224
    RHS       disj1_5_15_0  54
    RHS       disj2_5_15_0  -5206
    RHS       disj1_5_16_0  54
    RHS       disj2_5_16_0  -5173
    RHS       disj1_5_17_0  54
    RHS       disj2_5_17_0  -5189
    RHS       disj1_5_18_0  54
    RHS       disj2_5_18_0  -5208
    RHS       disj1_5_19_0  54
    RHS       disj2_5_19_0  -5164
    RHS       disj1_6_7_0  93
    RHS       disj2_6_7_0  -5227
    RHS       disj1_6_8_0  93
    RHS       disj2_6_8_0  -5234
    RHS       disj1_6_9_0  93
    RHS       disj2_6_9_0  -5174
    RHS       disj1_6_10_0  93
    RHS       disj2_6_10_0  -5244
    RHS       disj1_6_11_0  93
    RHS       disj2_6_11_0  -5241
    RHS       disj1_6_12_0  93
    RHS       disj2_6_12_0  -5192
    RHS       disj1_6_13_0  93
    RHS       disj2_6_13_0  -5192
    RHS       disj1_6_14_0  93
    RHS       disj2_6_14_0  -5224
    RHS       disj1_6_15_0  93
    RHS       disj2_6_15_0  -5206
    RHS       disj1_6_16_0  93
    RHS       disj2_6_16_0  -5173
    RHS       disj1_6_17_0  93
    RHS       disj2_6_17_0  -5189
    RHS       disj1_6_18_0  93
    RHS       disj2_6_18_0  -5208
    RHS       disj1_6_19_0  93
    RHS       disj2_6_19_0  -5164
    RHS       disj1_7_8_0  24
    RHS       disj2_7_8_0  -5234
    RHS       disj1_7_9_0  24
    RHS       disj2_7_9_0  -5174
    RHS       disj1_7_10_0  24
    RHS       disj2_7_10_0  -5244
    RHS       disj1_7_11_0  24
    RHS       disj2_7_11_0  -5241
    RHS       disj1_7_12_0  24
    RHS       disj2_7_12_0  -5192
    RHS       disj1_7_13_0  24
    RHS       disj2_7_13_0  -5192
    RHS       disj1_7_14_0  24
    RHS       disj2_7_14_0  -5224
    RHS       disj1_7_15_0  24
    RHS       disj2_7_15_0  -5206
    RHS       disj1_7_16_0  24
    RHS       disj2_7_16_0  -5173
    RHS       disj1_7_17_0  24
    RHS       disj2_7_17_0  -5189
    RHS       disj1_7_18_0  24
    RHS       disj2_7_18_0  -5208
    RHS       disj1_7_19_0  24
    RHS       disj2_7_19_0  -5164
    RHS       disj1_8_9_0  17
    RHS       disj2_8_9_0  -5174
    RHS       disj1_8_10_0  17
    RHS       disj2_8_10_0  -5244
    RHS       disj1_8_11_0  17
    RHS       disj2_8_11_0  -5241
    RHS       disj1_8_12_0  17
    RHS       disj2_8_12_0  -5192
    RHS       disj1_8_13_0  17
    RHS       disj2_8_13_0  -5192
    RHS       disj1_8_14_0  17
    RHS       disj2_8_14_0  -5224
    RHS       disj1_8_15_0  17
    RHS       disj2_8_15_0  -5206
    RHS       disj1_8_16_0  17
    RHS       disj2_8_16_0  -5173
    RHS       disj1_8_17_0  17
    RHS       disj2_8_17_0  -5189
    RHS       disj1_8_18_0  17
    RHS       disj2_8_18_0  -5208
    RHS       disj1_8_19_0  17
    RHS       disj2_8_19_0  -5164
    RHS       disj1_9_10_0  77
    RHS       disj2_9_10_0  -5244
    RHS       disj1_9_11_0  77
    RHS       disj2_9_11_0  -5241
    RHS       disj1_9_12_0  77
    RHS       disj2_9_12_0  -5192
    RHS       disj1_9_13_0  77
    RHS       disj2_9_13_0  -5192
    RHS       disj1_9_14_0  77
    RHS       disj2_9_14_0  -5224
    RHS       disj1_9_15_0  77
    RHS       disj2_9_15_0  -5206
    RHS       disj1_9_16_0  77
    RHS       disj2_9_16_0  -5173
    RHS       disj1_9_17_0  77
    RHS       disj2_9_17_0  -5189
    RHS       disj1_9_18_0  77
    RHS       disj2_9_18_0  -5208
    RHS       disj1_9_19_0  77
    RHS       disj2_9_19_0  -5164
    RHS       disj1_10_11_0  7
    RHS       disj2_10_11_0  -5241
    RHS       disj1_10_12_0  7
    RHS       disj2_10_12_0  -5192
    RHS       disj1_10_13_0  7
    RHS       disj2_10_13_0  -5192
    RHS       disj1_10_14_0  7
    RHS       disj2_10_14_0  -5224
    RHS       disj1_10_15_0  7
    RHS       disj2_10_15_0  -5206
    RHS       disj1_10_16_0  7
    RHS       disj2_10_16_0  -5173
    RHS       disj1_10_17_0  7
    RHS       disj2_10_17_0  -5189
    RHS       disj1_10_18_0  7
    RHS       disj2_10_18_0  -5208
    RHS       disj1_10_19_0  7
    RHS       disj2_10_19_0  -5164
    RHS       disj1_11_12_0  10
    RHS       disj2_11_12_0  -5192
    RHS       disj1_11_13_0  10
    RHS       disj2_11_13_0  -5192
    RHS       disj1_11_14_0  10
    RHS       disj2_11_14_0  -5224
    RHS       disj1_11_15_0  10
    RHS       disj2_11_15_0  -5206
    RHS       disj1_11_16_0  10
    RHS       disj2_11_16_0  -5173
    RHS       disj1_11_17_0  10
    RHS       disj2_11_17_0  -5189
    RHS       disj1_11_18_0  10
    RHS       disj2_11_18_0  -5208
    RHS       disj1_11_19_0  10
    RHS       disj2_11_19_0  -5164
    RHS       disj1_12_13_0  59
    RHS       disj2_12_13_0  -5192
    RHS       disj1_12_14_0  59
    RHS       disj2_12_14_0  -5224
    RHS       disj1_12_15_0  59
    RHS       disj2_12_15_0  -5206
    RHS       disj1_12_16_0  59
    RHS       disj2_12_16_0  -5173
    RHS       disj1_12_17_0  59
    RHS       disj2_12_17_0  -5189
    RHS       disj1_12_18_0  59
    RHS       disj2_12_18_0  -5208
    RHS       disj1_12_19_0  59
    RHS       disj2_12_19_0  -5164
    RHS       disj1_13_14_0  59
    RHS       disj2_13_14_0  -5224
    RHS       disj1_13_15_0  59
    RHS       disj2_13_15_0  -5206
    RHS       disj1_13_16_0  59
    RHS       disj2_13_16_0  -5173
    RHS       disj1_13_17_0  59
    RHS       disj2_13_17_0  -5189
    RHS       disj1_13_18_0  59
    RHS       disj2_13_18_0  -5208
    RHS       disj1_13_19_0  59
    RHS       disj2_13_19_0  -5164
    RHS       disj1_14_15_0  27
    RHS       disj2_14_15_0  -5206
    RHS       disj1_14_16_0  27
    RHS       disj2_14_16_0  -5173
    RHS       disj1_14_17_0  27
    RHS       disj2_14_17_0  -5189
    RHS       disj1_14_18_0  27
    RHS       disj2_14_18_0  -5208
    RHS       disj1_14_19_0  27
    RHS       disj2_14_19_0  -5164
    RHS       disj1_15_16_0  45
    RHS       disj2_15_16_0  -5173
    RHS       disj1_15_17_0  45
    RHS       disj2_15_17_0  -5189
    RHS       disj1_15_18_0  45
    RHS       disj2_15_18_0  -5208
    RHS       disj1_15_19_0  45
    RHS       disj2_15_19_0  -5164
    RHS       disj1_16_17_0  78
    RHS       disj2_16_17_0  -5189
    RHS       disj1_16_18_0  78
    RHS       disj2_16_18_0  -5208
    RHS       disj1_16_19_0  78
    RHS       disj2_16_19_0  -5164
    RHS       disj1_17_18_0  62
    RHS       disj2_17_18_0  -5208
    RHS       disj1_17_19_0  62
    RHS       disj2_17_19_0  -5164
    RHS       disj1_18_19_0  43
    RHS       disj2_18_19_0  -5164
    RHS       disj1_0_1_1  41
    RHS       disj2_0_1_1  -5199
    RHS       disj1_0_2_1  41
    RHS       disj2_0_2_1  -5153
    RHS       disj1_0_3_1  41
    RHS       disj2_0_3_1  -5174
    RHS       disj1_0_4_1  41
    RHS       disj2_0_4_1  -5168
    RHS       disj1_0_5_1  41
    RHS       disj2_0_5_1  -5159
    RHS       disj1_0_6_1  41
    RHS       disj2_0_6_1  -5174
    RHS       disj1_0_7_1  41
    RHS       disj2_0_7_1  -5210
    RHS       disj1_0_8_1  41
    RHS       disj2_0_8_1  -5207
    RHS       disj1_0_9_1  41
    RHS       disj2_0_9_1  -5155
    RHS       disj1_0_10_1  41
    RHS       disj2_0_10_1  -5175
    RHS       disj1_0_11_1  41
    RHS       disj2_0_11_1  -5160
    RHS       disj1_0_12_1  41
    RHS       disj2_0_12_1  -5235
    RHS       disj1_0_13_1  41
    RHS       disj2_0_13_1  -5160
    RHS       disj1_0_14_1  41
    RHS       disj2_0_14_1  -5205
    RHS       disj1_0_15_1  41
    RHS       disj2_0_15_1  -5177
    RHS       disj1_0_16_1  41
    RHS       disj2_0_16_1  -5206
    RHS       disj1_0_17_1  41
    RHS       disj2_0_17_1  -5206
    RHS       disj1_0_18_1  41
    RHS       disj2_0_18_1  -5230
    RHS       disj1_0_19_1  41
    RHS       disj2_0_19_1  -5242
    RHS       disj1_1_2_1  52
    RHS       disj2_1_2_1  -5153
    RHS       disj1_1_3_1  52
    RHS       disj2_1_3_1  -5174
    RHS       disj1_1_4_1  52
    RHS       disj2_1_4_1  -5168
    RHS       disj1_1_5_1  52
    RHS       disj2_1_5_1  -5159
    RHS       disj1_1_6_1  52
    RHS       disj2_1_6_1  -5174
    RHS       disj1_1_7_1  52
    RHS       disj2_1_7_1  -5210
    RHS       disj1_1_8_1  52
    RHS       disj2_1_8_1  -5207
    RHS       disj1_1_9_1  52
    RHS       disj2_1_9_1  -5155
    RHS       disj1_1_10_1  52
    RHS       disj2_1_10_1  -5175
    RHS       disj1_1_11_1  52
    RHS       disj2_1_11_1  -5160
    RHS       disj1_1_12_1  52
    RHS       disj2_1_12_1  -5235
    RHS       disj1_1_13_1  52
    RHS       disj2_1_13_1  -5160
    RHS       disj1_1_14_1  52
    RHS       disj2_1_14_1  -5205
    RHS       disj1_1_15_1  52
    RHS       disj2_1_15_1  -5177
    RHS       disj1_1_16_1  52
    RHS       disj2_1_16_1  -5206
    RHS       disj1_1_17_1  52
    RHS       disj2_1_17_1  -5206
    RHS       disj1_1_18_1  52
    RHS       disj2_1_18_1  -5230
    RHS       disj1_1_19_1  52
    RHS       disj2_1_19_1  -5242
    RHS       disj1_2_3_1  98
    RHS       disj2_2_3_1  -5174
    RHS       disj1_2_4_1  98
    RHS       disj2_2_4_1  -5168
    RHS       disj1_2_5_1  98
    RHS       disj2_2_5_1  -5159
    RHS       disj1_2_6_1  98
    RHS       disj2_2_6_1  -5174
    RHS       disj1_2_7_1  98
    RHS       disj2_2_7_1  -5210
    RHS       disj1_2_8_1  98
    RHS       disj2_2_8_1  -5207
    RHS       disj1_2_9_1  98
    RHS       disj2_2_9_1  -5155
    RHS       disj1_2_10_1  98
    RHS       disj2_2_10_1  -5175
    RHS       disj1_2_11_1  98
    RHS       disj2_2_11_1  -5160
    RHS       disj1_2_12_1  98
    RHS       disj2_2_12_1  -5235
    RHS       disj1_2_13_1  98
    RHS       disj2_2_13_1  -5160
    RHS       disj1_2_14_1  98
    RHS       disj2_2_14_1  -5205
    RHS       disj1_2_15_1  98
    RHS       disj2_2_15_1  -5177
    RHS       disj1_2_16_1  98
    RHS       disj2_2_16_1  -5206
    RHS       disj1_2_17_1  98
    RHS       disj2_2_17_1  -5206
    RHS       disj1_2_18_1  98
    RHS       disj2_2_18_1  -5230
    RHS       disj1_2_19_1  98
    RHS       disj2_2_19_1  -5242
    RHS       disj1_3_4_1  77
    RHS       disj2_3_4_1  -5168
    RHS       disj1_3_5_1  77
    RHS       disj2_3_5_1  -5159
    RHS       disj1_3_6_1  77
    RHS       disj2_3_6_1  -5174
    RHS       disj1_3_7_1  77
    RHS       disj2_3_7_1  -5210
    RHS       disj1_3_8_1  77
    RHS       disj2_3_8_1  -5207
    RHS       disj1_3_9_1  77
    RHS       disj2_3_9_1  -5155
    RHS       disj1_3_10_1  77
    RHS       disj2_3_10_1  -5175
    RHS       disj1_3_11_1  77
    RHS       disj2_3_11_1  -5160
    RHS       disj1_3_12_1  77
    RHS       disj2_3_12_1  -5235
    RHS       disj1_3_13_1  77
    RHS       disj2_3_13_1  -5160
    RHS       disj1_3_14_1  77
    RHS       disj2_3_14_1  -5205
    RHS       disj1_3_15_1  77
    RHS       disj2_3_15_1  -5177
    RHS       disj1_3_16_1  77
    RHS       disj2_3_16_1  -5206
    RHS       disj1_3_17_1  77
    RHS       disj2_3_17_1  -5206
    RHS       disj1_3_18_1  77
    RHS       disj2_3_18_1  -5230
    RHS       disj1_3_19_1  77
    RHS       disj2_3_19_1  -5242
    RHS       disj1_4_5_1  83
    RHS       disj2_4_5_1  -5159
    RHS       disj1_4_6_1  83
    RHS       disj2_4_6_1  -5174
    RHS       disj1_4_7_1  83
    RHS       disj2_4_7_1  -5210
    RHS       disj1_4_8_1  83
    RHS       disj2_4_8_1  -5207
    RHS       disj1_4_9_1  83
    RHS       disj2_4_9_1  -5155
    RHS       disj1_4_10_1  83
    RHS       disj2_4_10_1  -5175
    RHS       disj1_4_11_1  83
    RHS       disj2_4_11_1  -5160
    RHS       disj1_4_12_1  83
    RHS       disj2_4_12_1  -5235
    RHS       disj1_4_13_1  83
    RHS       disj2_4_13_1  -5160
    RHS       disj1_4_14_1  83
    RHS       disj2_4_14_1  -5205
    RHS       disj1_4_15_1  83
    RHS       disj2_4_15_1  -5177
    RHS       disj1_4_16_1  83
    RHS       disj2_4_16_1  -5206
    RHS       disj1_4_17_1  83
    RHS       disj2_4_17_1  -5206
    RHS       disj1_4_18_1  83
    RHS       disj2_4_18_1  -5230
    RHS       disj1_4_19_1  83
    RHS       disj2_4_19_1  -5242
    RHS       disj1_5_6_1  92
    RHS       disj2_5_6_1  -5174
    RHS       disj1_5_7_1  92
    RHS       disj2_5_7_1  -5210
    RHS       disj1_5_8_1  92
    RHS       disj2_5_8_1  -5207
    RHS       disj1_5_9_1  92
    RHS       disj2_5_9_1  -5155
    RHS       disj1_5_10_1  92
    RHS       disj2_5_10_1  -5175
    RHS       disj1_5_11_1  92
    RHS       disj2_5_11_1  -5160
    RHS       disj1_5_12_1  92
    RHS       disj2_5_12_1  -5235
    RHS       disj1_5_13_1  92
    RHS       disj2_5_13_1  -5160
    RHS       disj1_5_14_1  92
    RHS       disj2_5_14_1  -5205
    RHS       disj1_5_15_1  92
    RHS       disj2_5_15_1  -5177
    RHS       disj1_5_16_1  92
    RHS       disj2_5_16_1  -5206
    RHS       disj1_5_17_1  92
    RHS       disj2_5_17_1  -5206
    RHS       disj1_5_18_1  92
    RHS       disj2_5_18_1  -5230
    RHS       disj1_5_19_1  92
    RHS       disj2_5_19_1  -5242
    RHS       disj1_6_7_1  77
    RHS       disj2_6_7_1  -5210
    RHS       disj1_6_8_1  77
    RHS       disj2_6_8_1  -5207
    RHS       disj1_6_9_1  77
    RHS       disj2_6_9_1  -5155
    RHS       disj1_6_10_1  77
    RHS       disj2_6_10_1  -5175
    RHS       disj1_6_11_1  77
    RHS       disj2_6_11_1  -5160
    RHS       disj1_6_12_1  77
    RHS       disj2_6_12_1  -5235
    RHS       disj1_6_13_1  77
    RHS       disj2_6_13_1  -5160
    RHS       disj1_6_14_1  77
    RHS       disj2_6_14_1  -5205
    RHS       disj1_6_15_1  77
    RHS       disj2_6_15_1  -5177
    RHS       disj1_6_16_1  77
    RHS       disj2_6_16_1  -5206
    RHS       disj1_6_17_1  77
    RHS       disj2_6_17_1  -5206
    RHS       disj1_6_18_1  77
    RHS       disj2_6_18_1  -5230
    RHS       disj1_6_19_1  77
    RHS       disj2_6_19_1  -5242
    RHS       disj1_7_8_1  41
    RHS       disj2_7_8_1  -5207
    RHS       disj1_7_9_1  41
    RHS       disj2_7_9_1  -5155
    RHS       disj1_7_10_1  41
    RHS       disj2_7_10_1  -5175
    RHS       disj1_7_11_1  41
    RHS       disj2_7_11_1  -5160
    RHS       disj1_7_12_1  41
    RHS       disj2_7_12_1  -5235
    RHS       disj1_7_13_1  41
    RHS       disj2_7_13_1  -5160
    RHS       disj1_7_14_1  41
    RHS       disj2_7_14_1  -5205
    RHS       disj1_7_15_1  41
    RHS       disj2_7_15_1  -5177
    RHS       disj1_7_16_1  41
    RHS       disj2_7_16_1  -5206
    RHS       disj1_7_17_1  41
    RHS       disj2_7_17_1  -5206
    RHS       disj1_7_18_1  41
    RHS       disj2_7_18_1  -5230
    RHS       disj1_7_19_1  41
    RHS       disj2_7_19_1  -5242
    RHS       disj1_8_9_1  44
    RHS       disj2_8_9_1  -5155
    RHS       disj1_8_10_1  44
    RHS       disj2_8_10_1  -5175
    RHS       disj1_8_11_1  44
    RHS       disj2_8_11_1  -5160
    RHS       disj1_8_12_1  44
    RHS       disj2_8_12_1  -5235
    RHS       disj1_8_13_1  44
    RHS       disj2_8_13_1  -5160
    RHS       disj1_8_14_1  44
    RHS       disj2_8_14_1  -5205
    RHS       disj1_8_15_1  44
    RHS       disj2_8_15_1  -5177
    RHS       disj1_8_16_1  44
    RHS       disj2_8_16_1  -5206
    RHS       disj1_8_17_1  44
    RHS       disj2_8_17_1  -5206
    RHS       disj1_8_18_1  44
    RHS       disj2_8_18_1  -5230
    RHS       disj1_8_19_1  44
    RHS       disj2_8_19_1  -5242
    RHS       disj1_9_10_1  96
    RHS       disj2_9_10_1  -5175
    RHS       disj1_9_11_1  96
    RHS       disj2_9_11_1  -5160
    RHS       disj1_9_12_1  96
    RHS       disj2_9_12_1  -5235
    RHS       disj1_9_13_1  96
    RHS       disj2_9_13_1  -5160
    RHS       disj1_9_14_1  96
    RHS       disj2_9_14_1  -5205
    RHS       disj1_9_15_1  96
    RHS       disj2_9_15_1  -5177
    RHS       disj1_9_16_1  96
    RHS       disj2_9_16_1  -5206
    RHS       disj1_9_17_1  96
    RHS       disj2_9_17_1  -5206
    RHS       disj1_9_18_1  96
    RHS       disj2_9_18_1  -5230
    RHS       disj1_9_19_1  96
    RHS       disj2_9_19_1  -5242
    RHS       disj1_10_11_1  76
    RHS       disj2_10_11_1  -5160
    RHS       disj1_10_12_1  76
    RHS       disj2_10_12_1  -5235
    RHS       disj1_10_13_1  76
    RHS       disj2_10_13_1  -5160
    RHS       disj1_10_14_1  76
    RHS       disj2_10_14_1  -5205
    RHS       disj1_10_15_1  76
    RHS       disj2_10_15_1  -5177
    RHS       disj1_10_16_1  76
    RHS       disj2_10_16_1  -5206
    RHS       disj1_10_17_1  76
    RHS       disj2_10_17_1  -5206
    RHS       disj1_10_18_1  76
    RHS       disj2_10_18_1  -5230
    RHS       disj1_10_19_1  76
    RHS       disj2_10_19_1  -5242
    RHS       disj1_11_12_1  91
    RHS       disj2_11_12_1  -5235
    RHS       disj1_11_13_1  91
    RHS       disj2_11_13_1  -5160
    RHS       disj1_11_14_1  91
    RHS       disj2_11_14_1  -5205
    RHS       disj1_11_15_1  91
    RHS       disj2_11_15_1  -5177
    RHS       disj1_11_16_1  91
    RHS       disj2_11_16_1  -5206
    RHS       disj1_11_17_1  91
    RHS       disj2_11_17_1  -5206
    RHS       disj1_11_18_1  91
    RHS       disj2_11_18_1  -5230
    RHS       disj1_11_19_1  91
    RHS       disj2_11_19_1  -5242
    RHS       disj1_12_13_1  16
    RHS       disj2_12_13_1  -5160
    RHS       disj1_12_14_1  16
    RHS       disj2_12_14_1  -5205
    RHS       disj1_12_15_1  16
    RHS       disj2_12_15_1  -5177
    RHS       disj1_12_16_1  16
    RHS       disj2_12_16_1  -5206
    RHS       disj1_12_17_1  16
    RHS       disj2_12_17_1  -5206
    RHS       disj1_12_18_1  16
    RHS       disj2_12_18_1  -5230
    RHS       disj1_12_19_1  16
    RHS       disj2_12_19_1  -5242
    RHS       disj1_13_14_1  91
    RHS       disj2_13_14_1  -5205
    RHS       disj1_13_15_1  91
    RHS       disj2_13_15_1  -5177
    RHS       disj1_13_16_1  91
    RHS       disj2_13_16_1  -5206
    RHS       disj1_13_17_1  91
    RHS       disj2_13_17_1  -5206
    RHS       disj1_13_18_1  91
    RHS       disj2_13_18_1  -5230
    RHS       disj1_13_19_1  91
    RHS       disj2_13_19_1  -5242
    RHS       disj1_14_15_1  46
    RHS       disj2_14_15_1  -5177
    RHS       disj1_14_16_1  46
    RHS       disj2_14_16_1  -5206
    RHS       disj1_14_17_1  46
    RHS       disj2_14_17_1  -5206
    RHS       disj1_14_18_1  46
    RHS       disj2_14_18_1  -5230
    RHS       disj1_14_19_1  46
    RHS       disj2_14_19_1  -5242
    RHS       disj1_15_16_1  74
    RHS       disj2_15_16_1  -5206
    RHS       disj1_15_17_1  74
    RHS       disj2_15_17_1  -5206
    RHS       disj1_15_18_1  74
    RHS       disj2_15_18_1  -5230
    RHS       disj1_15_19_1  74
    RHS       disj2_15_19_1  -5242
    RHS       disj1_16_17_1  45
    RHS       disj2_16_17_1  -5206
    RHS       disj1_16_18_1  45
    RHS       disj2_16_18_1  -5230
    RHS       disj1_16_19_1  45
    RHS       disj2_16_19_1  -5242
    RHS       disj1_17_18_1  45
    RHS       disj2_17_18_1  -5230
    RHS       disj1_17_19_1  45
    RHS       disj2_17_19_1  -5242
    RHS       disj1_18_19_1  21
    RHS       disj2_18_19_1  -5242
    RHS       disj1_0_1_2  66
    RHS       disj2_0_1_2  -5220
    RHS       disj1_0_2_2  66
    RHS       disj2_0_2_2  -5235
    RHS       disj1_0_3_2  66
    RHS       disj2_0_3_2  -5153
    RHS       disj1_0_4_2  66
    RHS       disj2_0_4_2  -5221
    RHS       disj1_0_5_2  66
    RHS       disj2_0_5_2  -5172
    RHS       disj1_0_6_2  66
    RHS       disj2_0_6_2  -5164
    RHS       disj1_0_7_2  66
    RHS       disj2_0_7_2  -5168
    RHS       disj1_0_8_2  66
    RHS       disj2_0_8_2  -5226
    RHS       disj1_0_9_2  66
    RHS       disj2_0_9_2  -5176
    RHS       disj1_0_10_2  66
    RHS       disj2_0_10_2  -5216
    RHS       disj1_0_11_2  66
    RHS       disj2_0_11_2  -5242
    RHS       disj1_0_12_2  66
    RHS       disj2_0_12_2  -5223
    RHS       disj1_0_13_2  66
    RHS       disj2_0_13_2  -5208
    RHS       disj1_0_14_2  66
    RHS       disj2_0_14_2  -5192
    RHS       disj1_0_15_2  66
    RHS       disj2_0_15_2  -5192
    RHS       disj1_0_16_2  66
    RHS       disj2_0_16_2  -5223
    RHS       disj1_0_17_2  66
    RHS       disj2_0_17_2  -5228
    RHS       disj1_0_18_2  66
    RHS       disj2_0_18_2  -5153
    RHS       disj1_0_19_2  66
    RHS       disj2_0_19_2  -5191
    RHS       disj1_1_2_2  31
    RHS       disj2_1_2_2  -5235
    RHS       disj1_1_3_2  31
    RHS       disj2_1_3_2  -5153
    RHS       disj1_1_4_2  31
    RHS       disj2_1_4_2  -5221
    RHS       disj1_1_5_2  31
    RHS       disj2_1_5_2  -5172
    RHS       disj1_1_6_2  31
    RHS       disj2_1_6_2  -5164
    RHS       disj1_1_7_2  31
    RHS       disj2_1_7_2  -5168
    RHS       disj1_1_8_2  31
    RHS       disj2_1_8_2  -5226
    RHS       disj1_1_9_2  31
    RHS       disj2_1_9_2  -5176
    RHS       disj1_1_10_2  31
    RHS       disj2_1_10_2  -5216
    RHS       disj1_1_11_2  31
    RHS       disj2_1_11_2  -5242
    RHS       disj1_1_12_2  31
    RHS       disj2_1_12_2  -5223
    RHS       disj1_1_13_2  31
    RHS       disj2_1_13_2  -5208
    RHS       disj1_1_14_2  31
    RHS       disj2_1_14_2  -5192
    RHS       disj1_1_15_2  31
    RHS       disj2_1_15_2  -5192
    RHS       disj1_1_16_2  31
    RHS       disj2_1_16_2  -5223
    RHS       disj1_1_17_2  31
    RHS       disj2_1_17_2  -5228
    RHS       disj1_1_18_2  31
    RHS       disj2_1_18_2  -5153
    RHS       disj1_1_19_2  31
    RHS       disj2_1_19_2  -5191
    RHS       disj1_2_3_2  16
    RHS       disj2_2_3_2  -5153
    RHS       disj1_2_4_2  16
    RHS       disj2_2_4_2  -5221
    RHS       disj1_2_5_2  16
    RHS       disj2_2_5_2  -5172
    RHS       disj1_2_6_2  16
    RHS       disj2_2_6_2  -5164
    RHS       disj1_2_7_2  16
    RHS       disj2_2_7_2  -5168
    RHS       disj1_2_8_2  16
    RHS       disj2_2_8_2  -5226
    RHS       disj1_2_9_2  16
    RHS       disj2_2_9_2  -5176
    RHS       disj1_2_10_2  16
    RHS       disj2_2_10_2  -5216
    RHS       disj1_2_11_2  16
    RHS       disj2_2_11_2  -5242
    RHS       disj1_2_12_2  16
    RHS       disj2_2_12_2  -5223
    RHS       disj1_2_13_2  16
    RHS       disj2_2_13_2  -5208
    RHS       disj1_2_14_2  16
    RHS       disj2_2_14_2  -5192
    RHS       disj1_2_15_2  16
    RHS       disj2_2_15_2  -5192
    RHS       disj1_2_16_2  16
    RHS       disj2_2_16_2  -5223
    RHS       disj1_2_17_2  16
    RHS       disj2_2_17_2  -5228
    RHS       disj1_2_18_2  16
    RHS       disj2_2_18_2  -5153
    RHS       disj1_2_19_2  16
    RHS       disj2_2_19_2  -5191
    RHS       disj1_3_4_2  98
    RHS       disj2_3_4_2  -5221
    RHS       disj1_3_5_2  98
    RHS       disj2_3_5_2  -5172
    RHS       disj1_3_6_2  98
    RHS       disj2_3_6_2  -5164
    RHS       disj1_3_7_2  98
    RHS       disj2_3_7_2  -5168
    RHS       disj1_3_8_2  98
    RHS       disj2_3_8_2  -5226
    RHS       disj1_3_9_2  98
    RHS       disj2_3_9_2  -5176
    RHS       disj1_3_10_2  98
    RHS       disj2_3_10_2  -5216
    RHS       disj1_3_11_2  98
    RHS       disj2_3_11_2  -5242
    RHS       disj1_3_12_2  98
    RHS       disj2_3_12_2  -5223
    RHS       disj1_3_13_2  98
    RHS       disj2_3_13_2  -5208
    RHS       disj1_3_14_2  98
    RHS       disj2_3_14_2  -5192
    RHS       disj1_3_15_2  98
    RHS       disj2_3_15_2  -5192
    RHS       disj1_3_16_2  98
    RHS       disj2_3_16_2  -5223
    RHS       disj1_3_17_2  98
    RHS       disj2_3_17_2  -5228
    RHS       disj1_3_18_2  98
    RHS       disj2_3_18_2  -5153
    RHS       disj1_3_19_2  98
    RHS       disj2_3_19_2  -5191
    RHS       disj1_4_5_2  30
    RHS       disj2_4_5_2  -5172
    RHS       disj1_4_6_2  30
    RHS       disj2_4_6_2  -5164
    RHS       disj1_4_7_2  30
    RHS       disj2_4_7_2  -5168
    RHS       disj1_4_8_2  30
    RHS       disj2_4_8_2  -5226
    RHS       disj1_4_9_2  30
    RHS       disj2_4_9_2  -5176
    RHS       disj1_4_10_2  30
    RHS       disj2_4_10_2  -5216
    RHS       disj1_4_11_2  30
    RHS       disj2_4_11_2  -5242
    RHS       disj1_4_12_2  30
    RHS       disj2_4_12_2  -5223
    RHS       disj1_4_13_2  30
    RHS       disj2_4_13_2  -5208
    RHS       disj1_4_14_2  30
    RHS       disj2_4_14_2  -5192
    RHS       disj1_4_15_2  30
    RHS       disj2_4_15_2  -5192
    RHS       disj1_4_16_2  30
    RHS       disj2_4_16_2  -5223
    RHS       disj1_4_17_2  30
    RHS       disj2_4_17_2  -5228
    RHS       disj1_4_18_2  30
    RHS       disj2_4_18_2  -5153
    RHS       disj1_4_19_2  30
    RHS       disj2_4_19_2  -5191
    RHS       disj1_5_6_2  79
    RHS       disj2_5_6_2  -5164
    RHS       disj1_5_7_2  79
    RHS       disj2_5_7_2  -5168
    RHS       disj1_5_8_2  79
    RHS       disj2_5_8_2  -5226
    RHS       disj1_5_9_2  79
    RHS       disj2_5_9_2  -5176
    RHS       disj1_5_10_2  79
    RHS       disj2_5_10_2  -5216
    RHS       disj1_5_11_2  79
    RHS       disj2_5_11_2  -5242
    RHS       disj1_5_12_2  79
    RHS       disj2_5_12_2  -5223
    RHS       disj1_5_13_2  79
    RHS       disj2_5_13_2  -5208
    RHS       disj1_5_14_2  79
    RHS       disj2_5_14_2  -5192
    RHS       disj1_5_15_2  79
    RHS       disj2_5_15_2  -5192
    RHS       disj1_5_16_2  79
    RHS       disj2_5_16_2  -5223
    RHS       disj1_5_17_2  79
    RHS       disj2_5_17_2  -5228
    RHS       disj1_5_18_2  79
    RHS       disj2_5_18_2  -5153
    RHS       disj1_5_19_2  79
    RHS       disj2_5_19_2  -5191
    RHS       disj1_6_7_2  87
    RHS       disj2_6_7_2  -5168
    RHS       disj1_6_8_2  87
    RHS       disj2_6_8_2  -5226
    RHS       disj1_6_9_2  87
    RHS       disj2_6_9_2  -5176
    RHS       disj1_6_10_2  87
    RHS       disj2_6_10_2  -5216
    RHS       disj1_6_11_2  87
    RHS       disj2_6_11_2  -5242
    RHS       disj1_6_12_2  87
    RHS       disj2_6_12_2  -5223
    RHS       disj1_6_13_2  87
    RHS       disj2_6_13_2  -5208
    RHS       disj1_6_14_2  87
    RHS       disj2_6_14_2  -5192
    RHS       disj1_6_15_2  87
    RHS       disj2_6_15_2  -5192
    RHS       disj1_6_16_2  87
    RHS       disj2_6_16_2  -5223
    RHS       disj1_6_17_2  87
    RHS       disj2_6_17_2  -5228
    RHS       disj1_6_18_2  87
    RHS       disj2_6_18_2  -5153
    RHS       disj1_6_19_2  87
    RHS       disj2_6_19_2  -5191
    RHS       disj1_7_8_2  83
    RHS       disj2_7_8_2  -5226
    RHS       disj1_7_9_2  83
    RHS       disj2_7_9_2  -5176
    RHS       disj1_7_10_2  83
    RHS       disj2_7_10_2  -5216
    RHS       disj1_7_11_2  83
    RHS       disj2_7_11_2  -5242
    RHS       disj1_7_12_2  83
    RHS       disj2_7_12_2  -5223
    RHS       disj1_7_13_2  83
    RHS       disj2_7_13_2  -5208
    RHS       disj1_7_14_2  83
    RHS       disj2_7_14_2  -5192
    RHS       disj1_7_15_2  83
    RHS       disj2_7_15_2  -5192
    RHS       disj1_7_16_2  83
    RHS       disj2_7_16_2  -5223
    RHS       disj1_7_17_2  83
    RHS       disj2_7_17_2  -5228
    RHS       disj1_7_18_2  83
    RHS       disj2_7_18_2  -5153
    RHS       disj1_7_19_2  83
    RHS       disj2_7_19_2  -5191
    RHS       disj1_8_9_2  25
    RHS       disj2_8_9_2  -5176
    RHS       disj1_8_10_2  25
    RHS       disj2_8_10_2  -5216
    RHS       disj1_8_11_2  25
    RHS       disj2_8_11_2  -5242
    RHS       disj1_8_12_2  25
    RHS       disj2_8_12_2  -5223
    RHS       disj1_8_13_2  25
    RHS       disj2_8_13_2  -5208
    RHS       disj1_8_14_2  25
    RHS       disj2_8_14_2  -5192
    RHS       disj1_8_15_2  25
    RHS       disj2_8_15_2  -5192
    RHS       disj1_8_16_2  25
    RHS       disj2_8_16_2  -5223
    RHS       disj1_8_17_2  25
    RHS       disj2_8_17_2  -5228
    RHS       disj1_8_18_2  25
    RHS       disj2_8_18_2  -5153
    RHS       disj1_8_19_2  25
    RHS       disj2_8_19_2  -5191
    RHS       disj1_9_10_2  75
    RHS       disj2_9_10_2  -5216
    RHS       disj1_9_11_2  75
    RHS       disj2_9_11_2  -5242
    RHS       disj1_9_12_2  75
    RHS       disj2_9_12_2  -5223
    RHS       disj1_9_13_2  75
    RHS       disj2_9_13_2  -5208
    RHS       disj1_9_14_2  75
    RHS       disj2_9_14_2  -5192
    RHS       disj1_9_15_2  75
    RHS       disj2_9_15_2  -5192
    RHS       disj1_9_16_2  75
    RHS       disj2_9_16_2  -5223
    RHS       disj1_9_17_2  75
    RHS       disj2_9_17_2  -5228
    RHS       disj1_9_18_2  75
    RHS       disj2_9_18_2  -5153
    RHS       disj1_9_19_2  75
    RHS       disj2_9_19_2  -5191
    RHS       disj1_10_11_2  35
    RHS       disj2_10_11_2  -5242
    RHS       disj1_10_12_2  35
    RHS       disj2_10_12_2  -5223
    RHS       disj1_10_13_2  35
    RHS       disj2_10_13_2  -5208
    RHS       disj1_10_14_2  35
    RHS       disj2_10_14_2  -5192
    RHS       disj1_10_15_2  35
    RHS       disj2_10_15_2  -5192
    RHS       disj1_10_16_2  35
    RHS       disj2_10_16_2  -5223
    RHS       disj1_10_17_2  35
    RHS       disj2_10_17_2  -5228
    RHS       disj1_10_18_2  35
    RHS       disj2_10_18_2  -5153
    RHS       disj1_10_19_2  35
    RHS       disj2_10_19_2  -5191
    RHS       disj1_11_12_2  9
    RHS       disj2_11_12_2  -5223
    RHS       disj1_11_13_2  9
    RHS       disj2_11_13_2  -5208
    RHS       disj1_11_14_2  9
    RHS       disj2_11_14_2  -5192
    RHS       disj1_11_15_2  9
    RHS       disj2_11_15_2  -5192
    RHS       disj1_11_16_2  9
    RHS       disj2_11_16_2  -5223
    RHS       disj1_11_17_2  9
    RHS       disj2_11_17_2  -5228
    RHS       disj1_11_18_2  9
    RHS       disj2_11_18_2  -5153
    RHS       disj1_11_19_2  9
    RHS       disj2_11_19_2  -5191
    RHS       disj1_12_13_2  28
    RHS       disj2_12_13_2  -5208
    RHS       disj1_12_14_2  28
    RHS       disj2_12_14_2  -5192
    RHS       disj1_12_15_2  28
    RHS       disj2_12_15_2  -5192
    RHS       disj1_12_16_2  28
    RHS       disj2_12_16_2  -5223
    RHS       disj1_12_17_2  28
    RHS       disj2_12_17_2  -5228
    RHS       disj1_12_18_2  28
    RHS       disj2_12_18_2  -5153
    RHS       disj1_12_19_2  28
    RHS       disj2_12_19_2  -5191
    RHS       disj1_13_14_2  43
    RHS       disj2_13_14_2  -5192
    RHS       disj1_13_15_2  43
    RHS       disj2_13_15_2  -5192
    RHS       disj1_13_16_2  43
    RHS       disj2_13_16_2  -5223
    RHS       disj1_13_17_2  43
    RHS       disj2_13_17_2  -5228
    RHS       disj1_13_18_2  43
    RHS       disj2_13_18_2  -5153
    RHS       disj1_13_19_2  43
    RHS       disj2_13_19_2  -5191
    RHS       disj1_14_15_2  59
    RHS       disj2_14_15_2  -5192
    RHS       disj1_14_16_2  59
    RHS       disj2_14_16_2  -5223
    RHS       disj1_14_17_2  59
    RHS       disj2_14_17_2  -5228
    RHS       disj1_14_18_2  59
    RHS       disj2_14_18_2  -5153
    RHS       disj1_14_19_2  59
    RHS       disj2_14_19_2  -5191
    RHS       disj1_15_16_2  59
    RHS       disj2_15_16_2  -5223
    RHS       disj1_15_17_2  59
    RHS       disj2_15_17_2  -5228
    RHS       disj1_15_18_2  59
    RHS       disj2_15_18_2  -5153
    RHS       disj1_15_19_2  59
    RHS       disj2_15_19_2  -5191
    RHS       disj1_16_17_2  28
    RHS       disj2_16_17_2  -5228
    RHS       disj1_16_18_2  28
    RHS       disj2_16_18_2  -5153
    RHS       disj1_16_19_2  28
    RHS       disj2_16_19_2  -5191
    RHS       disj1_17_18_2  23
    RHS       disj2_17_18_2  -5153
    RHS       disj1_17_19_2  23
    RHS       disj2_17_19_2  -5191
    RHS       disj1_18_19_2  98
    RHS       disj2_18_19_2  -5191
    RHS       disj1_0_1_3  21
    RHS       disj2_0_1_3  -5225
    RHS       disj1_0_2_3  21
    RHS       disj2_0_2_3  -5212
    RHS       disj1_0_3_3  21
    RHS       disj2_0_3_3  -5174
    RHS       disj1_0_4_3  21
    RHS       disj2_0_4_3  -5232
    RHS       disj1_0_5_3  21
    RHS       disj2_0_5_3  -5208
    RHS       disj1_0_6_3  21
    RHS       disj2_0_6_3  -5182
    RHS       disj1_0_7_3  21
    RHS       disj2_0_7_3  -5191
    RHS       disj1_0_8_3  21
    RHS       disj2_0_8_3  -5153
    RHS       disj1_0_9_3  21
    RHS       disj2_0_9_3  -5172
    RHS       disj1_0_10_3  21
    RHS       disj2_0_10_3  -5223
    RHS       disj1_0_11_3  21
    RHS       disj2_0_11_3  -5192
    RHS       disj1_0_12_3  21
    RHS       disj2_0_12_3  -5199
    RHS       disj1_0_13_3  21
    RHS       disj2_0_13_3  -5201
    RHS       disj1_0_14_3  21
    RHS       disj2_0_14_3  -5206
    RHS       disj1_0_15_3  21
    RHS       disj2_0_15_3  -5205
    RHS       disj1_0_16_3  21
    RHS       disj2_0_16_3  -5228
    RHS       disj1_0_17_3  21
    RHS       disj2_0_17_3  -5223
    RHS       disj1_0_18_3  21
    RHS       disj2_0_18_3  -5231
    RHS       disj1_0_19_3  21
    RHS       disj2_0_19_3  -5208
    RHS       disj1_1_2_3  26
    RHS       disj2_1_2_3  -5212
    RHS       disj1_1_3_3  26
    RHS       disj2_1_3_3  -5174
    RHS       disj1_1_4_3  26
    RHS       disj2_1_4_3  -5232
    RHS       disj1_1_5_3  26
    RHS       disj2_1_5_3  -5208
    RHS       disj1_1_6_3  26
    RHS       disj2_1_6_3  -5182
    RHS       disj1_1_7_3  26
    RHS       disj2_1_7_3  -5191
    RHS       disj1_1_8_3  26
    RHS       disj2_1_8_3  -5153
    RHS       disj1_1_9_3  26
    RHS       disj2_1_9_3  -5172
    RHS       disj1_1_10_3  26
    RHS       disj2_1_10_3  -5223
    RHS       disj1_1_11_3  26
    RHS       disj2_1_11_3  -5192
    RHS       disj1_1_12_3  26
    RHS       disj2_1_12_3  -5199
    RHS       disj1_1_13_3  26
    RHS       disj2_1_13_3  -5201
    RHS       disj1_1_14_3  26
    RHS       disj2_1_14_3  -5206
    RHS       disj1_1_15_3  26
    RHS       disj2_1_15_3  -5205
    RHS       disj1_1_16_3  26
    RHS       disj2_1_16_3  -5228
    RHS       disj1_1_17_3  26
    RHS       disj2_1_17_3  -5223
    RHS       disj1_1_18_3  26
    RHS       disj2_1_18_3  -5231
    RHS       disj1_1_19_3  26
    RHS       disj2_1_19_3  -5208
    RHS       disj1_2_3_3  39
    RHS       disj2_2_3_3  -5174
    RHS       disj1_2_4_3  39
    RHS       disj2_2_4_3  -5232
    RHS       disj1_2_5_3  39
    RHS       disj2_2_5_3  -5208
    RHS       disj1_2_6_3  39
    RHS       disj2_2_6_3  -5182
    RHS       disj1_2_7_3  39
    RHS       disj2_2_7_3  -5191
    RHS       disj1_2_8_3  39
    RHS       disj2_2_8_3  -5153
    RHS       disj1_2_9_3  39
    RHS       disj2_2_9_3  -5172
    RHS       disj1_2_10_3  39
    RHS       disj2_2_10_3  -5223
    RHS       disj1_2_11_3  39
    RHS       disj2_2_11_3  -5192
    RHS       disj1_2_12_3  39
    RHS       disj2_2_12_3  -5199
    RHS       disj1_2_13_3  39
    RHS       disj2_2_13_3  -5201
    RHS       disj1_2_14_3  39
    RHS       disj2_2_14_3  -5206
    RHS       disj1_2_15_3  39
    RHS       disj2_2_15_3  -5205
    RHS       disj1_2_16_3  39
    RHS       disj2_2_16_3  -5228
    RHS       disj1_2_17_3  39
    RHS       disj2_2_17_3  -5223
    RHS       disj1_2_18_3  39
    RHS       disj2_2_18_3  -5231
    RHS       disj1_2_19_3  39
    RHS       disj2_2_19_3  -5208
    RHS       disj1_3_4_3  77
    RHS       disj2_3_4_3  -5232
    RHS       disj1_3_5_3  77
    RHS       disj2_3_5_3  -5208
    RHS       disj1_3_6_3  77
    RHS       disj2_3_6_3  -5182
    RHS       disj1_3_7_3  77
    RHS       disj2_3_7_3  -5191
    RHS       disj1_3_8_3  77
    RHS       disj2_3_8_3  -5153
    RHS       disj1_3_9_3  77
    RHS       disj2_3_9_3  -5172
    RHS       disj1_3_10_3  77
    RHS       disj2_3_10_3  -5223
    RHS       disj1_3_11_3  77
    RHS       disj2_3_11_3  -5192
    RHS       disj1_3_12_3  77
    RHS       disj2_3_12_3  -5199
    RHS       disj1_3_13_3  77
    RHS       disj2_3_13_3  -5201
    RHS       disj1_3_14_3  77
    RHS       disj2_3_14_3  -5206
    RHS       disj1_3_15_3  77
    RHS       disj2_3_15_3  -5205
    RHS       disj1_3_16_3  77
    RHS       disj2_3_16_3  -5228
    RHS       disj1_3_17_3  77
    RHS       disj2_3_17_3  -5223
    RHS       disj1_3_18_3  77
    RHS       disj2_3_18_3  -5231
    RHS       disj1_3_19_3  77
    RHS       disj2_3_19_3  -5208
    RHS       disj1_4_5_3  19
    RHS       disj2_4_5_3  -5208
    RHS       disj1_4_6_3  19
    RHS       disj2_4_6_3  -5182
    RHS       disj1_4_7_3  19
    RHS       disj2_4_7_3  -5191
    RHS       disj1_4_8_3  19
    RHS       disj2_4_8_3  -5153
    RHS       disj1_4_9_3  19
    RHS       disj2_4_9_3  -5172
    RHS       disj1_4_10_3  19
    RHS       disj2_4_10_3  -5223
    RHS       disj1_4_11_3  19
    RHS       disj2_4_11_3  -5192
    RHS       disj1_4_12_3  19
    RHS       disj2_4_12_3  -5199
    RHS       disj1_4_13_3  19
    RHS       disj2_4_13_3  -5201
    RHS       disj1_4_14_3  19
    RHS       disj2_4_14_3  -5206
    RHS       disj1_4_15_3  19
    RHS       disj2_4_15_3  -5205
    RHS       disj1_4_16_3  19
    RHS       disj2_4_16_3  -5228
    RHS       disj1_4_17_3  19
    RHS       disj2_4_17_3  -5223
    RHS       disj1_4_18_3  19
    RHS       disj2_4_18_3  -5231
    RHS       disj1_4_19_3  19
    RHS       disj2_4_19_3  -5208
    RHS       disj1_5_6_3  43
    RHS       disj2_5_6_3  -5182
    RHS       disj1_5_7_3  43
    RHS       disj2_5_7_3  -5191
    RHS       disj1_5_8_3  43
    RHS       disj2_5_8_3  -5153
    RHS       disj1_5_9_3  43
    RHS       disj2_5_9_3  -5172
    RHS       disj1_5_10_3  43
    RHS       disj2_5_10_3  -5223
    RHS       disj1_5_11_3  43
    RHS       disj2_5_11_3  -5192
    RHS       disj1_5_12_3  43
    RHS       disj2_5_12_3  -5199
    RHS       disj1_5_13_3  43
    RHS       disj2_5_13_3  -5201
    RHS       disj1_5_14_3  43
    RHS       disj2_5_14_3  -5206
    RHS       disj1_5_15_3  43
    RHS       disj2_5_15_3  -5205
    RHS       disj1_5_16_3  43
    RHS       disj2_5_16_3  -5228
    RHS       disj1_5_17_3  43
    RHS       disj2_5_17_3  -5223
    RHS       disj1_5_18_3  43
    RHS       disj2_5_18_3  -5231
    RHS       disj1_5_19_3  43
    RHS       disj2_5_19_3  -5208
    RHS       disj1_6_7_3  69
    RHS       disj2_6_7_3  -5191
    RHS       disj1_6_8_3  69
    RHS       disj2_6_8_3  -5153
    RHS       disj1_6_9_3  69
    RHS       disj2_6_9_3  -5172
    RHS       disj1_6_10_3  69
    RHS       disj2_6_10_3  -5223
    RHS       disj1_6_11_3  69
    RHS       disj2_6_11_3  -5192
    RHS       disj1_6_12_3  69
    RHS       disj2_6_12_3  -5199
    RHS       disj1_6_13_3  69
    RHS       disj2_6_13_3  -5201
    RHS       disj1_6_14_3  69
    RHS       disj2_6_14_3  -5206
    RHS       disj1_6_15_3  69
    RHS       disj2_6_15_3  -5205
    RHS       disj1_6_16_3  69
    RHS       disj2_6_16_3  -5228
    RHS       disj1_6_17_3  69
    RHS       disj2_6_17_3  -5223
    RHS       disj1_6_18_3  69
    RHS       disj2_6_18_3  -5231
    RHS       disj1_6_19_3  69
    RHS       disj2_6_19_3  -5208
    RHS       disj1_7_8_3  60
    RHS       disj2_7_8_3  -5153
    RHS       disj1_7_9_3  60
    RHS       disj2_7_9_3  -5172
    RHS       disj1_7_10_3  60
    RHS       disj2_7_10_3  -5223
    RHS       disj1_7_11_3  60
    RHS       disj2_7_11_3  -5192
    RHS       disj1_7_12_3  60
    RHS       disj2_7_12_3  -5199
    RHS       disj1_7_13_3  60
    RHS       disj2_7_13_3  -5201
    RHS       disj1_7_14_3  60
    RHS       disj2_7_14_3  -5206
    RHS       disj1_7_15_3  60
    RHS       disj2_7_15_3  -5205
    RHS       disj1_7_16_3  60
    RHS       disj2_7_16_3  -5228
    RHS       disj1_7_17_3  60
    RHS       disj2_7_17_3  -5223
    RHS       disj1_7_18_3  60
    RHS       disj2_7_18_3  -5231
    RHS       disj1_7_19_3  60
    RHS       disj2_7_19_3  -5208
    RHS       disj1_8_9_3  98
    RHS       disj2_8_9_3  -5172
    RHS       disj1_8_10_3  98
    RHS       disj2_8_10_3  -5223
    RHS       disj1_8_11_3  98
    RHS       disj2_8_11_3  -5192
    RHS       disj1_8_12_3  98
    RHS       disj2_8_12_3  -5199
    RHS       disj1_8_13_3  98
    RHS       disj2_8_13_3  -5201
    RHS       disj1_8_14_3  98
    RHS       disj2_8_14_3  -5206
    RHS       disj1_8_15_3  98
    RHS       disj2_8_15_3  -5205
    RHS       disj1_8_16_3  98
    RHS       disj2_8_16_3  -5228
    RHS       disj1_8_17_3  98
    RHS       disj2_8_17_3  -5223
    RHS       disj1_8_18_3  98
    RHS       disj2_8_18_3  -5231
    RHS       disj1_8_19_3  98
    RHS       disj2_8_19_3  -5208
    RHS       disj1_9_10_3  79
    RHS       disj2_9_10_3  -5223
    RHS       disj1_9_11_3  79
    RHS       disj2_9_11_3  -5192
    RHS       disj1_9_12_3  79
    RHS       disj2_9_12_3  -5199
    RHS       disj1_9_13_3  79
    RHS       disj2_9_13_3  -5201
    RHS       disj1_9_14_3  79
    RHS       disj2_9_14_3  -5206
    RHS       disj1_9_15_3  79
    RHS       disj2_9_15_3  -5205
    RHS       disj1_9_16_3  79
    RHS       disj2_9_16_3  -5228
    RHS       disj1_9_17_3  79
    RHS       disj2_9_17_3  -5223
    RHS       disj1_9_18_3  79
    RHS       disj2_9_18_3  -5231
    RHS       disj1_9_19_3  79
    RHS       disj2_9_19_3  -5208
    RHS       disj1_10_11_3  28
    RHS       disj2_10_11_3  -5192
    RHS       disj1_10_12_3  28
    RHS       disj2_10_12_3  -5199
    RHS       disj1_10_13_3  28
    RHS       disj2_10_13_3  -5201
    RHS       disj1_10_14_3  28
    RHS       disj2_10_14_3  -5206
    RHS       disj1_10_15_3  28
    RHS       disj2_10_15_3  -5205
    RHS       disj1_10_16_3  28
    RHS       disj2_10_16_3  -5228
    RHS       disj1_10_17_3  28
    RHS       disj2_10_17_3  -5223
    RHS       disj1_10_18_3  28
    RHS       disj2_10_18_3  -5231
    RHS       disj1_10_19_3  28
    RHS       disj2_10_19_3  -5208
    RHS       disj1_11_12_3  59
    RHS       disj2_11_12_3  -5199
    RHS       disj1_11_13_3  59
    RHS       disj2_11_13_3  -5201
    RHS       disj1_11_14_3  59
    RHS       disj2_11_14_3  -5206
    RHS       disj1_11_15_3  59
    RHS       disj2_11_15_3  -5205
    RHS       disj1_11_16_3  59
    RHS       disj2_11_16_3  -5228
    RHS       disj1_11_17_3  59
    RHS       disj2_11_17_3  -5223
    RHS       disj1_11_18_3  59
    RHS       disj2_11_18_3  -5231
    RHS       disj1_11_19_3  59
    RHS       disj2_11_19_3  -5208
    RHS       disj1_12_13_3  52
    RHS       disj2_12_13_3  -5201
    RHS       disj1_12_14_3  52
    RHS       disj2_12_14_3  -5206
    RHS       disj1_12_15_3  52
    RHS       disj2_12_15_3  -5205
    RHS       disj1_12_16_3  52
    RHS       disj2_12_16_3  -5228
    RHS       disj1_12_17_3  52
    RHS       disj2_12_17_3  -5223
    RHS       disj1_12_18_3  52
    RHS       disj2_12_18_3  -5231
    RHS       disj1_12_19_3  52
    RHS       disj2_12_19_3  -5208
    RHS       disj1_13_14_3  50
    RHS       disj2_13_14_3  -5206
    RHS       disj1_13_15_3  50
    RHS       disj2_13_15_3  -5205
    RHS       disj1_13_16_3  50
    RHS       disj2_13_16_3  -5228
    RHS       disj1_13_17_3  50
    RHS       disj2_13_17_3  -5223
    RHS       disj1_13_18_3  50
    RHS       disj2_13_18_3  -5231
    RHS       disj1_13_19_3  50
    RHS       disj2_13_19_3  -5208
    RHS       disj1_14_15_3  45
    RHS       disj2_14_15_3  -5205
    RHS       disj1_14_16_3  45
    RHS       disj2_14_16_3  -5228
    RHS       disj1_14_17_3  45
    RHS       disj2_14_17_3  -5223
    RHS       disj1_14_18_3  45
    RHS       disj2_14_18_3  -5231
    RHS       disj1_14_19_3  45
    RHS       disj2_14_19_3  -5208
    RHS       disj1_15_16_3  46
    RHS       disj2_15_16_3  -5228
    RHS       disj1_15_17_3  46
    RHS       disj2_15_17_3  -5223
    RHS       disj1_15_18_3  46
    RHS       disj2_15_18_3  -5231
    RHS       disj1_15_19_3  46
    RHS       disj2_15_19_3  -5208
    RHS       disj1_16_17_3  23
    RHS       disj2_16_17_3  -5223
    RHS       disj1_16_18_3  23
    RHS       disj2_16_18_3  -5231
    RHS       disj1_16_19_3  23
    RHS       disj2_16_19_3  -5208
    RHS       disj1_17_18_3  28
    RHS       disj2_17_18_3  -5231
    RHS       disj1_17_19_3  28
    RHS       disj2_17_19_3  -5208
    RHS       disj1_18_19_3  20
    RHS       disj2_18_19_3  -5208
    RHS       disj1_0_1_4  34
    RHS       disj2_0_1_4  -5235
    RHS       disj1_0_2_4  34
    RHS       disj2_0_2_4  -5197
    RHS       disj1_0_3_4  34
    RHS       disj2_0_3_4  -5196
    RHS       disj1_0_4_4  34
    RHS       disj2_0_4_4  -5187
    RHS       disj1_0_5_4  34
    RHS       disj2_0_5_4  -5189
    RHS       disj1_0_6_4  34
    RHS       disj2_0_6_4  -5164
    RHS       disj1_0_7_4  34
    RHS       disj2_0_7_4  -5213
    RHS       disj1_0_8_4  34
    RHS       disj2_0_8_4  -5202
    RHS       disj1_0_9_4  34
    RHS       disj2_0_9_4  -5208
    RHS       disj1_0_10_4  34
    RHS       disj2_0_10_4  -5156
    RHS       disj1_0_11_4  34
    RHS       disj2_0_11_4  -5192
    RHS       disj1_0_12_4  34
    RHS       disj2_0_12_4  -5205
    RHS       disj1_0_13_4  34
    RHS       disj2_0_13_4  -5201
    RHS       disj1_0_14_4  34
    RHS       disj2_0_14_4  -5161
    RHS       disj1_0_15_4  34
    RHS       disj2_0_15_4  -5208
    RHS       disj1_0_16_4  34
    RHS       disj2_0_16_4  -5223
    RHS       disj1_0_17_4  34
    RHS       disj2_0_17_4  -5206
    RHS       disj1_0_18_4  34
    RHS       disj2_0_18_4  -5197
    RHS       disj1_0_19_4  34
    RHS       disj2_0_19_4  -5197
    RHS       disj1_1_2_4  16
    RHS       disj2_1_2_4  -5197
    RHS       disj1_1_3_4  16
    RHS       disj2_1_3_4  -5196
    RHS       disj1_1_4_4  16
    RHS       disj2_1_4_4  -5187
    RHS       disj1_1_5_4  16
    RHS       disj2_1_5_4  -5189
    RHS       disj1_1_6_4  16
    RHS       disj2_1_6_4  -5164
    RHS       disj1_1_7_4  16
    RHS       disj2_1_7_4  -5213
    RHS       disj1_1_8_4  16
    RHS       disj2_1_8_4  -5202
    RHS       disj1_1_9_4  16
    RHS       disj2_1_9_4  -5208
    RHS       disj1_1_10_4  16
    RHS       disj2_1_10_4  -5156
    RHS       disj1_1_11_4  16
    RHS       disj2_1_11_4  -5192
    RHS       disj1_1_12_4  16
    RHS       disj2_1_12_4  -5205
    RHS       disj1_1_13_4  16
    RHS       disj2_1_13_4  -5201
    RHS       disj1_1_14_4  16
    RHS       disj2_1_14_4  -5161
    RHS       disj1_1_15_4  16
    RHS       disj2_1_15_4  -5208
    RHS       disj1_1_16_4  16
    RHS       disj2_1_16_4  -5223
    RHS       disj1_1_17_4  16
    RHS       disj2_1_17_4  -5206
    RHS       disj1_1_18_4  16
    RHS       disj2_1_18_4  -5197
    RHS       disj1_1_19_4  16
    RHS       disj2_1_19_4  -5197
    RHS       disj1_2_3_4  54
    RHS       disj2_2_3_4  -5196
    RHS       disj1_2_4_4  54
    RHS       disj2_2_4_4  -5187
    RHS       disj1_2_5_4  54
    RHS       disj2_2_5_4  -5189
    RHS       disj1_2_6_4  54
    RHS       disj2_2_6_4  -5164
    RHS       disj1_2_7_4  54
    RHS       disj2_2_7_4  -5213
    RHS       disj1_2_8_4  54
    RHS       disj2_2_8_4  -5202
    RHS       disj1_2_9_4  54
    RHS       disj2_2_9_4  -5208
    RHS       disj1_2_10_4  54
    RHS       disj2_2_10_4  -5156
    RHS       disj1_2_11_4  54
    RHS       disj2_2_11_4  -5192
    RHS       disj1_2_12_4  54
    RHS       disj2_2_12_4  -5205
    RHS       disj1_2_13_4  54
    RHS       disj2_2_13_4  -5201
    RHS       disj1_2_14_4  54
    RHS       disj2_2_14_4  -5161
    RHS       disj1_2_15_4  54
    RHS       disj2_2_15_4  -5208
    RHS       disj1_2_16_4  54
    RHS       disj2_2_16_4  -5223
    RHS       disj1_2_17_4  54
    RHS       disj2_2_17_4  -5206
    RHS       disj1_2_18_4  54
    RHS       disj2_2_18_4  -5197
    RHS       disj1_2_19_4  54
    RHS       disj2_2_19_4  -5197
    RHS       disj1_3_4_4  55
    RHS       disj2_3_4_4  -5187
    RHS       disj1_3_5_4  55
    RHS       disj2_3_5_4  -5189
    RHS       disj1_3_6_4  55
    RHS       disj2_3_6_4  -5164
    RHS       disj1_3_7_4  55
    RHS       disj2_3_7_4  -5213
    RHS       disj1_3_8_4  55
    RHS       disj2_3_8_4  -5202
    RHS       disj1_3_9_4  55
    RHS       disj2_3_9_4  -5208
    RHS       disj1_3_10_4  55
    RHS       disj2_3_10_4  -5156
    RHS       disj1_3_11_4  55
    RHS       disj2_3_11_4  -5192
    RHS       disj1_3_12_4  55
    RHS       disj2_3_12_4  -5205
    RHS       disj1_3_13_4  55
    RHS       disj2_3_13_4  -5201
    RHS       disj1_3_14_4  55
    RHS       disj2_3_14_4  -5161
    RHS       disj1_3_15_4  55
    RHS       disj2_3_15_4  -5208
    RHS       disj1_3_16_4  55
    RHS       disj2_3_16_4  -5223
    RHS       disj1_3_17_4  55
    RHS       disj2_3_17_4  -5206
    RHS       disj1_3_18_4  55
    RHS       disj2_3_18_4  -5197
    RHS       disj1_3_19_4  55
    RHS       disj2_3_19_4  -5197
    RHS       disj1_4_5_4  64
    RHS       disj2_4_5_4  -5189
    RHS       disj1_4_6_4  64
    RHS       disj2_4_6_4  -5164
    RHS       disj1_4_7_4  64
    RHS       disj2_4_7_4  -5213
    RHS       disj1_4_8_4  64
    RHS       disj2_4_8_4  -5202
    RHS       disj1_4_9_4  64
    RHS       disj2_4_9_4  -5208
    RHS       disj1_4_10_4  64
    RHS       disj2_4_10_4  -5156
    RHS       disj1_4_11_4  64
    RHS       disj2_4_11_4  -5192
    RHS       disj1_4_12_4  64
    RHS       disj2_4_12_4  -5205
    RHS       disj1_4_13_4  64
    RHS       disj2_4_13_4  -5201
    RHS       disj1_4_14_4  64
    RHS       disj2_4_14_4  -5161
    RHS       disj1_4_15_4  64
    RHS       disj2_4_15_4  -5208
    RHS       disj1_4_16_4  64
    RHS       disj2_4_16_4  -5223
    RHS       disj1_4_17_4  64
    RHS       disj2_4_17_4  -5206
    RHS       disj1_4_18_4  64
    RHS       disj2_4_18_4  -5197
    RHS       disj1_4_19_4  64
    RHS       disj2_4_19_4  -5197
    RHS       disj1_5_6_4  62
    RHS       disj2_5_6_4  -5164
    RHS       disj1_5_7_4  62
    RHS       disj2_5_7_4  -5213
    RHS       disj1_5_8_4  62
    RHS       disj2_5_8_4  -5202
    RHS       disj1_5_9_4  62
    RHS       disj2_5_9_4  -5208
    RHS       disj1_5_10_4  62
    RHS       disj2_5_10_4  -5156
    RHS       disj1_5_11_4  62
    RHS       disj2_5_11_4  -5192
    RHS       disj1_5_12_4  62
    RHS       disj2_5_12_4  -5205
    RHS       disj1_5_13_4  62
    RHS       disj2_5_13_4  -5201
    RHS       disj1_5_14_4  62
    RHS       disj2_5_14_4  -5161
    RHS       disj1_5_15_4  62
    RHS       disj2_5_15_4  -5208
    RHS       disj1_5_16_4  62
    RHS       disj2_5_16_4  -5223
    RHS       disj1_5_17_4  62
    RHS       disj2_5_17_4  -5206
    RHS       disj1_5_18_4  62
    RHS       disj2_5_18_4  -5197
    RHS       disj1_5_19_4  62
    RHS       disj2_5_19_4  -5197
    RHS       disj1_6_7_4  87
    RHS       disj2_6_7_4  -5213
    RHS       disj1_6_8_4  87
    RHS       disj2_6_8_4  -5202
    RHS       disj1_6_9_4  87
    RHS       disj2_6_9_4  -5208
    RHS       disj1_6_10_4  87
    RHS       disj2_6_10_4  -5156
    RHS       disj1_6_11_4  87
    RHS       disj2_6_11_4  -5192
    RHS       disj1_6_12_4  87
    RHS       disj2_6_12_4  -5205
    RHS       disj1_6_13_4  87
    RHS       disj2_6_13_4  -5201
    RHS       disj1_6_14_4  87
    RHS       disj2_6_14_4  -5161
    RHS       disj1_6_15_4  87
    RHS       disj2_6_15_4  -5208
    RHS       disj1_6_16_4  87
    RHS       disj2_6_16_4  -5223
    RHS       disj1_6_17_4  87
    RHS       disj2_6_17_4  -5206
    RHS       disj1_6_18_4  87
    RHS       disj2_6_18_4  -5197
    RHS       disj1_6_19_4  87
    RHS       disj2_6_19_4  -5197
    RHS       disj1_7_8_4  38
    RHS       disj2_7_8_4  -5202
    RHS       disj1_7_9_4  38
    RHS       disj2_7_9_4  -5208
    RHS       disj1_7_10_4  38
    RHS       disj2_7_10_4  -5156
    RHS       disj1_7_11_4  38
    RHS       disj2_7_11_4  -5192
    RHS       disj1_7_12_4  38
    RHS       disj2_7_12_4  -5205
    RHS       disj1_7_13_4  38
    RHS       disj2_7_13_4  -5201
    RHS       disj1_7_14_4  38
    RHS       disj2_7_14_4  -5161
    RHS       disj1_7_15_4  38
    RHS       disj2_7_15_4  -5208
    RHS       disj1_7_16_4  38
    RHS       disj2_7_16_4  -5223
    RHS       disj1_7_17_4  38
    RHS       disj2_7_17_4  -5206
    RHS       disj1_7_18_4  38
    RHS       disj2_7_18_4  -5197
    RHS       disj1_7_19_4  38
    RHS       disj2_7_19_4  -5197
    RHS       disj1_8_9_4  49
    RHS       disj2_8_9_4  -5208
    RHS       disj1_8_10_4  49
    RHS       disj2_8_10_4  -5156
    RHS       disj1_8_11_4  49
    RHS       disj2_8_11_4  -5192
    RHS       disj1_8_12_4  49
    RHS       disj2_8_12_4  -5205
    RHS       disj1_8_13_4  49
    RHS       disj2_8_13_4  -5201
    RHS       disj1_8_14_4  49
    RHS       disj2_8_14_4  -5161
    RHS       disj1_8_15_4  49
    RHS       disj2_8_15_4  -5208
    RHS       disj1_8_16_4  49
    RHS       disj2_8_16_4  -5223
    RHS       disj1_8_17_4  49
    RHS       disj2_8_17_4  -5206
    RHS       disj1_8_18_4  49
    RHS       disj2_8_18_4  -5197
    RHS       disj1_8_19_4  49
    RHS       disj2_8_19_4  -5197
    RHS       disj1_9_10_4  43
    RHS       disj2_9_10_4  -5156
    RHS       disj1_9_11_4  43
    RHS       disj2_9_11_4  -5192
    RHS       disj1_9_12_4  43
    RHS       disj2_9_12_4  -5205
    RHS       disj1_9_13_4  43
    RHS       disj2_9_13_4  -5201
    RHS       disj1_9_14_4  43
    RHS       disj2_9_14_4  -5161
    RHS       disj1_9_15_4  43
    RHS       disj2_9_15_4  -5208
    RHS       disj1_9_16_4  43
    RHS       disj2_9_16_4  -5223
    RHS       disj1_9_17_4  43
    RHS       disj2_9_17_4  -5206
    RHS       disj1_9_18_4  43
    RHS       disj2_9_18_4  -5197
    RHS       disj1_9_19_4  43
    RHS       disj2_9_19_4  -5197
    RHS       disj1_10_11_4  95
    RHS       disj2_10_11_4  -5192
    RHS       disj1_10_12_4  95
    RHS       disj2_10_12_4  -5205
    RHS       disj1_10_13_4  95
    RHS       disj2_10_13_4  -5201
    RHS       disj1_10_14_4  95
    RHS       disj2_10_14_4  -5161
    RHS       disj1_10_15_4  95
    RHS       disj2_10_15_4  -5208
    RHS       disj1_10_16_4  95
    RHS       disj2_10_16_4  -5223
    RHS       disj1_10_17_4  95
    RHS       disj2_10_17_4  -5206
    RHS       disj1_10_18_4  95
    RHS       disj2_10_18_4  -5197
    RHS       disj1_10_19_4  95
    RHS       disj2_10_19_4  -5197
    RHS       disj1_11_12_4  59
    RHS       disj2_11_12_4  -5205
    RHS       disj1_11_13_4  59
    RHS       disj2_11_13_4  -5201
    RHS       disj1_11_14_4  59
    RHS       disj2_11_14_4  -5161
    RHS       disj1_11_15_4  59
    RHS       disj2_11_15_4  -5208
    RHS       disj1_11_16_4  59
    RHS       disj2_11_16_4  -5223
    RHS       disj1_11_17_4  59
    RHS       disj2_11_17_4  -5206
    RHS       disj1_11_18_4  59
    RHS       disj2_11_18_4  -5197
    RHS       disj1_11_19_4  59
    RHS       disj2_11_19_4  -5197
    RHS       disj1_12_13_4  46
    RHS       disj2_12_13_4  -5201
    RHS       disj1_12_14_4  46
    RHS       disj2_12_14_4  -5161
    RHS       disj1_12_15_4  46
    RHS       disj2_12_15_4  -5208
    RHS       disj1_12_16_4  46
    RHS       disj2_12_16_4  -5223
    RHS       disj1_12_17_4  46
    RHS       disj2_12_17_4  -5206
    RHS       disj1_12_18_4  46
    RHS       disj2_12_18_4  -5197
    RHS       disj1_12_19_4  46
    RHS       disj2_12_19_4  -5197
    RHS       disj1_13_14_4  50
    RHS       disj2_13_14_4  -5161
    RHS       disj1_13_15_4  50
    RHS       disj2_13_15_4  -5208
    RHS       disj1_13_16_4  50
    RHS       disj2_13_16_4  -5223
    RHS       disj1_13_17_4  50
    RHS       disj2_13_17_4  -5206
    RHS       disj1_13_18_4  50
    RHS       disj2_13_18_4  -5197
    RHS       disj1_13_19_4  50
    RHS       disj2_13_19_4  -5197
    RHS       disj1_14_15_4  90
    RHS       disj2_14_15_4  -5208
    RHS       disj1_14_16_4  90
    RHS       disj2_14_16_4  -5223
    RHS       disj1_14_17_4  90
    RHS       disj2_14_17_4  -5206
    RHS       disj1_14_18_4  90
    RHS       disj2_14_18_4  -5197
    RHS       disj1_14_19_4  90
    RHS       disj2_14_19_4  -5197
    RHS       disj1_15_16_4  43
    RHS       disj2_15_16_4  -5223
    RHS       disj1_15_17_4  43
    RHS       disj2_15_17_4  -5206
    RHS       disj1_15_18_4  43
    RHS       disj2_15_18_4  -5197
    RHS       disj1_15_19_4  43
    RHS       disj2_15_19_4  -5197
    RHS       disj1_16_17_4  28
    RHS       disj2_16_17_4  -5206
    RHS       disj1_16_18_4  28
    RHS       disj2_16_18_4  -5197
    RHS       disj1_16_19_4  28
    RHS       disj2_16_19_4  -5197
    RHS       disj1_17_18_4  45
    RHS       disj2_17_18_4  -5197
    RHS       disj1_17_19_4  45
    RHS       disj2_17_19_4  -5197
    RHS       disj1_18_19_4  54
    RHS       disj2_18_19_4  -5197
BOUNDS
 BV BOUND     y_0_1_0
 BV BOUND     y_0_1_1
 BV BOUND     y_0_1_2
 BV BOUND     y_0_1_3
 BV BOUND     y_0_1_4
 BV BOUND     y_0_2_0
 BV BOUND     y_0_2_1
 BV BOUND     y_0_2_2
 BV BOUND     y_0_2_3
 BV BOUND     y_0_2_4
 BV BOUND     y_0_3_0
 BV BOUND     y_0_3_1
 BV BOUND     y_0_3_2
 BV BOUND     y_0_3_3
 BV BOUND     y_0_3_4
 BV BOUND     y_0_4_0
 BV BOUND     y_0_4_1
 BV BOUND     y_0_4_2
 BV BOUND     y_0_4_3
 BV BOUND     y_0_4_4
 BV BOUND     y_0_5_0
 BV BOUND     y_0_5_1
 BV BOUND     y_0_5_2
 BV BOUND     y_0_5_3
 BV BOUND     y_0_5_4
 BV BOUND     y_0_6_0
 BV BOUND     y_0_6_1
 BV BOUND     y_0_6_2
 BV BOUND     y_0_6_3
 BV BOUND     y_0_6_4
 BV BOUND     y_0_7_0
 BV BOUND     y_0_7_1
 BV BOUND     y_0_7_2
 BV BOUND     y_0_7_3
 BV BOUND     y_0_7_4
 BV BOUND     y_0_8_0
 BV BOUND     y_0_8_1
 BV BOUND     y_0_8_2
 BV BOUND     y_0_8_3
 BV BOUND     y_0_8_4
 BV BOUND     y_0_9_0
 BV BOUND     y_0_9_1
 BV BOUND     y_0_9_2
 BV BOUND     y_0_9_3
 BV BOUND     y_0_9_4
 BV BOUND     y_0_10_0
 BV BOUND     y_0_10_1
 BV BOUND     y_0_10_2
 BV BOUND     y_0_10_3
 BV BOUND     y_0_10_4
 BV BOUND     y_0_11_0
 BV BOUND     y_0_11_1
 BV BOUND     y_0_11_2
 BV BOUND     y_0_11_3
 BV BOUND     y_0_11_4
 BV BOUND     y_0_12_0
 BV BOUND     y_0_12_1
 BV BOUND     y_0_12_2
 BV BOUND     y_0_12_3
 BV BOUND     y_0_12_4
 BV BOUND     y_0_13_0
 BV BOUND     y_0_13_1
 BV BOUND     y_0_13_2
 BV BOUND     y_0_13_3
 BV BOUND     y_0_13_4
 BV BOUND     y_0_14_0
 BV BOUND     y_0_14_1
 BV BOUND     y_0_14_2
 BV BOUND     y_0_14_3
 BV BOUND     y_0_14_4
 BV BOUND     y_0_15_0
 BV BOUND     y_0_15_1
 BV BOUND     y_0_15_2
 BV BOUND     y_0_15_3
 BV BOUND     y_0_15_4
 BV BOUND     y_0_16_0
 BV BOUND     y_0_16_1
 BV BOUND     y_0_16_2
 BV BOUND     y_0_16_3
 BV BOUND     y_0_16_4
 BV BOUND     y_0_17_0
 BV BOUND     y_0_17_1
 BV BOUND     y_0_17_2
 BV BOUND     y_0_17_3
 BV BOUND     y_0_17_4
 BV BOUND     y_0_18_0
 BV BOUND     y_0_18_1
 BV BOUND     y_0_18_2
 BV BOUND     y_0_18_3
 BV BOUND     y_0_18_4
 BV BOUND     y_0_19_0
 BV BOUND     y_0_19_1
 BV BOUND     y_0_19_2
 BV BOUND     y_0_19_3
 BV BOUND     y_0_19_4
 BV BOUND     y_1_2_0
 BV BOUND     y_1_2_1
 BV BOUND     y_1_2_2
 BV BOUND     y_1_2_3
 BV BOUND     y_1_2_4
 BV BOUND     y_1_3_0
 BV BOUND     y_1_3_1
 BV BOUND     y_1_3_2
 BV BOUND     y_1_3_3
 BV BOUND     y_1_3_4
 BV BOUND     y_1_4_0
 BV BOUND     y_1_4_1
 BV BOUND     y_1_4_2
 BV BOUND     y_1_4_3
 BV BOUND     y_1_4_4
 BV BOUND     y_1_5_0
 BV BOUND     y_1_5_1
 BV BOUND     y_1_5_2
 BV BOUND     y_1_5_3
 BV BOUND     y_1_5_4
 BV BOUND     y_1_6_0
 BV BOUND     y_1_6_1
 BV BOUND     y_1_6_2
 BV BOUND     y_1_6_3
 BV BOUND     y_1_6_4
 BV BOUND     y_1_7_0
 BV BOUND     y_1_7_1
 BV BOUND     y_1_7_2
 BV BOUND     y_1_7_3
 BV BOUND     y_1_7_4
 BV BOUND     y_1_8_0
 BV BOUND     y_1_8_1
 BV BOUND     y_1_8_2
 BV BOUND     y_1_8_3
 BV BOUND     y_1_8_4
 BV BOUND     y_1_9_0
 BV BOUND     y_1_9_1
 BV BOUND     y_1_9_2
 BV BOUND     y_1_9_3
 BV BOUND     y_1_9_4
 BV BOUND     y_1_10_0
 BV BOUND     y_1_10_1
 BV BOUND     y_1_10_2
 BV BOUND     y_1_10_3
 BV BOUND     y_1_10_4
 BV BOUND     y_1_11_0
 BV BOUND     y_1_11_1
 BV BOUND     y_1_11_2
 BV BOUND     y_1_11_3
 BV BOUND     y_1_11_4
 BV BOUND     y_1_12_0
 BV BOUND     y_1_12_1
 BV BOUND     y_1_12_2
 BV BOUND     y_1_12_3
 BV BOUND     y_1_12_4
 BV BOUND     y_1_13_0
 BV BOUND     y_1_13_1
 BV BOUND     y_1_13_2
 BV BOUND     y_1_13_3
 BV BOUND     y_1_13_4
 BV BOUND     y_1_14_0
 BV BOUND     y_1_14_1
 BV BOUND     y_1_14_2
 BV BOUND     y_1_14_3
 BV BOUND     y_1_14_4
 BV BOUND     y_1_15_0
 BV BOUND     y_1_15_1
 BV BOUND     y_1_15_2
 BV BOUND     y_1_15_3
 BV BOUND     y_1_15_4
 BV BOUND     y_1_16_0
 BV BOUND     y_1_16_1
 BV BOUND     y_1_16_2
 BV BOUND     y_1_16_3
 BV BOUND     y_1_16_4
 BV BOUND     y_1_17_0
 BV BOUND     y_1_17_1
 BV BOUND     y_1_17_2
 BV BOUND     y_1_17_3
 BV BOUND     y_1_17_4
 BV BOUND     y_1_18_0
 BV BOUND     y_1_18_1
 BV BOUND     y_1_18_2
 BV BOUND     y_1_18_3
 BV BOUND     y_1_18_4
 BV BOUND     y_1_19_0
 BV BOUND     y_1_19_1
 BV BOUND     y_1_19_2
 BV BOUND     y_1_19_3
 BV BOUND     y_1_19_4
 BV BOUND     y_2_3_0
 BV BOUND     y_2_3_1
 BV BOUND     y_2_3_2
 BV BOUND     y_2_3_3
 BV BOUND     y_2_3_4
 BV BOUND     y_2_4_0
 BV BOUND     y_2_4_1
 BV BOUND     y_2_4_2
 BV BOUND     y_2_4_3
 BV BOUND     y_2_4_4
 BV BOUND     y_2_5_0
 BV BOUND     y_2_5_1
 BV BOUND     y_2_5_2
 BV BOUND     y_2_5_3
 BV BOUND     y_2_5_4
 BV BOUND     y_2_6_0
 BV BOUND     y_2_6_1
 BV BOUND     y_2_6_2
 BV BOUND     y_2_6_3
 BV BOUND     y_2_6_4
 BV BOUND     y_2_7_0
 BV BOUND     y_2_7_1
 BV BOUND     y_2_7_2
 BV BOUND     y_2_7_3
 BV BOUND     y_2_7_4
 BV BOUND     y_2_8_0
 BV BOUND     y_2_8_1
 BV BOUND     y_2_8_2
 BV BOUND     y_2_8_3
 BV BOUND     y_2_8_4
 BV BOUND     y_2_9_0
 BV BOUND     y_2_9_1
 BV BOUND     y_2_9_2
 BV BOUND     y_2_9_3
 BV BOUND     y_2_9_4
 BV BOUND     y_2_10_0
 BV BOUND     y_2_10_1
 BV BOUND     y_2_10_2
 BV BOUND     y_2_10_3
 BV BOUND     y_2_10_4
 BV BOUND     y_2_11_0
 BV BOUND     y_2_11_1
 BV BOUND     y_2_11_2
 BV BOUND     y_2_11_3
 BV BOUND     y_2_11_4
 BV BOUND     y_2_12_0
 BV BOUND     y_2_12_1
 BV BOUND     y_2_12_2
 BV BOUND     y_2_12_3
 BV BOUND     y_2_12_4
 BV BOUND     y_2_13_0
 BV BOUND     y_2_13_1
 BV BOUND     y_2_13_2
 BV BOUND     y_2_13_3
 BV BOUND     y_2_13_4
 BV BOUND     y_2_14_0
 BV BOUND     y_2_14_1
 BV BOUND     y_2_14_2
 BV BOUND     y_2_14_3
 BV BOUND     y_2_14_4
 BV BOUND     y_2_15_0
 BV BOUND     y_2_15_1
 BV BOUND     y_2_15_2
 BV BOUND     y_2_15_3
 BV BOUND     y_2_15_4
 BV BOUND     y_2_16_0
 BV BOUND     y_2_16_1
 BV BOUND     y_2_16_2
 BV BOUND     y_2_16_3
 BV BOUND     y_2_16_4
 BV BOUND     y_2_17_0
 BV BOUND     y_2_17_1
 BV BOUND     y_2_17_2
 BV BOUND     y_2_17_3
 BV BOUND     y_2_17_4
 BV BOUND     y_2_18_0
 BV BOUND     y_2_18_1
 BV BOUND     y_2_18_2
 BV BOUND     y_2_18_3
 BV BOUND     y_2_18_4
 BV BOUND     y_2_19_0
 BV BOUND     y_2_19_1
 BV BOUND     y_2_19_2
 BV BOUND     y_2_19_3
 BV BOUND     y_2_19_4
 BV BOUND     y_3_4_0
 BV BOUND     y_3_4_1
 BV BOUND     y_3_4_2
 BV BOUND     y_3_4_3
 BV BOUND     y_3_4_4
 BV BOUND     y_3_5_0
 BV BOUND     y_3_5_1
 BV BOUND     y_3_5_2
 BV BOUND     y_3_5_3
 BV BOUND     y_3_5_4
 BV BOUND     y_3_6_0
 BV BOUND     y_3_6_1
 BV BOUND     y_3_6_2
 BV BOUND     y_3_6_3
 BV BOUND     y_3_6_4
 BV BOUND     y_3_7_0
 BV BOUND     y_3_7_1
 BV BOUND     y_3_7_2
 BV BOUND     y_3_7_3
 BV BOUND     y_3_7_4
 BV BOUND     y_3_8_0
 BV BOUND     y_3_8_1
 BV BOUND     y_3_8_2
 BV BOUND     y_3_8_3
 BV BOUND     y_3_8_4
 BV BOUND     y_3_9_0
 BV BOUND     y_3_9_1
 BV BOUND     y_3_9_2
 BV BOUND     y_3_9_3
 BV BOUND     y_3_9_4
 BV BOUND     y_3_10_0
 BV BOUND     y_3_10_1
 BV BOUND     y_3_10_2
 BV BOUND     y_3_10_3
 BV BOUND     y_3_10_4
 BV BOUND     y_3_11_0
 BV BOUND     y_3_11_1
 BV BOUND     y_3_11_2
 BV BOUND     y_3_11_3
 BV BOUND     y_3_11_4
 BV BOUND     y_3_12_0
 BV BOUND     y_3_12_1
 BV BOUND     y_3_12_2
 BV BOUND     y_3_12_3
 BV BOUND     y_3_12_4
 BV BOUND     y_3_13_0
 BV BOUND     y_3_13_1
 BV BOUND     y_3_13_2
 BV BOUND     y_3_13_3
 BV BOUND     y_3_13_4
 BV BOUND     y_3_14_0
 BV BOUND     y_3_14_1
 BV BOUND     y_3_14_2
 BV BOUND     y_3_14_3
 BV BOUND     y_3_14_4
 BV BOUND     y_3_15_0
 BV BOUND     y_3_15_1
 BV BOUND     y_3_15_2
 BV BOUND     y_3_15_3
 BV BOUND     y_3_15_4
 BV BOUND     y_3_16_0
 BV BOUND     y_3_16_1
 BV BOUND     y_3_16_2
 BV BOUND     y_3_16_3
 BV BOUND     y_3_16_4
 BV BOUND     y_3_17_0
 BV BOUND     y_3_17_1
 BV BOUND     y_3_17_2
 BV BOUND     y_3_17_3
 BV BOUND     y_3_17_4
 BV BOUND     y_3_18_0
 BV BOUND     y_3_18_1
 BV BOUND     y_3_18_2
 BV BOUND     y_3_18_3
 BV BOUND     y_3_18_4
 BV BOUND     y_3_19_0
 BV BOUND     y_3_19_1
 BV BOUND     y_3_19_2
 BV BOUND     y_3_19_3
 BV BOUND     y_3_19_4
 BV BOUND     y_4_5_0
 BV BOUND     y_4_5_1
 BV BOUND     y_4_5_2
 BV BOUND     y_4_5_3
 BV BOUND     y_4_5_4
 BV BOUND     y_4_6_0
 BV BOUND     y_4_6_1
 BV BOUND     y_4_6_2
 BV BOUND     y_4_6_3
 BV BOUND     y_4_6_4
 BV BOUND     y_4_7_0
 BV BOUND     y_4_7_1
 BV BOUND     y_4_7_2
 BV BOUND     y_4_7_3
 BV BOUND     y_4_7_4
 BV BOUND     y_4_8_0
 BV BOUND     y_4_8_1
 BV BOUND     y_4_8_2
 BV BOUND     y_4_8_3
 BV BOUND     y_4_8_4
 BV BOUND     y_4_9_0
 BV BOUND     y_4_9_1
 BV BOUND     y_4_9_2
 BV BOUND     y_4_9_3
 BV BOUND     y_4_9_4
 BV BOUND     y_4_10_0
 BV BOUND     y_4_10_1
 BV BOUND     y_4_10_2
 BV BOUND     y_4_10_3
 BV BOUND     y_4_10_4
 BV BOUND     y_4_11_0
 BV BOUND     y_4_11_1
 BV BOUND     y_4_11_2
 BV BOUND     y_4_11_3
 BV BOUND     y_4_11_4
 BV BOUND     y_4_12_0
 BV BOUND     y_4_12_1
 BV BOUND     y_4_12_2
 BV BOUND     y_4_12_3
 BV BOUND     y_4_12_4
 BV BOUND     y_4_13_0
 BV BOUND     y_4_13_1
 BV BOUND     y_4_13_2
 BV BOUND     y_4_13_3
 BV BOUND     y_4_13_4
 BV BOUND     y_4_14_0
 BV BOUND     y_4_14_1
 BV BOUND     y_4_14_2
 BV BOUND     y_4_14_3
 BV BOUND     y_4_14_4
 BV BOUND     y_4_15_0
 BV BOUND     y_4_15_1
 BV BOUND     y_4_15_2
 BV BOUND     y_4_15_3
 BV BOUND     y_4_15_4
 BV BOUND     y_4_16_0
 BV BOUND     y_4_16_1
 BV BOUND     y_4_16_2
 BV BOUND     y_4_16_3
 BV BOUND     y_4_16_4
 BV BOUND     y_4_17_0
 BV BOUND     y_4_17_1
 BV BOUND     y_4_17_2
 BV BOUND     y_4_17_3
 BV BOUND     y_4_17_4
 BV BOUND     y_4_18_0
 BV BOUND     y_4_18_1
 BV BOUND     y_4_18_2
 BV BOUND     y_4_18_3
 BV BOUND     y_4_18_4
 BV BOUND     y_4_19_0
 BV BOUND     y_4_19_1
 BV BOUND     y_4_19_2
 BV BOUND     y_4_19_3
 BV BOUND     y_4_19_4
 BV BOUND     y_5_6_0
 BV BOUND     y_5_6_1
 BV BOUND     y_5_6_2
 BV BOUND     y_5_6_3
 BV BOUND     y_5_6_4
 BV BOUND     y_5_7_0
 BV BOUND     y_5_7_1
 BV BOUND     y_5_7_2
 BV BOUND     y_5_7_3
 BV BOUND     y_5_7_4
 BV BOUND     y_5_8_0
 BV BOUND     y_5_8_1
 BV BOUND     y_5_8_2
 BV BOUND     y_5_8_3
 BV BOUND     y_5_8_4
 BV BOUND     y_5_9_0
 BV BOUND     y_5_9_1
 BV BOUND     y_5_9_2
 BV BOUND     y_5_9_3
 BV BOUND     y_5_9_4
 BV BOUND     y_5_10_0
 BV BOUND     y_5_10_1
 BV BOUND     y_5_10_2
 BV BOUND     y_5_10_3
 BV BOUND     y_5_10_4
 BV BOUND     y_5_11_0
 BV BOUND     y_5_11_1
 BV BOUND     y_5_11_2
 BV BOUND     y_5_11_3
 BV BOUND     y_5_11_4
 BV BOUND     y_5_12_0
 BV BOUND     y_5_12_1
 BV BOUND     y_5_12_2
 BV BOUND     y_5_12_3
 BV BOUND     y_5_12_4
 BV BOUND     y_5_13_0
 BV BOUND     y_5_13_1
 BV BOUND     y_5_13_2
 BV BOUND     y_5_13_3
 BV BOUND     y_5_13_4
 BV BOUND     y_5_14_0
 BV BOUND     y_5_14_1
 BV BOUND     y_5_14_2
 BV BOUND     y_5_14_3
 BV BOUND     y_5_14_4
 BV BOUND     y_5_15_0
 BV BOUND     y_5_15_1
 BV BOUND     y_5_15_2
 BV BOUND     y_5_15_3
 BV BOUND     y_5_15_4
 BV BOUND     y_5_16_0
 BV BOUND     y_5_16_1
 BV BOUND     y_5_16_2
 BV BOUND     y_5_16_3
 BV BOUND     y_5_16_4
 BV BOUND     y_5_17_0
 BV BOUND     y_5_17_1
 BV BOUND     y_5_17_2
 BV BOUND     y_5_17_3
 BV BOUND     y_5_17_4
 BV BOUND     y_5_18_0
 BV BOUND     y_5_18_1
 BV BOUND     y_5_18_2
 BV BOUND     y_5_18_3
 BV BOUND     y_5_18_4
 BV BOUND     y_5_19_0
 BV BOUND     y_5_19_1
 BV BOUND     y_5_19_2
 BV BOUND     y_5_19_3
 BV BOUND     y_5_19_4
 BV BOUND     y_6_7_0
 BV BOUND     y_6_7_1
 BV BOUND     y_6_7_2
 BV BOUND     y_6_7_3
 BV BOUND     y_6_7_4
 BV BOUND     y_6_8_0
 BV BOUND     y_6_8_1
 BV BOUND     y_6_8_2
 BV BOUND     y_6_8_3
 BV BOUND     y_6_8_4
 BV BOUND     y_6_9_0
 BV BOUND     y_6_9_1
 BV BOUND     y_6_9_2
 BV BOUND     y_6_9_3
 BV BOUND     y_6_9_4
 BV BOUND     y_6_10_0
 BV BOUND     y_6_10_1
 BV BOUND     y_6_10_2
 BV BOUND     y_6_10_3
 BV BOUND     y_6_10_4
 BV BOUND     y_6_11_0
 BV BOUND     y_6_11_1
 BV BOUND     y_6_11_2
 BV BOUND     y_6_11_3
 BV BOUND     y_6_11_4
 BV BOUND     y_6_12_0
 BV BOUND     y_6_12_1
 BV BOUND     y_6_12_2
 BV BOUND     y_6_12_3
 BV BOUND     y_6_12_4
 BV BOUND     y_6_13_0
 BV BOUND     y_6_13_1
 BV BOUND     y_6_13_2
 BV BOUND     y_6_13_3
 BV BOUND     y_6_13_4
 BV BOUND     y_6_14_0
 BV BOUND     y_6_14_1
 BV BOUND     y_6_14_2
 BV BOUND     y_6_14_3
 BV BOUND     y_6_14_4
 BV BOUND     y_6_15_0
 BV BOUND     y_6_15_1
 BV BOUND     y_6_15_2
 BV BOUND     y_6_15_3
 BV BOUND     y_6_15_4
 BV BOUND     y_6_16_0
 BV BOUND     y_6_16_1
 BV BOUND     y_6_16_2
 BV BOUND     y_6_16_3
 BV BOUND     y_6_16_4
 BV BOUND     y_6_17_0
 BV BOUND     y_6_17_1
 BV BOUND     y_6_17_2
 BV BOUND     y_6_17_3
 BV BOUND     y_6_17_4
 BV BOUND     y_6_18_0
 BV BOUND     y_6_18_1
 BV BOUND     y_6_18_2
 BV BOUND     y_6_18_3
 BV BOUND     y_6_18_4
 BV BOUND     y_6_19_0
 BV BOUND     y_6_19_1
 BV BOUND     y_6_19_2
 BV BOUND     y_6_19_3
 BV BOUND     y_6_19_4
 BV BOUND     y_7_8_0
 BV BOUND     y_7_8_1
 BV BOUND     y_7_8_2
 BV BOUND     y_7_8_3
 BV BOUND     y_7_8_4
 BV BOUND     y_7_9_0
 BV BOUND     y_7_9_1
 BV BOUND     y_7_9_2
 BV BOUND     y_7_9_3
 BV BOUND     y_7_9_4
 BV BOUND     y_7_10_0
 BV BOUND     y_7_10_1
 BV BOUND     y_7_10_2
 BV BOUND     y_7_10_3
 BV BOUND     y_7_10_4
 BV BOUND     y_7_11_0
 BV BOUND     y_7_11_1
 BV BOUND     y_7_11_2
 BV BOUND     y_7_11_3
 BV BOUND     y_7_11_4
 BV BOUND     y_7_12_0
 BV BOUND     y_7_12_1
 BV BOUND     y_7_12_2
 BV BOUND     y_7_12_3
 BV BOUND     y_7_12_4
 BV BOUND     y_7_13_0
 BV BOUND     y_7_13_1
 BV BOUND     y_7_13_2
 BV BOUND     y_7_13_3
 BV BOUND     y_7_13_4
 BV BOUND     y_7_14_0
 BV BOUND     y_7_14_1
 BV BOUND     y_7_14_2
 BV BOUND     y_7_14_3
 BV BOUND     y_7_14_4
 BV BOUND     y_7_15_0
 BV BOUND     y_7_15_1
 BV BOUND     y_7_15_2
 BV BOUND     y_7_15_3
 BV BOUND     y_7_15_4
 BV BOUND     y_7_16_0
 BV BOUND     y_7_16_1
 BV BOUND     y_7_16_2
 BV BOUND     y_7_16_3
 BV BOUND     y_7_16_4
 BV BOUND     y_7_17_0
 BV BOUND     y_7_17_1
 BV BOUND     y_7_17_2
 BV BOUND     y_7_17_3
 BV BOUND     y_7_17_4
 BV BOUND     y_7_18_0
 BV BOUND     y_7_18_1
 BV BOUND     y_7_18_2
 BV BOUND     y_7_18_3
 BV BOUND     y_7_18_4
 BV BOUND     y_7_19_0
 BV BOUND     y_7_19_1
 BV BOUND     y_7_19_2
 BV BOUND     y_7_19_3
 BV BOUND     y_7_19_4
 BV BOUND     y_8_9_0
 BV BOUND     y_8_9_1
 BV BOUND     y_8_9_2
 BV BOUND     y_8_9_3
 BV BOUND     y_8_9_4
 BV BOUND     y_8_10_0
 BV BOUND     y_8_10_1
 BV BOUND     y_8_10_2
 BV BOUND     y_8_10_3
 BV BOUND     y_8_10_4
 BV BOUND     y_8_11_0
 BV BOUND     y_8_11_1
 BV BOUND     y_8_11_2
 BV BOUND     y_8_11_3
 BV BOUND     y_8_11_4
 BV BOUND     y_8_12_0
 BV BOUND     y_8_12_1
 BV BOUND     y_8_12_2
 BV BOUND     y_8_12_3
 BV BOUND     y_8_12_4
 BV BOUND     y_8_13_0
 BV BOUND     y_8_13_1
 BV BOUND     y_8_13_2
 BV BOUND     y_8_13_3
 BV BOUND     y_8_13_4
 BV BOUND     y_8_14_0
 BV BOUND     y_8_14_1
 BV BOUND     y_8_14_2
 BV BOUND     y_8_14_3
 BV BOUND     y_8_14_4
 BV BOUND     y_8_15_0
 BV BOUND     y_8_15_1
 BV BOUND     y_8_15_2
 BV BOUND     y_8_15_3
 BV BOUND     y_8_15_4
 BV BOUND     y_8_16_0
 BV BOUND     y_8_16_1
 BV BOUND     y_8_16_2
 BV BOUND     y_8_16_3
 BV BOUND     y_8_16_4
 BV BOUND     y_8_17_0
 BV BOUND     y_8_17_1
 BV BOUND     y_8_17_2
 BV BOUND     y_8_17_3
 BV BOUND     y_8_17_4
 BV BOUND     y_8_18_0
 BV BOUND     y_8_18_1
 BV BOUND     y_8_18_2
 BV BOUND     y_8_18_3
 BV BOUND     y_8_18_4
 BV BOUND     y_8_19_0
 BV BOUND     y_8_19_1
 BV BOUND     y_8_19_2
 BV BOUND     y_8_19_3
 BV BOUND     y_8_19_4
 BV BOUND     y_9_10_0
 BV BOUND     y_9_10_1
 BV BOUND     y_9_10_2
 BV BOUND     y_9_10_3
 BV BOUND     y_9_10_4
 BV BOUND     y_9_11_0
 BV BOUND     y_9_11_1
 BV BOUND     y_9_11_2
 BV BOUND     y_9_11_3
 BV BOUND     y_9_11_4
 BV BOUND     y_9_12_0
 BV BOUND     y_9_12_1
 BV BOUND     y_9_12_2
 BV BOUND     y_9_12_3
 BV BOUND     y_9_12_4
 BV BOUND     y_9_13_0
 BV BOUND     y_9_13_1
 BV BOUND     y_9_13_2
 BV BOUND     y_9_13_3
 BV BOUND     y_9_13_4
 BV BOUND     y_9_14_0
 BV BOUND     y_9_14_1
 BV BOUND     y_9_14_2
 BV BOUND     y_9_14_3
 BV BOUND     y_9_14_4
 BV BOUND     y_9_15_0
 BV BOUND     y_9_15_1
 BV BOUND     y_9_15_2
 BV BOUND     y_9_15_3
 BV BOUND     y_9_15_4
 BV BOUND     y_9_16_0
 BV BOUND     y_9_16_1
 BV BOUND     y_9_16_2
 BV BOUND     y_9_16_3
 BV BOUND     y_9_16_4
 BV BOUND     y_9_17_0
 BV BOUND     y_9_17_1
 BV BOUND     y_9_17_2
 BV BOUND     y_9_17_3
 BV BOUND     y_9_17_4
 BV BOUND     y_9_18_0
 BV BOUND     y_9_18_1
 BV BOUND     y_9_18_2
 BV BOUND     y_9_18_3
 BV BOUND     y_9_18_4
 BV BOUND     y_9_19_0
 BV BOUND     y_9_19_1
 BV BOUND     y_9_19_2
 BV BOUND     y_9_19_3
 BV BOUND     y_9_19_4
 BV BOUND     y_10_11_0
 BV BOUND     y_10_11_1
 BV BOUND     y_10_11_2
 BV BOUND     y_10_11_3
 BV BOUND     y_10_11_4
 BV BOUND     y_10_12_0
 BV BOUND     y_10_12_1
 BV BOUND     y_10_12_2
 BV BOUND     y_10_12_3
 BV BOUND     y_10_12_4
 BV BOUND     y_10_13_0
 BV BOUND     y_10_13_1
 BV BOUND     y_10_13_2
 BV BOUND     y_10_13_3
 BV BOUND     y_10_13_4
 BV BOUND     y_10_14_0
 BV BOUND     y_10_14_1
 BV BOUND     y_10_14_2
 BV BOUND     y_10_14_3
 BV BOUND     y_10_14_4
 BV BOUND     y_10_15_0
 BV BOUND     y_10_15_1
 BV BOUND     y_10_15_2
 BV BOUND     y_10_15_3
 BV BOUND     y_10_15_4
 BV BOUND     y_10_16_0
 BV BOUND     y_10_16_1
 BV BOUND     y_10_16_2
 BV BOUND     y_10_16_3
 BV BOUND     y_10_16_4
 BV BOUND     y_10_17_0
 BV BOUND     y_10_17_1
 BV BOUND     y_10_17_2
 BV BOUND     y_10_17_3
 BV BOUND     y_10_17_4
 BV BOUND     y_10_18_0
 BV BOUND     y_10_18_1
 BV BOUND     y_10_18_2
 BV BOUND     y_10_18_3
 BV BOUND     y_10_18_4
 BV BOUND     y_10_19_0
 BV BOUND     y_10_19_1
 BV BOUND     y_10_19_2
 BV BOUND     y_10_19_3
 BV BOUND     y_10_19_4
 BV BOUND     y_11_12_0
 BV BOUND     y_11_12_1
 BV BOUND     y_11_12_2
 BV BOUND     y_11_12_3
 BV BOUND     y_11_12_4
 BV BOUND     y_11_13_0
 BV BOUND     y_11_13_1
 BV BOUND     y_11_13_2
 BV BOUND     y_11_13_3
 BV BOUND     y_11_13_4
 BV BOUND     y_11_14_0
 BV BOUND     y_11_14_1
 BV BOUND     y_11_14_2
 BV BOUND     y_11_14_3
 BV BOUND     y_11_14_4
 BV BOUND     y_11_15_0
 BV BOUND     y_11_15_1
 BV BOUND     y_11_15_2
 BV BOUND     y_11_15_3
 BV BOUND     y_11_15_4
 BV BOUND     y_11_16_0
 BV BOUND     y_11_16_1
 BV BOUND     y_11_16_2
 BV BOUND     y_11_16_3
 BV BOUND     y_11_16_4
 BV BOUND     y_11_17_0
 BV BOUND     y_11_17_1
 BV BOUND     y_11_17_2
 BV BOUND     y_11_17_3
 BV BOUND     y_11_17_4
 BV BOUND     y_11_18_0
 BV BOUND     y_11_18_1
 BV BOUND     y_11_18_2
 BV BOUND     y_11_18_3
 BV BOUND     y_11_18_4
 BV BOUND     y_11_19_0
 BV BOUND     y_11_19_1
 BV BOUND     y_11_19_2
 BV BOUND     y_11_19_3
 BV BOUND     y_11_19_4
 BV BOUND     y_12_13_0
 BV BOUND     y_12_13_1
 BV BOUND     y_12_13_2
 BV BOUND     y_12_13_3
 BV BOUND     y_12_13_4
 BV BOUND     y_12_14_0
 BV BOUND     y_12_14_1
 BV BOUND     y_12_14_2
 BV BOUND     y_12_14_3
 BV BOUND     y_12_14_4
 BV BOUND     y_12_15_0
 BV BOUND     y_12_15_1
 BV BOUND     y_12_15_2
 BV BOUND     y_12_15_3
 BV BOUND     y_12_15_4
 BV BOUND     y_12_16_0
 BV BOUND     y_12_16_1
 BV BOUND     y_12_16_2
 BV BOUND     y_12_16_3
 BV BOUND     y_12_16_4
 BV BOUND     y_12_17_0
 BV BOUND     y_12_17_1
 BV BOUND     y_12_17_2
 BV BOUND     y_12_17_3
 BV BOUND     y_12_17_4
 BV BOUND     y_12_18_0
 BV BOUND     y_12_18_1
 BV BOUND     y_12_18_2
 BV BOUND     y_12_18_3
 BV BOUND     y_12_18_4
 BV BOUND     y_12_19_0
 BV BOUND     y_12_19_1
 BV BOUND     y_12_19_2
 BV BOUND     y_12_19_3
 BV BOUND     y_12_19_4
 BV BOUND     y_13_14_0
 BV BOUND     y_13_14_1
 BV BOUND     y_13_14_2
 BV BOUND     y_13_14_3
 BV BOUND     y_13_14_4
 BV BOUND     y_13_15_0
 BV BOUND     y_13_15_1
 BV BOUND     y_13_15_2
 BV BOUND     y_13_15_3
 BV BOUND     y_13_15_4
 BV BOUND     y_13_16_0
 BV BOUND     y_13_16_1
 BV BOUND     y_13_16_2
 BV BOUND     y_13_16_3
 BV BOUND     y_13_16_4
 BV BOUND     y_13_17_0
 BV BOUND     y_13_17_1
 BV BOUND     y_13_17_2
 BV BOUND     y_13_17_3
 BV BOUND     y_13_17_4
 BV BOUND     y_13_18_0
 BV BOUND     y_13_18_1
 BV BOUND     y_13_18_2
 BV BOUND     y_13_18_3
 BV BOUND     y_13_18_4
 BV BOUND     y_13_19_0
 BV BOUND     y_13_19_1
 BV BOUND     y_13_19_2
 BV BOUND     y_13_19_3
 BV BOUND     y_13_19_4
 BV BOUND     y_14_15_0
 BV BOUND     y_14_15_1
 BV BOUND     y_14_15_2
 BV BOUND     y_14_15_3
 BV BOUND     y_14_15_4
 BV BOUND     y_14_16_0
 BV BOUND     y_14_16_1
 BV BOUND     y_14_16_2
 BV BOUND     y_14_16_3
 BV BOUND     y_14_16_4
 BV BOUND     y_14_17_0
 BV BOUND     y_14_17_1
 BV BOUND     y_14_17_2
 BV BOUND     y_14_17_3
 BV BOUND     y_14_17_4
 BV BOUND     y_14_18_0
 BV BOUND     y_14_18_1
 BV BOUND     y_14_18_2
 BV BOUND     y_14_18_3
 BV BOUND     y_14_18_4
 BV BOUND     y_14_19_0
 BV BOUND     y_14_19_1
 BV BOUND     y_14_19_2
 BV BOUND     y_14_19_3
 BV BOUND     y_14_19_4
 BV BOUND     y_15_16_0
 BV BOUND     y_15_16_1
 BV BOUND     y_15_16_2
 BV BOUND     y_15_16_3
 BV BOUND     y_15_16_4
 BV BOUND     y_15_17_0
 BV BOUND     y_15_17_1
 BV BOUND     y_15_17_2
 BV BOUND     y_15_17_3
 BV BOUND     y_15_17_4
 BV BOUND     y_15_18_0
 BV BOUND     y_15_18_1
 BV BOUND     y_15_18_2
 BV BOUND     y_15_18_3
 BV BOUND     y_15_18_4
 BV BOUND     y_15_19_0
 BV BOUND     y_15_19_1
 BV BOUND     y_15_19_2
 BV BOUND     y_15_19_3
 BV BOUND     y_15_19_4
 BV BOUND     y_16_17_0
 BV BOUND     y_16_17_1
 BV BOUND     y_16_17_2
 BV BOUND     y_16_17_3
 BV BOUND     y_16_17_4
 BV BOUND     y_16_18_0
 BV BOUND     y_16_18_1
 BV BOUND     y_16_18_2
 BV BOUND     y_16_18_3
 BV BOUND     y_16_18_4
 BV BOUND     y_16_19_0
 BV BOUND     y_16_19_1
 BV BOUND     y_16_19_2
 BV BOUND     y_16_19_3
 BV BOUND     y_16_19_4
 BV BOUND     y_17_18_0
 BV BOUND     y_17_18_1
 BV BOUND     y_17_18_2
 BV BOUND     y_17_18_3
 BV BOUND     y_17_18_4
 BV BOUND     y_17_19_0
 BV BOUND     y_17_19_1
 BV BOUND     y_17_19_2
 BV BOUND     y_17_19_3
 BV BOUND     y_17_19_4
 BV BOUND     y_18_19_0
 BV BOUND     y_18_19_1
 BV BOUND     y_18_19_2
 BV BOUND     y_18_19_3
 BV BOUND     y_18_19_4
ENDATA
