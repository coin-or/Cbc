NAME          SETPACK
ROWS
 N  OBJ
 L  PACK_0
 L  PACK_1
 L  PACK_2
 L  PACK_3
 L  PACK_4
 L  PACK_5
 L  PACK_6
 L  PACK_7
 L  PACK_8
 L  PACK_9
 L  PACK_10
 L  PACK_11
 L  PACK_12
 L  PACK_13
 L  PACK_14
 L  PACK_15
 L  PACK_16
 L  PACK_17
 L  PACK_18
 L  PACK_19
 L  PACK_20
 L  PACK_21
 L  PACK_22
 L  PACK_23
 L  PACK_24
 L  PACK_25
 L  PACK_26
 L  PACK_27
 L  PACK_28
 L  PACK_29
 L  PACK_30
 L  PACK_31
 L  PACK_32
 L  PACK_33
 L  PACK_34
 L  PACK_35
 L  PACK_36
 L  PACK_37
 L  PACK_38
 L  PACK_39
COLUMNS
    x_0         OBJ       -82
    x_0         PACK_14  1.0
    x_0         PACK_15  1.0
    x_1         OBJ       -15
    x_1         PACK_5  1.0
    x_1         PACK_6  1.0
    x_1         PACK_7  1.0
    x_1         PACK_8  1.0
    x_2         OBJ       -4
    x_2         PACK_6  1.0
    x_2         PACK_7  1.0
    x_2         PACK_8  1.0
    x_3         OBJ       -95
    x_3         PACK_17  1.0
    x_3         PACK_18  1.0
    x_3         PACK_19  1.0
    x_3         PACK_20  1.0
    x_3         PACK_21  1.0
    x_4         OBJ       -36
    x_4         PACK_23  1.0
    x_4         PACK_24  1.0
    x_4         PACK_25  1.0
    x_4         PACK_26  1.0
    x_4         PACK_27  1.0
    x_5         OBJ       -32
    x_5         PACK_23  1.0
    x_5         PACK_24  1.0
    x_5         PACK_25  1.0
    x_6         OBJ       -29
    x_6         PACK_13  1.0
    x_6         PACK_14  1.0
    x_6         PACK_15  1.0
    x_6         PACK_16  1.0
    x_7         OBJ       -18
    x_7         PACK_4  1.0
    x_7         PACK_5  1.0
    x_7         PACK_6  1.0
    x_7         PACK_7  1.0
    x_8         OBJ       -95
    x_8         PACK_34  1.0
    x_8         PACK_35  1.0
    x_8         PACK_36  1.0
    x_9         OBJ       -14
    x_9         PACK_10  1.0
    x_9         PACK_11  1.0
    x_9         PACK_12  1.0
    x_10        OBJ       -87
    x_10        PACK_24  1.0
    x_10        PACK_25  1.0
    x_10        PACK_26  1.0
    x_10        PACK_27  1.0
    x_10        PACK_28  1.0
    x_11        OBJ       -95
    x_11        PACK_35  1.0
    x_11        PACK_36  1.0
    x_11        PACK_37  1.0
    x_11        PACK_38  1.0
    x_12        OBJ       -70
    x_12        PACK_20  1.0
    x_12        PACK_21  1.0
    x_12        PACK_22  1.0
    x_13        OBJ       -12
    x_13        PACK_14  1.0
    x_13        PACK_15  1.0
    x_14        OBJ       -76
    x_14        PACK_20  1.0
    x_14        PACK_21  1.0
    x_15        OBJ       -55
    x_15        PACK_17  1.0
    x_15        PACK_18  1.0
    x_15        PACK_19  1.0
    x_15        PACK_20  1.0
    x_15        PACK_21  1.0
    x_16        OBJ       -5
    x_16        PACK_13  1.0
    x_16        PACK_14  1.0
    x_17        OBJ       -4
    x_17        PACK_13  1.0
    x_17        PACK_14  1.0
    x_17        PACK_15  1.0
    x_17        PACK_16  1.0
    x_18        OBJ       -12
    x_18        PACK_25  1.0
    x_18        PACK_26  1.0
    x_18        PACK_27  1.0
    x_18        PACK_28  1.0
    x_18        PACK_29  1.0
    x_19        OBJ       -28
    x_19        PACK_9  1.0
    x_19        PACK_10  1.0
    x_19        PACK_11  1.0
    x_19        PACK_12  1.0
    x_19        PACK_13  1.0
    x_20        OBJ       -30
    x_20        PACK_8  1.0
    x_20        PACK_9  1.0
    x_20        PACK_10  1.0
    x_20        PACK_11  1.0
    x_21        OBJ       -65
    x_21        PACK_35  1.0
    x_21        PACK_36  1.0
    x_21        PACK_37  1.0
    x_22        OBJ       -78
    x_22        PACK_37  1.0
    x_22        PACK_38  1.0
    x_22        PACK_39  1.0
    x_23        OBJ       -4
    x_23        PACK_37  1.0
    x_23        PACK_38  1.0
    x_23        PACK_39  1.0
    x_24        OBJ       -72
    x_24        PACK_23  1.0
    x_24        PACK_24  1.0
    x_24        PACK_25  1.0
    x_24        PACK_26  1.0
    x_24        PACK_27  1.0
    x_25        OBJ       -26
    x_25        PACK_8  1.0
    x_25        PACK_9  1.0
    x_25        PACK_10  1.0
    x_26        OBJ       -92
    x_26        PACK_5  1.0
    x_26        PACK_6  1.0
    x_26        PACK_7  1.0
    x_26        PACK_8  1.0
    x_26        PACK_9  1.0
    x_27        OBJ       -84
    x_27        PACK_7  1.0
    x_27        PACK_8  1.0
    x_28        OBJ       -90
    x_28        PACK_10  1.0
    x_28        PACK_11  1.0
    x_28        PACK_12  1.0
    x_29        OBJ       -70
    x_29        PACK_38  1.0
    x_29        PACK_39  1.0
    x_30        OBJ       -54
    x_30        PACK_24  1.0
    x_30        PACK_25  1.0
    x_31        OBJ       -29
    x_31        PACK_38  1.0
    x_31        PACK_39  1.0
    x_32        OBJ       -58
    x_32        PACK_33  1.0
    x_32        PACK_34  1.0
    x_32        PACK_35  1.0
    x_32        PACK_36  1.0
    x_32        PACK_37  1.0
    x_33        OBJ       -76
    x_33        PACK_35  1.0
    x_33        PACK_36  1.0
    x_33        PACK_37  1.0
    x_33        PACK_38  1.0
    x_34        OBJ       -36
    x_34        PACK_7  1.0
    x_34        PACK_8  1.0
    x_35        OBJ       -1
    x_35        PACK_21  1.0
    x_35        PACK_22  1.0
    x_35        PACK_23  1.0
    x_35        PACK_24  1.0
    x_36        OBJ       -98
    x_36        PACK_18  1.0
    x_36        PACK_19  1.0
    x_37        OBJ       -21
    x_37        PACK_10  1.0
    x_37        PACK_11  1.0
    x_37        PACK_12  1.0
    x_37        PACK_13  1.0
    x_37        PACK_14  1.0
    x_38        OBJ       -90
    x_38        PACK_0  1.0
    x_38        PACK_1  1.0
    x_38        PACK_2  1.0
    x_38        PACK_3  1.0
    x_38        PACK_4  1.0
    x_39        OBJ       -55
    x_39        PACK_32  1.0
    x_39        PACK_33  1.0
    x_39        PACK_34  1.0
    x_39        PACK_35  1.0
    x_40        OBJ       -44
    x_40        PACK_32  1.0
    x_40        PACK_33  1.0
    x_40        PACK_34  1.0
    x_41        OBJ       -36
    x_41        PACK_19  1.0
    x_41        PACK_20  1.0
    x_42        OBJ       -20
    x_42        PACK_9  1.0
    x_42        PACK_10  1.0
    x_42        PACK_11  1.0
    x_43        OBJ       -28
    x_43        PACK_10  1.0
    x_43        PACK_11  1.0
    x_43        PACK_12  1.0
    x_43        PACK_13  1.0
    x_44        OBJ       -98
    x_44        PACK_38  1.0
    x_44        PACK_39  1.0
    x_45        OBJ       -44
    x_45        PACK_31  1.0
    x_45        PACK_32  1.0
    x_45        PACK_33  1.0
    x_45        PACK_34  1.0
    x_46        OBJ       -14
    x_46        PACK_7  1.0
    x_46        PACK_8  1.0
    x_47        OBJ       -12
    x_47        PACK_19  1.0
    x_47        PACK_20  1.0
    x_47        PACK_21  1.0
    x_47        PACK_22  1.0
    x_48        OBJ       -49
    x_48        PACK_3  1.0
    x_48        PACK_4  1.0
    x_48        PACK_5  1.0
    x_49        OBJ       -13
    x_49        PACK_36  1.0
    x_49        PACK_37  1.0
    x_49        PACK_38  1.0
    x_50        OBJ       -46
    x_50        PACK_5  1.0
    x_50        PACK_6  1.0
    x_51        OBJ       -45
    x_51        PACK_4  1.0
    x_51        PACK_5  1.0
    x_51        PACK_6  1.0
    x_51        PACK_7  1.0
    x_51        PACK_8  1.0
    x_52        OBJ       -78
    x_52        PACK_8  1.0
    x_52        PACK_9  1.0
    x_52        PACK_10  1.0
    x_53        OBJ       -34
    x_53        PACK_35  1.0
    x_53        PACK_36  1.0
    x_53        PACK_37  1.0
    x_53        PACK_38  1.0
    x_53        PACK_39  1.0
    x_54        OBJ       -6
    x_54        PACK_16  1.0
    x_54        PACK_17  1.0
    x_54        PACK_18  1.0
    x_55        OBJ       -94
    x_55        PACK_13  1.0
    x_55        PACK_14  1.0
    x_55        PACK_15  1.0
    x_55        PACK_16  1.0
    x_55        PACK_17  1.0
    x_56        OBJ       -59
    x_56        PACK_19  1.0
    x_56        PACK_20  1.0
    x_56        PACK_21  1.0
    x_57        OBJ       -69
    x_57        PACK_23  1.0
    x_57        PACK_24  1.0
    x_57        PACK_25  1.0
    x_57        PACK_26  1.0
    x_57        PACK_27  1.0
    x_58        OBJ       -16
    x_58        PACK_33  1.0
    x_58        PACK_34  1.0
    x_58        PACK_35  1.0
    x_58        PACK_36  1.0
    x_58        PACK_37  1.0
    x_59        OBJ       -49
    x_59        PACK_7  1.0
    x_59        PACK_8  1.0
    x_59        PACK_9  1.0
    x_59        PACK_10  1.0
    x_59        PACK_11  1.0
    x_60        OBJ       -11
    x_60        PACK_14  1.0
    x_60        PACK_15  1.0
    x_60        PACK_16  1.0
    x_61        OBJ       -71
    x_61        PACK_21  1.0
    x_61        PACK_22  1.0
    x_62        OBJ       -38
    x_62        PACK_37  1.0
    x_62        PACK_38  1.0
    x_63        OBJ       -81
    x_63        PACK_37  1.0
    x_63        PACK_38  1.0
    x_63        PACK_39  1.0
    x_64        OBJ       -80
    x_64        PACK_0  1.0
    x_64        PACK_1  1.0
    x_64        PACK_2  1.0
    x_65        OBJ       -47
    x_65        PACK_3  1.0
    x_65        PACK_4  1.0
    x_66        OBJ       -74
    x_66        PACK_4  1.0
    x_66        PACK_5  1.0
    x_66        PACK_6  1.0
    x_67        OBJ       -25
    x_67        PACK_21  1.0
    x_67        PACK_22  1.0
    x_68        OBJ       -91
    x_68        PACK_32  1.0
    x_68        PACK_33  1.0
    x_69        OBJ       -9
    x_69        PACK_17  1.0
    x_69        PACK_18  1.0
    x_69        PACK_19  1.0
RHS
    RHS1      PACK_0  1.0
    RHS1      PACK_1  1.0
    RHS1      PACK_2  1.0
    RHS1      PACK_3  1.0
    RHS1      PACK_4  1.0
    RHS1      PACK_5  1.0
    RHS1      PACK_6  1.0
    RHS1      PACK_7  1.0
    RHS1      PACK_8  1.0
    RHS1      PACK_9  1.0
    RHS1      PACK_10  1.0
    RHS1      PACK_11  1.0
    RHS1      PACK_12  1.0
    RHS1      PACK_13  1.0
    RHS1      PACK_14  1.0
    RHS1      PACK_15  1.0
    RHS1      PACK_16  1.0
    RHS1      PACK_17  1.0
    RHS1      PACK_18  1.0
    RHS1      PACK_19  1.0
    RHS1      PACK_20  1.0
    RHS1      PACK_21  1.0
    RHS1      PACK_22  1.0
    RHS1      PACK_23  1.0
    RHS1      PACK_24  1.0
    RHS1      PACK_25  1.0
    RHS1      PACK_26  1.0
    RHS1      PACK_27  1.0
    RHS1      PACK_28  1.0
    RHS1      PACK_29  1.0
    RHS1      PACK_30  1.0
    RHS1      PACK_31  1.0
    RHS1      PACK_32  1.0
    RHS1      PACK_33  1.0
    RHS1      PACK_34  1.0
    RHS1      PACK_35  1.0
    RHS1      PACK_36  1.0
    RHS1      PACK_37  1.0
    RHS1      PACK_38  1.0
    RHS1      PACK_39  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
 BV BND1      x_30
 BV BND1      x_31
 BV BND1      x_32
 BV BND1      x_33
 BV BND1      x_34
 BV BND1      x_35
 BV BND1      x_36
 BV BND1      x_37
 BV BND1      x_38
 BV BND1      x_39
 BV BND1      x_40
 BV BND1      x_41
 BV BND1      x_42
 BV BND1      x_43
 BV BND1      x_44
 BV BND1      x_45
 BV BND1      x_46
 BV BND1      x_47
 BV BND1      x_48
 BV BND1      x_49
 BV BND1      x_50
 BV BND1      x_51
 BV BND1      x_52
 BV BND1      x_53
 BV BND1      x_54
 BV BND1      x_55
 BV BND1      x_56
 BV BND1      x_57
 BV BND1      x_58
 BV BND1      x_59
 BV BND1      x_60
 BV BND1      x_61
 BV BND1      x_62
 BV BND1      x_63
 BV BND1      x_64
 BV BND1      x_65
 BV BND1      x_66
 BV BND1      x_67
 BV BND1      x_68
 BV BND1      x_69
ENDATA
