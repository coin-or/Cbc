NAME          steiner_grid4x4_t3_corners
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 L  cap_0_1
 L  cap_0_4
 L  cap_1_2
 L  cap_1_5
 L  cap_2_3
 L  cap_2_6
 L  cap_3_7
 L  cap_4_5
 L  cap_4_8
 L  cap_5_6
 L  cap_5_9
 L  cap_6_7
 L  cap_6_10
 L  cap_7_11
 L  cap_8_9
 L  cap_8_12
 L  cap_9_10
 L  cap_9_13
 L  cap_10_11
 L  cap_10_14
 L  cap_11_15
 L  cap_12_13
 L  cap_13_14
 L  cap_14_15
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x_0_1     OBJ       1.0
    x_0_1     cap_0_1   -3
    x_0_4     OBJ       1.0
    x_0_4     cap_0_4   -3
    x_1_2     OBJ       1.0
    x_1_2     cap_1_2   -3
    x_1_5     OBJ       1.0
    x_1_5     cap_1_5   -3
    x_2_3     OBJ       1.0
    x_2_3     cap_2_3   -3
    x_2_6     OBJ       1.0
    x_2_6     cap_2_6   -3
    x_3_7     OBJ       1.0
    x_3_7     cap_3_7   -3
    x_4_5     OBJ       1.0
    x_4_5     cap_4_5   -3
    x_4_8     OBJ       1.0
    x_4_8     cap_4_8   -3
    x_5_6     OBJ       1.0
    x_5_6     cap_5_6   -3
    x_5_9     OBJ       1.0
    x_5_9     cap_5_9   -3
    x_6_7     OBJ       1.0
    x_6_7     cap_6_7   -3
    x_6_10    OBJ       1.0
    x_6_10    cap_6_10  -3
    x_7_11    OBJ       1.0
    x_7_11    cap_7_11  -3
    x_8_9     OBJ       1.0
    x_8_9     cap_8_9   -3
    x_8_12    OBJ       1.0
    x_8_12    cap_8_12  -3
    x_9_10    OBJ       1.0
    x_9_10    cap_9_10  -3
    x_9_13    OBJ       1.0
    x_9_13    cap_9_13  -3
    x_10_11   OBJ       1.0
    x_10_11   cap_10_11  -3
    x_10_14   OBJ       1.0
    x_10_14   cap_10_14  -3
    x_11_15   OBJ       1.0
    x_11_15   cap_11_15  -3
    x_12_13   OBJ       1.0
    x_12_13   cap_12_13  -3
    x_13_14   OBJ       1.0
    x_13_14   cap_13_14  -3
    x_14_15   OBJ       1.0
    x_14_15   cap_14_15  -3
    MARK0001  'MARKER'                 'INTEND'
    f_0_1     flow_0    1.0
    f_0_1     flow_1    -1.0
    f_0_1     cap_0_1   1.0
    f_1_0     flow_0    -1.0
    f_1_0     flow_1    1.0
    f_1_0     cap_0_1   1.0
    f_0_4     flow_0    1.0
    f_0_4     flow_4    -1.0
    f_0_4     cap_0_4   1.0
    f_4_0     flow_0    -1.0
    f_4_0     flow_4    1.0
    f_4_0     cap_0_4   1.0
    f_1_2     flow_1    1.0
    f_1_2     flow_2    -1.0
    f_1_2     cap_1_2   1.0
    f_2_1     flow_1    -1.0
    f_2_1     flow_2    1.0
    f_2_1     cap_1_2   1.0
    f_1_5     flow_1    1.0
    f_1_5     flow_5    -1.0
    f_1_5     cap_1_5   1.0
    f_5_1     flow_1    -1.0
    f_5_1     flow_5    1.0
    f_5_1     cap_1_5   1.0
    f_2_3     flow_2    1.0
    f_2_3     flow_3    -1.0
    f_2_3     cap_2_3   1.0
    f_3_2     flow_2    -1.0
    f_3_2     flow_3    1.0
    f_3_2     cap_2_3   1.0
    f_2_6     flow_2    1.0
    f_2_6     flow_6    -1.0
    f_2_6     cap_2_6   1.0
    f_6_2     flow_2    -1.0
    f_6_2     flow_6    1.0
    f_6_2     cap_2_6   1.0
    f_3_7     flow_3    1.0
    f_3_7     flow_7    -1.0
    f_3_7     cap_3_7   1.0
    f_7_3     flow_3    -1.0
    f_7_3     flow_7    1.0
    f_7_3     cap_3_7   1.0
    f_4_5     flow_4    1.0
    f_4_5     flow_5    -1.0
    f_4_5     cap_4_5   1.0
    f_5_4     flow_4    -1.0
    f_5_4     flow_5    1.0
    f_5_4     cap_4_5   1.0
    f_4_8     flow_4    1.0
    f_4_8     flow_8    -1.0
    f_4_8     cap_4_8   1.0
    f_8_4     flow_4    -1.0
    f_8_4     flow_8    1.0
    f_8_4     cap_4_8   1.0
    f_5_6     flow_5    1.0
    f_5_6     flow_6    -1.0
    f_5_6     cap_5_6   1.0
    f_6_5     flow_5    -1.0
    f_6_5     flow_6    1.0
    f_6_5     cap_5_6   1.0
    f_5_9     flow_5    1.0
    f_5_9     flow_9    -1.0
    f_5_9     cap_5_9   1.0
    f_9_5     flow_5    -1.0
    f_9_5     flow_9    1.0
    f_9_5     cap_5_9   1.0
    f_6_7     flow_6    1.0
    f_6_7     flow_7    -1.0
    f_6_7     cap_6_7   1.0
    f_7_6     flow_6    -1.0
    f_7_6     flow_7    1.0
    f_7_6     cap_6_7   1.0
    f_6_10    flow_6    1.0
    f_6_10    flow_10   -1.0
    f_6_10    cap_6_10  1.0
    f_10_6    flow_6    -1.0
    f_10_6    flow_10   1.0
    f_10_6    cap_6_10  1.0
    f_7_11    flow_7    1.0
    f_7_11    flow_11   -1.0
    f_7_11    cap_7_11  1.0
    f_11_7    flow_7    -1.0
    f_11_7    flow_11   1.0
    f_11_7    cap_7_11  1.0
    f_8_9     flow_8    1.0
    f_8_9     flow_9    -1.0
    f_8_9     cap_8_9   1.0
    f_9_8     flow_8    -1.0
    f_9_8     flow_9    1.0
    f_9_8     cap_8_9   1.0
    f_8_12    flow_8    1.0
    f_8_12    flow_12   -1.0
    f_8_12    cap_8_12  1.0
    f_12_8    flow_8    -1.0
    f_12_8    flow_12   1.0
    f_12_8    cap_8_12  1.0
    f_9_10    flow_9    1.0
    f_9_10    flow_10   -1.0
    f_9_10    cap_9_10  1.0
    f_10_9    flow_9    -1.0
    f_10_9    flow_10   1.0
    f_10_9    cap_9_10  1.0
    f_9_13    flow_9    1.0
    f_9_13    flow_13   -1.0
    f_9_13    cap_9_13  1.0
    f_13_9    flow_9    -1.0
    f_13_9    flow_13   1.0
    f_13_9    cap_9_13  1.0
    f_10_11   flow_10   1.0
    f_10_11   flow_11   -1.0
    f_10_11   cap_10_11  1.0
    f_11_10   flow_10   -1.0
    f_11_10   flow_11   1.0
    f_11_10   cap_10_11  1.0
    f_10_14   flow_10   1.0
    f_10_14   flow_14   -1.0
    f_10_14   cap_10_14  1.0
    f_14_10   flow_10   -1.0
    f_14_10   flow_14   1.0
    f_14_10   cap_10_14  1.0
    f_11_15   flow_11   1.0
    f_11_15   flow_15   -1.0
    f_11_15   cap_11_15  1.0
    f_15_11   flow_11   -1.0
    f_15_11   flow_15   1.0
    f_15_11   cap_11_15  1.0
    f_12_13   flow_12   1.0
    f_12_13   flow_13   -1.0
    f_12_13   cap_12_13  1.0
    f_13_12   flow_12   -1.0
    f_13_12   flow_13   1.0
    f_13_12   cap_12_13  1.0
    f_13_14   flow_13   1.0
    f_13_14   flow_14   -1.0
    f_13_14   cap_13_14  1.0
    f_14_13   flow_13   -1.0
    f_14_13   flow_14   1.0
    f_14_13   cap_13_14  1.0
    f_14_15   flow_14   1.0
    f_14_15   flow_15   -1.0
    f_14_15   cap_14_15  1.0
    f_15_14   flow_14   -1.0
    f_15_14   flow_15   1.0
    f_15_14   cap_14_15  1.0
RHS
    RHS       flow_0    3
    RHS       flow_1    -1
    RHS       flow_2    -1
    RHS       flow_11   -1
BOUNDS
 BV BOUND     x_0_1
 BV BOUND     x_0_4
 BV BOUND     x_1_2
 BV BOUND     x_1_5
 BV BOUND     x_2_3
 BV BOUND     x_2_6
 BV BOUND     x_3_7
 BV BOUND     x_4_5
 BV BOUND     x_4_8
 BV BOUND     x_5_6
 BV BOUND     x_5_9
 BV BOUND     x_6_7
 BV BOUND     x_6_10
 BV BOUND     x_7_11
 BV BOUND     x_8_9
 BV BOUND     x_8_12
 BV BOUND     x_9_10
 BV BOUND     x_9_13
 BV BOUND     x_10_11
 BV BOUND     x_10_14
 BV BOUND     x_11_15
 BV BOUND     x_12_13
 BV BOUND     x_13_14
 BV BOUND     x_14_15
 UP BOUND     f_0_1     3
 UP BOUND     f_1_0     3
 UP BOUND     f_0_4     3
 UP BOUND     f_4_0     3
 UP BOUND     f_1_2     3
 UP BOUND     f_2_1     3
 UP BOUND     f_1_5     3
 UP BOUND     f_5_1     3
 UP BOUND     f_2_3     3
 UP BOUND     f_3_2     3
 UP BOUND     f_2_6     3
 UP BOUND     f_6_2     3
 UP BOUND     f_3_7     3
 UP BOUND     f_7_3     3
 UP BOUND     f_4_5     3
 UP BOUND     f_5_4     3
 UP BOUND     f_4_8     3
 UP BOUND     f_8_4     3
 UP BOUND     f_5_6     3
 UP BOUND     f_6_5     3
 UP BOUND     f_5_9     3
 UP BOUND     f_9_5     3
 UP BOUND     f_6_7     3
 UP BOUND     f_7_6     3
 UP BOUND     f_6_10    3
 UP BOUND     f_10_6    3
 UP BOUND     f_7_11    3
 UP BOUND     f_11_7    3
 UP BOUND     f_8_9     3
 UP BOUND     f_9_8     3
 UP BOUND     f_8_12    3
 UP BOUND     f_12_8    3
 UP BOUND     f_9_10    3
 UP BOUND     f_10_9    3
 UP BOUND     f_9_13    3
 UP BOUND     f_13_9    3
 UP BOUND     f_10_11   3
 UP BOUND     f_11_10   3
 UP BOUND     f_10_14   3
 UP BOUND     f_14_10   3
 UP BOUND     f_11_15   3
 UP BOUND     f_15_11   3
 UP BOUND     f_12_13   3
 UP BOUND     f_13_12   3
 UP BOUND     f_13_14   3
 UP BOUND     f_14_13   3
 UP BOUND     f_14_15   3
 UP BOUND     f_15_14   3
ENDATA
