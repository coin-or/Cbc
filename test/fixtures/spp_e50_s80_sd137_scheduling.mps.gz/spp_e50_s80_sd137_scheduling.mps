NAME          SETPACK
ROWS
 N  OBJ
 L  PACK_0
 L  PACK_1
 L  PACK_2
 L  PACK_3
 L  PACK_4
 L  PACK_5
 L  PACK_6
 L  PACK_7
 L  PACK_8
 L  PACK_9
 L  PACK_10
 L  PACK_11
 L  PACK_12
 L  PACK_13
 L  PACK_14
 L  PACK_15
 L  PACK_16
 L  PACK_17
 L  PACK_18
 L  PACK_19
 L  PACK_20
 L  PACK_21
 L  PACK_22
 L  PACK_23
 L  PACK_24
 L  PACK_25
 L  PACK_26
 L  PACK_27
 L  PACK_28
 L  PACK_29
 L  PACK_30
 L  PACK_31
 L  PACK_32
 L  PACK_33
 L  PACK_34
 L  PACK_35
 L  PACK_36
 L  PACK_37
 L  PACK_38
 L  PACK_39
 L  PACK_40
 L  PACK_41
 L  PACK_42
 L  PACK_43
 L  PACK_44
 L  PACK_45
 L  PACK_46
 L  PACK_47
 L  PACK_48
 L  PACK_49
COLUMNS
    x_0         OBJ       -10
    x_0         PACK_17  1.0
    x_0         PACK_18  1.0
    x_0         PACK_19  1.0
    x_0         PACK_20  1.0
    x_1         OBJ       -24
    x_1         PACK_9  1.0
    x_1         PACK_10  1.0
    x_1         PACK_11  1.0
    x_1         PACK_12  1.0
    x_1         PACK_13  1.0
    x_2         OBJ       -53
    x_2         PACK_45  1.0
    x_2         PACK_46  1.0
    x_2         PACK_47  1.0
    x_2         PACK_48  1.0
    x_2         PACK_49  1.0
    x_3         OBJ       -42
    x_3         PACK_44  1.0
    x_3         PACK_45  1.0
    x_3         PACK_46  1.0
    x_3         PACK_47  1.0
    x_3         PACK_48  1.0
    x_4         OBJ       -25
    x_4         PACK_9  1.0
    x_4         PACK_10  1.0
    x_5         OBJ       -30
    x_5         PACK_6  1.0
    x_5         PACK_7  1.0
    x_5         PACK_8  1.0
    x_5         PACK_9  1.0
    x_5         PACK_10  1.0
    x_6         OBJ       -63
    x_6         PACK_8  1.0
    x_6         PACK_9  1.0
    x_7         OBJ       -45
    x_7         PACK_22  1.0
    x_7         PACK_23  1.0
    x_8         OBJ       -2
    x_8         PACK_37  1.0
    x_8         PACK_38  1.0
    x_8         PACK_39  1.0
    x_9         OBJ       -52
    x_9         PACK_39  1.0
    x_9         PACK_40  1.0
    x_10        OBJ       -66
    x_10        PACK_45  1.0
    x_10        PACK_46  1.0
    x_10        PACK_47  1.0
    x_10        PACK_48  1.0
    x_11        OBJ       -42
    x_11        PACK_28  1.0
    x_11        PACK_29  1.0
    x_11        PACK_30  1.0
    x_11        PACK_31  1.0
    x_11        PACK_32  1.0
    x_12        OBJ       -51
    x_12        PACK_10  1.0
    x_12        PACK_11  1.0
    x_12        PACK_12  1.0
    x_13        OBJ       -68
    x_13        PACK_12  1.0
    x_13        PACK_13  1.0
    x_14        OBJ       -61
    x_14        PACK_10  1.0
    x_14        PACK_11  1.0
    x_14        PACK_12  1.0
    x_14        PACK_13  1.0
    x_14        PACK_14  1.0
    x_15        OBJ       -18
    x_15        PACK_7  1.0
    x_15        PACK_8  1.0
    x_15        PACK_9  1.0
    x_15        PACK_10  1.0
    x_15        PACK_11  1.0
    x_16        OBJ       -55
    x_16        PACK_24  1.0
    x_16        PACK_25  1.0
    x_17        OBJ       -67
    x_17        PACK_38  1.0
    x_17        PACK_39  1.0
    x_17        PACK_40  1.0
    x_17        PACK_41  1.0
    x_18        OBJ       -67
    x_18        PACK_38  1.0
    x_18        PACK_39  1.0
    x_18        PACK_40  1.0
    x_18        PACK_41  1.0
    x_18        PACK_42  1.0
    x_19        OBJ       -43
    x_19        PACK_2  1.0
    x_19        PACK_3  1.0
    x_19        PACK_4  1.0
    x_19        PACK_5  1.0
    x_20        OBJ       -1
    x_20        PACK_23  1.0
    x_20        PACK_24  1.0
    x_21        OBJ       -79
    x_21        PACK_30  1.0
    x_21        PACK_31  1.0
    x_22        OBJ       -4
    x_22        PACK_21  1.0
    x_22        PACK_22  1.0
    x_22        PACK_23  1.0
    x_22        PACK_24  1.0
    x_23        OBJ       -86
    x_23        PACK_25  1.0
    x_23        PACK_26  1.0
    x_23        PACK_27  1.0
    x_23        PACK_28  1.0
    x_24        OBJ       -89
    x_24        PACK_30  1.0
    x_24        PACK_31  1.0
    x_25        OBJ       -19
    x_25        PACK_0  1.0
    x_25        PACK_1  1.0
    x_25        PACK_2  1.0
    x_25        PACK_3  1.0
    x_26        OBJ       -62
    x_26        PACK_3  1.0
    x_26        PACK_4  1.0
    x_26        PACK_5  1.0
    x_26        PACK_6  1.0
    x_26        PACK_7  1.0
    x_27        OBJ       -47
    x_27        PACK_24  1.0
    x_27        PACK_25  1.0
    x_27        PACK_26  1.0
    x_28        OBJ       -23
    x_28        PACK_2  1.0
    x_28        PACK_3  1.0
    x_28        PACK_4  1.0
    x_28        PACK_5  1.0
    x_28        PACK_6  1.0
    x_29        OBJ       -45
    x_29        PACK_1  1.0
    x_29        PACK_2  1.0
    x_29        PACK_3  1.0
    x_30        OBJ       -32
    x_30        PACK_12  1.0
    x_30        PACK_13  1.0
    x_30        PACK_14  1.0
    x_31        OBJ       -63
    x_31        PACK_19  1.0
    x_31        PACK_20  1.0
    x_31        PACK_21  1.0
    x_31        PACK_22  1.0
    x_32        OBJ       -50
    x_32        PACK_46  1.0
    x_32        PACK_47  1.0
    x_33        OBJ       -42
    x_33        PACK_41  1.0
    x_33        PACK_42  1.0
    x_33        PACK_43  1.0
    x_33        PACK_44  1.0
    x_33        PACK_45  1.0
    x_34        OBJ       -41
    x_34        PACK_34  1.0
    x_34        PACK_35  1.0
    x_34        PACK_36  1.0
    x_35        OBJ       -92
    x_35        PACK_19  1.0
    x_35        PACK_20  1.0
    x_35        PACK_21  1.0
    x_35        PACK_22  1.0
    x_35        PACK_23  1.0
    x_36        OBJ       -2
    x_36        PACK_8  1.0
    x_36        PACK_9  1.0
    x_36        PACK_10  1.0
    x_36        PACK_11  1.0
    x_37        OBJ       -90
    x_37        PACK_19  1.0
    x_37        PACK_20  1.0
    x_37        PACK_21  1.0
    x_38        OBJ       -52
    x_38        PACK_23  1.0
    x_38        PACK_24  1.0
    x_38        PACK_25  1.0
    x_38        PACK_26  1.0
    x_39        OBJ       -44
    x_39        PACK_20  1.0
    x_39        PACK_21  1.0
    x_39        PACK_22  1.0
    x_39        PACK_23  1.0
    x_40        OBJ       -9
    x_40        PACK_32  1.0
    x_40        PACK_33  1.0
    x_40        PACK_34  1.0
    x_40        PACK_35  1.0
    x_41        OBJ       -93
    x_41        PACK_18  1.0
    x_41        PACK_19  1.0
    x_41        PACK_20  1.0
    x_41        PACK_21  1.0
    x_42        OBJ       -46
    x_42        PACK_18  1.0
    x_42        PACK_19  1.0
    x_42        PACK_20  1.0
    x_42        PACK_21  1.0
    x_42        PACK_22  1.0
    x_43        OBJ       -90
    x_43        PACK_43  1.0
    x_43        PACK_44  1.0
    x_43        PACK_45  1.0
    x_43        PACK_46  1.0
    x_43        PACK_47  1.0
    x_44        OBJ       -66
    x_44        PACK_21  1.0
    x_44        PACK_22  1.0
    x_44        PACK_23  1.0
    x_44        PACK_24  1.0
    x_45        OBJ       -16
    x_45        PACK_23  1.0
    x_45        PACK_24  1.0
    x_46        OBJ       -26
    x_46        PACK_17  1.0
    x_46        PACK_18  1.0
    x_46        PACK_19  1.0
    x_46        PACK_20  1.0
    x_46        PACK_21  1.0
    x_47        OBJ       -6
    x_47        PACK_44  1.0
    x_47        PACK_45  1.0
    x_47        PACK_46  1.0
    x_47        PACK_47  1.0
    x_48        OBJ       -77
    x_48        PACK_16  1.0
    x_48        PACK_17  1.0
    x_48        PACK_18  1.0
    x_48        PACK_19  1.0
    x_48        PACK_20  1.0
    x_49        OBJ       -42
    x_49        PACK_36  1.0
    x_49        PACK_37  1.0
    x_49        PACK_38  1.0
    x_49        PACK_39  1.0
    x_49        PACK_40  1.0
    x_50        OBJ       -70
    x_50        PACK_40  1.0
    x_50        PACK_41  1.0
    x_50        PACK_42  1.0
    x_51        OBJ       -73
    x_51        PACK_16  1.0
    x_51        PACK_17  1.0
    x_52        OBJ       -71
    x_52        PACK_19  1.0
    x_52        PACK_20  1.0
    x_53        OBJ       -76
    x_53        PACK_2  1.0
    x_53        PACK_3  1.0
    x_53        PACK_4  1.0
    x_53        PACK_5  1.0
    x_54        OBJ       -91
    x_54        PACK_14  1.0
    x_54        PACK_15  1.0
    x_55        OBJ       -44
    x_55        PACK_28  1.0
    x_55        PACK_29  1.0
    x_55        PACK_30  1.0
    x_56        OBJ       -5
    x_56        PACK_38  1.0
    x_56        PACK_39  1.0
    x_56        PACK_40  1.0
    x_56        PACK_41  1.0
    x_56        PACK_42  1.0
    x_57        OBJ       -31
    x_57        PACK_34  1.0
    x_57        PACK_35  1.0
    x_58        OBJ       -73
    x_58        PACK_6  1.0
    x_58        PACK_7  1.0
    x_58        PACK_8  1.0
    x_58        PACK_9  1.0
    x_59        OBJ       -13
    x_59        PACK_15  1.0
    x_59        PACK_16  1.0
    x_60        OBJ       -50
    x_60        PACK_16  1.0
    x_60        PACK_17  1.0
    x_61        OBJ       -67
    x_61        PACK_33  1.0
    x_61        PACK_34  1.0
    x_62        OBJ       -85
    x_62        PACK_43  1.0
    x_62        PACK_44  1.0
    x_62        PACK_45  1.0
    x_62        PACK_46  1.0
    x_63        OBJ       -94
    x_63        PACK_16  1.0
    x_63        PACK_17  1.0
    x_63        PACK_18  1.0
    x_64        OBJ       -1
    x_64        PACK_24  1.0
    x_64        PACK_25  1.0
    x_64        PACK_26  1.0
    x_64        PACK_27  1.0
    x_65        OBJ       -89
    x_65        PACK_14  1.0
    x_65        PACK_15  1.0
    x_65        PACK_16  1.0
    x_66        OBJ       -93
    x_66        PACK_11  1.0
    x_66        PACK_12  1.0
    x_66        PACK_13  1.0
    x_66        PACK_14  1.0
    x_66        PACK_15  1.0
    x_67        OBJ       -28
    x_67        PACK_28  1.0
    x_67        PACK_29  1.0
    x_67        PACK_30  1.0
    x_67        PACK_31  1.0
    x_68        OBJ       -43
    x_68        PACK_11  1.0
    x_68        PACK_12  1.0
    x_68        PACK_13  1.0
    x_68        PACK_14  1.0
    x_68        PACK_15  1.0
    x_69        OBJ       -32
    x_69        PACK_14  1.0
    x_69        PACK_15  1.0
    x_69        PACK_16  1.0
    x_69        PACK_17  1.0
    x_70        OBJ       -30
    x_70        PACK_0  1.0
    x_70        PACK_1  1.0
    x_70        PACK_2  1.0
    x_70        PACK_3  1.0
    x_70        PACK_4  1.0
    x_71        OBJ       -70
    x_71        PACK_28  1.0
    x_71        PACK_29  1.0
    x_71        PACK_30  1.0
    x_71        PACK_31  1.0
    x_71        PACK_32  1.0
    x_72        OBJ       -58
    x_72        PACK_11  1.0
    x_72        PACK_12  1.0
    x_73        OBJ       -18
    x_73        PACK_7  1.0
    x_73        PACK_8  1.0
    x_73        PACK_9  1.0
    x_74        OBJ       -80
    x_74        PACK_34  1.0
    x_74        PACK_35  1.0
    x_74        PACK_36  1.0
    x_75        OBJ       -96
    x_75        PACK_19  1.0
    x_75        PACK_20  1.0
    x_75        PACK_21  1.0
    x_75        PACK_22  1.0
    x_75        PACK_23  1.0
    x_76        OBJ       -56
    x_76        PACK_48  1.0
    x_76        PACK_49  1.0
    x_77        OBJ       -30
    x_77        PACK_4  1.0
    x_77        PACK_5  1.0
    x_77        PACK_6  1.0
    x_77        PACK_7  1.0
    x_77        PACK_8  1.0
    x_78        OBJ       -62
    x_78        PACK_29  1.0
    x_78        PACK_30  1.0
    x_78        PACK_31  1.0
    x_78        PACK_32  1.0
    x_78        PACK_33  1.0
    x_79        OBJ       -100
    x_79        PACK_8  1.0
    x_79        PACK_9  1.0
RHS
    RHS1      PACK_0  1.0
    RHS1      PACK_1  1.0
    RHS1      PACK_2  1.0
    RHS1      PACK_3  1.0
    RHS1      PACK_4  1.0
    RHS1      PACK_5  1.0
    RHS1      PACK_6  1.0
    RHS1      PACK_7  1.0
    RHS1      PACK_8  1.0
    RHS1      PACK_9  1.0
    RHS1      PACK_10  1.0
    RHS1      PACK_11  1.0
    RHS1      PACK_12  1.0
    RHS1      PACK_13  1.0
    RHS1      PACK_14  1.0
    RHS1      PACK_15  1.0
    RHS1      PACK_16  1.0
    RHS1      PACK_17  1.0
    RHS1      PACK_18  1.0
    RHS1      PACK_19  1.0
    RHS1      PACK_20  1.0
    RHS1      PACK_21  1.0
    RHS1      PACK_22  1.0
    RHS1      PACK_23  1.0
    RHS1      PACK_24  1.0
    RHS1      PACK_25  1.0
    RHS1      PACK_26  1.0
    RHS1      PACK_27  1.0
    RHS1      PACK_28  1.0
    RHS1      PACK_29  1.0
    RHS1      PACK_30  1.0
    RHS1      PACK_31  1.0
    RHS1      PACK_32  1.0
    RHS1      PACK_33  1.0
    RHS1      PACK_34  1.0
    RHS1      PACK_35  1.0
    RHS1      PACK_36  1.0
    RHS1      PACK_37  1.0
    RHS1      PACK_38  1.0
    RHS1      PACK_39  1.0
    RHS1      PACK_40  1.0
    RHS1      PACK_41  1.0
    RHS1      PACK_42  1.0
    RHS1      PACK_43  1.0
    RHS1      PACK_44  1.0
    RHS1      PACK_45  1.0
    RHS1      PACK_46  1.0
    RHS1      PACK_47  1.0
    RHS1      PACK_48  1.0
    RHS1      PACK_49  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
 BV BND1      x_30
 BV BND1      x_31
 BV BND1      x_32
 BV BND1      x_33
 BV BND1      x_34
 BV BND1      x_35
 BV BND1      x_36
 BV BND1      x_37
 BV BND1      x_38
 BV BND1      x_39
 BV BND1      x_40
 BV BND1      x_41
 BV BND1      x_42
 BV BND1      x_43
 BV BND1      x_44
 BV BND1      x_45
 BV BND1      x_46
 BV BND1      x_47
 BV BND1      x_48
 BV BND1      x_49
 BV BND1      x_50
 BV BND1      x_51
 BV BND1      x_52
 BV BND1      x_53
 BV BND1      x_54
 BV BND1      x_55
 BV BND1      x_56
 BV BND1      x_57
 BV BND1      x_58
 BV BND1      x_59
 BV BND1      x_60
 BV BND1      x_61
 BV BND1      x_62
 BV BND1      x_63
 BV BND1      x_64
 BV BND1      x_65
 BV BND1      x_66
 BV BND1      x_67
 BV BND1      x_68
 BV BND1      x_69
 BV BND1      x_70
 BV BND1      x_71
 BV BND1      x_72
 BV BND1      x_73
 BV BND1      x_74
 BV BND1      x_75
 BV BND1      x_76
 BV BND1      x_77
 BV BND1      x_78
 BV BND1      x_79
ENDATA
