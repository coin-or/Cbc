NAME          MIS
ROWS
 N  OBJ
 L  EDGE_3_7
 L  EDGE_4_6
 L  EDGE_3_10
 L  EDGE_5_13
 L  EDGE_0_2
 L  EDGE_9_14
 L  EDGE_0_8
 L  EDGE_0_14
 L  EDGE_0_11
 L  EDGE_13_14
 L  EDGE_7_10
 L  EDGE_6_8
 L  EDGE_3_9
 L  EDGE_3_6
 L  EDGE_3_12
 L  EDGE_4_11
 L  EDGE_5_12
 L  EDGE_9_10
 L  EDGE_8_14
 L  EDGE_0_4
 L  EDGE_0_10
 L  EDGE_1_11
 L  EDGE_0_13
 L  EDGE_11_13
 L  EDGE_1_14
 L  EDGE_7_9
 L  EDGE_6_7
 L  EDGE_7_12
 L  EDGE_4_7
 L  EDGE_3_11
 L  EDGE_3_8
 L  EDGE_4_13
 L  EDGE_0_3
 L  EDGE_8_10
 L  EDGE_1_4
 L  EDGE_2_3
 L  EDGE_8_13
 L  EDGE_1_7
COLUMNS
    x_0         OBJ       -82
    x_0         EDGE_0_2  1.0
    x_0         EDGE_0_8  1.0
    x_0         EDGE_0_14  1.0
    x_0         EDGE_0_11  1.0
    x_0         EDGE_0_4  1.0
    x_0         EDGE_0_10  1.0
    x_0         EDGE_0_13  1.0
    x_0         EDGE_0_3  1.0
    x_1         OBJ       -15
    x_1         EDGE_1_11  1.0
    x_1         EDGE_1_14  1.0
    x_1         EDGE_1_4  1.0
    x_1         EDGE_1_7  1.0
    x_2         OBJ       -4
    x_2         EDGE_0_2  1.0
    x_2         EDGE_2_3  1.0
    x_3         OBJ       -95
    x_3         EDGE_3_7  1.0
    x_3         EDGE_3_10  1.0
    x_3         EDGE_3_9  1.0
    x_3         EDGE_3_6  1.0
    x_3         EDGE_3_12  1.0
    x_3         EDGE_3_11  1.0
    x_3         EDGE_3_8  1.0
    x_3         EDGE_0_3  1.0
    x_3         EDGE_2_3  1.0
    x_4         OBJ       -36
    x_4         EDGE_4_6  1.0
    x_4         EDGE_4_11  1.0
    x_4         EDGE_0_4  1.0
    x_4         EDGE_4_7  1.0
    x_4         EDGE_4_13  1.0
    x_4         EDGE_1_4  1.0
    x_5         OBJ       -32
    x_5         EDGE_5_13  1.0
    x_5         EDGE_5_12  1.0
    x_6         OBJ       -29
    x_6         EDGE_4_6  1.0
    x_6         EDGE_6_8  1.0
    x_6         EDGE_3_6  1.0
    x_6         EDGE_6_7  1.0
    x_7         OBJ       -18
    x_7         EDGE_3_7  1.0
    x_7         EDGE_7_10  1.0
    x_7         EDGE_7_9  1.0
    x_7         EDGE_6_7  1.0
    x_7         EDGE_7_12  1.0
    x_7         EDGE_4_7  1.0
    x_7         EDGE_1_7  1.0
    x_8         OBJ       -95
    x_8         EDGE_0_8  1.0
    x_8         EDGE_6_8  1.0
    x_8         EDGE_8_14  1.0
    x_8         EDGE_3_8  1.0
    x_8         EDGE_8_10  1.0
    x_8         EDGE_8_13  1.0
    x_9         OBJ       -14
    x_9         EDGE_9_14  1.0
    x_9         EDGE_3_9  1.0
    x_9         EDGE_9_10  1.0
    x_9         EDGE_7_9  1.0
    x_10        OBJ       -87
    x_10        EDGE_3_10  1.0
    x_10        EDGE_7_10  1.0
    x_10        EDGE_9_10  1.0
    x_10        EDGE_0_10  1.0
    x_10        EDGE_8_10  1.0
    x_11        OBJ       -95
    x_11        EDGE_0_11  1.0
    x_11        EDGE_4_11  1.0
    x_11        EDGE_1_11  1.0
    x_11        EDGE_11_13  1.0
    x_11        EDGE_3_11  1.0
    x_12        OBJ       -70
    x_12        EDGE_3_12  1.0
    x_12        EDGE_5_12  1.0
    x_12        EDGE_7_12  1.0
    x_13        OBJ       -12
    x_13        EDGE_5_13  1.0
    x_13        EDGE_13_14  1.0
    x_13        EDGE_0_13  1.0
    x_13        EDGE_11_13  1.0
    x_13        EDGE_4_13  1.0
    x_13        EDGE_8_13  1.0
    x_14        OBJ       -76
    x_14        EDGE_9_14  1.0
    x_14        EDGE_0_14  1.0
    x_14        EDGE_13_14  1.0
    x_14        EDGE_8_14  1.0
    x_14        EDGE_1_14  1.0
RHS
    RHS1      EDGE_3_7  1.0
    RHS1      EDGE_4_6  1.0
    RHS1      EDGE_3_10  1.0
    RHS1      EDGE_5_13  1.0
    RHS1      EDGE_0_2  1.0
    RHS1      EDGE_9_14  1.0
    RHS1      EDGE_0_8  1.0
    RHS1      EDGE_0_14  1.0
    RHS1      EDGE_0_11  1.0
    RHS1      EDGE_13_14  1.0
    RHS1      EDGE_7_10  1.0
    RHS1      EDGE_6_8  1.0
    RHS1      EDGE_3_9  1.0
    RHS1      EDGE_3_6  1.0
    RHS1      EDGE_3_12  1.0
    RHS1      EDGE_4_11  1.0
    RHS1      EDGE_5_12  1.0
    RHS1      EDGE_9_10  1.0
    RHS1      EDGE_8_14  1.0
    RHS1      EDGE_0_4  1.0
    RHS1      EDGE_0_10  1.0
    RHS1      EDGE_1_11  1.0
    RHS1      EDGE_0_13  1.0
    RHS1      EDGE_11_13  1.0
    RHS1      EDGE_1_14  1.0
    RHS1      EDGE_7_9  1.0
    RHS1      EDGE_6_7  1.0
    RHS1      EDGE_7_12  1.0
    RHS1      EDGE_4_7  1.0
    RHS1      EDGE_3_11  1.0
    RHS1      EDGE_3_8  1.0
    RHS1      EDGE_4_13  1.0
    RHS1      EDGE_0_3  1.0
    RHS1      EDGE_8_10  1.0
    RHS1      EDGE_1_4  1.0
    RHS1      EDGE_2_3  1.0
    RHS1      EDGE_8_13  1.0
    RHS1      EDGE_1_7  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
ENDATA
