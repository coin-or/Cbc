NAME          SETCOVER
ROWS
 N  OBJ
 G  COVER_0
 G  COVER_1
 G  COVER_2
 G  COVER_3
 G  COVER_4
 G  COVER_5
 G  COVER_6
 G  COVER_7
 G  COVER_8
 G  COVER_9
COLUMNS
    x_0         OBJ       82
    x_0         COVER_1  1.0
    x_0         COVER_2  1.0
    x_0         COVER_4  1.0
    x_0         COVER_5  1.0
    x_0         COVER_8  1.0
    x_1         OBJ       15
    x_1         COVER_1  1.0
    x_1         COVER_5  1.0
    x_1         COVER_8  1.0
    x_1         COVER_9  1.0
    x_2         OBJ       4
    x_3         OBJ       95
    x_3         COVER_3  1.0
    x_3         COVER_4  1.0
    x_3         COVER_5  1.0
    x_3         COVER_6  1.0
    x_3         COVER_7  1.0
    x_3         COVER_8  1.0
    x_3         COVER_9  1.0
    x_4         OBJ       36
    x_4         COVER_3  1.0
    x_4         COVER_4  1.0
    x_4         COVER_8  1.0
    x_5         OBJ       32
    x_5         COVER_0  1.0
    x_5         COVER_8  1.0
    x_5         COVER_9  1.0
    x_6         OBJ       29
    x_6         COVER_1  1.0
    x_6         COVER_2  1.0
    x_7         OBJ       18
    x_7         COVER_0  1.0
    x_7         COVER_1  1.0
    x_7         COVER_3  1.0
    x_7         COVER_7  1.0
    x_8         OBJ       95
    x_8         COVER_0  1.0
    x_8         COVER_1  1.0
    x_8         COVER_2  1.0
    x_8         COVER_6  1.0
    x_9         OBJ       14
    x_9         COVER_2  1.0
    x_9         COVER_6  1.0
    x_9         COVER_8  1.0
    x_10        OBJ       87
    x_10        COVER_3  1.0
    x_10        COVER_5  1.0
    x_10        COVER_8  1.0
    x_11        OBJ       95
    x_11        COVER_1  1.0
    x_11        COVER_6  1.0
    x_11        COVER_8  1.0
    x_12        OBJ       70
    x_12        COVER_3  1.0
    x_12        COVER_6  1.0
    x_12        COVER_8  1.0
    x_13        OBJ       12
    x_13        COVER_1  1.0
    x_13        COVER_4  1.0
    x_13        COVER_7  1.0
    x_14        OBJ       76
    x_14        COVER_0  1.0
    x_14        COVER_6  1.0
    x_14        COVER_7  1.0
RHS
    RHS1      COVER_0  1.0
    RHS1      COVER_1  1.0
    RHS1      COVER_2  1.0
    RHS1      COVER_3  1.0
    RHS1      COVER_4  1.0
    RHS1      COVER_5  1.0
    RHS1      COVER_6  1.0
    RHS1      COVER_7  1.0
    RHS1      COVER_8  1.0
    RHS1      COVER_9  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
ENDATA
