NAME          fcnf_grid_5x5_fixedheavy
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 E  flow_20
 E  flow_21
 E  flow_22
 E  flow_23
 E  flow_24
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
 L  link_42
 L  link_43
 L  link_44
 L  link_45
 L  link_46
 L  link_47
 L  link_48
 L  link_49
 L  link_50
 L  link_51
 L  link_52
 L  link_53
 L  link_54
 L  link_55
 L  link_56
 L  link_57
 L  link_58
 L  link_59
 L  link_60
 L  link_61
 L  link_62
 L  link_63
 L  link_64
 L  link_65
 L  link_66
 L  link_67
 L  link_68
 L  link_69
 L  link_70
 L  link_71
 L  link_72
 L  link_73
 L  link_74
 L  link_75
 L  link_76
 L  link_77
 L  link_78
 L  link_79
COLUMNS
    x_0         OBJ       1.11
    x_0         flow_0      1.0
    x_0         flow_1      -1.0
    x_0         link_0      1.0
    x_1         OBJ       0.76
    x_1         flow_0      1.0
    x_1         flow_5      -1.0
    x_1         link_1      1.0
    x_2         OBJ       0.84
    x_2         flow_1      1.0
    x_2         flow_2      -1.0
    x_2         link_2      1.0
    x_3         OBJ       0.74
    x_3         flow_1      1.0
    x_3         flow_6      -1.0
    x_3         link_3      1.0
    x_4         OBJ       1.54
    x_4         flow_1      1.0
    x_4         flow_0      -1.0
    x_4         link_4      1.0
    x_5         OBJ       1.65
    x_5         flow_2      1.0
    x_5         flow_3      -1.0
    x_5         link_5      1.0
    x_6         OBJ       0.61
    x_6         flow_2      1.0
    x_6         flow_7      -1.0
    x_6         link_6      1.0
    x_7         OBJ       0.74
    x_7         flow_2      1.0
    x_7         flow_1      -1.0
    x_7         link_7      1.0
    x_8         OBJ       0.64
    x_8         flow_3      1.0
    x_8         flow_4      -1.0
    x_8         link_8      1.0
    x_9         OBJ       1.91
    x_9         flow_3      1.0
    x_9         flow_8      -1.0
    x_9         link_9      1.0
    x_10        OBJ       0.55
    x_10        flow_3      1.0
    x_10        flow_2      -1.0
    x_10        link_10     1.0
    x_11        OBJ       1.21
    x_11        flow_4      1.0
    x_11        flow_9      -1.0
    x_11        link_11     1.0
    x_12        OBJ       0.89
    x_12        flow_4      1.0
    x_12        flow_3      -1.0
    x_12        link_12     1.0
    x_13        OBJ       0.57
    x_13        flow_5      1.0
    x_13        flow_6      -1.0
    x_13        link_13     1.0
    x_14        OBJ       1.15
    x_14        flow_5      1.0
    x_14        flow_10     -1.0
    x_14        link_14     1.0
    x_15        OBJ       1.54
    x_15        flow_5      1.0
    x_15        flow_0      -1.0
    x_15        link_15     1.0
    x_16        OBJ       1.05
    x_16        flow_6      1.0
    x_16        flow_7      -1.0
    x_16        link_16     1.0
    x_17        OBJ       1.38
    x_17        flow_6      1.0
    x_17        flow_11     -1.0
    x_17        link_17     1.0
    x_18        OBJ       1.23
    x_18        flow_6      1.0
    x_18        flow_5      -1.0
    x_18        link_18     1.0
    x_19        OBJ       1.53
    x_19        flow_6      1.0
    x_19        flow_1      -1.0
    x_19        link_19     1.0
    x_20        OBJ       0.57
    x_20        flow_7      1.0
    x_20        flow_8      -1.0
    x_20        link_20     1.0
    x_21        OBJ       1.82
    x_21        flow_7      1.0
    x_21        flow_12     -1.0
    x_21        link_21     1.0
    x_22        OBJ       1.47
    x_22        flow_7      1.0
    x_22        flow_6      -1.0
    x_22        link_22     1.0
    x_23        OBJ       1.35
    x_23        flow_7      1.0
    x_23        flow_2      -1.0
    x_23        link_23     1.0
    x_24        OBJ       1.01
    x_24        flow_8      1.0
    x_24        flow_9      -1.0
    x_24        link_24     1.0
    x_25        OBJ       1.58
    x_25        flow_8      1.0
    x_25        flow_13     -1.0
    x_25        link_25     1.0
    x_26        OBJ       1.51
    x_26        flow_8      1.0
    x_26        flow_7      -1.0
    x_26        link_26     1.0
    x_27        OBJ       0.77
    x_27        flow_8      1.0
    x_27        flow_3      -1.0
    x_27        link_27     1.0
    x_28        OBJ       1.43
    x_28        flow_9      1.0
    x_28        flow_14     -1.0
    x_28        link_28     1.0
    x_29        OBJ       0.59
    x_29        flow_9      1.0
    x_29        flow_8      -1.0
    x_29        link_29     1.0
    x_30        OBJ       0.91
    x_30        flow_9      1.0
    x_30        flow_4      -1.0
    x_30        link_30     1.0
    x_31        OBJ       1.52
    x_31        flow_10     1.0
    x_31        flow_11     -1.0
    x_31        link_31     1.0
    x_32        OBJ       0.92
    x_32        flow_10     1.0
    x_32        flow_15     -1.0
    x_32        link_32     1.0
    x_33        OBJ       1.96
    x_33        flow_10     1.0
    x_33        flow_5      -1.0
    x_33        link_33     1.0
    x_34        OBJ       0.99
    x_34        flow_11     1.0
    x_34        flow_12     -1.0
    x_34        link_34     1.0
    x_35        OBJ       0.93
    x_35        flow_11     1.0
    x_35        flow_16     -1.0
    x_35        link_35     1.0
    x_36        OBJ       0.95
    x_36        flow_11     1.0
    x_36        flow_10     -1.0
    x_36        link_36     1.0
    x_37        OBJ       0.61
    x_37        flow_11     1.0
    x_37        flow_6      -1.0
    x_37        link_37     1.0
    x_38        OBJ       1.49
    x_38        flow_12     1.0
    x_38        flow_13     -1.0
    x_38        link_38     1.0
    x_39        OBJ       1.09
    x_39        flow_12     1.0
    x_39        flow_17     -1.0
    x_39        link_39     1.0
    x_40        OBJ       0.63
    x_40        flow_12     1.0
    x_40        flow_11     -1.0
    x_40        link_40     1.0
    x_41        OBJ       0.92
    x_41        flow_12     1.0
    x_41        flow_7      -1.0
    x_41        link_41     1.0
    x_42        OBJ       0.86
    x_42        flow_13     1.0
    x_42        flow_14     -1.0
    x_42        link_42     1.0
    x_43        OBJ       1.23
    x_43        flow_13     1.0
    x_43        flow_18     -1.0
    x_43        link_43     1.0
    x_44        OBJ       1.54
    x_44        flow_13     1.0
    x_44        flow_12     -1.0
    x_44        link_44     1.0
    x_45        OBJ       0.88
    x_45        flow_13     1.0
    x_45        flow_8      -1.0
    x_45        link_45     1.0
    x_46        OBJ       1.05
    x_46        flow_14     1.0
    x_46        flow_19     -1.0
    x_46        link_46     1.0
    x_47        OBJ       1.87
    x_47        flow_14     1.0
    x_47        flow_13     -1.0
    x_47        link_47     1.0
    x_48        OBJ       0.62
    x_48        flow_14     1.0
    x_48        flow_9      -1.0
    x_48        link_48     1.0
    x_49        OBJ       1.52
    x_49        flow_15     1.0
    x_49        flow_16     -1.0
    x_49        link_49     1.0
    x_50        OBJ       1.36
    x_50        flow_15     1.0
    x_50        flow_20     -1.0
    x_50        link_50     1.0
    x_51        OBJ       1.26
    x_51        flow_15     1.0
    x_51        flow_10     -1.0
    x_51        link_51     1.0
    x_52        OBJ       1.54
    x_52        flow_16     1.0
    x_52        flow_17     -1.0
    x_52        link_52     1.0
    x_53        OBJ       1.0
    x_53        flow_16     1.0
    x_53        flow_21     -1.0
    x_53        link_53     1.0
    x_54        OBJ       0.82
    x_54        flow_16     1.0
    x_54        flow_15     -1.0
    x_54        link_54     1.0
    x_55        OBJ       1.32
    x_55        flow_16     1.0
    x_55        flow_11     -1.0
    x_55        link_55     1.0
    x_56        OBJ       1.09
    x_56        flow_17     1.0
    x_56        flow_18     -1.0
    x_56        link_56     1.0
    x_57        OBJ       1.82
    x_57        flow_17     1.0
    x_57        flow_22     -1.0
    x_57        link_57     1.0
    x_58        OBJ       1.88
    x_58        flow_17     1.0
    x_58        flow_16     -1.0
    x_58        link_58     1.0
    x_59        OBJ       1.43
    x_59        flow_17     1.0
    x_59        flow_12     -1.0
    x_59        link_59     1.0
    x_60        OBJ       1.39
    x_60        flow_18     1.0
    x_60        flow_19     -1.0
    x_60        link_60     1.0
    x_61        OBJ       1.43
    x_61        flow_18     1.0
    x_61        flow_23     -1.0
    x_61        link_61     1.0
    x_62        OBJ       1.69
    x_62        flow_18     1.0
    x_62        flow_17     -1.0
    x_62        link_62     1.0
    x_63        OBJ       0.75
    x_63        flow_18     1.0
    x_63        flow_13     -1.0
    x_63        link_63     1.0
    x_64        OBJ       1.79
    x_64        flow_19     1.0
    x_64        flow_24     -1.0
    x_64        link_64     1.0
    x_65        OBJ       1.84
    x_65        flow_19     1.0
    x_65        flow_18     -1.0
    x_65        link_65     1.0
    x_66        OBJ       1.83
    x_66        flow_19     1.0
    x_66        flow_14     -1.0
    x_66        link_66     1.0
    x_67        OBJ       1.38
    x_67        flow_20     1.0
    x_67        flow_21     -1.0
    x_67        link_67     1.0
    x_68        OBJ       0.9
    x_68        flow_20     1.0
    x_68        flow_15     -1.0
    x_68        link_68     1.0
    x_69        OBJ       1.49
    x_69        flow_21     1.0
    x_69        flow_22     -1.0
    x_69        link_69     1.0
    x_70        OBJ       0.93
    x_70        flow_21     1.0
    x_70        flow_20     -1.0
    x_70        link_70     1.0
    x_71        OBJ       1.21
    x_71        flow_21     1.0
    x_71        flow_16     -1.0
    x_71        link_71     1.0
    x_72        OBJ       1.37
    x_72        flow_22     1.0
    x_72        flow_23     -1.0
    x_72        link_72     1.0
    x_73        OBJ       1.22
    x_73        flow_22     1.0
    x_73        flow_21     -1.0
    x_73        link_73     1.0
    x_74        OBJ       0.92
    x_74        flow_22     1.0
    x_74        flow_17     -1.0
    x_74        link_74     1.0
    x_75        OBJ       1.22
    x_75        flow_23     1.0
    x_75        flow_24     -1.0
    x_75        link_75     1.0
    x_76        OBJ       1.02
    x_76        flow_23     1.0
    x_76        flow_22     -1.0
    x_76        link_76     1.0
    x_77        OBJ       1.14
    x_77        flow_23     1.0
    x_77        flow_18     -1.0
    x_77        link_77     1.0
    x_78        OBJ       1.31
    x_78        flow_24     1.0
    x_78        flow_23     -1.0
    x_78        link_78     1.0
    x_79        OBJ       0.51
    x_79        flow_24     1.0
    x_79        flow_19     -1.0
    x_79        link_79     1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       41.68
    y_0         link_0      -3.0
    y_1         OBJ       29.01
    y_1         link_1      -3.0
    y_2         OBJ       42.75
    y_2         link_2      -3.0
    y_3         OBJ       40.55
    y_3         link_3      -5.0
    y_4         OBJ       35.14
    y_4         link_4      -6.0
    y_5         OBJ       46.8
    y_5         link_5      -5.0
    y_6         OBJ       53.66
    y_6         link_6      -7.0
    y_7         OBJ       40.44
    y_7         link_7      -7.0
    y_8         OBJ       58.36
    y_8         link_8      -3.0
    y_9         OBJ       52.87
    y_9         link_9      -5.0
    y_10        OBJ       35.44
    y_10        link_10     -6.0
    y_11        OBJ       27.62
    y_11        link_11     -4.0
    y_12        OBJ       29.92
    y_12        link_12     -3.0
    y_13        OBJ       58.42
    y_13        link_13     -8.0
    y_14        OBJ       21.51
    y_14        link_14     -8.0
    y_15        OBJ       53.78
    y_15        link_15     -5.0
    y_16        OBJ       38.84
    y_16        link_16     -6.0
    y_17        OBJ       41.62
    y_17        link_17     -4.0
    y_18        OBJ       59.74
    y_18        link_18     -8.0
    y_19        OBJ       33.84
    y_19        link_19     -8.0
    y_20        OBJ       26.29
    y_20        link_20     -4.0
    y_21        OBJ       43.2
    y_21        link_21     -7.0
    y_22        OBJ       41.73
    y_22        link_22     -5.0
    y_23        OBJ       36.18
    y_23        link_23     -5.0
    y_24        OBJ       53.52
    y_24        link_24     -7.0
    y_25        OBJ       59.96
    y_25        link_25     -3.0
    y_26        OBJ       38.96
    y_26        link_26     -4.0
    y_27        OBJ       45.7
    y_27        link_27     -3.0
    y_28        OBJ       31.75
    y_28        link_28     -8.0
    y_29        OBJ       22.98
    y_29        link_29     -6.0
    y_30        OBJ       47.53
    y_30        link_30     -8.0
    y_31        OBJ       54.32
    y_31        link_31     -3.0
    y_32        OBJ       58.44
    y_32        link_32     -5.0
    y_33        OBJ       59.86
    y_33        link_33     -7.0
    y_34        OBJ       51.91
    y_34        link_34     -3.0
    y_35        OBJ       32.0
    y_35        link_35     -6.0
    y_36        OBJ       55.31
    y_36        link_36     -6.0
    y_37        OBJ       30.09
    y_37        link_37     -4.0
    y_38        OBJ       22.97
    y_38        link_38     -6.0
    y_39        OBJ       33.81
    y_39        link_39     -6.0
    y_40        OBJ       56.09
    y_40        link_40     -4.0
    y_41        OBJ       41.34
    y_41        link_41     -5.0
    y_42        OBJ       48.05
    y_42        link_42     -7.0
    y_43        OBJ       40.18
    y_43        link_43     -6.0
    y_44        OBJ       59.57
    y_44        link_44     -6.0
    y_45        OBJ       29.27
    y_45        link_45     -7.0
    y_46        OBJ       24.51
    y_46        link_46     -5.0
    y_47        OBJ       25.82
    y_47        link_47     -3.0
    y_48        OBJ       56.48
    y_48        link_48     -8.0
    y_49        OBJ       52.11
    y_49        link_49     -6.0
    y_50        OBJ       45.29
    y_50        link_50     -8.0
    y_51        OBJ       28.79
    y_51        link_51     -4.0
    y_52        OBJ       49.43
    y_52        link_52     -3.0
    y_53        OBJ       20.55
    y_53        link_53     -8.0
    y_54        OBJ       25.17
    y_54        link_54     -4.0
    y_55        OBJ       23.09
    y_55        link_55     -3.0
    y_56        OBJ       40.06
    y_56        link_56     -8.0
    y_57        OBJ       36.11
    y_57        link_57     -5.0
    y_58        OBJ       45.28
    y_58        link_58     -8.0
    y_59        OBJ       22.66
    y_59        link_59     -7.0
    y_60        OBJ       32.75
    y_60        link_60     -8.0
    y_61        OBJ       31.55
    y_61        link_61     -3.0
    y_62        OBJ       24.69
    y_62        link_62     -3.0
    y_63        OBJ       26.94
    y_63        link_63     -3.0
    y_64        OBJ       57.01
    y_64        link_64     -4.0
    y_65        OBJ       47.92
    y_65        link_65     -5.0
    y_66        OBJ       53.05
    y_66        link_66     -4.0
    y_67        OBJ       58.52
    y_67        link_67     -5.0
    y_68        OBJ       36.18
    y_68        link_68     -4.0
    y_69        OBJ       26.88
    y_69        link_69     -4.0
    y_70        OBJ       56.55
    y_70        link_70     -6.0
    y_71        OBJ       51.56
    y_71        link_71     -8.0
    y_72        OBJ       37.8
    y_72        link_72     -6.0
    y_73        OBJ       24.49
    y_73        link_73     -8.0
    y_74        OBJ       27.73
    y_74        link_74     -4.0
    y_75        OBJ       45.66
    y_75        link_75     -4.0
    y_76        OBJ       34.55
    y_76        link_76     -6.0
    y_77        OBJ       21.32
    y_77        link_77     -5.0
    y_78        OBJ       48.08
    y_78        link_78     -3.0
    y_79        OBJ       52.1
    y_79        link_79     -5.0
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_0      2
    RHS       flow_24     -2
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
 BV BOUND     y_42
 BV BOUND     y_43
 BV BOUND     y_44
 BV BOUND     y_45
 BV BOUND     y_46
 BV BOUND     y_47
 BV BOUND     y_48
 BV BOUND     y_49
 BV BOUND     y_50
 BV BOUND     y_51
 BV BOUND     y_52
 BV BOUND     y_53
 BV BOUND     y_54
 BV BOUND     y_55
 BV BOUND     y_56
 BV BOUND     y_57
 BV BOUND     y_58
 BV BOUND     y_59
 BV BOUND     y_60
 BV BOUND     y_61
 BV BOUND     y_62
 BV BOUND     y_63
 BV BOUND     y_64
 BV BOUND     y_65
 BV BOUND     y_66
 BV BOUND     y_67
 BV BOUND     y_68
 BV BOUND     y_69
 BV BOUND     y_70
 BV BOUND     y_71
 BV BOUND     y_72
 BV BOUND     y_73
 BV BOUND     y_74
 BV BOUND     y_75
 BV BOUND     y_76
 BV BOUND     y_77
 BV BOUND     y_78
 BV BOUND     y_79
ENDATA
