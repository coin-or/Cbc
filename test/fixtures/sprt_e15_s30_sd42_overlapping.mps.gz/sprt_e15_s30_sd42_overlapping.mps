NAME          SETPART
ROWS
 N  OBJ
 E  PART_0
 E  PART_1
 E  PART_2
 E  PART_3
 E  PART_4
 E  PART_5
 E  PART_6
 E  PART_7
 E  PART_8
 E  PART_9
 E  PART_10
 E  PART_11
 E  PART_12
 E  PART_13
 E  PART_14
COLUMNS
    x_0         OBJ       82
    x_0         PART_5  1.0
    x_1         OBJ       15
    x_1         PART_11  1.0
    x_2         OBJ       4
    x_2         PART_13  1.0
    x_3         OBJ       95
    x_3         PART_10  1.0
    x_4         OBJ       36
    x_4         PART_1  1.0
    x_5         OBJ       32
    x_5         PART_12  1.0
    x_6         OBJ       29
    x_6         PART_8  1.0
    x_7         OBJ       18
    x_7         PART_14  1.0
    x_8         OBJ       95
    x_8         PART_2  1.0
    x_9         OBJ       14
    x_9         PART_0  1.0
    x_10        OBJ       87
    x_10        PART_4  1.0
    x_11        OBJ       95
    x_11        PART_9  1.0
    x_12        OBJ       70
    x_12        PART_7  1.0
    x_13        OBJ       12
    x_13        PART_3  1.0
    x_14        OBJ       76
    x_14        PART_6  1.0
    x_15        OBJ       55
    x_15        PART_6  1.0
    x_15        PART_1  1.0
    x_16        OBJ       5
    x_16        PART_13  1.0
    x_16        PART_5  1.0
    x_16        PART_9  1.0
    x_16        PART_4  1.0
    x_17        OBJ       4
    x_17        PART_11  1.0
    x_17        PART_7  1.0
    x_18        OBJ       12
    x_18        PART_14  1.0
    x_18        PART_6  1.0
    x_19        OBJ       28
    x_19        PART_8  1.0
    x_19        PART_4  1.0
    x_20        OBJ       30
    x_20        PART_9  1.0
    x_20        PART_3  1.0
    x_20        PART_11  1.0
    x_20        PART_1  1.0
    x_21        OBJ       65
    x_21        PART_10  1.0
    x_21        PART_3  1.0
    x_22        OBJ       78
    x_22        PART_1  1.0
    x_22        PART_13  1.0
    x_22        PART_3  1.0
    x_22        PART_14  1.0
    x_23        OBJ       4
    x_23        PART_4  1.0
    x_23        PART_7  1.0
    x_23        PART_10  1.0
    x_23        PART_5  1.0
    x_23        PART_2  1.0
    x_24        OBJ       72
    x_24        PART_5  1.0
    x_24        PART_3  1.0
    x_24        PART_10  1.0
    x_24        PART_4  1.0
    x_25        OBJ       26
    x_25        PART_9  1.0
    x_25        PART_10  1.0
    x_26        OBJ       92
    x_26        PART_8  1.0
    x_26        PART_11  1.0
    x_26        PART_3  1.0
    x_27        OBJ       84
    x_27        PART_7  1.0
    x_27        PART_6  1.0
    x_27        PART_4  1.0
    x_28        OBJ       90
    x_28        PART_10  1.0
    x_28        PART_5  1.0
    x_28        PART_12  1.0
    x_29        OBJ       70
    x_29        PART_3  1.0
    x_29        PART_13  1.0
RHS
    RHS1      PART_0  1.0
    RHS1      PART_1  1.0
    RHS1      PART_2  1.0
    RHS1      PART_3  1.0
    RHS1      PART_4  1.0
    RHS1      PART_5  1.0
    RHS1      PART_6  1.0
    RHS1      PART_7  1.0
    RHS1      PART_8  1.0
    RHS1      PART_9  1.0
    RHS1      PART_10  1.0
    RHS1      PART_11  1.0
    RHS1      PART_12  1.0
    RHS1      PART_13  1.0
    RHS1      PART_14  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
ENDATA
