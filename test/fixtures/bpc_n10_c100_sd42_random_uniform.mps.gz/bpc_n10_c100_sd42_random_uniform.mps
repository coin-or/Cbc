NAME          BPC
ROWS
 N  OBJ
 E  ASSIGN_0
 E  ASSIGN_1
 E  ASSIGN_2
 E  ASSIGN_3
 E  ASSIGN_4
 E  ASSIGN_5
 E  ASSIGN_6
 E  ASSIGN_7
 E  ASSIGN_8
 E  ASSIGN_9
 L  CAP_0
 L  CAP_1
 L  CAP_2
 L  CAP_3
 L  CAP_4
 L  CAP_5
 L  CAP_6
 L  CAP_7
 L  CAP_8
 L  CAP_9
 L  CONF_2_4_0
 L  CONF_2_4_1
 L  CONF_2_4_2
 L  CONF_2_4_3
 L  CONF_2_4_4
 L  CONF_2_4_5
 L  CONF_2_4_6
 L  CONF_2_4_7
 L  CONF_2_4_8
 L  CONF_2_4_9
 L  CONF_2_7_0
 L  CONF_2_7_1
 L  CONF_2_7_2
 L  CONF_2_7_3
 L  CONF_2_7_4
 L  CONF_2_7_5
 L  CONF_2_7_6
 L  CONF_2_7_7
 L  CONF_2_7_8
 L  CONF_2_7_9
 L  CONF_0_3_0
 L  CONF_0_3_1
 L  CONF_0_3_2
 L  CONF_0_3_3
 L  CONF_0_3_4
 L  CONF_0_3_5
 L  CONF_0_3_6
 L  CONF_0_3_7
 L  CONF_0_3_8
 L  CONF_0_3_9
 L  CONF_0_9_0
 L  CONF_0_9_1
 L  CONF_0_9_2
 L  CONF_0_9_3
 L  CONF_0_9_4
 L  CONF_0_9_5
 L  CONF_0_9_6
 L  CONF_0_9_7
 L  CONF_0_9_8
 L  CONF_0_9_9
 L  CONF_5_7_0
 L  CONF_5_7_1
 L  CONF_5_7_2
 L  CONF_5_7_3
 L  CONF_5_7_4
 L  CONF_5_7_5
 L  CONF_5_7_6
 L  CONF_5_7_7
 L  CONF_5_7_8
 L  CONF_5_7_9
 L  CONF_6_7_0
 L  CONF_6_7_1
 L  CONF_6_7_2
 L  CONF_6_7_3
 L  CONF_6_7_4
 L  CONF_6_7_5
 L  CONF_6_7_6
 L  CONF_6_7_7
 L  CONF_6_7_8
 L  CONF_6_7_9
 L  CONF_1_7_0
 L  CONF_1_7_1
 L  CONF_1_7_2
 L  CONF_1_7_3
 L  CONF_1_7_4
 L  CONF_1_7_5
 L  CONF_1_7_6
 L  CONF_1_7_7
 L  CONF_1_7_8
 L  CONF_1_7_9
 L  CONF_0_5_0
 L  CONF_0_5_1
 L  CONF_0_5_2
 L  CONF_0_5_3
 L  CONF_0_5_4
 L  CONF_0_5_5
 L  CONF_0_5_6
 L  CONF_0_5_7
 L  CONF_0_5_8
 L  CONF_0_5_9
 L  CONF_0_8_0
 L  CONF_0_8_1
 L  CONF_0_8_2
 L  CONF_0_8_3
 L  CONF_0_8_4
 L  CONF_0_8_5
 L  CONF_0_8_6
 L  CONF_0_8_7
 L  CONF_0_8_8
 L  CONF_0_8_9
 L  CONF_6_9_0
 L  CONF_6_9_1
 L  CONF_6_9_2
 L  CONF_6_9_3
 L  CONF_6_9_4
 L  CONF_6_9_5
 L  CONF_6_9_6
 L  CONF_6_9_7
 L  CONF_6_9_8
 L  CONF_6_9_9
 L  CONF_2_8_0
 L  CONF_2_8_1
 L  CONF_2_8_2
 L  CONF_2_8_3
 L  CONF_2_8_4
 L  CONF_2_8_5
 L  CONF_2_8_6
 L  CONF_2_8_7
 L  CONF_2_8_8
 L  CONF_2_8_9
COLUMNS
    x_0_0       ASSIGN_0  1.0
    x_0_0       CAP_0  30
    x_0_0       CONF_0_3_0  1.0
    x_0_0       CONF_0_5_0  1.0
    x_0_0       CONF_0_8_0  1.0
    x_0_0       CONF_0_9_0  1.0
    x_0_1       ASSIGN_0  1.0
    x_0_1       CAP_1  30
    x_0_1       CONF_0_3_1  1.0
    x_0_1       CONF_0_5_1  1.0
    x_0_1       CONF_0_8_1  1.0
    x_0_1       CONF_0_9_1  1.0
    x_0_2       ASSIGN_0  1.0
    x_0_2       CAP_2  30
    x_0_2       CONF_0_3_2  1.0
    x_0_2       CONF_0_5_2  1.0
    x_0_2       CONF_0_8_2  1.0
    x_0_2       CONF_0_9_2  1.0
    x_0_3       ASSIGN_0  1.0
    x_0_3       CAP_3  30
    x_0_3       CONF_0_3_3  1.0
    x_0_3       CONF_0_5_3  1.0
    x_0_3       CONF_0_8_3  1.0
    x_0_3       CONF_0_9_3  1.0
    x_0_4       ASSIGN_0  1.0
    x_0_4       CAP_4  30
    x_0_4       CONF_0_3_4  1.0
    x_0_4       CONF_0_5_4  1.0
    x_0_4       CONF_0_8_4  1.0
    x_0_4       CONF_0_9_4  1.0
    x_0_5       ASSIGN_0  1.0
    x_0_5       CAP_5  30
    x_0_5       CONF_0_3_5  1.0
    x_0_5       CONF_0_5_5  1.0
    x_0_5       CONF_0_8_5  1.0
    x_0_5       CONF_0_9_5  1.0
    x_0_6       ASSIGN_0  1.0
    x_0_6       CAP_6  30
    x_0_6       CONF_0_3_6  1.0
    x_0_6       CONF_0_5_6  1.0
    x_0_6       CONF_0_8_6  1.0
    x_0_6       CONF_0_9_6  1.0
    x_0_7       ASSIGN_0  1.0
    x_0_7       CAP_7  30
    x_0_7       CONF_0_3_7  1.0
    x_0_7       CONF_0_5_7  1.0
    x_0_7       CONF_0_8_7  1.0
    x_0_7       CONF_0_9_7  1.0
    x_0_8       ASSIGN_0  1.0
    x_0_8       CAP_8  30
    x_0_8       CONF_0_3_8  1.0
    x_0_8       CONF_0_5_8  1.0
    x_0_8       CONF_0_8_8  1.0
    x_0_8       CONF_0_9_8  1.0
    x_0_9       ASSIGN_0  1.0
    x_0_9       CAP_9  30
    x_0_9       CONF_0_3_9  1.0
    x_0_9       CONF_0_5_9  1.0
    x_0_9       CONF_0_8_9  1.0
    x_0_9       CONF_0_9_9  1.0
    x_1_0       ASSIGN_1  1.0
    x_1_0       CAP_0  13
    x_1_0       CONF_1_7_0  1.0
    x_1_1       ASSIGN_1  1.0
    x_1_1       CAP_1  13
    x_1_1       CONF_1_7_1  1.0
    x_1_2       ASSIGN_1  1.0
    x_1_2       CAP_2  13
    x_1_2       CONF_1_7_2  1.0
    x_1_3       ASSIGN_1  1.0
    x_1_3       CAP_3  13
    x_1_3       CONF_1_7_3  1.0
    x_1_4       ASSIGN_1  1.0
    x_1_4       CAP_4  13
    x_1_4       CONF_1_7_4  1.0
    x_1_5       ASSIGN_1  1.0
    x_1_5       CAP_5  13
    x_1_5       CONF_1_7_5  1.0
    x_1_6       ASSIGN_1  1.0
    x_1_6       CAP_6  13
    x_1_6       CONF_1_7_6  1.0
    x_1_7       ASSIGN_1  1.0
    x_1_7       CAP_7  13
    x_1_7       CONF_1_7_7  1.0
    x_1_8       ASSIGN_1  1.0
    x_1_8       CAP_8  13
    x_1_8       CONF_1_7_8  1.0
    x_1_9       ASSIGN_1  1.0
    x_1_9       CAP_9  13
    x_1_9       CONF_1_7_9  1.0
    x_2_0       ASSIGN_2  1.0
    x_2_0       CAP_0  10
    x_2_0       CONF_2_4_0  1.0
    x_2_0       CONF_2_7_0  1.0
    x_2_0       CONF_2_8_0  1.0
    x_2_1       ASSIGN_2  1.0
    x_2_1       CAP_1  10
    x_2_1       CONF_2_4_1  1.0
    x_2_1       CONF_2_7_1  1.0
    x_2_1       CONF_2_8_1  1.0
    x_2_2       ASSIGN_2  1.0
    x_2_2       CAP_2  10
    x_2_2       CONF_2_4_2  1.0
    x_2_2       CONF_2_7_2  1.0
    x_2_2       CONF_2_8_2  1.0
    x_2_3       ASSIGN_2  1.0
    x_2_3       CAP_3  10
    x_2_3       CONF_2_4_3  1.0
    x_2_3       CONF_2_7_3  1.0
    x_2_3       CONF_2_8_3  1.0
    x_2_4       ASSIGN_2  1.0
    x_2_4       CAP_4  10
    x_2_4       CONF_2_4_4  1.0
    x_2_4       CONF_2_7_4  1.0
    x_2_4       CONF_2_8_4  1.0
    x_2_5       ASSIGN_2  1.0
    x_2_5       CAP_5  10
    x_2_5       CONF_2_4_5  1.0
    x_2_5       CONF_2_7_5  1.0
    x_2_5       CONF_2_8_5  1.0
    x_2_6       ASSIGN_2  1.0
    x_2_6       CAP_6  10
    x_2_6       CONF_2_4_6  1.0
    x_2_6       CONF_2_7_6  1.0
    x_2_6       CONF_2_8_6  1.0
    x_2_7       ASSIGN_2  1.0
    x_2_7       CAP_7  10
    x_2_7       CONF_2_4_7  1.0
    x_2_7       CONF_2_7_7  1.0
    x_2_7       CONF_2_8_7  1.0
    x_2_8       ASSIGN_2  1.0
    x_2_8       CAP_8  10
    x_2_8       CONF_2_4_8  1.0
    x_2_8       CONF_2_7_8  1.0
    x_2_8       CONF_2_8_8  1.0
    x_2_9       ASSIGN_2  1.0
    x_2_9       CAP_9  10
    x_2_9       CONF_2_4_9  1.0
    x_2_9       CONF_2_7_9  1.0
    x_2_9       CONF_2_8_9  1.0
    x_3_0       ASSIGN_3  1.0
    x_3_0       CAP_0  33
    x_3_0       CONF_0_3_0  1.0
    x_3_1       ASSIGN_3  1.0
    x_3_1       CAP_1  33
    x_3_1       CONF_0_3_1  1.0
    x_3_2       ASSIGN_3  1.0
    x_3_2       CAP_2  33
    x_3_2       CONF_0_3_2  1.0
    x_3_3       ASSIGN_3  1.0
    x_3_3       CAP_3  33
    x_3_3       CONF_0_3_3  1.0
    x_3_4       ASSIGN_3  1.0
    x_3_4       CAP_4  33
    x_3_4       CONF_0_3_4  1.0
    x_3_5       ASSIGN_3  1.0
    x_3_5       CAP_5  33
    x_3_5       CONF_0_3_5  1.0
    x_3_6       ASSIGN_3  1.0
    x_3_6       CAP_6  33
    x_3_6       CONF_0_3_6  1.0
    x_3_7       ASSIGN_3  1.0
    x_3_7       CAP_7  33
    x_3_7       CONF_0_3_7  1.0
    x_3_8       ASSIGN_3  1.0
    x_3_8       CAP_8  33
    x_3_8       CONF_0_3_8  1.0
    x_3_9       ASSIGN_3  1.0
    x_3_9       CAP_9  33
    x_3_9       CONF_0_3_9  1.0
    x_4_0       ASSIGN_4  1.0
    x_4_0       CAP_0  18
    x_4_0       CONF_2_4_0  1.0
    x_4_1       ASSIGN_4  1.0
    x_4_1       CAP_1  18
    x_4_1       CONF_2_4_1  1.0
    x_4_2       ASSIGN_4  1.0
    x_4_2       CAP_2  18
    x_4_2       CONF_2_4_2  1.0
    x_4_3       ASSIGN_4  1.0
    x_4_3       CAP_3  18
    x_4_3       CONF_2_4_3  1.0
    x_4_4       ASSIGN_4  1.0
    x_4_4       CAP_4  18
    x_4_4       CONF_2_4_4  1.0
    x_4_5       ASSIGN_4  1.0
    x_4_5       CAP_5  18
    x_4_5       CONF_2_4_5  1.0
    x_4_6       ASSIGN_4  1.0
    x_4_6       CAP_6  18
    x_4_6       CONF_2_4_6  1.0
    x_4_7       ASSIGN_4  1.0
    x_4_7       CAP_7  18
    x_4_7       CONF_2_4_7  1.0
    x_4_8       ASSIGN_4  1.0
    x_4_8       CAP_8  18
    x_4_8       CONF_2_4_8  1.0
    x_4_9       ASSIGN_4  1.0
    x_4_9       CAP_9  18
    x_4_9       CONF_2_4_9  1.0
    x_5_0       ASSIGN_5  1.0
    x_5_0       CAP_0  17
    x_5_0       CONF_0_5_0  1.0
    x_5_0       CONF_5_7_0  1.0
    x_5_1       ASSIGN_5  1.0
    x_5_1       CAP_1  17
    x_5_1       CONF_0_5_1  1.0
    x_5_1       CONF_5_7_1  1.0
    x_5_2       ASSIGN_5  1.0
    x_5_2       CAP_2  17
    x_5_2       CONF_0_5_2  1.0
    x_5_2       CONF_5_7_2  1.0
    x_5_3       ASSIGN_5  1.0
    x_5_3       CAP_3  17
    x_5_3       CONF_0_5_3  1.0
    x_5_3       CONF_5_7_3  1.0
    x_5_4       ASSIGN_5  1.0
    x_5_4       CAP_4  17
    x_5_4       CONF_0_5_4  1.0
    x_5_4       CONF_5_7_4  1.0
    x_5_5       ASSIGN_5  1.0
    x_5_5       CAP_5  17
    x_5_5       CONF_0_5_5  1.0
    x_5_5       CONF_5_7_5  1.0
    x_5_6       ASSIGN_5  1.0
    x_5_6       CAP_6  17
    x_5_6       CONF_0_5_6  1.0
    x_5_6       CONF_5_7_6  1.0
    x_5_7       ASSIGN_5  1.0
    x_5_7       CAP_7  17
    x_5_7       CONF_0_5_7  1.0
    x_5_7       CONF_5_7_7  1.0
    x_5_8       ASSIGN_5  1.0
    x_5_8       CAP_8  17
    x_5_8       CONF_0_5_8  1.0
    x_5_8       CONF_5_7_8  1.0
    x_5_9       ASSIGN_5  1.0
    x_5_9       CAP_9  17
    x_5_9       CONF_0_5_9  1.0
    x_5_9       CONF_5_7_9  1.0
    x_6_0       ASSIGN_6  1.0
    x_6_0       CAP_0  17
    x_6_0       CONF_6_7_0  1.0
    x_6_0       CONF_6_9_0  1.0
    x_6_1       ASSIGN_6  1.0
    x_6_1       CAP_1  17
    x_6_1       CONF_6_7_1  1.0
    x_6_1       CONF_6_9_1  1.0
    x_6_2       ASSIGN_6  1.0
    x_6_2       CAP_2  17
    x_6_2       CONF_6_7_2  1.0
    x_6_2       CONF_6_9_2  1.0
    x_6_3       ASSIGN_6  1.0
    x_6_3       CAP_3  17
    x_6_3       CONF_6_7_3  1.0
    x_6_3       CONF_6_9_3  1.0
    x_6_4       ASSIGN_6  1.0
    x_6_4       CAP_4  17
    x_6_4       CONF_6_7_4  1.0
    x_6_4       CONF_6_9_4  1.0
    x_6_5       ASSIGN_6  1.0
    x_6_5       CAP_5  17
    x_6_5       CONF_6_7_5  1.0
    x_6_5       CONF_6_9_5  1.0
    x_6_6       ASSIGN_6  1.0
    x_6_6       CAP_6  17
    x_6_6       CONF_6_7_6  1.0
    x_6_6       CONF_6_9_6  1.0
    x_6_7       ASSIGN_6  1.0
    x_6_7       CAP_7  17
    x_6_7       CONF_6_7_7  1.0
    x_6_7       CONF_6_9_7  1.0
    x_6_8       ASSIGN_6  1.0
    x_6_8       CAP_8  17
    x_6_8       CONF_6_7_8  1.0
    x_6_8       CONF_6_9_8  1.0
    x_6_9       ASSIGN_6  1.0
    x_6_9       CAP_9  17
    x_6_9       CONF_6_7_9  1.0
    x_6_9       CONF_6_9_9  1.0
    x_7_0       ASSIGN_7  1.0
    x_7_0       CAP_0  14
    x_7_0       CONF_1_7_0  1.0
    x_7_0       CONF_2_7_0  1.0
    x_7_0       CONF_5_7_0  1.0
    x_7_0       CONF_6_7_0  1.0
    x_7_1       ASSIGN_7  1.0
    x_7_1       CAP_1  14
    x_7_1       CONF_1_7_1  1.0
    x_7_1       CONF_2_7_1  1.0
    x_7_1       CONF_5_7_1  1.0
    x_7_1       CONF_6_7_1  1.0
    x_7_2       ASSIGN_7  1.0
    x_7_2       CAP_2  14
    x_7_2       CONF_1_7_2  1.0
    x_7_2       CONF_2_7_2  1.0
    x_7_2       CONF_5_7_2  1.0
    x_7_2       CONF_6_7_2  1.0
    x_7_3       ASSIGN_7  1.0
    x_7_3       CAP_3  14
    x_7_3       CONF_1_7_3  1.0
    x_7_3       CONF_2_7_3  1.0
    x_7_3       CONF_5_7_3  1.0
    x_7_3       CONF_6_7_3  1.0
    x_7_4       ASSIGN_7  1.0
    x_7_4       CAP_4  14
    x_7_4       CONF_1_7_4  1.0
    x_7_4       CONF_2_7_4  1.0
    x_7_4       CONF_5_7_4  1.0
    x_7_4       CONF_6_7_4  1.0
    x_7_5       ASSIGN_7  1.0
    x_7_5       CAP_5  14
    x_7_5       CONF_1_7_5  1.0
    x_7_5       CONF_2_7_5  1.0
    x_7_5       CONF_5_7_5  1.0
    x_7_5       CONF_6_7_5  1.0
    x_7_6       ASSIGN_7  1.0
    x_7_6       CAP_6  14
    x_7_6       CONF_1_7_6  1.0
    x_7_6       CONF_2_7_6  1.0
    x_7_6       CONF_5_7_6  1.0
    x_7_6       CONF_6_7_6  1.0
    x_7_7       ASSIGN_7  1.0
    x_7_7       CAP_7  14
    x_7_7       CONF_1_7_7  1.0
    x_7_7       CONF_2_7_7  1.0
    x_7_7       CONF_5_7_7  1.0
    x_7_7       CONF_6_7_7  1.0
    x_7_8       ASSIGN_7  1.0
    x_7_8       CAP_8  14
    x_7_8       CONF_1_7_8  1.0
    x_7_8       CONF_2_7_8  1.0
    x_7_8       CONF_5_7_8  1.0
    x_7_8       CONF_6_7_8  1.0
    x_7_9       ASSIGN_7  1.0
    x_7_9       CAP_9  14
    x_7_9       CONF_1_7_9  1.0
    x_7_9       CONF_2_7_9  1.0
    x_7_9       CONF_5_7_9  1.0
    x_7_9       CONF_6_7_9  1.0
    x_8_0       ASSIGN_8  1.0
    x_8_0       CAP_0  33
    x_8_0       CONF_0_8_0  1.0
    x_8_0       CONF_2_8_0  1.0
    x_8_1       ASSIGN_8  1.0
    x_8_1       CAP_1  33
    x_8_1       CONF_0_8_1  1.0
    x_8_1       CONF_2_8_1  1.0
    x_8_2       ASSIGN_8  1.0
    x_8_2       CAP_2  33
    x_8_2       CONF_0_8_2  1.0
    x_8_2       CONF_2_8_2  1.0
    x_8_3       ASSIGN_8  1.0
    x_8_3       CAP_3  33
    x_8_3       CONF_0_8_3  1.0
    x_8_3       CONF_2_8_3  1.0
    x_8_4       ASSIGN_8  1.0
    x_8_4       CAP_4  33
    x_8_4       CONF_0_8_4  1.0
    x_8_4       CONF_2_8_4  1.0
    x_8_5       ASSIGN_8  1.0
    x_8_5       CAP_5  33
    x_8_5       CONF_0_8_5  1.0
    x_8_5       CONF_2_8_5  1.0
    x_8_6       ASSIGN_8  1.0
    x_8_6       CAP_6  33
    x_8_6       CONF_0_8_6  1.0
    x_8_6       CONF_2_8_6  1.0
    x_8_7       ASSIGN_8  1.0
    x_8_7       CAP_7  33
    x_8_7       CONF_0_8_7  1.0
    x_8_7       CONF_2_8_7  1.0
    x_8_8       ASSIGN_8  1.0
    x_8_8       CAP_8  33
    x_8_8       CONF_0_8_8  1.0
    x_8_8       CONF_2_8_8  1.0
    x_8_9       ASSIGN_8  1.0
    x_8_9       CAP_9  33
    x_8_9       CONF_0_8_9  1.0
    x_8_9       CONF_2_8_9  1.0
    x_9_0       ASSIGN_9  1.0
    x_9_0       CAP_0  13
    x_9_0       CONF_0_9_0  1.0
    x_9_0       CONF_6_9_0  1.0
    x_9_1       ASSIGN_9  1.0
    x_9_1       CAP_1  13
    x_9_1       CONF_0_9_1  1.0
    x_9_1       CONF_6_9_1  1.0
    x_9_2       ASSIGN_9  1.0
    x_9_2       CAP_2  13
    x_9_2       CONF_0_9_2  1.0
    x_9_2       CONF_6_9_2  1.0
    x_9_3       ASSIGN_9  1.0
    x_9_3       CAP_3  13
    x_9_3       CONF_0_9_3  1.0
    x_9_3       CONF_6_9_3  1.0
    x_9_4       ASSIGN_9  1.0
    x_9_4       CAP_4  13
    x_9_4       CONF_0_9_4  1.0
    x_9_4       CONF_6_9_4  1.0
    x_9_5       ASSIGN_9  1.0
    x_9_5       CAP_5  13
    x_9_5       CONF_0_9_5  1.0
    x_9_5       CONF_6_9_5  1.0
    x_9_6       ASSIGN_9  1.0
    x_9_6       CAP_6  13
    x_9_6       CONF_0_9_6  1.0
    x_9_6       CONF_6_9_6  1.0
    x_9_7       ASSIGN_9  1.0
    x_9_7       CAP_7  13
    x_9_7       CONF_0_9_7  1.0
    x_9_7       CONF_6_9_7  1.0
    x_9_8       ASSIGN_9  1.0
    x_9_8       CAP_8  13
    x_9_8       CONF_0_9_8  1.0
    x_9_8       CONF_6_9_8  1.0
    x_9_9       ASSIGN_9  1.0
    x_9_9       CAP_9  13
    x_9_9       CONF_0_9_9  1.0
    x_9_9       CONF_6_9_9  1.0
    y_0         OBJ       1.0
    y_0         CAP_0  -100
    y_0         CONF_2_4_0  -1.0
    y_0         CONF_2_7_0  -1.0
    y_0         CONF_0_3_0  -1.0
    y_0         CONF_0_9_0  -1.0
    y_0         CONF_5_7_0  -1.0
    y_0         CONF_6_7_0  -1.0
    y_0         CONF_1_7_0  -1.0
    y_0         CONF_0_5_0  -1.0
    y_0         CONF_0_8_0  -1.0
    y_0         CONF_6_9_0  -1.0
    y_0         CONF_2_8_0  -1.0
    y_1         OBJ       1.0
    y_1         CAP_1  -100
    y_1         CONF_2_4_1  -1.0
    y_1         CONF_2_7_1  -1.0
    y_1         CONF_0_3_1  -1.0
    y_1         CONF_0_9_1  -1.0
    y_1         CONF_5_7_1  -1.0
    y_1         CONF_6_7_1  -1.0
    y_1         CONF_1_7_1  -1.0
    y_1         CONF_0_5_1  -1.0
    y_1         CONF_0_8_1  -1.0
    y_1         CONF_6_9_1  -1.0
    y_1         CONF_2_8_1  -1.0
    y_2         OBJ       1.0
    y_2         CAP_2  -100
    y_2         CONF_2_4_2  -1.0
    y_2         CONF_2_7_2  -1.0
    y_2         CONF_0_3_2  -1.0
    y_2         CONF_0_9_2  -1.0
    y_2         CONF_5_7_2  -1.0
    y_2         CONF_6_7_2  -1.0
    y_2         CONF_1_7_2  -1.0
    y_2         CONF_0_5_2  -1.0
    y_2         CONF_0_8_2  -1.0
    y_2         CONF_6_9_2  -1.0
    y_2         CONF_2_8_2  -1.0
    y_3         OBJ       1.0
    y_3         CAP_3  -100
    y_3         CONF_2_4_3  -1.0
    y_3         CONF_2_7_3  -1.0
    y_3         CONF_0_3_3  -1.0
    y_3         CONF_0_9_3  -1.0
    y_3         CONF_5_7_3  -1.0
    y_3         CONF_6_7_3  -1.0
    y_3         CONF_1_7_3  -1.0
    y_3         CONF_0_5_3  -1.0
    y_3         CONF_0_8_3  -1.0
    y_3         CONF_6_9_3  -1.0
    y_3         CONF_2_8_3  -1.0
    y_4         OBJ       1.0
    y_4         CAP_4  -100
    y_4         CONF_2_4_4  -1.0
    y_4         CONF_2_7_4  -1.0
    y_4         CONF_0_3_4  -1.0
    y_4         CONF_0_9_4  -1.0
    y_4         CONF_5_7_4  -1.0
    y_4         CONF_6_7_4  -1.0
    y_4         CONF_1_7_4  -1.0
    y_4         CONF_0_5_4  -1.0
    y_4         CONF_0_8_4  -1.0
    y_4         CONF_6_9_4  -1.0
    y_4         CONF_2_8_4  -1.0
    y_5         OBJ       1.0
    y_5         CAP_5  -100
    y_5         CONF_2_4_5  -1.0
    y_5         CONF_2_7_5  -1.0
    y_5         CONF_0_3_5  -1.0
    y_5         CONF_0_9_5  -1.0
    y_5         CONF_5_7_5  -1.0
    y_5         CONF_6_7_5  -1.0
    y_5         CONF_1_7_5  -1.0
    y_5         CONF_0_5_5  -1.0
    y_5         CONF_0_8_5  -1.0
    y_5         CONF_6_9_5  -1.0
    y_5         CONF_2_8_5  -1.0
    y_6         OBJ       1.0
    y_6         CAP_6  -100
    y_6         CONF_2_4_6  -1.0
    y_6         CONF_2_7_6  -1.0
    y_6         CONF_0_3_6  -1.0
    y_6         CONF_0_9_6  -1.0
    y_6         CONF_5_7_6  -1.0
    y_6         CONF_6_7_6  -1.0
    y_6         CONF_1_7_6  -1.0
    y_6         CONF_0_5_6  -1.0
    y_6         CONF_0_8_6  -1.0
    y_6         CONF_6_9_6  -1.0
    y_6         CONF_2_8_6  -1.0
    y_7         OBJ       1.0
    y_7         CAP_7  -100
    y_7         CONF_2_4_7  -1.0
    y_7         CONF_2_7_7  -1.0
    y_7         CONF_0_3_7  -1.0
    y_7         CONF_0_9_7  -1.0
    y_7         CONF_5_7_7  -1.0
    y_7         CONF_6_7_7  -1.0
    y_7         CONF_1_7_7  -1.0
    y_7         CONF_0_5_7  -1.0
    y_7         CONF_0_8_7  -1.0
    y_7         CONF_6_9_7  -1.0
    y_7         CONF_2_8_7  -1.0
    y_8         OBJ       1.0
    y_8         CAP_8  -100
    y_8         CONF_2_4_8  -1.0
    y_8         CONF_2_7_8  -1.0
    y_8         CONF_0_3_8  -1.0
    y_8         CONF_0_9_8  -1.0
    y_8         CONF_5_7_8  -1.0
    y_8         CONF_6_7_8  -1.0
    y_8         CONF_1_7_8  -1.0
    y_8         CONF_0_5_8  -1.0
    y_8         CONF_0_8_8  -1.0
    y_8         CONF_6_9_8  -1.0
    y_8         CONF_2_8_8  -1.0
    y_9         OBJ       1.0
    y_9         CAP_9  -100
    y_9         CONF_2_4_9  -1.0
    y_9         CONF_2_7_9  -1.0
    y_9         CONF_0_3_9  -1.0
    y_9         CONF_0_9_9  -1.0
    y_9         CONF_5_7_9  -1.0
    y_9         CONF_6_7_9  -1.0
    y_9         CONF_1_7_9  -1.0
    y_9         CONF_0_5_9  -1.0
    y_9         CONF_0_8_9  -1.0
    y_9         CONF_6_9_9  -1.0
    y_9         CONF_2_8_9  -1.0
RHS
    RHS1      ASSIGN_0  1.0
    RHS1      ASSIGN_1  1.0
    RHS1      ASSIGN_2  1.0
    RHS1      ASSIGN_3  1.0
    RHS1      ASSIGN_4  1.0
    RHS1      ASSIGN_5  1.0
    RHS1      ASSIGN_6  1.0
    RHS1      ASSIGN_7  1.0
    RHS1      ASSIGN_8  1.0
    RHS1      ASSIGN_9  1.0
BOUNDS
 BV BND1      y_0
 BV BND1      y_1
 BV BND1      y_2
 BV BND1      y_3
 BV BND1      y_4
 BV BND1      y_5
 BV BND1      y_6
 BV BND1      y_7
 BV BND1      y_8
 BV BND1      y_9
 BV BND1      x_0_0
 BV BND1      x_0_1
 BV BND1      x_0_2
 BV BND1      x_0_3
 BV BND1      x_0_4
 BV BND1      x_0_5
 BV BND1      x_0_6
 BV BND1      x_0_7
 BV BND1      x_0_8
 BV BND1      x_0_9
 BV BND1      x_1_0
 BV BND1      x_1_1
 BV BND1      x_1_2
 BV BND1      x_1_3
 BV BND1      x_1_4
 BV BND1      x_1_5
 BV BND1      x_1_6
 BV BND1      x_1_7
 BV BND1      x_1_8
 BV BND1      x_1_9
 BV BND1      x_2_0
 BV BND1      x_2_1
 BV BND1      x_2_2
 BV BND1      x_2_3
 BV BND1      x_2_4
 BV BND1      x_2_5
 BV BND1      x_2_6
 BV BND1      x_2_7
 BV BND1      x_2_8
 BV BND1      x_2_9
 BV BND1      x_3_0
 BV BND1      x_3_1
 BV BND1      x_3_2
 BV BND1      x_3_3
 BV BND1      x_3_4
 BV BND1      x_3_5
 BV BND1      x_3_6
 BV BND1      x_3_7
 BV BND1      x_3_8
 BV BND1      x_3_9
 BV BND1      x_4_0
 BV BND1      x_4_1
 BV BND1      x_4_2
 BV BND1      x_4_3
 BV BND1      x_4_4
 BV BND1      x_4_5
 BV BND1      x_4_6
 BV BND1      x_4_7
 BV BND1      x_4_8
 BV BND1      x_4_9
 BV BND1      x_5_0
 BV BND1      x_5_1
 BV BND1      x_5_2
 BV BND1      x_5_3
 BV BND1      x_5_4
 BV BND1      x_5_5
 BV BND1      x_5_6
 BV BND1      x_5_7
 BV BND1      x_5_8
 BV BND1      x_5_9
 BV BND1      x_6_0
 BV BND1      x_6_1
 BV BND1      x_6_2
 BV BND1      x_6_3
 BV BND1      x_6_4
 BV BND1      x_6_5
 BV BND1      x_6_6
 BV BND1      x_6_7
 BV BND1      x_6_8
 BV BND1      x_6_9
 BV BND1      x_7_0
 BV BND1      x_7_1
 BV BND1      x_7_2
 BV BND1      x_7_3
 BV BND1      x_7_4
 BV BND1      x_7_5
 BV BND1      x_7_6
 BV BND1      x_7_7
 BV BND1      x_7_8
 BV BND1      x_7_9
 BV BND1      x_8_0
 BV BND1      x_8_1
 BV BND1      x_8_2
 BV BND1      x_8_3
 BV BND1      x_8_4
 BV BND1      x_8_5
 BV BND1      x_8_6
 BV BND1      x_8_7
 BV BND1      x_8_8
 BV BND1      x_8_9
 BV BND1      x_9_0
 BV BND1      x_9_1
 BV BND1      x_9_2
 BV BND1      x_9_3
 BV BND1      x_9_4
 BV BND1      x_9_5
 BV BND1      x_9_6
 BV BND1      x_9_7
 BV BND1      x_9_8
 BV BND1      x_9_9
ENDATA
