NAME          orb01
ROWS
 N  OBJ
 G  prec_0_0
 G  prec_0_1
 G  prec_0_2
 G  prec_0_3
 G  prec_0_4
 G  prec_0_5
 G  prec_0_6
 G  prec_0_7
 G  prec_0_8
 G  prec_1_0
 G  prec_1_1
 G  prec_1_2
 G  prec_1_3
 G  prec_1_4
 G  prec_1_5
 G  prec_1_6
 G  prec_1_7
 G  prec_1_8
 G  prec_2_0
 G  prec_2_1
 G  prec_2_2
 G  prec_2_3
 G  prec_2_4
 G  prec_2_5
 G  prec_2_6
 G  prec_2_7
 G  prec_2_8
 G  prec_3_0
 G  prec_3_1
 G  prec_3_2
 G  prec_3_3
 G  prec_3_4
 G  prec_3_5
 G  prec_3_6
 G  prec_3_7
 G  prec_3_8
 G  prec_4_0
 G  prec_4_1
 G  prec_4_2
 G  prec_4_3
 G  prec_4_4
 G  prec_4_5
 G  prec_4_6
 G  prec_4_7
 G  prec_4_8
 G  prec_5_0
 G  prec_5_1
 G  prec_5_2
 G  prec_5_3
 G  prec_5_4
 G  prec_5_5
 G  prec_5_6
 G  prec_5_7
 G  prec_5_8
 G  prec_6_0
 G  prec_6_1
 G  prec_6_2
 G  prec_6_3
 G  prec_6_4
 G  prec_6_5
 G  prec_6_6
 G  prec_6_7
 G  prec_6_8
 G  prec_7_0
 G  prec_7_1
 G  prec_7_2
 G  prec_7_3
 G  prec_7_4
 G  prec_7_5
 G  prec_7_6
 G  prec_7_7
 G  prec_7_8
 G  prec_8_0
 G  prec_8_1
 G  prec_8_2
 G  prec_8_3
 G  prec_8_4
 G  prec_8_5
 G  prec_8_6
 G  prec_8_7
 G  prec_8_8
 G  prec_9_0
 G  prec_9_1
 G  prec_9_2
 G  prec_9_3
 G  prec_9_4
 G  prec_9_5
 G  prec_9_6
 G  prec_9_7
 G  prec_9_8
 G  mksp_0
 G  mksp_1
 G  mksp_2
 G  mksp_3
 G  mksp_4
 G  mksp_5
 G  mksp_6
 G  mksp_7
 G  mksp_8
 G  mksp_9
 G  disj1_0_1_0
 G  disj2_0_1_0
 G  disj1_0_2_0
 G  disj2_0_2_0
 G  disj1_0_3_0
 G  disj2_0_3_0
 G  disj1_0_4_0
 G  disj2_0_4_0
 G  disj1_0_5_0
 G  disj2_0_5_0
 G  disj1_0_6_0
 G  disj2_0_6_0
 G  disj1_0_7_0
 G  disj2_0_7_0
 G  disj1_0_8_0
 G  disj2_0_8_0
 G  disj1_0_9_0
 G  disj2_0_9_0
 G  disj1_1_2_0
 G  disj2_1_2_0
 G  disj1_1_3_0
 G  disj2_1_3_0
 G  disj1_1_4_0
 G  disj2_1_4_0
 G  disj1_1_5_0
 G  disj2_1_5_0
 G  disj1_1_6_0
 G  disj2_1_6_0
 G  disj1_1_7_0
 G  disj2_1_7_0
 G  disj1_1_8_0
 G  disj2_1_8_0
 G  disj1_1_9_0
 G  disj2_1_9_0
 G  disj1_2_3_0
 G  disj2_2_3_0
 G  disj1_2_4_0
 G  disj2_2_4_0
 G  disj1_2_5_0
 G  disj2_2_5_0
 G  disj1_2_6_0
 G  disj2_2_6_0
 G  disj1_2_7_0
 G  disj2_2_7_0
 G  disj1_2_8_0
 G  disj2_2_8_0
 G  disj1_2_9_0
 G  disj2_2_9_0
 G  disj1_3_4_0
 G  disj2_3_4_0
 G  disj1_3_5_0
 G  disj2_3_5_0
 G  disj1_3_6_0
 G  disj2_3_6_0
 G  disj1_3_7_0
 G  disj2_3_7_0
 G  disj1_3_8_0
 G  disj2_3_8_0
 G  disj1_3_9_0
 G  disj2_3_9_0
 G  disj1_4_5_0
 G  disj2_4_5_0
 G  disj1_4_6_0
 G  disj2_4_6_0
 G  disj1_4_7_0
 G  disj2_4_7_0
 G  disj1_4_8_0
 G  disj2_4_8_0
 G  disj1_4_9_0
 G  disj2_4_9_0
 G  disj1_5_6_0
 G  disj2_5_6_0
 G  disj1_5_7_0
 G  disj2_5_7_0
 G  disj1_5_8_0
 G  disj2_5_8_0
 G  disj1_5_9_0
 G  disj2_5_9_0
 G  disj1_6_7_0
 G  disj2_6_7_0
 G  disj1_6_8_0
 G  disj2_6_8_0
 G  disj1_6_9_0
 G  disj2_6_9_0
 G  disj1_7_8_0
 G  disj2_7_8_0
 G  disj1_7_9_0
 G  disj2_7_9_0
 G  disj1_8_9_0
 G  disj2_8_9_0
 G  disj1_0_1_1
 G  disj2_0_1_1
 G  disj1_0_2_1
 G  disj2_0_2_1
 G  disj1_0_3_1
 G  disj2_0_3_1
 G  disj1_0_4_1
 G  disj2_0_4_1
 G  disj1_0_5_1
 G  disj2_0_5_1
 G  disj1_0_6_1
 G  disj2_0_6_1
 G  disj1_0_7_1
 G  disj2_0_7_1
 G  disj1_0_8_1
 G  disj2_0_8_1
 G  disj1_0_9_1
 G  disj2_0_9_1
 G  disj1_1_2_1
 G  disj2_1_2_1
 G  disj1_1_3_1
 G  disj2_1_3_1
 G  disj1_1_4_1
 G  disj2_1_4_1
 G  disj1_1_5_1
 G  disj2_1_5_1
 G  disj1_1_6_1
 G  disj2_1_6_1
 G  disj1_1_7_1
 G  disj2_1_7_1
 G  disj1_1_8_1
 G  disj2_1_8_1
 G  disj1_1_9_1
 G  disj2_1_9_1
 G  disj1_2_3_1
 G  disj2_2_3_1
 G  disj1_2_4_1
 G  disj2_2_4_1
 G  disj1_2_5_1
 G  disj2_2_5_1
 G  disj1_2_6_1
 G  disj2_2_6_1
 G  disj1_2_7_1
 G  disj2_2_7_1
 G  disj1_2_8_1
 G  disj2_2_8_1
 G  disj1_2_9_1
 G  disj2_2_9_1
 G  disj1_3_4_1
 G  disj2_3_4_1
 G  disj1_3_5_1
 G  disj2_3_5_1
 G  disj1_3_6_1
 G  disj2_3_6_1
 G  disj1_3_7_1
 G  disj2_3_7_1
 G  disj1_3_8_1
 G  disj2_3_8_1
 G  disj1_3_9_1
 G  disj2_3_9_1
 G  disj1_4_5_1
 G  disj2_4_5_1
 G  disj1_4_6_1
 G  disj2_4_6_1
 G  disj1_4_7_1
 G  disj2_4_7_1
 G  disj1_4_8_1
 G  disj2_4_8_1
 G  disj1_4_9_1
 G  disj2_4_9_1
 G  disj1_5_6_1
 G  disj2_5_6_1
 G  disj1_5_7_1
 G  disj2_5_7_1
 G  disj1_5_8_1
 G  disj2_5_8_1
 G  disj1_5_9_1
 G  disj2_5_9_1
 G  disj1_6_7_1
 G  disj2_6_7_1
 G  disj1_6_8_1
 G  disj2_6_8_1
 G  disj1_6_9_1
 G  disj2_6_9_1
 G  disj1_7_8_1
 G  disj2_7_8_1
 G  disj1_7_9_1
 G  disj2_7_9_1
 G  disj1_8_9_1
 G  disj2_8_9_1
 G  disj1_0_1_2
 G  disj2_0_1_2
 G  disj1_0_2_2
 G  disj2_0_2_2
 G  disj1_0_3_2
 G  disj2_0_3_2
 G  disj1_0_4_2
 G  disj2_0_4_2
 G  disj1_0_5_2
 G  disj2_0_5_2
 G  disj1_0_6_2
 G  disj2_0_6_2
 G  disj1_0_7_2
 G  disj2_0_7_2
 G  disj1_0_8_2
 G  disj2_0_8_2
 G  disj1_0_9_2
 G  disj2_0_9_2
 G  disj1_1_2_2
 G  disj2_1_2_2
 G  disj1_1_3_2
 G  disj2_1_3_2
 G  disj1_1_4_2
 G  disj2_1_4_2
 G  disj1_1_5_2
 G  disj2_1_5_2
 G  disj1_1_6_2
 G  disj2_1_6_2
 G  disj1_1_7_2
 G  disj2_1_7_2
 G  disj1_1_8_2
 G  disj2_1_8_2
 G  disj1_1_9_2
 G  disj2_1_9_2
 G  disj1_2_3_2
 G  disj2_2_3_2
 G  disj1_2_4_2
 G  disj2_2_4_2
 G  disj1_2_5_2
 G  disj2_2_5_2
 G  disj1_2_6_2
 G  disj2_2_6_2
 G  disj1_2_7_2
 G  disj2_2_7_2
 G  disj1_2_8_2
 G  disj2_2_8_2
 G  disj1_2_9_2
 G  disj2_2_9_2
 G  disj1_3_4_2
 G  disj2_3_4_2
 G  disj1_3_5_2
 G  disj2_3_5_2
 G  disj1_3_6_2
 G  disj2_3_6_2
 G  disj1_3_7_2
 G  disj2_3_7_2
 G  disj1_3_8_2
 G  disj2_3_8_2
 G  disj1_3_9_2
 G  disj2_3_9_2
 G  disj1_4_5_2
 G  disj2_4_5_2
 G  disj1_4_6_2
 G  disj2_4_6_2
 G  disj1_4_7_2
 G  disj2_4_7_2
 G  disj1_4_8_2
 G  disj2_4_8_2
 G  disj1_4_9_2
 G  disj2_4_9_2
 G  disj1_5_6_2
 G  disj2_5_6_2
 G  disj1_5_7_2
 G  disj2_5_7_2
 G  disj1_5_8_2
 G  disj2_5_8_2
 G  disj1_5_9_2
 G  disj2_5_9_2
 G  disj1_6_7_2
 G  disj2_6_7_2
 G  disj1_6_8_2
 G  disj2_6_8_2
 G  disj1_6_9_2
 G  disj2_6_9_2
 G  disj1_7_8_2
 G  disj2_7_8_2
 G  disj1_7_9_2
 G  disj2_7_9_2
 G  disj1_8_9_2
 G  disj2_8_9_2
 G  disj1_0_1_3
 G  disj2_0_1_3
 G  disj1_0_2_3
 G  disj2_0_2_3
 G  disj1_0_3_3
 G  disj2_0_3_3
 G  disj1_0_4_3
 G  disj2_0_4_3
 G  disj1_0_5_3
 G  disj2_0_5_3
 G  disj1_0_6_3
 G  disj2_0_6_3
 G  disj1_0_7_3
 G  disj2_0_7_3
 G  disj1_0_8_3
 G  disj2_0_8_3
 G  disj1_0_9_3
 G  disj2_0_9_3
 G  disj1_1_2_3
 G  disj2_1_2_3
 G  disj1_1_3_3
 G  disj2_1_3_3
 G  disj1_1_4_3
 G  disj2_1_4_3
 G  disj1_1_5_3
 G  disj2_1_5_3
 G  disj1_1_6_3
 G  disj2_1_6_3
 G  disj1_1_7_3
 G  disj2_1_7_3
 G  disj1_1_8_3
 G  disj2_1_8_3
 G  disj1_1_9_3
 G  disj2_1_9_3
 G  disj1_2_3_3
 G  disj2_2_3_3
 G  disj1_2_4_3
 G  disj2_2_4_3
 G  disj1_2_5_3
 G  disj2_2_5_3
 G  disj1_2_6_3
 G  disj2_2_6_3
 G  disj1_2_7_3
 G  disj2_2_7_3
 G  disj1_2_8_3
 G  disj2_2_8_3
 G  disj1_2_9_3
 G  disj2_2_9_3
 G  disj1_3_4_3
 G  disj2_3_4_3
 G  disj1_3_5_3
 G  disj2_3_5_3
 G  disj1_3_6_3
 G  disj2_3_6_3
 G  disj1_3_7_3
 G  disj2_3_7_3
 G  disj1_3_8_3
 G  disj2_3_8_3
 G  disj1_3_9_3
 G  disj2_3_9_3
 G  disj1_4_5_3
 G  disj2_4_5_3
 G  disj1_4_6_3
 G  disj2_4_6_3
 G  disj1_4_7_3
 G  disj2_4_7_3
 G  disj1_4_8_3
 G  disj2_4_8_3
 G  disj1_4_9_3
 G  disj2_4_9_3
 G  disj1_5_6_3
 G  disj2_5_6_3
 G  disj1_5_7_3
 G  disj2_5_7_3
 G  disj1_5_8_3
 G  disj2_5_8_3
 G  disj1_5_9_3
 G  disj2_5_9_3
 G  disj1_6_7_3
 G  disj2_6_7_3
 G  disj1_6_8_3
 G  disj2_6_8_3
 G  disj1_6_9_3
 G  disj2_6_9_3
 G  disj1_7_8_3
 G  disj2_7_8_3
 G  disj1_7_9_3
 G  disj2_7_9_3
 G  disj1_8_9_3
 G  disj2_8_9_3
 G  disj1_0_1_4
 G  disj2_0_1_4
 G  disj1_0_2_4
 G  disj2_0_2_4
 G  disj1_0_3_4
 G  disj2_0_3_4
 G  disj1_0_4_4
 G  disj2_0_4_4
 G  disj1_0_5_4
 G  disj2_0_5_4
 G  disj1_0_6_4
 G  disj2_0_6_4
 G  disj1_0_7_4
 G  disj2_0_7_4
 G  disj1_0_8_4
 G  disj2_0_8_4
 G  disj1_0_9_4
 G  disj2_0_9_4
 G  disj1_1_2_4
 G  disj2_1_2_4
 G  disj1_1_3_4
 G  disj2_1_3_4
 G  disj1_1_4_4
 G  disj2_1_4_4
 G  disj1_1_5_4
 G  disj2_1_5_4
 G  disj1_1_6_4
 G  disj2_1_6_4
 G  disj1_1_7_4
 G  disj2_1_7_4
 G  disj1_1_8_4
 G  disj2_1_8_4
 G  disj1_1_9_4
 G  disj2_1_9_4
 G  disj1_2_3_4
 G  disj2_2_3_4
 G  disj1_2_4_4
 G  disj2_2_4_4
 G  disj1_2_5_4
 G  disj2_2_5_4
 G  disj1_2_6_4
 G  disj2_2_6_4
 G  disj1_2_7_4
 G  disj2_2_7_4
 G  disj1_2_8_4
 G  disj2_2_8_4
 G  disj1_2_9_4
 G  disj2_2_9_4
 G  disj1_3_4_4
 G  disj2_3_4_4
 G  disj1_3_5_4
 G  disj2_3_5_4
 G  disj1_3_6_4
 G  disj2_3_6_4
 G  disj1_3_7_4
 G  disj2_3_7_4
 G  disj1_3_8_4
 G  disj2_3_8_4
 G  disj1_3_9_4
 G  disj2_3_9_4
 G  disj1_4_5_4
 G  disj2_4_5_4
 G  disj1_4_6_4
 G  disj2_4_6_4
 G  disj1_4_7_4
 G  disj2_4_7_4
 G  disj1_4_8_4
 G  disj2_4_8_4
 G  disj1_4_9_4
 G  disj2_4_9_4
 G  disj1_5_6_4
 G  disj2_5_6_4
 G  disj1_5_7_4
 G  disj2_5_7_4
 G  disj1_5_8_4
 G  disj2_5_8_4
 G  disj1_5_9_4
 G  disj2_5_9_4
 G  disj1_6_7_4
 G  disj2_6_7_4
 G  disj1_6_8_4
 G  disj2_6_8_4
 G  disj1_6_9_4
 G  disj2_6_9_4
 G  disj1_7_8_4
 G  disj2_7_8_4
 G  disj1_7_9_4
 G  disj2_7_9_4
 G  disj1_8_9_4
 G  disj2_8_9_4
 G  disj1_0_1_5
 G  disj2_0_1_5
 G  disj1_0_2_5
 G  disj2_0_2_5
 G  disj1_0_3_5
 G  disj2_0_3_5
 G  disj1_0_4_5
 G  disj2_0_4_5
 G  disj1_0_5_5
 G  disj2_0_5_5
 G  disj1_0_6_5
 G  disj2_0_6_5
 G  disj1_0_7_5
 G  disj2_0_7_5
 G  disj1_0_8_5
 G  disj2_0_8_5
 G  disj1_0_9_5
 G  disj2_0_9_5
 G  disj1_1_2_5
 G  disj2_1_2_5
 G  disj1_1_3_5
 G  disj2_1_3_5
 G  disj1_1_4_5
 G  disj2_1_4_5
 G  disj1_1_5_5
 G  disj2_1_5_5
 G  disj1_1_6_5
 G  disj2_1_6_5
 G  disj1_1_7_5
 G  disj2_1_7_5
 G  disj1_1_8_5
 G  disj2_1_8_5
 G  disj1_1_9_5
 G  disj2_1_9_5
 G  disj1_2_3_5
 G  disj2_2_3_5
 G  disj1_2_4_5
 G  disj2_2_4_5
 G  disj1_2_5_5
 G  disj2_2_5_5
 G  disj1_2_6_5
 G  disj2_2_6_5
 G  disj1_2_7_5
 G  disj2_2_7_5
 G  disj1_2_8_5
 G  disj2_2_8_5
 G  disj1_2_9_5
 G  disj2_2_9_5
 G  disj1_3_4_5
 G  disj2_3_4_5
 G  disj1_3_5_5
 G  disj2_3_5_5
 G  disj1_3_6_5
 G  disj2_3_6_5
 G  disj1_3_7_5
 G  disj2_3_7_5
 G  disj1_3_8_5
 G  disj2_3_8_5
 G  disj1_3_9_5
 G  disj2_3_9_5
 G  disj1_4_5_5
 G  disj2_4_5_5
 G  disj1_4_6_5
 G  disj2_4_6_5
 G  disj1_4_7_5
 G  disj2_4_7_5
 G  disj1_4_8_5
 G  disj2_4_8_5
 G  disj1_4_9_5
 G  disj2_4_9_5
 G  disj1_5_6_5
 G  disj2_5_6_5
 G  disj1_5_7_5
 G  disj2_5_7_5
 G  disj1_5_8_5
 G  disj2_5_8_5
 G  disj1_5_9_5
 G  disj2_5_9_5
 G  disj1_6_7_5
 G  disj2_6_7_5
 G  disj1_6_8_5
 G  disj2_6_8_5
 G  disj1_6_9_5
 G  disj2_6_9_5
 G  disj1_7_8_5
 G  disj2_7_8_5
 G  disj1_7_9_5
 G  disj2_7_9_5
 G  disj1_8_9_5
 G  disj2_8_9_5
 G  disj1_0_1_6
 G  disj2_0_1_6
 G  disj1_0_2_6
 G  disj2_0_2_6
 G  disj1_0_3_6
 G  disj2_0_3_6
 G  disj1_0_4_6
 G  disj2_0_4_6
 G  disj1_0_5_6
 G  disj2_0_5_6
 G  disj1_0_6_6
 G  disj2_0_6_6
 G  disj1_0_7_6
 G  disj2_0_7_6
 G  disj1_0_8_6
 G  disj2_0_8_6
 G  disj1_0_9_6
 G  disj2_0_9_6
 G  disj1_1_2_6
 G  disj2_1_2_6
 G  disj1_1_3_6
 G  disj2_1_3_6
 G  disj1_1_4_6
 G  disj2_1_4_6
 G  disj1_1_5_6
 G  disj2_1_5_6
 G  disj1_1_6_6
 G  disj2_1_6_6
 G  disj1_1_7_6
 G  disj2_1_7_6
 G  disj1_1_8_6
 G  disj2_1_8_6
 G  disj1_1_9_6
 G  disj2_1_9_6
 G  disj1_2_3_6
 G  disj2_2_3_6
 G  disj1_2_4_6
 G  disj2_2_4_6
 G  disj1_2_5_6
 G  disj2_2_5_6
 G  disj1_2_6_6
 G  disj2_2_6_6
 G  disj1_2_7_6
 G  disj2_2_7_6
 G  disj1_2_8_6
 G  disj2_2_8_6
 G  disj1_2_9_6
 G  disj2_2_9_6
 G  disj1_3_4_6
 G  disj2_3_4_6
 G  disj1_3_5_6
 G  disj2_3_5_6
 G  disj1_3_6_6
 G  disj2_3_6_6
 G  disj1_3_7_6
 G  disj2_3_7_6
 G  disj1_3_8_6
 G  disj2_3_8_6
 G  disj1_3_9_6
 G  disj2_3_9_6
 G  disj1_4_5_6
 G  disj2_4_5_6
 G  disj1_4_6_6
 G  disj2_4_6_6
 G  disj1_4_7_6
 G  disj2_4_7_6
 G  disj1_4_8_6
 G  disj2_4_8_6
 G  disj1_4_9_6
 G  disj2_4_9_6
 G  disj1_5_6_6
 G  disj2_5_6_6
 G  disj1_5_7_6
 G  disj2_5_7_6
 G  disj1_5_8_6
 G  disj2_5_8_6
 G  disj1_5_9_6
 G  disj2_5_9_6
 G  disj1_6_7_6
 G  disj2_6_7_6
 G  disj1_6_8_6
 G  disj2_6_8_6
 G  disj1_6_9_6
 G  disj2_6_9_6
 G  disj1_7_8_6
 G  disj2_7_8_6
 G  disj1_7_9_6
 G  disj2_7_9_6
 G  disj1_8_9_6
 G  disj2_8_9_6
 G  disj1_0_1_7
 G  disj2_0_1_7
 G  disj1_0_2_7
 G  disj2_0_2_7
 G  disj1_0_3_7
 G  disj2_0_3_7
 G  disj1_0_4_7
 G  disj2_0_4_7
 G  disj1_0_5_7
 G  disj2_0_5_7
 G  disj1_0_6_7
 G  disj2_0_6_7
 G  disj1_0_7_7
 G  disj2_0_7_7
 G  disj1_0_8_7
 G  disj2_0_8_7
 G  disj1_0_9_7
 G  disj2_0_9_7
 G  disj1_1_2_7
 G  disj2_1_2_7
 G  disj1_1_3_7
 G  disj2_1_3_7
 G  disj1_1_4_7
 G  disj2_1_4_7
 G  disj1_1_5_7
 G  disj2_1_5_7
 G  disj1_1_6_7
 G  disj2_1_6_7
 G  disj1_1_7_7
 G  disj2_1_7_7
 G  disj1_1_8_7
 G  disj2_1_8_7
 G  disj1_1_9_7
 G  disj2_1_9_7
 G  disj1_2_3_7
 G  disj2_2_3_7
 G  disj1_2_4_7
 G  disj2_2_4_7
 G  disj1_2_5_7
 G  disj2_2_5_7
 G  disj1_2_6_7
 G  disj2_2_6_7
 G  disj1_2_7_7
 G  disj2_2_7_7
 G  disj1_2_8_7
 G  disj2_2_8_7
 G  disj1_2_9_7
 G  disj2_2_9_7
 G  disj1_3_4_7
 G  disj2_3_4_7
 G  disj1_3_5_7
 G  disj2_3_5_7
 G  disj1_3_6_7
 G  disj2_3_6_7
 G  disj1_3_7_7
 G  disj2_3_7_7
 G  disj1_3_8_7
 G  disj2_3_8_7
 G  disj1_3_9_7
 G  disj2_3_9_7
 G  disj1_4_5_7
 G  disj2_4_5_7
 G  disj1_4_6_7
 G  disj2_4_6_7
 G  disj1_4_7_7
 G  disj2_4_7_7
 G  disj1_4_8_7
 G  disj2_4_8_7
 G  disj1_4_9_7
 G  disj2_4_9_7
 G  disj1_5_6_7
 G  disj2_5_6_7
 G  disj1_5_7_7
 G  disj2_5_7_7
 G  disj1_5_8_7
 G  disj2_5_8_7
 G  disj1_5_9_7
 G  disj2_5_9_7
 G  disj1_6_7_7
 G  disj2_6_7_7
 G  disj1_6_8_7
 G  disj2_6_8_7
 G  disj1_6_9_7
 G  disj2_6_9_7
 G  disj1_7_8_7
 G  disj2_7_8_7
 G  disj1_7_9_7
 G  disj2_7_9_7
 G  disj1_8_9_7
 G  disj2_8_9_7
 G  disj1_0_1_8
 G  disj2_0_1_8
 G  disj1_0_2_8
 G  disj2_0_2_8
 G  disj1_0_3_8
 G  disj2_0_3_8
 G  disj1_0_4_8
 G  disj2_0_4_8
 G  disj1_0_5_8
 G  disj2_0_5_8
 G  disj1_0_6_8
 G  disj2_0_6_8
 G  disj1_0_7_8
 G  disj2_0_7_8
 G  disj1_0_8_8
 G  disj2_0_8_8
 G  disj1_0_9_8
 G  disj2_0_9_8
 G  disj1_1_2_8
 G  disj2_1_2_8
 G  disj1_1_3_8
 G  disj2_1_3_8
 G  disj1_1_4_8
 G  disj2_1_4_8
 G  disj1_1_5_8
 G  disj2_1_5_8
 G  disj1_1_6_8
 G  disj2_1_6_8
 G  disj1_1_7_8
 G  disj2_1_7_8
 G  disj1_1_8_8
 G  disj2_1_8_8
 G  disj1_1_9_8
 G  disj2_1_9_8
 G  disj1_2_3_8
 G  disj2_2_3_8
 G  disj1_2_4_8
 G  disj2_2_4_8
 G  disj1_2_5_8
 G  disj2_2_5_8
 G  disj1_2_6_8
 G  disj2_2_6_8
 G  disj1_2_7_8
 G  disj2_2_7_8
 G  disj1_2_8_8
 G  disj2_2_8_8
 G  disj1_2_9_8
 G  disj2_2_9_8
 G  disj1_3_4_8
 G  disj2_3_4_8
 G  disj1_3_5_8
 G  disj2_3_5_8
 G  disj1_3_6_8
 G  disj2_3_6_8
 G  disj1_3_7_8
 G  disj2_3_7_8
 G  disj1_3_8_8
 G  disj2_3_8_8
 G  disj1_3_9_8
 G  disj2_3_9_8
 G  disj1_4_5_8
 G  disj2_4_5_8
 G  disj1_4_6_8
 G  disj2_4_6_8
 G  disj1_4_7_8
 G  disj2_4_7_8
 G  disj1_4_8_8
 G  disj2_4_8_8
 G  disj1_4_9_8
 G  disj2_4_9_8
 G  disj1_5_6_8
 G  disj2_5_6_8
 G  disj1_5_7_8
 G  disj2_5_7_8
 G  disj1_5_8_8
 G  disj2_5_8_8
 G  disj1_5_9_8
 G  disj2_5_9_8
 G  disj1_6_7_8
 G  disj2_6_7_8
 G  disj1_6_8_8
 G  disj2_6_8_8
 G  disj1_6_9_8
 G  disj2_6_9_8
 G  disj1_7_8_8
 G  disj2_7_8_8
 G  disj1_7_9_8
 G  disj2_7_9_8
 G  disj1_8_9_8
 G  disj2_8_9_8
 G  disj1_0_1_9
 G  disj2_0_1_9
 G  disj1_0_2_9
 G  disj2_0_2_9
 G  disj1_0_3_9
 G  disj2_0_3_9
 G  disj1_0_4_9
 G  disj2_0_4_9
 G  disj1_0_5_9
 G  disj2_0_5_9
 G  disj1_0_6_9
 G  disj2_0_6_9
 G  disj1_0_7_9
 G  disj2_0_7_9
 G  disj1_0_8_9
 G  disj2_0_8_9
 G  disj1_0_9_9
 G  disj2_0_9_9
 G  disj1_1_2_9
 G  disj2_1_2_9
 G  disj1_1_3_9
 G  disj2_1_3_9
 G  disj1_1_4_9
 G  disj2_1_4_9
 G  disj1_1_5_9
 G  disj2_1_5_9
 G  disj1_1_6_9
 G  disj2_1_6_9
 G  disj1_1_7_9
 G  disj2_1_7_9
 G  disj1_1_8_9
 G  disj2_1_8_9
 G  disj1_1_9_9
 G  disj2_1_9_9
 G  disj1_2_3_9
 G  disj2_2_3_9
 G  disj1_2_4_9
 G  disj2_2_4_9
 G  disj1_2_5_9
 G  disj2_2_5_9
 G  disj1_2_6_9
 G  disj2_2_6_9
 G  disj1_2_7_9
 G  disj2_2_7_9
 G  disj1_2_8_9
 G  disj2_2_8_9
 G  disj1_2_9_9
 G  disj2_2_9_9
 G  disj1_3_4_9
 G  disj2_3_4_9
 G  disj1_3_5_9
 G  disj2_3_5_9
 G  disj1_3_6_9
 G  disj2_3_6_9
 G  disj1_3_7_9
 G  disj2_3_7_9
 G  disj1_3_8_9
 G  disj2_3_8_9
 G  disj1_3_9_9
 G  disj2_3_9_9
 G  disj1_4_5_9
 G  disj2_4_5_9
 G  disj1_4_6_9
 G  disj2_4_6_9
 G  disj1_4_7_9
 G  disj2_4_7_9
 G  disj1_4_8_9
 G  disj2_4_8_9
 G  disj1_4_9_9
 G  disj2_4_9_9
 G  disj1_5_6_9
 G  disj2_5_6_9
 G  disj1_5_7_9
 G  disj2_5_7_9
 G  disj1_5_8_9
 G  disj2_5_8_9
 G  disj1_5_9_9
 G  disj2_5_9_9
 G  disj1_6_7_9
 G  disj2_6_7_9
 G  disj1_6_8_9
 G  disj2_6_8_9
 G  disj1_6_9_9
 G  disj2_6_9_9
 G  disj1_7_8_9
 G  disj2_7_8_9
 G  disj1_7_9_9
 G  disj2_7_9_9
 G  disj1_8_9_9
 G  disj2_8_9_9
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C         OBJ       1.0
    C         mksp_0    1.0
    C         mksp_1    1.0
    C         mksp_2    1.0
    C         mksp_3    1.0
    C         mksp_4    1.0
    C         mksp_5    1.0
    C         mksp_6    1.0
    C         mksp_7    1.0
    C         mksp_8    1.0
    C         mksp_9    1.0
    x_0_0     prec_0_0  -1.0
    x_0_0     disj1_0_1_2  -1.0
    x_0_0     disj2_0_1_2  1.0
    x_0_0     disj1_0_2_2  -1.0
    x_0_0     disj2_0_2_2  1.0
    x_0_0     disj1_0_3_2  -1.0
    x_0_0     disj2_0_3_2  1.0
    x_0_0     disj1_0_4_2  -1.0
    x_0_0     disj2_0_4_2  1.0
    x_0_0     disj1_0_5_2  -1.0
    x_0_0     disj2_0_5_2  1.0
    x_0_0     disj1_0_6_2  -1.0
    x_0_0     disj2_0_6_2  1.0
    x_0_0     disj1_0_7_2  -1.0
    x_0_0     disj2_0_7_2  1.0
    x_0_0     disj1_0_8_2  -1.0
    x_0_0     disj2_0_8_2  1.0
    x_0_0     disj1_0_9_2  -1.0
    x_0_0     disj2_0_9_2  1.0
    x_0_1     prec_0_0  1.0
    x_0_1     prec_0_1  -1.0
    x_0_1     disj1_0_1_0  -1.0
    x_0_1     disj2_0_1_0  1.0
    x_0_1     disj1_0_2_0  -1.0
    x_0_1     disj2_0_2_0  1.0
    x_0_1     disj1_0_3_0  -1.0
    x_0_1     disj2_0_3_0  1.0
    x_0_1     disj1_0_4_0  -1.0
    x_0_1     disj2_0_4_0  1.0
    x_0_1     disj1_0_5_0  -1.0
    x_0_1     disj2_0_5_0  1.0
    x_0_1     disj1_0_6_0  -1.0
    x_0_1     disj2_0_6_0  1.0
    x_0_1     disj1_0_7_0  -1.0
    x_0_1     disj2_0_7_0  1.0
    x_0_1     disj1_0_8_0  -1.0
    x_0_1     disj2_0_8_0  1.0
    x_0_1     disj1_0_9_0  -1.0
    x_0_1     disj2_0_9_0  1.0
    x_0_2     prec_0_1  1.0
    x_0_2     prec_0_2  -1.0
    x_0_2     disj1_0_1_3  -1.0
    x_0_2     disj2_0_1_3  1.0
    x_0_2     disj1_0_2_3  -1.0
    x_0_2     disj2_0_2_3  1.0
    x_0_2     disj1_0_3_3  -1.0
    x_0_2     disj2_0_3_3  1.0
    x_0_2     disj1_0_4_3  -1.0
    x_0_2     disj2_0_4_3  1.0
    x_0_2     disj1_0_5_3  -1.0
    x_0_2     disj2_0_5_3  1.0
    x_0_2     disj1_0_6_3  -1.0
    x_0_2     disj2_0_6_3  1.0
    x_0_2     disj1_0_7_3  -1.0
    x_0_2     disj2_0_7_3  1.0
    x_0_2     disj1_0_8_3  -1.0
    x_0_2     disj2_0_8_3  1.0
    x_0_2     disj1_0_9_3  -1.0
    x_0_2     disj2_0_9_3  1.0
    x_0_3     prec_0_2  1.0
    x_0_3     prec_0_3  -1.0
    x_0_3     disj1_0_1_1  -1.0
    x_0_3     disj2_0_1_1  1.0
    x_0_3     disj1_0_2_1  -1.0
    x_0_3     disj2_0_2_1  1.0
    x_0_3     disj1_0_3_1  -1.0
    x_0_3     disj2_0_3_1  1.0
    x_0_3     disj1_0_4_1  -1.0
    x_0_3     disj2_0_4_1  1.0
    x_0_3     disj1_0_5_1  -1.0
    x_0_3     disj2_0_5_1  1.0
    x_0_3     disj1_0_6_1  -1.0
    x_0_3     disj2_0_6_1  1.0
    x_0_3     disj1_0_7_1  -1.0
    x_0_3     disj2_0_7_1  1.0
    x_0_3     disj1_0_8_1  -1.0
    x_0_3     disj2_0_8_1  1.0
    x_0_3     disj1_0_9_1  -1.0
    x_0_3     disj2_0_9_1  1.0
    x_0_4     prec_0_3  1.0
    x_0_4     prec_0_4  -1.0
    x_0_4     disj1_0_1_4  -1.0
    x_0_4     disj2_0_1_4  1.0
    x_0_4     disj1_0_2_4  -1.0
    x_0_4     disj2_0_2_4  1.0
    x_0_4     disj1_0_3_4  -1.0
    x_0_4     disj2_0_3_4  1.0
    x_0_4     disj1_0_4_4  -1.0
    x_0_4     disj2_0_4_4  1.0
    x_0_4     disj1_0_5_4  -1.0
    x_0_4     disj2_0_5_4  1.0
    x_0_4     disj1_0_6_4  -1.0
    x_0_4     disj2_0_6_4  1.0
    x_0_4     disj1_0_7_4  -1.0
    x_0_4     disj2_0_7_4  1.0
    x_0_4     disj1_0_8_4  -1.0
    x_0_4     disj2_0_8_4  1.0
    x_0_4     disj1_0_9_4  -1.0
    x_0_4     disj2_0_9_4  1.0
    x_0_5     prec_0_4  1.0
    x_0_5     prec_0_5  -1.0
    x_0_5     disj1_0_1_5  -1.0
    x_0_5     disj2_0_1_5  1.0
    x_0_5     disj1_0_2_5  -1.0
    x_0_5     disj2_0_2_5  1.0
    x_0_5     disj1_0_3_5  -1.0
    x_0_5     disj2_0_3_5  1.0
    x_0_5     disj1_0_4_5  -1.0
    x_0_5     disj2_0_4_5  1.0
    x_0_5     disj1_0_5_5  -1.0
    x_0_5     disj2_0_5_5  1.0
    x_0_5     disj1_0_6_5  -1.0
    x_0_5     disj2_0_6_5  1.0
    x_0_5     disj1_0_7_5  -1.0
    x_0_5     disj2_0_7_5  1.0
    x_0_5     disj1_0_8_5  -1.0
    x_0_5     disj2_0_8_5  1.0
    x_0_5     disj1_0_9_5  -1.0
    x_0_5     disj2_0_9_5  1.0
    x_0_6     prec_0_5  1.0
    x_0_6     prec_0_6  -1.0
    x_0_6     disj1_0_1_7  -1.0
    x_0_6     disj2_0_1_7  1.0
    x_0_6     disj1_0_2_7  -1.0
    x_0_6     disj2_0_2_7  1.0
    x_0_6     disj1_0_3_7  -1.0
    x_0_6     disj2_0_3_7  1.0
    x_0_6     disj1_0_4_7  -1.0
    x_0_6     disj2_0_4_7  1.0
    x_0_6     disj1_0_5_7  -1.0
    x_0_6     disj2_0_5_7  1.0
    x_0_6     disj1_0_6_7  -1.0
    x_0_6     disj2_0_6_7  1.0
    x_0_6     disj1_0_7_7  -1.0
    x_0_6     disj2_0_7_7  1.0
    x_0_6     disj1_0_8_7  -1.0
    x_0_6     disj2_0_8_7  1.0
    x_0_6     disj1_0_9_7  -1.0
    x_0_6     disj2_0_9_7  1.0
    x_0_7     prec_0_6  1.0
    x_0_7     prec_0_7  -1.0
    x_0_7     disj1_0_1_6  -1.0
    x_0_7     disj2_0_1_6  1.0
    x_0_7     disj1_0_2_6  -1.0
    x_0_7     disj2_0_2_6  1.0
    x_0_7     disj1_0_3_6  -1.0
    x_0_7     disj2_0_3_6  1.0
    x_0_7     disj1_0_4_6  -1.0
    x_0_7     disj2_0_4_6  1.0
    x_0_7     disj1_0_5_6  -1.0
    x_0_7     disj2_0_5_6  1.0
    x_0_7     disj1_0_6_6  -1.0
    x_0_7     disj2_0_6_6  1.0
    x_0_7     disj1_0_7_6  -1.0
    x_0_7     disj2_0_7_6  1.0
    x_0_7     disj1_0_8_6  -1.0
    x_0_7     disj2_0_8_6  1.0
    x_0_7     disj1_0_9_6  -1.0
    x_0_7     disj2_0_9_6  1.0
    x_0_8     prec_0_7  1.0
    x_0_8     prec_0_8  -1.0
    x_0_8     disj1_0_1_9  -1.0
    x_0_8     disj2_0_1_9  1.0
    x_0_8     disj1_0_2_9  -1.0
    x_0_8     disj2_0_2_9  1.0
    x_0_8     disj1_0_3_9  -1.0
    x_0_8     disj2_0_3_9  1.0
    x_0_8     disj1_0_4_9  -1.0
    x_0_8     disj2_0_4_9  1.0
    x_0_8     disj1_0_5_9  -1.0
    x_0_8     disj2_0_5_9  1.0
    x_0_8     disj1_0_6_9  -1.0
    x_0_8     disj2_0_6_9  1.0
    x_0_8     disj1_0_7_9  -1.0
    x_0_8     disj2_0_7_9  1.0
    x_0_8     disj1_0_8_9  -1.0
    x_0_8     disj2_0_8_9  1.0
    x_0_8     disj1_0_9_9  -1.0
    x_0_8     disj2_0_9_9  1.0
    x_0_9     prec_0_8  1.0
    x_0_9     mksp_0    -1.0
    x_0_9     disj1_0_1_8  -1.0
    x_0_9     disj2_0_1_8  1.0
    x_0_9     disj1_0_2_8  -1.0
    x_0_9     disj2_0_2_8  1.0
    x_0_9     disj1_0_3_8  -1.0
    x_0_9     disj2_0_3_8  1.0
    x_0_9     disj1_0_4_8  -1.0
    x_0_9     disj2_0_4_8  1.0
    x_0_9     disj1_0_5_8  -1.0
    x_0_9     disj2_0_5_8  1.0
    x_0_9     disj1_0_6_8  -1.0
    x_0_9     disj2_0_6_8  1.0
    x_0_9     disj1_0_7_8  -1.0
    x_0_9     disj2_0_7_8  1.0
    x_0_9     disj1_0_8_8  -1.0
    x_0_9     disj2_0_8_8  1.0
    x_0_9     disj1_0_9_8  -1.0
    x_0_9     disj2_0_9_8  1.0
    x_1_0     prec_1_0  -1.0
    x_1_0     disj1_0_1_1  1.0
    x_1_0     disj2_0_1_1  -1.0
    x_1_0     disj1_1_2_1  -1.0
    x_1_0     disj2_1_2_1  1.0
    x_1_0     disj1_1_3_1  -1.0
    x_1_0     disj2_1_3_1  1.0
    x_1_0     disj1_1_4_1  -1.0
    x_1_0     disj2_1_4_1  1.0
    x_1_0     disj1_1_5_1  -1.0
    x_1_0     disj2_1_5_1  1.0
    x_1_0     disj1_1_6_1  -1.0
    x_1_0     disj2_1_6_1  1.0
    x_1_0     disj1_1_7_1  -1.0
    x_1_0     disj2_1_7_1  1.0
    x_1_0     disj1_1_8_1  -1.0
    x_1_0     disj2_1_8_1  1.0
    x_1_0     disj1_1_9_1  -1.0
    x_1_0     disj2_1_9_1  1.0
    x_1_1     prec_1_0  1.0
    x_1_1     prec_1_1  -1.0
    x_1_1     disj1_0_1_4  1.0
    x_1_1     disj2_0_1_4  -1.0
    x_1_1     disj1_1_2_4  -1.0
    x_1_1     disj2_1_2_4  1.0
    x_1_1     disj1_1_3_4  -1.0
    x_1_1     disj2_1_3_4  1.0
    x_1_1     disj1_1_4_4  -1.0
    x_1_1     disj2_1_4_4  1.0
    x_1_1     disj1_1_5_4  -1.0
    x_1_1     disj2_1_5_4  1.0
    x_1_1     disj1_1_6_4  -1.0
    x_1_1     disj2_1_6_4  1.0
    x_1_1     disj1_1_7_4  -1.0
    x_1_1     disj2_1_7_4  1.0
    x_1_1     disj1_1_8_4  -1.0
    x_1_1     disj2_1_8_4  1.0
    x_1_1     disj1_1_9_4  -1.0
    x_1_1     disj2_1_9_4  1.0
    x_1_2     prec_1_1  1.0
    x_1_2     prec_1_2  -1.0
    x_1_2     disj1_0_1_3  1.0
    x_1_2     disj2_0_1_3  -1.0
    x_1_2     disj1_1_2_3  -1.0
    x_1_2     disj2_1_2_3  1.0
    x_1_2     disj1_1_3_3  -1.0
    x_1_2     disj2_1_3_3  1.0
    x_1_2     disj1_1_4_3  -1.0
    x_1_2     disj2_1_4_3  1.0
    x_1_2     disj1_1_5_3  -1.0
    x_1_2     disj2_1_5_3  1.0
    x_1_2     disj1_1_6_3  -1.0
    x_1_2     disj2_1_6_3  1.0
    x_1_2     disj1_1_7_3  -1.0
    x_1_2     disj2_1_7_3  1.0
    x_1_2     disj1_1_8_3  -1.0
    x_1_2     disj2_1_8_3  1.0
    x_1_2     disj1_1_9_3  -1.0
    x_1_2     disj2_1_9_3  1.0
    x_1_3     prec_1_2  1.0
    x_1_3     prec_1_3  -1.0
    x_1_3     disj1_0_1_0  1.0
    x_1_3     disj2_0_1_0  -1.0
    x_1_3     disj1_1_2_0  -1.0
    x_1_3     disj2_1_2_0  1.0
    x_1_3     disj1_1_3_0  -1.0
    x_1_3     disj2_1_3_0  1.0
    x_1_3     disj1_1_4_0  -1.0
    x_1_3     disj2_1_4_0  1.0
    x_1_3     disj1_1_5_0  -1.0
    x_1_3     disj2_1_5_0  1.0
    x_1_3     disj1_1_6_0  -1.0
    x_1_3     disj2_1_6_0  1.0
    x_1_3     disj1_1_7_0  -1.0
    x_1_3     disj2_1_7_0  1.0
    x_1_3     disj1_1_8_0  -1.0
    x_1_3     disj2_1_8_0  1.0
    x_1_3     disj1_1_9_0  -1.0
    x_1_3     disj2_1_9_0  1.0
    x_1_4     prec_1_3  1.0
    x_1_4     prec_1_4  -1.0
    x_1_4     disj1_0_1_2  1.0
    x_1_4     disj2_0_1_2  -1.0
    x_1_4     disj1_1_2_2  -1.0
    x_1_4     disj2_1_2_2  1.0
    x_1_4     disj1_1_3_2  -1.0
    x_1_4     disj2_1_3_2  1.0
    x_1_4     disj1_1_4_2  -1.0
    x_1_4     disj2_1_4_2  1.0
    x_1_4     disj1_1_5_2  -1.0
    x_1_4     disj2_1_5_2  1.0
    x_1_4     disj1_1_6_2  -1.0
    x_1_4     disj2_1_6_2  1.0
    x_1_4     disj1_1_7_2  -1.0
    x_1_4     disj2_1_7_2  1.0
    x_1_4     disj1_1_8_2  -1.0
    x_1_4     disj2_1_8_2  1.0
    x_1_4     disj1_1_9_2  -1.0
    x_1_4     disj2_1_9_2  1.0
    x_1_5     prec_1_4  1.0
    x_1_5     prec_1_5  -1.0
    x_1_5     disj1_0_1_6  1.0
    x_1_5     disj2_0_1_6  -1.0
    x_1_5     disj1_1_2_6  -1.0
    x_1_5     disj2_1_2_6  1.0
    x_1_5     disj1_1_3_6  -1.0
    x_1_5     disj2_1_3_6  1.0
    x_1_5     disj1_1_4_6  -1.0
    x_1_5     disj2_1_4_6  1.0
    x_1_5     disj1_1_5_6  -1.0
    x_1_5     disj2_1_5_6  1.0
    x_1_5     disj1_1_6_6  -1.0
    x_1_5     disj2_1_6_6  1.0
    x_1_5     disj1_1_7_6  -1.0
    x_1_5     disj2_1_7_6  1.0
    x_1_5     disj1_1_8_6  -1.0
    x_1_5     disj2_1_8_6  1.0
    x_1_5     disj1_1_9_6  -1.0
    x_1_5     disj2_1_9_6  1.0
    x_1_6     prec_1_5  1.0
    x_1_6     prec_1_6  -1.0
    x_1_6     disj1_0_1_5  1.0
    x_1_6     disj2_0_1_5  -1.0
    x_1_6     disj1_1_2_5  -1.0
    x_1_6     disj2_1_2_5  1.0
    x_1_6     disj1_1_3_5  -1.0
    x_1_6     disj2_1_3_5  1.0
    x_1_6     disj1_1_4_5  -1.0
    x_1_6     disj2_1_4_5  1.0
    x_1_6     disj1_1_5_5  -1.0
    x_1_6     disj2_1_5_5  1.0
    x_1_6     disj1_1_6_5  -1.0
    x_1_6     disj2_1_6_5  1.0
    x_1_6     disj1_1_7_5  -1.0
    x_1_6     disj2_1_7_5  1.0
    x_1_6     disj1_1_8_5  -1.0
    x_1_6     disj2_1_8_5  1.0
    x_1_6     disj1_1_9_5  -1.0
    x_1_6     disj2_1_9_5  1.0
    x_1_7     prec_1_6  1.0
    x_1_7     prec_1_7  -1.0
    x_1_7     disj1_0_1_8  1.0
    x_1_7     disj2_0_1_8  -1.0
    x_1_7     disj1_1_2_8  -1.0
    x_1_7     disj2_1_2_8  1.0
    x_1_7     disj1_1_3_8  -1.0
    x_1_7     disj2_1_3_8  1.0
    x_1_7     disj1_1_4_8  -1.0
    x_1_7     disj2_1_4_8  1.0
    x_1_7     disj1_1_5_8  -1.0
    x_1_7     disj2_1_5_8  1.0
    x_1_7     disj1_1_6_8  -1.0
    x_1_7     disj2_1_6_8  1.0
    x_1_7     disj1_1_7_8  -1.0
    x_1_7     disj2_1_7_8  1.0
    x_1_7     disj1_1_8_8  -1.0
    x_1_7     disj2_1_8_8  1.0
    x_1_7     disj1_1_9_8  -1.0
    x_1_7     disj2_1_9_8  1.0
    x_1_8     prec_1_7  1.0
    x_1_8     prec_1_8  -1.0
    x_1_8     disj1_0_1_9  1.0
    x_1_8     disj2_0_1_9  -1.0
    x_1_8     disj1_1_2_9  -1.0
    x_1_8     disj2_1_2_9  1.0
    x_1_8     disj1_1_3_9  -1.0
    x_1_8     disj2_1_3_9  1.0
    x_1_8     disj1_1_4_9  -1.0
    x_1_8     disj2_1_4_9  1.0
    x_1_8     disj1_1_5_9  -1.0
    x_1_8     disj2_1_5_9  1.0
    x_1_8     disj1_1_6_9  -1.0
    x_1_8     disj2_1_6_9  1.0
    x_1_8     disj1_1_7_9  -1.0
    x_1_8     disj2_1_7_9  1.0
    x_1_8     disj1_1_8_9  -1.0
    x_1_8     disj2_1_8_9  1.0
    x_1_8     disj1_1_9_9  -1.0
    x_1_8     disj2_1_9_9  1.0
    x_1_9     prec_1_8  1.0
    x_1_9     mksp_1    -1.0
    x_1_9     disj1_0_1_7  1.0
    x_1_9     disj2_0_1_7  -1.0
    x_1_9     disj1_1_2_7  -1.0
    x_1_9     disj2_1_2_7  1.0
    x_1_9     disj1_1_3_7  -1.0
    x_1_9     disj2_1_3_7  1.0
    x_1_9     disj1_1_4_7  -1.0
    x_1_9     disj2_1_4_7  1.0
    x_1_9     disj1_1_5_7  -1.0
    x_1_9     disj2_1_5_7  1.0
    x_1_9     disj1_1_6_7  -1.0
    x_1_9     disj2_1_6_7  1.0
    x_1_9     disj1_1_7_7  -1.0
    x_1_9     disj2_1_7_7  1.0
    x_1_9     disj1_1_8_7  -1.0
    x_1_9     disj2_1_8_7  1.0
    x_1_9     disj1_1_9_7  -1.0
    x_1_9     disj2_1_9_7  1.0
    x_2_0     prec_2_0  -1.0
    x_2_0     disj1_0_2_3  1.0
    x_2_0     disj2_0_2_3  -1.0
    x_2_0     disj1_1_2_3  1.0
    x_2_0     disj2_1_2_3  -1.0
    x_2_0     disj1_2_3_3  -1.0
    x_2_0     disj2_2_3_3  1.0
    x_2_0     disj1_2_4_3  -1.0
    x_2_0     disj2_2_4_3  1.0
    x_2_0     disj1_2_5_3  -1.0
    x_2_0     disj2_2_5_3  1.0
    x_2_0     disj1_2_6_3  -1.0
    x_2_0     disj2_2_6_3  1.0
    x_2_0     disj1_2_7_3  -1.0
    x_2_0     disj2_2_7_3  1.0
    x_2_0     disj1_2_8_3  -1.0
    x_2_0     disj2_2_8_3  1.0
    x_2_0     disj1_2_9_3  -1.0
    x_2_0     disj2_2_9_3  1.0
    x_2_1     prec_2_0  1.0
    x_2_1     prec_2_1  -1.0
    x_2_1     disj1_0_2_2  1.0
    x_2_1     disj2_0_2_2  -1.0
    x_2_1     disj1_1_2_2  1.0
    x_2_1     disj2_1_2_2  -1.0
    x_2_1     disj1_2_3_2  -1.0
    x_2_1     disj2_2_3_2  1.0
    x_2_1     disj1_2_4_2  -1.0
    x_2_1     disj2_2_4_2  1.0
    x_2_1     disj1_2_5_2  -1.0
    x_2_1     disj2_2_5_2  1.0
    x_2_1     disj1_2_6_2  -1.0
    x_2_1     disj2_2_6_2  1.0
    x_2_1     disj1_2_7_2  -1.0
    x_2_1     disj2_2_7_2  1.0
    x_2_1     disj1_2_8_2  -1.0
    x_2_1     disj2_2_8_2  1.0
    x_2_1     disj1_2_9_2  -1.0
    x_2_1     disj2_2_9_2  1.0
    x_2_2     prec_2_1  1.0
    x_2_2     prec_2_2  -1.0
    x_2_2     disj1_0_2_0  1.0
    x_2_2     disj2_0_2_0  -1.0
    x_2_2     disj1_1_2_0  1.0
    x_2_2     disj2_1_2_0  -1.0
    x_2_2     disj1_2_3_0  -1.0
    x_2_2     disj2_2_3_0  1.0
    x_2_2     disj1_2_4_0  -1.0
    x_2_2     disj2_2_4_0  1.0
    x_2_2     disj1_2_5_0  -1.0
    x_2_2     disj2_2_5_0  1.0
    x_2_2     disj1_2_6_0  -1.0
    x_2_2     disj2_2_6_0  1.0
    x_2_2     disj1_2_7_0  -1.0
    x_2_2     disj2_2_7_0  1.0
    x_2_2     disj1_2_8_0  -1.0
    x_2_2     disj2_2_8_0  1.0
    x_2_2     disj1_2_9_0  -1.0
    x_2_2     disj2_2_9_0  1.0
    x_2_3     prec_2_2  1.0
    x_2_3     prec_2_3  -1.0
    x_2_3     disj1_0_2_4  1.0
    x_2_3     disj2_0_2_4  -1.0
    x_2_3     disj1_1_2_4  1.0
    x_2_3     disj2_1_2_4  -1.0
    x_2_3     disj1_2_3_4  -1.0
    x_2_3     disj2_2_3_4  1.0
    x_2_3     disj1_2_4_4  -1.0
    x_2_3     disj2_2_4_4  1.0
    x_2_3     disj1_2_5_4  -1.0
    x_2_3     disj2_2_5_4  1.0
    x_2_3     disj1_2_6_4  -1.0
    x_2_3     disj2_2_6_4  1.0
    x_2_3     disj1_2_7_4  -1.0
    x_2_3     disj2_2_7_4  1.0
    x_2_3     disj1_2_8_4  -1.0
    x_2_3     disj2_2_8_4  1.0
    x_2_3     disj1_2_9_4  -1.0
    x_2_3     disj2_2_9_4  1.0
    x_2_4     prec_2_3  1.0
    x_2_4     prec_2_4  -1.0
    x_2_4     disj1_0_2_1  1.0
    x_2_4     disj2_0_2_1  -1.0
    x_2_4     disj1_1_2_1  1.0
    x_2_4     disj2_1_2_1  -1.0
    x_2_4     disj1_2_3_1  -1.0
    x_2_4     disj2_2_3_1  1.0
    x_2_4     disj1_2_4_1  -1.0
    x_2_4     disj2_2_4_1  1.0
    x_2_4     disj1_2_5_1  -1.0
    x_2_4     disj2_2_5_1  1.0
    x_2_4     disj1_2_6_1  -1.0
    x_2_4     disj2_2_6_1  1.0
    x_2_4     disj1_2_7_1  -1.0
    x_2_4     disj2_2_7_1  1.0
    x_2_4     disj1_2_8_1  -1.0
    x_2_4     disj2_2_8_1  1.0
    x_2_4     disj1_2_9_1  -1.0
    x_2_4     disj2_2_9_1  1.0
    x_2_5     prec_2_4  1.0
    x_2_5     prec_2_5  -1.0
    x_2_5     disj1_0_2_7  1.0
    x_2_5     disj2_0_2_7  -1.0
    x_2_5     disj1_1_2_7  1.0
    x_2_5     disj2_1_2_7  -1.0
    x_2_5     disj1_2_3_7  -1.0
    x_2_5     disj2_2_3_7  1.0
    x_2_5     disj1_2_4_7  -1.0
    x_2_5     disj2_2_4_7  1.0
    x_2_5     disj1_2_5_7  -1.0
    x_2_5     disj2_2_5_7  1.0
    x_2_5     disj1_2_6_7  -1.0
    x_2_5     disj2_2_6_7  1.0
    x_2_5     disj1_2_7_7  -1.0
    x_2_5     disj2_2_7_7  1.0
    x_2_5     disj1_2_8_7  -1.0
    x_2_5     disj2_2_8_7  1.0
    x_2_5     disj1_2_9_7  -1.0
    x_2_5     disj2_2_9_7  1.0
    x_2_6     prec_2_5  1.0
    x_2_6     prec_2_6  -1.0
    x_2_6     disj1_0_2_6  1.0
    x_2_6     disj2_0_2_6  -1.0
    x_2_6     disj1_1_2_6  1.0
    x_2_6     disj2_1_2_6  -1.0
    x_2_6     disj1_2_3_6  -1.0
    x_2_6     disj2_2_3_6  1.0
    x_2_6     disj1_2_4_6  -1.0
    x_2_6     disj2_2_4_6  1.0
    x_2_6     disj1_2_5_6  -1.0
    x_2_6     disj2_2_5_6  1.0
    x_2_6     disj1_2_6_6  -1.0
    x_2_6     disj2_2_6_6  1.0
    x_2_6     disj1_2_7_6  -1.0
    x_2_6     disj2_2_7_6  1.0
    x_2_6     disj1_2_8_6  -1.0
    x_2_6     disj2_2_8_6  1.0
    x_2_6     disj1_2_9_6  -1.0
    x_2_6     disj2_2_9_6  1.0
    x_2_7     prec_2_6  1.0
    x_2_7     prec_2_7  -1.0
    x_2_7     disj1_0_2_5  1.0
    x_2_7     disj2_0_2_5  -1.0
    x_2_7     disj1_1_2_5  1.0
    x_2_7     disj2_1_2_5  -1.0
    x_2_7     disj1_2_3_5  -1.0
    x_2_7     disj2_2_3_5  1.0
    x_2_7     disj1_2_4_5  -1.0
    x_2_7     disj2_2_4_5  1.0
    x_2_7     disj1_2_5_5  -1.0
    x_2_7     disj2_2_5_5  1.0
    x_2_7     disj1_2_6_5  -1.0
    x_2_7     disj2_2_6_5  1.0
    x_2_7     disj1_2_7_5  -1.0
    x_2_7     disj2_2_7_5  1.0
    x_2_7     disj1_2_8_5  -1.0
    x_2_7     disj2_2_8_5  1.0
    x_2_7     disj1_2_9_5  -1.0
    x_2_7     disj2_2_9_5  1.0
    x_2_8     prec_2_7  1.0
    x_2_8     prec_2_8  -1.0
    x_2_8     disj1_0_2_8  1.0
    x_2_8     disj2_0_2_8  -1.0
    x_2_8     disj1_1_2_8  1.0
    x_2_8     disj2_1_2_8  -1.0
    x_2_8     disj1_2_3_8  -1.0
    x_2_8     disj2_2_3_8  1.0
    x_2_8     disj1_2_4_8  -1.0
    x_2_8     disj2_2_4_8  1.0
    x_2_8     disj1_2_5_8  -1.0
    x_2_8     disj2_2_5_8  1.0
    x_2_8     disj1_2_6_8  -1.0
    x_2_8     disj2_2_6_8  1.0
    x_2_8     disj1_2_7_8  -1.0
    x_2_8     disj2_2_7_8  1.0
    x_2_8     disj1_2_8_8  -1.0
    x_2_8     disj2_2_8_8  1.0
    x_2_8     disj1_2_9_8  -1.0
    x_2_8     disj2_2_9_8  1.0
    x_2_9     prec_2_8  1.0
    x_2_9     mksp_2    -1.0
    x_2_9     disj1_0_2_9  1.0
    x_2_9     disj2_0_2_9  -1.0
    x_2_9     disj1_1_2_9  1.0
    x_2_9     disj2_1_2_9  -1.0
    x_2_9     disj1_2_3_9  -1.0
    x_2_9     disj2_2_3_9  1.0
    x_2_9     disj1_2_4_9  -1.0
    x_2_9     disj2_2_4_9  1.0
    x_2_9     disj1_2_5_9  -1.0
    x_2_9     disj2_2_5_9  1.0
    x_2_9     disj1_2_6_9  -1.0
    x_2_9     disj2_2_6_9  1.0
    x_2_9     disj1_2_7_9  -1.0
    x_2_9     disj2_2_7_9  1.0
    x_2_9     disj1_2_8_9  -1.0
    x_2_9     disj2_2_8_9  1.0
    x_2_9     disj1_2_9_9  -1.0
    x_2_9     disj2_2_9_9  1.0
    x_3_0     prec_3_0  -1.0
    x_3_0     disj1_0_3_4  1.0
    x_3_0     disj2_0_3_4  -1.0
    x_3_0     disj1_1_3_4  1.0
    x_3_0     disj2_1_3_4  -1.0
    x_3_0     disj1_2_3_4  1.0
    x_3_0     disj2_2_3_4  -1.0
    x_3_0     disj1_3_4_4  -1.0
    x_3_0     disj2_3_4_4  1.0
    x_3_0     disj1_3_5_4  -1.0
    x_3_0     disj2_3_5_4  1.0
    x_3_0     disj1_3_6_4  -1.0
    x_3_0     disj2_3_6_4  1.0
    x_3_0     disj1_3_7_4  -1.0
    x_3_0     disj2_3_7_4  1.0
    x_3_0     disj1_3_8_4  -1.0
    x_3_0     disj2_3_8_4  1.0
    x_3_0     disj1_3_9_4  -1.0
    x_3_0     disj2_3_9_4  1.0
    x_3_1     prec_3_0  1.0
    x_3_1     prec_3_1  -1.0
    x_3_1     disj1_0_3_1  1.0
    x_3_1     disj2_0_3_1  -1.0
    x_3_1     disj1_1_3_1  1.0
    x_3_1     disj2_1_3_1  -1.0
    x_3_1     disj1_2_3_1  1.0
    x_3_1     disj2_2_3_1  -1.0
    x_3_1     disj1_3_4_1  -1.0
    x_3_1     disj2_3_4_1  1.0
    x_3_1     disj1_3_5_1  -1.0
    x_3_1     disj2_3_5_1  1.0
    x_3_1     disj1_3_6_1  -1.0
    x_3_1     disj2_3_6_1  1.0
    x_3_1     disj1_3_7_1  -1.0
    x_3_1     disj2_3_7_1  1.0
    x_3_1     disj1_3_8_1  -1.0
    x_3_1     disj2_3_8_1  1.0
    x_3_1     disj1_3_9_1  -1.0
    x_3_1     disj2_3_9_1  1.0
    x_3_2     prec_3_1  1.0
    x_3_2     prec_3_2  -1.0
    x_3_2     disj1_0_3_0  1.0
    x_3_2     disj2_0_3_0  -1.0
    x_3_2     disj1_1_3_0  1.0
    x_3_2     disj2_1_3_0  -1.0
    x_3_2     disj1_2_3_0  1.0
    x_3_2     disj2_2_3_0  -1.0
    x_3_2     disj1_3_4_0  -1.0
    x_3_2     disj2_3_4_0  1.0
    x_3_2     disj1_3_5_0  -1.0
    x_3_2     disj2_3_5_0  1.0
    x_3_2     disj1_3_6_0  -1.0
    x_3_2     disj2_3_6_0  1.0
    x_3_2     disj1_3_7_0  -1.0
    x_3_2     disj2_3_7_0  1.0
    x_3_2     disj1_3_8_0  -1.0
    x_3_2     disj2_3_8_0  1.0
    x_3_2     disj1_3_9_0  -1.0
    x_3_2     disj2_3_9_0  1.0
    x_3_3     prec_3_2  1.0
    x_3_3     prec_3_3  -1.0
    x_3_3     disj1_0_3_3  1.0
    x_3_3     disj2_0_3_3  -1.0
    x_3_3     disj1_1_3_3  1.0
    x_3_3     disj2_1_3_3  -1.0
    x_3_3     disj1_2_3_3  1.0
    x_3_3     disj2_2_3_3  -1.0
    x_3_3     disj1_3_4_3  -1.0
    x_3_3     disj2_3_4_3  1.0
    x_3_3     disj1_3_5_3  -1.0
    x_3_3     disj2_3_5_3  1.0
    x_3_3     disj1_3_6_3  -1.0
    x_3_3     disj2_3_6_3  1.0
    x_3_3     disj1_3_7_3  -1.0
    x_3_3     disj2_3_7_3  1.0
    x_3_3     disj1_3_8_3  -1.0
    x_3_3     disj2_3_8_3  1.0
    x_3_3     disj1_3_9_3  -1.0
    x_3_3     disj2_3_9_3  1.0
    x_3_4     prec_3_3  1.0
    x_3_4     prec_3_4  -1.0
    x_3_4     disj1_0_3_2  1.0
    x_3_4     disj2_0_3_2  -1.0
    x_3_4     disj1_1_3_2  1.0
    x_3_4     disj2_1_3_2  -1.0
    x_3_4     disj1_2_3_2  1.0
    x_3_4     disj2_2_3_2  -1.0
    x_3_4     disj1_3_4_2  -1.0
    x_3_4     disj2_3_4_2  1.0
    x_3_4     disj1_3_5_2  -1.0
    x_3_4     disj2_3_5_2  1.0
    x_3_4     disj1_3_6_2  -1.0
    x_3_4     disj2_3_6_2  1.0
    x_3_4     disj1_3_7_2  -1.0
    x_3_4     disj2_3_7_2  1.0
    x_3_4     disj1_3_8_2  -1.0
    x_3_4     disj2_3_8_2  1.0
    x_3_4     disj1_3_9_2  -1.0
    x_3_4     disj2_3_9_2  1.0
    x_3_5     prec_3_4  1.0
    x_3_5     prec_3_5  -1.0
    x_3_5     disj1_0_3_5  1.0
    x_3_5     disj2_0_3_5  -1.0
    x_3_5     disj1_1_3_5  1.0
    x_3_5     disj2_1_3_5  -1.0
    x_3_5     disj1_2_3_5  1.0
    x_3_5     disj2_2_3_5  -1.0
    x_3_5     disj1_3_4_5  -1.0
    x_3_5     disj2_3_4_5  1.0
    x_3_5     disj1_3_5_5  -1.0
    x_3_5     disj2_3_5_5  1.0
    x_3_5     disj1_3_6_5  -1.0
    x_3_5     disj2_3_6_5  1.0
    x_3_5     disj1_3_7_5  -1.0
    x_3_5     disj2_3_7_5  1.0
    x_3_5     disj1_3_8_5  -1.0
    x_3_5     disj2_3_8_5  1.0
    x_3_5     disj1_3_9_5  -1.0
    x_3_5     disj2_3_9_5  1.0
    x_3_6     prec_3_5  1.0
    x_3_6     prec_3_6  -1.0
    x_3_6     disj1_0_3_7  1.0
    x_3_6     disj2_0_3_7  -1.0
    x_3_6     disj1_1_3_7  1.0
    x_3_6     disj2_1_3_7  -1.0
    x_3_6     disj1_2_3_7  1.0
    x_3_6     disj2_2_3_7  -1.0
    x_3_6     disj1_3_4_7  -1.0
    x_3_6     disj2_3_4_7  1.0
    x_3_6     disj1_3_5_7  -1.0
    x_3_6     disj2_3_5_7  1.0
    x_3_6     disj1_3_6_7  -1.0
    x_3_6     disj2_3_6_7  1.0
    x_3_6     disj1_3_7_7  -1.0
    x_3_6     disj2_3_7_7  1.0
    x_3_6     disj1_3_8_7  -1.0
    x_3_6     disj2_3_8_7  1.0
    x_3_6     disj1_3_9_7  -1.0
    x_3_6     disj2_3_9_7  1.0
    x_3_7     prec_3_6  1.0
    x_3_7     prec_3_7  -1.0
    x_3_7     disj1_0_3_6  1.0
    x_3_7     disj2_0_3_6  -1.0
    x_3_7     disj1_1_3_6  1.0
    x_3_7     disj2_1_3_6  -1.0
    x_3_7     disj1_2_3_6  1.0
    x_3_7     disj2_2_3_6  -1.0
    x_3_7     disj1_3_4_6  -1.0
    x_3_7     disj2_3_4_6  1.0
    x_3_7     disj1_3_5_6  -1.0
    x_3_7     disj2_3_5_6  1.0
    x_3_7     disj1_3_6_6  -1.0
    x_3_7     disj2_3_6_6  1.0
    x_3_7     disj1_3_7_6  -1.0
    x_3_7     disj2_3_7_6  1.0
    x_3_7     disj1_3_8_6  -1.0
    x_3_7     disj2_3_8_6  1.0
    x_3_7     disj1_3_9_6  -1.0
    x_3_7     disj2_3_9_6  1.0
    x_3_8     prec_3_7  1.0
    x_3_8     prec_3_8  -1.0
    x_3_8     disj1_0_3_9  1.0
    x_3_8     disj2_0_3_9  -1.0
    x_3_8     disj1_1_3_9  1.0
    x_3_8     disj2_1_3_9  -1.0
    x_3_8     disj1_2_3_9  1.0
    x_3_8     disj2_2_3_9  -1.0
    x_3_8     disj1_3_4_9  -1.0
    x_3_8     disj2_3_4_9  1.0
    x_3_8     disj1_3_5_9  -1.0
    x_3_8     disj2_3_5_9  1.0
    x_3_8     disj1_3_6_9  -1.0
    x_3_8     disj2_3_6_9  1.0
    x_3_8     disj1_3_7_9  -1.0
    x_3_8     disj2_3_7_9  1.0
    x_3_8     disj1_3_8_9  -1.0
    x_3_8     disj2_3_8_9  1.0
    x_3_8     disj1_3_9_9  -1.0
    x_3_8     disj2_3_9_9  1.0
    x_3_9     prec_3_8  1.0
    x_3_9     mksp_3    -1.0
    x_3_9     disj1_0_3_8  1.0
    x_3_9     disj2_0_3_8  -1.0
    x_3_9     disj1_1_3_8  1.0
    x_3_9     disj2_1_3_8  -1.0
    x_3_9     disj1_2_3_8  1.0
    x_3_9     disj2_2_3_8  -1.0
    x_3_9     disj1_3_4_8  -1.0
    x_3_9     disj2_3_4_8  1.0
    x_3_9     disj1_3_5_8  -1.0
    x_3_9     disj2_3_5_8  1.0
    x_3_9     disj1_3_6_8  -1.0
    x_3_9     disj2_3_6_8  1.0
    x_3_9     disj1_3_7_8  -1.0
    x_3_9     disj2_3_7_8  1.0
    x_3_9     disj1_3_8_8  -1.0
    x_3_9     disj2_3_8_8  1.0
    x_3_9     disj1_3_9_8  -1.0
    x_3_9     disj2_3_9_8  1.0
    x_4_0     prec_4_0  -1.0
    x_4_0     disj1_0_4_0  1.0
    x_4_0     disj2_0_4_0  -1.0
    x_4_0     disj1_1_4_0  1.0
    x_4_0     disj2_1_4_0  -1.0
    x_4_0     disj1_2_4_0  1.0
    x_4_0     disj2_2_4_0  -1.0
    x_4_0     disj1_3_4_0  1.0
    x_4_0     disj2_3_4_0  -1.0
    x_4_0     disj1_4_5_0  -1.0
    x_4_0     disj2_4_5_0  1.0
    x_4_0     disj1_4_6_0  -1.0
    x_4_0     disj2_4_6_0  1.0
    x_4_0     disj1_4_7_0  -1.0
    x_4_0     disj2_4_7_0  1.0
    x_4_0     disj1_4_8_0  -1.0
    x_4_0     disj2_4_8_0  1.0
    x_4_0     disj1_4_9_0  -1.0
    x_4_0     disj2_4_9_0  1.0
    x_4_1     prec_4_0  1.0
    x_4_1     prec_4_1  -1.0
    x_4_1     disj1_0_4_3  1.0
    x_4_1     disj2_0_4_3  -1.0
    x_4_1     disj1_1_4_3  1.0
    x_4_1     disj2_1_4_3  -1.0
    x_4_1     disj1_2_4_3  1.0
    x_4_1     disj2_2_4_3  -1.0
    x_4_1     disj1_3_4_3  1.0
    x_4_1     disj2_3_4_3  -1.0
    x_4_1     disj1_4_5_3  -1.0
    x_4_1     disj2_4_5_3  1.0
    x_4_1     disj1_4_6_3  -1.0
    x_4_1     disj2_4_6_3  1.0
    x_4_1     disj1_4_7_3  -1.0
    x_4_1     disj2_4_7_3  1.0
    x_4_1     disj1_4_8_3  -1.0
    x_4_1     disj2_4_8_3  1.0
    x_4_1     disj1_4_9_3  -1.0
    x_4_1     disj2_4_9_3  1.0
    x_4_2     prec_4_1  1.0
    x_4_2     prec_4_2  -1.0
    x_4_2     disj1_0_4_1  1.0
    x_4_2     disj2_0_4_1  -1.0
    x_4_2     disj1_1_4_1  1.0
    x_4_2     disj2_1_4_1  -1.0
    x_4_2     disj1_2_4_1  1.0
    x_4_2     disj2_2_4_1  -1.0
    x_4_2     disj1_3_4_1  1.0
    x_4_2     disj2_3_4_1  -1.0
    x_4_2     disj1_4_5_1  -1.0
    x_4_2     disj2_4_5_1  1.0
    x_4_2     disj1_4_6_1  -1.0
    x_4_2     disj2_4_6_1  1.0
    x_4_2     disj1_4_7_1  -1.0
    x_4_2     disj2_4_7_1  1.0
    x_4_2     disj1_4_8_1  -1.0
    x_4_2     disj2_4_8_1  1.0
    x_4_2     disj1_4_9_1  -1.0
    x_4_2     disj2_4_9_1  1.0
    x_4_3     prec_4_2  1.0
    x_4_3     prec_4_3  -1.0
    x_4_3     disj1_0_4_2  1.0
    x_4_3     disj2_0_4_2  -1.0
    x_4_3     disj1_1_4_2  1.0
    x_4_3     disj2_1_4_2  -1.0
    x_4_3     disj1_2_4_2  1.0
    x_4_3     disj2_2_4_2  -1.0
    x_4_3     disj1_3_4_2  1.0
    x_4_3     disj2_3_4_2  -1.0
    x_4_3     disj1_4_5_2  -1.0
    x_4_3     disj2_4_5_2  1.0
    x_4_3     disj1_4_6_2  -1.0
    x_4_3     disj2_4_6_2  1.0
    x_4_3     disj1_4_7_2  -1.0
    x_4_3     disj2_4_7_2  1.0
    x_4_3     disj1_4_8_2  -1.0
    x_4_3     disj2_4_8_2  1.0
    x_4_3     disj1_4_9_2  -1.0
    x_4_3     disj2_4_9_2  1.0
    x_4_4     prec_4_3  1.0
    x_4_4     prec_4_4  -1.0
    x_4_4     disj1_0_4_4  1.0
    x_4_4     disj2_0_4_4  -1.0
    x_4_4     disj1_1_4_4  1.0
    x_4_4     disj2_1_4_4  -1.0
    x_4_4     disj1_2_4_4  1.0
    x_4_4     disj2_2_4_4  -1.0
    x_4_4     disj1_3_4_4  1.0
    x_4_4     disj2_3_4_4  -1.0
    x_4_4     disj1_4_5_4  -1.0
    x_4_4     disj2_4_5_4  1.0
    x_4_4     disj1_4_6_4  -1.0
    x_4_4     disj2_4_6_4  1.0
    x_4_4     disj1_4_7_4  -1.0
    x_4_4     disj2_4_7_4  1.0
    x_4_4     disj1_4_8_4  -1.0
    x_4_4     disj2_4_8_4  1.0
    x_4_4     disj1_4_9_4  -1.0
    x_4_4     disj2_4_9_4  1.0
    x_4_5     prec_4_4  1.0
    x_4_5     prec_4_5  -1.0
    x_4_5     disj1_0_4_6  1.0
    x_4_5     disj2_0_4_6  -1.0
    x_4_5     disj1_1_4_6  1.0
    x_4_5     disj2_1_4_6  -1.0
    x_4_5     disj1_2_4_6  1.0
    x_4_5     disj2_2_4_6  -1.0
    x_4_5     disj1_3_4_6  1.0
    x_4_5     disj2_3_4_6  -1.0
    x_4_5     disj1_4_5_6  -1.0
    x_4_5     disj2_4_5_6  1.0
    x_4_5     disj1_4_6_6  -1.0
    x_4_5     disj2_4_6_6  1.0
    x_4_5     disj1_4_7_6  -1.0
    x_4_5     disj2_4_7_6  1.0
    x_4_5     disj1_4_8_6  -1.0
    x_4_5     disj2_4_8_6  1.0
    x_4_5     disj1_4_9_6  -1.0
    x_4_5     disj2_4_9_6  1.0
    x_4_6     prec_4_5  1.0
    x_4_6     prec_4_6  -1.0
    x_4_6     disj1_0_4_7  1.0
    x_4_6     disj2_0_4_7  -1.0
    x_4_6     disj1_1_4_7  1.0
    x_4_6     disj2_1_4_7  -1.0
    x_4_6     disj1_2_4_7  1.0
    x_4_6     disj2_2_4_7  -1.0
    x_4_6     disj1_3_4_7  1.0
    x_4_6     disj2_3_4_7  -1.0
    x_4_6     disj1_4_5_7  -1.0
    x_4_6     disj2_4_5_7  1.0
    x_4_6     disj1_4_6_7  -1.0
    x_4_6     disj2_4_6_7  1.0
    x_4_6     disj1_4_7_7  -1.0
    x_4_6     disj2_4_7_7  1.0
    x_4_6     disj1_4_8_7  -1.0
    x_4_6     disj2_4_8_7  1.0
    x_4_6     disj1_4_9_7  -1.0
    x_4_6     disj2_4_9_7  1.0
    x_4_7     prec_4_6  1.0
    x_4_7     prec_4_7  -1.0
    x_4_7     disj1_0_4_5  1.0
    x_4_7     disj2_0_4_5  -1.0
    x_4_7     disj1_1_4_5  1.0
    x_4_7     disj2_1_4_5  -1.0
    x_4_7     disj1_2_4_5  1.0
    x_4_7     disj2_2_4_5  -1.0
    x_4_7     disj1_3_4_5  1.0
    x_4_7     disj2_3_4_5  -1.0
    x_4_7     disj1_4_5_5  -1.0
    x_4_7     disj2_4_5_5  1.0
    x_4_7     disj1_4_6_5  -1.0
    x_4_7     disj2_4_6_5  1.0
    x_4_7     disj1_4_7_5  -1.0
    x_4_7     disj2_4_7_5  1.0
    x_4_7     disj1_4_8_5  -1.0
    x_4_7     disj2_4_8_5  1.0
    x_4_7     disj1_4_9_5  -1.0
    x_4_7     disj2_4_9_5  1.0
    x_4_8     prec_4_7  1.0
    x_4_8     prec_4_8  -1.0
    x_4_8     disj1_0_4_8  1.0
    x_4_8     disj2_0_4_8  -1.0
    x_4_8     disj1_1_4_8  1.0
    x_4_8     disj2_1_4_8  -1.0
    x_4_8     disj1_2_4_8  1.0
    x_4_8     disj2_2_4_8  -1.0
    x_4_8     disj1_3_4_8  1.0
    x_4_8     disj2_3_4_8  -1.0
    x_4_8     disj1_4_5_8  -1.0
    x_4_8     disj2_4_5_8  1.0
    x_4_8     disj1_4_6_8  -1.0
    x_4_8     disj2_4_6_8  1.0
    x_4_8     disj1_4_7_8  -1.0
    x_4_8     disj2_4_7_8  1.0
    x_4_8     disj1_4_8_8  -1.0
    x_4_8     disj2_4_8_8  1.0
    x_4_8     disj1_4_9_8  -1.0
    x_4_8     disj2_4_9_8  1.0
    x_4_9     prec_4_8  1.0
    x_4_9     mksp_4    -1.0
    x_4_9     disj1_0_4_9  1.0
    x_4_9     disj2_0_4_9  -1.0
    x_4_9     disj1_1_4_9  1.0
    x_4_9     disj2_1_4_9  -1.0
    x_4_9     disj1_2_4_9  1.0
    x_4_9     disj2_2_4_9  -1.0
    x_4_9     disj1_3_4_9  1.0
    x_4_9     disj2_3_4_9  -1.0
    x_4_9     disj1_4_5_9  -1.0
    x_4_9     disj2_4_5_9  1.0
    x_4_9     disj1_4_6_9  -1.0
    x_4_9     disj2_4_6_9  1.0
    x_4_9     disj1_4_7_9  -1.0
    x_4_9     disj2_4_7_9  1.0
    x_4_9     disj1_4_8_9  -1.0
    x_4_9     disj2_4_8_9  1.0
    x_4_9     disj1_4_9_9  -1.0
    x_4_9     disj2_4_9_9  1.0
    x_5_0     prec_5_0  -1.0
    x_5_0     disj1_0_5_1  1.0
    x_5_0     disj2_0_5_1  -1.0
    x_5_0     disj1_1_5_1  1.0
    x_5_0     disj2_1_5_1  -1.0
    x_5_0     disj1_2_5_1  1.0
    x_5_0     disj2_2_5_1  -1.0
    x_5_0     disj1_3_5_1  1.0
    x_5_0     disj2_3_5_1  -1.0
    x_5_0     disj1_4_5_1  1.0
    x_5_0     disj2_4_5_1  -1.0
    x_5_0     disj1_5_6_1  -1.0
    x_5_0     disj2_5_6_1  1.0
    x_5_0     disj1_5_7_1  -1.0
    x_5_0     disj2_5_7_1  1.0
    x_5_0     disj1_5_8_1  -1.0
    x_5_0     disj2_5_8_1  1.0
    x_5_0     disj1_5_9_1  -1.0
    x_5_0     disj2_5_9_1  1.0
    x_5_1     prec_5_0  1.0
    x_5_1     prec_5_1  -1.0
    x_5_1     disj1_0_5_3  1.0
    x_5_1     disj2_0_5_3  -1.0
    x_5_1     disj1_1_5_3  1.0
    x_5_1     disj2_1_5_3  -1.0
    x_5_1     disj1_2_5_3  1.0
    x_5_1     disj2_2_5_3  -1.0
    x_5_1     disj1_3_5_3  1.0
    x_5_1     disj2_3_5_3  -1.0
    x_5_1     disj1_4_5_3  1.0
    x_5_1     disj2_4_5_3  -1.0
    x_5_1     disj1_5_6_3  -1.0
    x_5_1     disj2_5_6_3  1.0
    x_5_1     disj1_5_7_3  -1.0
    x_5_1     disj2_5_7_3  1.0
    x_5_1     disj1_5_8_3  -1.0
    x_5_1     disj2_5_8_3  1.0
    x_5_1     disj1_5_9_3  -1.0
    x_5_1     disj2_5_9_3  1.0
    x_5_2     prec_5_1  1.0
    x_5_2     prec_5_2  -1.0
    x_5_2     disj1_0_5_2  1.0
    x_5_2     disj2_0_5_2  -1.0
    x_5_2     disj1_1_5_2  1.0
    x_5_2     disj2_1_5_2  -1.0
    x_5_2     disj1_2_5_2  1.0
    x_5_2     disj2_2_5_2  -1.0
    x_5_2     disj1_3_5_2  1.0
    x_5_2     disj2_3_5_2  -1.0
    x_5_2     disj1_4_5_2  1.0
    x_5_2     disj2_4_5_2  -1.0
    x_5_2     disj1_5_6_2  -1.0
    x_5_2     disj2_5_6_2  1.0
    x_5_2     disj1_5_7_2  -1.0
    x_5_2     disj2_5_7_2  1.0
    x_5_2     disj1_5_8_2  -1.0
    x_5_2     disj2_5_8_2  1.0
    x_5_2     disj1_5_9_2  -1.0
    x_5_2     disj2_5_9_2  1.0
    x_5_3     prec_5_2  1.0
    x_5_3     prec_5_3  -1.0
    x_5_3     disj1_0_5_0  1.0
    x_5_3     disj2_0_5_0  -1.0
    x_5_3     disj1_1_5_0  1.0
    x_5_3     disj2_1_5_0  -1.0
    x_5_3     disj1_2_5_0  1.0
    x_5_3     disj2_2_5_0  -1.0
    x_5_3     disj1_3_5_0  1.0
    x_5_3     disj2_3_5_0  -1.0
    x_5_3     disj1_4_5_0  1.0
    x_5_3     disj2_4_5_0  -1.0
    x_5_3     disj1_5_6_0  -1.0
    x_5_3     disj2_5_6_0  1.0
    x_5_3     disj1_5_7_0  -1.0
    x_5_3     disj2_5_7_0  1.0
    x_5_3     disj1_5_8_0  -1.0
    x_5_3     disj2_5_8_0  1.0
    x_5_3     disj1_5_9_0  -1.0
    x_5_3     disj2_5_9_0  1.0
    x_5_4     prec_5_3  1.0
    x_5_4     prec_5_4  -1.0
    x_5_4     disj1_0_5_4  1.0
    x_5_4     disj2_0_5_4  -1.0
    x_5_4     disj1_1_5_4  1.0
    x_5_4     disj2_1_5_4  -1.0
    x_5_4     disj1_2_5_4  1.0
    x_5_4     disj2_2_5_4  -1.0
    x_5_4     disj1_3_5_4  1.0
    x_5_4     disj2_3_5_4  -1.0
    x_5_4     disj1_4_5_4  1.0
    x_5_4     disj2_4_5_4  -1.0
    x_5_4     disj1_5_6_4  -1.0
    x_5_4     disj2_5_6_4  1.0
    x_5_4     disj1_5_7_4  -1.0
    x_5_4     disj2_5_7_4  1.0
    x_5_4     disj1_5_8_4  -1.0
    x_5_4     disj2_5_8_4  1.0
    x_5_4     disj1_5_9_4  -1.0
    x_5_4     disj2_5_9_4  1.0
    x_5_5     prec_5_4  1.0
    x_5_5     prec_5_5  -1.0
    x_5_5     disj1_0_5_7  1.0
    x_5_5     disj2_0_5_7  -1.0
    x_5_5     disj1_1_5_7  1.0
    x_5_5     disj2_1_5_7  -1.0
    x_5_5     disj1_2_5_7  1.0
    x_5_5     disj2_2_5_7  -1.0
    x_5_5     disj1_3_5_7  1.0
    x_5_5     disj2_3_5_7  -1.0
    x_5_5     disj1_4_5_7  1.0
    x_5_5     disj2_4_5_7  -1.0
    x_5_5     disj1_5_6_7  -1.0
    x_5_5     disj2_5_6_7  1.0
    x_5_5     disj1_5_7_7  -1.0
    x_5_5     disj2_5_7_7  1.0
    x_5_5     disj1_5_8_7  -1.0
    x_5_5     disj2_5_8_7  1.0
    x_5_5     disj1_5_9_7  -1.0
    x_5_5     disj2_5_9_7  1.0
    x_5_6     prec_5_5  1.0
    x_5_6     prec_5_6  -1.0
    x_5_6     disj1_0_5_5  1.0
    x_5_6     disj2_0_5_5  -1.0
    x_5_6     disj1_1_5_5  1.0
    x_5_6     disj2_1_5_5  -1.0
    x_5_6     disj1_2_5_5  1.0
    x_5_6     disj2_2_5_5  -1.0
    x_5_6     disj1_3_5_5  1.0
    x_5_6     disj2_3_5_5  -1.0
    x_5_6     disj1_4_5_5  1.0
    x_5_6     disj2_4_5_5  -1.0
    x_5_6     disj1_5_6_5  -1.0
    x_5_6     disj2_5_6_5  1.0
    x_5_6     disj1_5_7_5  -1.0
    x_5_6     disj2_5_7_5  1.0
    x_5_6     disj1_5_8_5  -1.0
    x_5_6     disj2_5_8_5  1.0
    x_5_6     disj1_5_9_5  -1.0
    x_5_6     disj2_5_9_5  1.0
    x_5_7     prec_5_6  1.0
    x_5_7     prec_5_7  -1.0
    x_5_7     disj1_0_5_6  1.0
    x_5_7     disj2_0_5_6  -1.0
    x_5_7     disj1_1_5_6  1.0
    x_5_7     disj2_1_5_6  -1.0
    x_5_7     disj1_2_5_6  1.0
    x_5_7     disj2_2_5_6  -1.0
    x_5_7     disj1_3_5_6  1.0
    x_5_7     disj2_3_5_6  -1.0
    x_5_7     disj1_4_5_6  1.0
    x_5_7     disj2_4_5_6  -1.0
    x_5_7     disj1_5_6_6  -1.0
    x_5_7     disj2_5_6_6  1.0
    x_5_7     disj1_5_7_6  -1.0
    x_5_7     disj2_5_7_6  1.0
    x_5_7     disj1_5_8_6  -1.0
    x_5_7     disj2_5_8_6  1.0
    x_5_7     disj1_5_9_6  -1.0
    x_5_7     disj2_5_9_6  1.0
    x_5_8     prec_5_7  1.0
    x_5_8     prec_5_8  -1.0
    x_5_8     disj1_0_5_9  1.0
    x_5_8     disj2_0_5_9  -1.0
    x_5_8     disj1_1_5_9  1.0
    x_5_8     disj2_1_5_9  -1.0
    x_5_8     disj1_2_5_9  1.0
    x_5_8     disj2_2_5_9  -1.0
    x_5_8     disj1_3_5_9  1.0
    x_5_8     disj2_3_5_9  -1.0
    x_5_8     disj1_4_5_9  1.0
    x_5_8     disj2_4_5_9  -1.0
    x_5_8     disj1_5_6_9  -1.0
    x_5_8     disj2_5_6_9  1.0
    x_5_8     disj1_5_7_9  -1.0
    x_5_8     disj2_5_7_9  1.0
    x_5_8     disj1_5_8_9  -1.0
    x_5_8     disj2_5_8_9  1.0
    x_5_8     disj1_5_9_9  -1.0
    x_5_8     disj2_5_9_9  1.0
    x_5_9     prec_5_8  1.0
    x_5_9     mksp_5    -1.0
    x_5_9     disj1_0_5_8  1.0
    x_5_9     disj2_0_5_8  -1.0
    x_5_9     disj1_1_5_8  1.0
    x_5_9     disj2_1_5_8  -1.0
    x_5_9     disj1_2_5_8  1.0
    x_5_9     disj2_2_5_8  -1.0
    x_5_9     disj1_3_5_8  1.0
    x_5_9     disj2_3_5_8  -1.0
    x_5_9     disj1_4_5_8  1.0
    x_5_9     disj2_4_5_8  -1.0
    x_5_9     disj1_5_6_8  -1.0
    x_5_9     disj2_5_6_8  1.0
    x_5_9     disj1_5_7_8  -1.0
    x_5_9     disj2_5_7_8  1.0
    x_5_9     disj1_5_8_8  -1.0
    x_5_9     disj2_5_8_8  1.0
    x_5_9     disj1_5_9_8  -1.0
    x_5_9     disj2_5_9_8  1.0
    x_6_0     prec_6_0  -1.0
    x_6_0     disj1_0_6_2  1.0
    x_6_0     disj2_0_6_2  -1.0
    x_6_0     disj1_1_6_2  1.0
    x_6_0     disj2_1_6_2  -1.0
    x_6_0     disj1_2_6_2  1.0
    x_6_0     disj2_2_6_2  -1.0
    x_6_0     disj1_3_6_2  1.0
    x_6_0     disj2_3_6_2  -1.0
    x_6_0     disj1_4_6_2  1.0
    x_6_0     disj2_4_6_2  -1.0
    x_6_0     disj1_5_6_2  1.0
    x_6_0     disj2_5_6_2  -1.0
    x_6_0     disj1_6_7_2  -1.0
    x_6_0     disj2_6_7_2  1.0
    x_6_0     disj1_6_8_2  -1.0
    x_6_0     disj2_6_8_2  1.0
    x_6_0     disj1_6_9_2  -1.0
    x_6_0     disj2_6_9_2  1.0
    x_6_1     prec_6_0  1.0
    x_6_1     prec_6_1  -1.0
    x_6_1     disj1_0_6_1  1.0
    x_6_1     disj2_0_6_1  -1.0
    x_6_1     disj1_1_6_1  1.0
    x_6_1     disj2_1_6_1  -1.0
    x_6_1     disj1_2_6_1  1.0
    x_6_1     disj2_2_6_1  -1.0
    x_6_1     disj1_3_6_1  1.0
    x_6_1     disj2_3_6_1  -1.0
    x_6_1     disj1_4_6_1  1.0
    x_6_1     disj2_4_6_1  -1.0
    x_6_1     disj1_5_6_1  1.0
    x_6_1     disj2_5_6_1  -1.0
    x_6_1     disj1_6_7_1  -1.0
    x_6_1     disj2_6_7_1  1.0
    x_6_1     disj1_6_8_1  -1.0
    x_6_1     disj2_6_8_1  1.0
    x_6_1     disj1_6_9_1  -1.0
    x_6_1     disj2_6_9_1  1.0
    x_6_2     prec_6_1  1.0
    x_6_2     prec_6_2  -1.0
    x_6_2     disj1_0_6_4  1.0
    x_6_2     disj2_0_6_4  -1.0
    x_6_2     disj1_1_6_4  1.0
    x_6_2     disj2_1_6_4  -1.0
    x_6_2     disj1_2_6_4  1.0
    x_6_2     disj2_2_6_4  -1.0
    x_6_2     disj1_3_6_4  1.0
    x_6_2     disj2_3_6_4  -1.0
    x_6_2     disj1_4_6_4  1.0
    x_6_2     disj2_4_6_4  -1.0
    x_6_2     disj1_5_6_4  1.0
    x_6_2     disj2_5_6_4  -1.0
    x_6_2     disj1_6_7_4  -1.0
    x_6_2     disj2_6_7_4  1.0
    x_6_2     disj1_6_8_4  -1.0
    x_6_2     disj2_6_8_4  1.0
    x_6_2     disj1_6_9_4  -1.0
    x_6_2     disj2_6_9_4  1.0
    x_6_3     prec_6_2  1.0
    x_6_3     prec_6_3  -1.0
    x_6_3     disj1_0_6_0  1.0
    x_6_3     disj2_0_6_0  -1.0
    x_6_3     disj1_1_6_0  1.0
    x_6_3     disj2_1_6_0  -1.0
    x_6_3     disj1_2_6_0  1.0
    x_6_3     disj2_2_6_0  -1.0
    x_6_3     disj1_3_6_0  1.0
    x_6_3     disj2_3_6_0  -1.0
    x_6_3     disj1_4_6_0  1.0
    x_6_3     disj2_4_6_0  -1.0
    x_6_3     disj1_5_6_0  1.0
    x_6_3     disj2_5_6_0  -1.0
    x_6_3     disj1_6_7_0  -1.0
    x_6_3     disj2_6_7_0  1.0
    x_6_3     disj1_6_8_0  -1.0
    x_6_3     disj2_6_8_0  1.0
    x_6_3     disj1_6_9_0  -1.0
    x_6_3     disj2_6_9_0  1.0
    x_6_4     prec_6_3  1.0
    x_6_4     prec_6_4  -1.0
    x_6_4     disj1_0_6_3  1.0
    x_6_4     disj2_0_6_3  -1.0
    x_6_4     disj1_1_6_3  1.0
    x_6_4     disj2_1_6_3  -1.0
    x_6_4     disj1_2_6_3  1.0
    x_6_4     disj2_2_6_3  -1.0
    x_6_4     disj1_3_6_3  1.0
    x_6_4     disj2_3_6_3  -1.0
    x_6_4     disj1_4_6_3  1.0
    x_6_4     disj2_4_6_3  -1.0
    x_6_4     disj1_5_6_3  1.0
    x_6_4     disj2_5_6_3  -1.0
    x_6_4     disj1_6_7_3  -1.0
    x_6_4     disj2_6_7_3  1.0
    x_6_4     disj1_6_8_3  -1.0
    x_6_4     disj2_6_8_3  1.0
    x_6_4     disj1_6_9_3  -1.0
    x_6_4     disj2_6_9_3  1.0
    x_6_5     prec_6_4  1.0
    x_6_5     prec_6_5  -1.0
    x_6_5     disj1_0_6_5  1.0
    x_6_5     disj2_0_6_5  -1.0
    x_6_5     disj1_1_6_5  1.0
    x_6_5     disj2_1_6_5  -1.0
    x_6_5     disj1_2_6_5  1.0
    x_6_5     disj2_2_6_5  -1.0
    x_6_5     disj1_3_6_5  1.0
    x_6_5     disj2_3_6_5  -1.0
    x_6_5     disj1_4_6_5  1.0
    x_6_5     disj2_4_6_5  -1.0
    x_6_5     disj1_5_6_5  1.0
    x_6_5     disj2_5_6_5  -1.0
    x_6_5     disj1_6_7_5  -1.0
    x_6_5     disj2_6_7_5  1.0
    x_6_5     disj1_6_8_5  -1.0
    x_6_5     disj2_6_8_5  1.0
    x_6_5     disj1_6_9_5  -1.0
    x_6_5     disj2_6_9_5  1.0
    x_6_6     prec_6_5  1.0
    x_6_6     prec_6_6  -1.0
    x_6_6     disj1_0_6_6  1.0
    x_6_6     disj2_0_6_6  -1.0
    x_6_6     disj1_1_6_6  1.0
    x_6_6     disj2_1_6_6  -1.0
    x_6_6     disj1_2_6_6  1.0
    x_6_6     disj2_2_6_6  -1.0
    x_6_6     disj1_3_6_6  1.0
    x_6_6     disj2_3_6_6  -1.0
    x_6_6     disj1_4_6_6  1.0
    x_6_6     disj2_4_6_6  -1.0
    x_6_6     disj1_5_6_6  1.0
    x_6_6     disj2_5_6_6  -1.0
    x_6_6     disj1_6_7_6  -1.0
    x_6_6     disj2_6_7_6  1.0
    x_6_6     disj1_6_8_6  -1.0
    x_6_6     disj2_6_8_6  1.0
    x_6_6     disj1_6_9_6  -1.0
    x_6_6     disj2_6_9_6  1.0
    x_6_7     prec_6_6  1.0
    x_6_7     prec_6_7  -1.0
    x_6_7     disj1_0_6_7  1.0
    x_6_7     disj2_0_6_7  -1.0
    x_6_7     disj1_1_6_7  1.0
    x_6_7     disj2_1_6_7  -1.0
    x_6_7     disj1_2_6_7  1.0
    x_6_7     disj2_2_6_7  -1.0
    x_6_7     disj1_3_6_7  1.0
    x_6_7     disj2_3_6_7  -1.0
    x_6_7     disj1_4_6_7  1.0
    x_6_7     disj2_4_6_7  -1.0
    x_6_7     disj1_5_6_7  1.0
    x_6_7     disj2_5_6_7  -1.0
    x_6_7     disj1_6_7_7  -1.0
    x_6_7     disj2_6_7_7  1.0
    x_6_7     disj1_6_8_7  -1.0
    x_6_7     disj2_6_8_7  1.0
    x_6_7     disj1_6_9_7  -1.0
    x_6_7     disj2_6_9_7  1.0
    x_6_8     prec_6_7  1.0
    x_6_8     prec_6_8  -1.0
    x_6_8     disj1_0_6_8  1.0
    x_6_8     disj2_0_6_8  -1.0
    x_6_8     disj1_1_6_8  1.0
    x_6_8     disj2_1_6_8  -1.0
    x_6_8     disj1_2_6_8  1.0
    x_6_8     disj2_2_6_8  -1.0
    x_6_8     disj1_3_6_8  1.0
    x_6_8     disj2_3_6_8  -1.0
    x_6_8     disj1_4_6_8  1.0
    x_6_8     disj2_4_6_8  -1.0
    x_6_8     disj1_5_6_8  1.0
    x_6_8     disj2_5_6_8  -1.0
    x_6_8     disj1_6_7_8  -1.0
    x_6_8     disj2_6_7_8  1.0
    x_6_8     disj1_6_8_8  -1.0
    x_6_8     disj2_6_8_8  1.0
    x_6_8     disj1_6_9_8  -1.0
    x_6_8     disj2_6_9_8  1.0
    x_6_9     prec_6_8  1.0
    x_6_9     mksp_6    -1.0
    x_6_9     disj1_0_6_9  1.0
    x_6_9     disj2_0_6_9  -1.0
    x_6_9     disj1_1_6_9  1.0
    x_6_9     disj2_1_6_9  -1.0
    x_6_9     disj1_2_6_9  1.0
    x_6_9     disj2_2_6_9  -1.0
    x_6_9     disj1_3_6_9  1.0
    x_6_9     disj2_3_6_9  -1.0
    x_6_9     disj1_4_6_9  1.0
    x_6_9     disj2_4_6_9  -1.0
    x_6_9     disj1_5_6_9  1.0
    x_6_9     disj2_5_6_9  -1.0
    x_6_9     disj1_6_7_9  -1.0
    x_6_9     disj2_6_7_9  1.0
    x_6_9     disj1_6_8_9  -1.0
    x_6_9     disj2_6_8_9  1.0
    x_6_9     disj1_6_9_9  -1.0
    x_6_9     disj2_6_9_9  1.0
    x_7_0     prec_7_0  -1.0
    x_7_0     disj1_0_7_3  1.0
    x_7_0     disj2_0_7_3  -1.0
    x_7_0     disj1_1_7_3  1.0
    x_7_0     disj2_1_7_3  -1.0
    x_7_0     disj1_2_7_3  1.0
    x_7_0     disj2_2_7_3  -1.0
    x_7_0     disj1_3_7_3  1.0
    x_7_0     disj2_3_7_3  -1.0
    x_7_0     disj1_4_7_3  1.0
    x_7_0     disj2_4_7_3  -1.0
    x_7_0     disj1_5_7_3  1.0
    x_7_0     disj2_5_7_3  -1.0
    x_7_0     disj1_6_7_3  1.0
    x_7_0     disj2_6_7_3  -1.0
    x_7_0     disj1_7_8_3  -1.0
    x_7_0     disj2_7_8_3  1.0
    x_7_0     disj1_7_9_3  -1.0
    x_7_0     disj2_7_9_3  1.0
    x_7_1     prec_7_0  1.0
    x_7_1     prec_7_1  -1.0
    x_7_1     disj1_0_7_4  1.0
    x_7_1     disj2_0_7_4  -1.0
    x_7_1     disj1_1_7_4  1.0
    x_7_1     disj2_1_7_4  -1.0
    x_7_1     disj1_2_7_4  1.0
    x_7_1     disj2_2_7_4  -1.0
    x_7_1     disj1_3_7_4  1.0
    x_7_1     disj2_3_7_4  -1.0
    x_7_1     disj1_4_7_4  1.0
    x_7_1     disj2_4_7_4  -1.0
    x_7_1     disj1_5_7_4  1.0
    x_7_1     disj2_5_7_4  -1.0
    x_7_1     disj1_6_7_4  1.0
    x_7_1     disj2_6_7_4  -1.0
    x_7_1     disj1_7_8_4  -1.0
    x_7_1     disj2_7_8_4  1.0
    x_7_1     disj1_7_9_4  -1.0
    x_7_1     disj2_7_9_4  1.0
    x_7_2     prec_7_1  1.0
    x_7_2     prec_7_2  -1.0
    x_7_2     disj1_0_7_0  1.0
    x_7_2     disj2_0_7_0  -1.0
    x_7_2     disj1_1_7_0  1.0
    x_7_2     disj2_1_7_0  -1.0
    x_7_2     disj1_2_7_0  1.0
    x_7_2     disj2_2_7_0  -1.0
    x_7_2     disj1_3_7_0  1.0
    x_7_2     disj2_3_7_0  -1.0
    x_7_2     disj1_4_7_0  1.0
    x_7_2     disj2_4_7_0  -1.0
    x_7_2     disj1_5_7_0  1.0
    x_7_2     disj2_5_7_0  -1.0
    x_7_2     disj1_6_7_0  1.0
    x_7_2     disj2_6_7_0  -1.0
    x_7_2     disj1_7_8_0  -1.0
    x_7_2     disj2_7_8_0  1.0
    x_7_2     disj1_7_9_0  -1.0
    x_7_2     disj2_7_9_0  1.0
    x_7_3     prec_7_2  1.0
    x_7_3     prec_7_3  -1.0
    x_7_3     disj1_0_7_1  1.0
    x_7_3     disj2_0_7_1  -1.0
    x_7_3     disj1_1_7_1  1.0
    x_7_3     disj2_1_7_1  -1.0
    x_7_3     disj1_2_7_1  1.0
    x_7_3     disj2_2_7_1  -1.0
    x_7_3     disj1_3_7_1  1.0
    x_7_3     disj2_3_7_1  -1.0
    x_7_3     disj1_4_7_1  1.0
    x_7_3     disj2_4_7_1  -1.0
    x_7_3     disj1_5_7_1  1.0
    x_7_3     disj2_5_7_1  -1.0
    x_7_3     disj1_6_7_1  1.0
    x_7_3     disj2_6_7_1  -1.0
    x_7_3     disj1_7_8_1  -1.0
    x_7_3     disj2_7_8_1  1.0
    x_7_3     disj1_7_9_1  -1.0
    x_7_3     disj2_7_9_1  1.0
    x_7_4     prec_7_3  1.0
    x_7_4     prec_7_4  -1.0
    x_7_4     disj1_0_7_2  1.0
    x_7_4     disj2_0_7_2  -1.0
    x_7_4     disj1_1_7_2  1.0
    x_7_4     disj2_1_7_2  -1.0
    x_7_4     disj1_2_7_2  1.0
    x_7_4     disj2_2_7_2  -1.0
    x_7_4     disj1_3_7_2  1.0
    x_7_4     disj2_3_7_2  -1.0
    x_7_4     disj1_4_7_2  1.0
    x_7_4     disj2_4_7_2  -1.0
    x_7_4     disj1_5_7_2  1.0
    x_7_4     disj2_5_7_2  -1.0
    x_7_4     disj1_6_7_2  1.0
    x_7_4     disj2_6_7_2  -1.0
    x_7_4     disj1_7_8_2  -1.0
    x_7_4     disj2_7_8_2  1.0
    x_7_4     disj1_7_9_2  -1.0
    x_7_4     disj2_7_9_2  1.0
    x_7_5     prec_7_4  1.0
    x_7_5     prec_7_5  -1.0
    x_7_5     disj1_0_7_6  1.0
    x_7_5     disj2_0_7_6  -1.0
    x_7_5     disj1_1_7_6  1.0
    x_7_5     disj2_1_7_6  -1.0
    x_7_5     disj1_2_7_6  1.0
    x_7_5     disj2_2_7_6  -1.0
    x_7_5     disj1_3_7_6  1.0
    x_7_5     disj2_3_7_6  -1.0
    x_7_5     disj1_4_7_6  1.0
    x_7_5     disj2_4_7_6  -1.0
    x_7_5     disj1_5_7_6  1.0
    x_7_5     disj2_5_7_6  -1.0
    x_7_5     disj1_6_7_6  1.0
    x_7_5     disj2_6_7_6  -1.0
    x_7_5     disj1_7_8_6  -1.0
    x_7_5     disj2_7_8_6  1.0
    x_7_5     disj1_7_9_6  -1.0
    x_7_5     disj2_7_9_6  1.0
    x_7_6     prec_7_5  1.0
    x_7_6     prec_7_6  -1.0
    x_7_6     disj1_0_7_5  1.0
    x_7_6     disj2_0_7_5  -1.0
    x_7_6     disj1_1_7_5  1.0
    x_7_6     disj2_1_7_5  -1.0
    x_7_6     disj1_2_7_5  1.0
    x_7_6     disj2_2_7_5  -1.0
    x_7_6     disj1_3_7_5  1.0
    x_7_6     disj2_3_7_5  -1.0
    x_7_6     disj1_4_7_5  1.0
    x_7_6     disj2_4_7_5  -1.0
    x_7_6     disj1_5_7_5  1.0
    x_7_6     disj2_5_7_5  -1.0
    x_7_6     disj1_6_7_5  1.0
    x_7_6     disj2_6_7_5  -1.0
    x_7_6     disj1_7_8_5  -1.0
    x_7_6     disj2_7_8_5  1.0
    x_7_6     disj1_7_9_5  -1.0
    x_7_6     disj2_7_9_5  1.0
    x_7_7     prec_7_6  1.0
    x_7_7     prec_7_7  -1.0
    x_7_7     disj1_0_7_7  1.0
    x_7_7     disj2_0_7_7  -1.0
    x_7_7     disj1_1_7_7  1.0
    x_7_7     disj2_1_7_7  -1.0
    x_7_7     disj1_2_7_7  1.0
    x_7_7     disj2_2_7_7  -1.0
    x_7_7     disj1_3_7_7  1.0
    x_7_7     disj2_3_7_7  -1.0
    x_7_7     disj1_4_7_7  1.0
    x_7_7     disj2_4_7_7  -1.0
    x_7_7     disj1_5_7_7  1.0
    x_7_7     disj2_5_7_7  -1.0
    x_7_7     disj1_6_7_7  1.0
    x_7_7     disj2_6_7_7  -1.0
    x_7_7     disj1_7_8_7  -1.0
    x_7_7     disj2_7_8_7  1.0
    x_7_7     disj1_7_9_7  -1.0
    x_7_7     disj2_7_9_7  1.0
    x_7_8     prec_7_7  1.0
    x_7_8     prec_7_8  -1.0
    x_7_8     disj1_0_7_8  1.0
    x_7_8     disj2_0_7_8  -1.0
    x_7_8     disj1_1_7_8  1.0
    x_7_8     disj2_1_7_8  -1.0
    x_7_8     disj1_2_7_8  1.0
    x_7_8     disj2_2_7_8  -1.0
    x_7_8     disj1_3_7_8  1.0
    x_7_8     disj2_3_7_8  -1.0
    x_7_8     disj1_4_7_8  1.0
    x_7_8     disj2_4_7_8  -1.0
    x_7_8     disj1_5_7_8  1.0
    x_7_8     disj2_5_7_8  -1.0
    x_7_8     disj1_6_7_8  1.0
    x_7_8     disj2_6_7_8  -1.0
    x_7_8     disj1_7_8_8  -1.0
    x_7_8     disj2_7_8_8  1.0
    x_7_8     disj1_7_9_8  -1.0
    x_7_8     disj2_7_9_8  1.0
    x_7_9     prec_7_8  1.0
    x_7_9     mksp_7    -1.0
    x_7_9     disj1_0_7_9  1.0
    x_7_9     disj2_0_7_9  -1.0
    x_7_9     disj1_1_7_9  1.0
    x_7_9     disj2_1_7_9  -1.0
    x_7_9     disj1_2_7_9  1.0
    x_7_9     disj2_2_7_9  -1.0
    x_7_9     disj1_3_7_9  1.0
    x_7_9     disj2_3_7_9  -1.0
    x_7_9     disj1_4_7_9  1.0
    x_7_9     disj2_4_7_9  -1.0
    x_7_9     disj1_5_7_9  1.0
    x_7_9     disj2_5_7_9  -1.0
    x_7_9     disj1_6_7_9  1.0
    x_7_9     disj2_6_7_9  -1.0
    x_7_9     disj1_7_8_9  -1.0
    x_7_9     disj2_7_8_9  1.0
    x_7_9     disj1_7_9_9  -1.0
    x_7_9     disj2_7_9_9  1.0
    x_8_0     prec_8_0  -1.0
    x_8_0     disj1_0_8_1  1.0
    x_8_0     disj2_0_8_1  -1.0
    x_8_0     disj1_1_8_1  1.0
    x_8_0     disj2_1_8_1  -1.0
    x_8_0     disj1_2_8_1  1.0
    x_8_0     disj2_2_8_1  -1.0
    x_8_0     disj1_3_8_1  1.0
    x_8_0     disj2_3_8_1  -1.0
    x_8_0     disj1_4_8_1  1.0
    x_8_0     disj2_4_8_1  -1.0
    x_8_0     disj1_5_8_1  1.0
    x_8_0     disj2_5_8_1  -1.0
    x_8_0     disj1_6_8_1  1.0
    x_8_0     disj2_6_8_1  -1.0
    x_8_0     disj1_7_8_1  1.0
    x_8_0     disj2_7_8_1  -1.0
    x_8_0     disj1_8_9_1  -1.0
    x_8_0     disj2_8_9_1  1.0
    x_8_1     prec_8_0  1.0
    x_8_1     prec_8_1  -1.0
    x_8_1     disj1_0_8_3  1.0
    x_8_1     disj2_0_8_3  -1.0
    x_8_1     disj1_1_8_3  1.0
    x_8_1     disj2_1_8_3  -1.0
    x_8_1     disj1_2_8_3  1.0
    x_8_1     disj2_2_8_3  -1.0
    x_8_1     disj1_3_8_3  1.0
    x_8_1     disj2_3_8_3  -1.0
    x_8_1     disj1_4_8_3  1.0
    x_8_1     disj2_4_8_3  -1.0
    x_8_1     disj1_5_8_3  1.0
    x_8_1     disj2_5_8_3  -1.0
    x_8_1     disj1_6_8_3  1.0
    x_8_1     disj2_6_8_3  -1.0
    x_8_1     disj1_7_8_3  1.0
    x_8_1     disj2_7_8_3  -1.0
    x_8_1     disj1_8_9_3  -1.0
    x_8_1     disj2_8_9_3  1.0
    x_8_2     prec_8_1  1.0
    x_8_2     prec_8_2  -1.0
    x_8_2     disj1_0_8_2  1.0
    x_8_2     disj2_0_8_2  -1.0
    x_8_2     disj1_1_8_2  1.0
    x_8_2     disj2_1_8_2  -1.0
    x_8_2     disj1_2_8_2  1.0
    x_8_2     disj2_2_8_2  -1.0
    x_8_2     disj1_3_8_2  1.0
    x_8_2     disj2_3_8_2  -1.0
    x_8_2     disj1_4_8_2  1.0
    x_8_2     disj2_4_8_2  -1.0
    x_8_2     disj1_5_8_2  1.0
    x_8_2     disj2_5_8_2  -1.0
    x_8_2     disj1_6_8_2  1.0
    x_8_2     disj2_6_8_2  -1.0
    x_8_2     disj1_7_8_2  1.0
    x_8_2     disj2_7_8_2  -1.0
    x_8_2     disj1_8_9_2  -1.0
    x_8_2     disj2_8_9_2  1.0
    x_8_3     prec_8_2  1.0
    x_8_3     prec_8_3  -1.0
    x_8_3     disj1_0_8_0  1.0
    x_8_3     disj2_0_8_0  -1.0
    x_8_3     disj1_1_8_0  1.0
    x_8_3     disj2_1_8_0  -1.0
    x_8_3     disj1_2_8_0  1.0
    x_8_3     disj2_2_8_0  -1.0
    x_8_3     disj1_3_8_0  1.0
    x_8_3     disj2_3_8_0  -1.0
    x_8_3     disj1_4_8_0  1.0
    x_8_3     disj2_4_8_0  -1.0
    x_8_3     disj1_5_8_0  1.0
    x_8_3     disj2_5_8_0  -1.0
    x_8_3     disj1_6_8_0  1.0
    x_8_3     disj2_6_8_0  -1.0
    x_8_3     disj1_7_8_0  1.0
    x_8_3     disj2_7_8_0  -1.0
    x_8_3     disj1_8_9_0  -1.0
    x_8_3     disj2_8_9_0  1.0
    x_8_4     prec_8_3  1.0
    x_8_4     prec_8_4  -1.0
    x_8_4     disj1_0_8_4  1.0
    x_8_4     disj2_0_8_4  -1.0
    x_8_4     disj1_1_8_4  1.0
    x_8_4     disj2_1_8_4  -1.0
    x_8_4     disj1_2_8_4  1.0
    x_8_4     disj2_2_8_4  -1.0
    x_8_4     disj1_3_8_4  1.0
    x_8_4     disj2_3_8_4  -1.0
    x_8_4     disj1_4_8_4  1.0
    x_8_4     disj2_4_8_4  -1.0
    x_8_4     disj1_5_8_4  1.0
    x_8_4     disj2_5_8_4  -1.0
    x_8_4     disj1_6_8_4  1.0
    x_8_4     disj2_6_8_4  -1.0
    x_8_4     disj1_7_8_4  1.0
    x_8_4     disj2_7_8_4  -1.0
    x_8_4     disj1_8_9_4  -1.0
    x_8_4     disj2_8_9_4  1.0
    x_8_5     prec_8_4  1.0
    x_8_5     prec_8_5  -1.0
    x_8_5     disj1_0_8_7  1.0
    x_8_5     disj2_0_8_7  -1.0
    x_8_5     disj1_1_8_7  1.0
    x_8_5     disj2_1_8_7  -1.0
    x_8_5     disj1_2_8_7  1.0
    x_8_5     disj2_2_8_7  -1.0
    x_8_5     disj1_3_8_7  1.0
    x_8_5     disj2_3_8_7  -1.0
    x_8_5     disj1_4_8_7  1.0
    x_8_5     disj2_4_8_7  -1.0
    x_8_5     disj1_5_8_7  1.0
    x_8_5     disj2_5_8_7  -1.0
    x_8_5     disj1_6_8_7  1.0
    x_8_5     disj2_6_8_7  -1.0
    x_8_5     disj1_7_8_7  1.0
    x_8_5     disj2_7_8_7  -1.0
    x_8_5     disj1_8_9_7  -1.0
    x_8_5     disj2_8_9_7  1.0
    x_8_6     prec_8_5  1.0
    x_8_6     prec_8_6  -1.0
    x_8_6     disj1_0_8_6  1.0
    x_8_6     disj2_0_8_6  -1.0
    x_8_6     disj1_1_8_6  1.0
    x_8_6     disj2_1_8_6  -1.0
    x_8_6     disj1_2_8_6  1.0
    x_8_6     disj2_2_8_6  -1.0
    x_8_6     disj1_3_8_6  1.0
    x_8_6     disj2_3_8_6  -1.0
    x_8_6     disj1_4_8_6  1.0
    x_8_6     disj2_4_8_6  -1.0
    x_8_6     disj1_5_8_6  1.0
    x_8_6     disj2_5_8_6  -1.0
    x_8_6     disj1_6_8_6  1.0
    x_8_6     disj2_6_8_6  -1.0
    x_8_6     disj1_7_8_6  1.0
    x_8_6     disj2_7_8_6  -1.0
    x_8_6     disj1_8_9_6  -1.0
    x_8_6     disj2_8_9_6  1.0
    x_8_7     prec_8_6  1.0
    x_8_7     prec_8_7  -1.0
    x_8_7     disj1_0_8_5  1.0
    x_8_7     disj2_0_8_5  -1.0
    x_8_7     disj1_1_8_5  1.0
    x_8_7     disj2_1_8_5  -1.0
    x_8_7     disj1_2_8_5  1.0
    x_8_7     disj2_2_8_5  -1.0
    x_8_7     disj1_3_8_5  1.0
    x_8_7     disj2_3_8_5  -1.0
    x_8_7     disj1_4_8_5  1.0
    x_8_7     disj2_4_8_5  -1.0
    x_8_7     disj1_5_8_5  1.0
    x_8_7     disj2_5_8_5  -1.0
    x_8_7     disj1_6_8_5  1.0
    x_8_7     disj2_6_8_5  -1.0
    x_8_7     disj1_7_8_5  1.0
    x_8_7     disj2_7_8_5  -1.0
    x_8_7     disj1_8_9_5  -1.0
    x_8_7     disj2_8_9_5  1.0
    x_8_8     prec_8_7  1.0
    x_8_8     prec_8_8  -1.0
    x_8_8     disj1_0_8_8  1.0
    x_8_8     disj2_0_8_8  -1.0
    x_8_8     disj1_1_8_8  1.0
    x_8_8     disj2_1_8_8  -1.0
    x_8_8     disj1_2_8_8  1.0
    x_8_8     disj2_2_8_8  -1.0
    x_8_8     disj1_3_8_8  1.0
    x_8_8     disj2_3_8_8  -1.0
    x_8_8     disj1_4_8_8  1.0
    x_8_8     disj2_4_8_8  -1.0
    x_8_8     disj1_5_8_8  1.0
    x_8_8     disj2_5_8_8  -1.0
    x_8_8     disj1_6_8_8  1.0
    x_8_8     disj2_6_8_8  -1.0
    x_8_8     disj1_7_8_8  1.0
    x_8_8     disj2_7_8_8  -1.0
    x_8_8     disj1_8_9_8  -1.0
    x_8_8     disj2_8_9_8  1.0
    x_8_9     prec_8_8  1.0
    x_8_9     mksp_8    -1.0
    x_8_9     disj1_0_8_9  1.0
    x_8_9     disj2_0_8_9  -1.0
    x_8_9     disj1_1_8_9  1.0
    x_8_9     disj2_1_8_9  -1.0
    x_8_9     disj1_2_8_9  1.0
    x_8_9     disj2_2_8_9  -1.0
    x_8_9     disj1_3_8_9  1.0
    x_8_9     disj2_3_8_9  -1.0
    x_8_9     disj1_4_8_9  1.0
    x_8_9     disj2_4_8_9  -1.0
    x_8_9     disj1_5_8_9  1.0
    x_8_9     disj2_5_8_9  -1.0
    x_8_9     disj1_6_8_9  1.0
    x_8_9     disj2_6_8_9  -1.0
    x_8_9     disj1_7_8_9  1.0
    x_8_9     disj2_7_8_9  -1.0
    x_8_9     disj1_8_9_9  -1.0
    x_8_9     disj2_8_9_9  1.0
    x_9_0     prec_9_0  -1.0
    x_9_0     disj1_0_9_2  1.0
    x_9_0     disj2_0_9_2  -1.0
    x_9_0     disj1_1_9_2  1.0
    x_9_0     disj2_1_9_2  -1.0
    x_9_0     disj1_2_9_2  1.0
    x_9_0     disj2_2_9_2  -1.0
    x_9_0     disj1_3_9_2  1.0
    x_9_0     disj2_3_9_2  -1.0
    x_9_0     disj1_4_9_2  1.0
    x_9_0     disj2_4_9_2  -1.0
    x_9_0     disj1_5_9_2  1.0
    x_9_0     disj2_5_9_2  -1.0
    x_9_0     disj1_6_9_2  1.0
    x_9_0     disj2_6_9_2  -1.0
    x_9_0     disj1_7_9_2  1.0
    x_9_0     disj2_7_9_2  -1.0
    x_9_0     disj1_8_9_2  1.0
    x_9_0     disj2_8_9_2  -1.0
    x_9_1     prec_9_0  1.0
    x_9_1     prec_9_1  -1.0
    x_9_1     disj1_0_9_3  1.0
    x_9_1     disj2_0_9_3  -1.0
    x_9_1     disj1_1_9_3  1.0
    x_9_1     disj2_1_9_3  -1.0
    x_9_1     disj1_2_9_3  1.0
    x_9_1     disj2_2_9_3  -1.0
    x_9_1     disj1_3_9_3  1.0
    x_9_1     disj2_3_9_3  -1.0
    x_9_1     disj1_4_9_3  1.0
    x_9_1     disj2_4_9_3  -1.0
    x_9_1     disj1_5_9_3  1.0
    x_9_1     disj2_5_9_3  -1.0
    x_9_1     disj1_6_9_3  1.0
    x_9_1     disj2_6_9_3  -1.0
    x_9_1     disj1_7_9_3  1.0
    x_9_1     disj2_7_9_3  -1.0
    x_9_1     disj1_8_9_3  1.0
    x_9_1     disj2_8_9_3  -1.0
    x_9_2     prec_9_1  1.0
    x_9_2     prec_9_2  -1.0
    x_9_2     disj1_0_9_0  1.0
    x_9_2     disj2_0_9_0  -1.0
    x_9_2     disj1_1_9_0  1.0
    x_9_2     disj2_1_9_0  -1.0
    x_9_2     disj1_2_9_0  1.0
    x_9_2     disj2_2_9_0  -1.0
    x_9_2     disj1_3_9_0  1.0
    x_9_2     disj2_3_9_0  -1.0
    x_9_2     disj1_4_9_0  1.0
    x_9_2     disj2_4_9_0  -1.0
    x_9_2     disj1_5_9_0  1.0
    x_9_2     disj2_5_9_0  -1.0
    x_9_2     disj1_6_9_0  1.0
    x_9_2     disj2_6_9_0  -1.0
    x_9_2     disj1_7_9_0  1.0
    x_9_2     disj2_7_9_0  -1.0
    x_9_2     disj1_8_9_0  1.0
    x_9_2     disj2_8_9_0  -1.0
    x_9_3     prec_9_2  1.0
    x_9_3     prec_9_3  -1.0
    x_9_3     disj1_0_9_1  1.0
    x_9_3     disj2_0_9_1  -1.0
    x_9_3     disj1_1_9_1  1.0
    x_9_3     disj2_1_9_1  -1.0
    x_9_3     disj1_2_9_1  1.0
    x_9_3     disj2_2_9_1  -1.0
    x_9_3     disj1_3_9_1  1.0
    x_9_3     disj2_3_9_1  -1.0
    x_9_3     disj1_4_9_1  1.0
    x_9_3     disj2_4_9_1  -1.0
    x_9_3     disj1_5_9_1  1.0
    x_9_3     disj2_5_9_1  -1.0
    x_9_3     disj1_6_9_1  1.0
    x_9_3     disj2_6_9_1  -1.0
    x_9_3     disj1_7_9_1  1.0
    x_9_3     disj2_7_9_1  -1.0
    x_9_3     disj1_8_9_1  1.0
    x_9_3     disj2_8_9_1  -1.0
    x_9_4     prec_9_3  1.0
    x_9_4     prec_9_4  -1.0
    x_9_4     disj1_0_9_4  1.0
    x_9_4     disj2_0_9_4  -1.0
    x_9_4     disj1_1_9_4  1.0
    x_9_4     disj2_1_9_4  -1.0
    x_9_4     disj1_2_9_4  1.0
    x_9_4     disj2_2_9_4  -1.0
    x_9_4     disj1_3_9_4  1.0
    x_9_4     disj2_3_9_4  -1.0
    x_9_4     disj1_4_9_4  1.0
    x_9_4     disj2_4_9_4  -1.0
    x_9_4     disj1_5_9_4  1.0
    x_9_4     disj2_5_9_4  -1.0
    x_9_4     disj1_6_9_4  1.0
    x_9_4     disj2_6_9_4  -1.0
    x_9_4     disj1_7_9_4  1.0
    x_9_4     disj2_7_9_4  -1.0
    x_9_4     disj1_8_9_4  1.0
    x_9_4     disj2_8_9_4  -1.0
    x_9_5     prec_9_4  1.0
    x_9_5     prec_9_5  -1.0
    x_9_5     disj1_0_9_5  1.0
    x_9_5     disj2_0_9_5  -1.0
    x_9_5     disj1_1_9_5  1.0
    x_9_5     disj2_1_9_5  -1.0
    x_9_5     disj1_2_9_5  1.0
    x_9_5     disj2_2_9_5  -1.0
    x_9_5     disj1_3_9_5  1.0
    x_9_5     disj2_3_9_5  -1.0
    x_9_5     disj1_4_9_5  1.0
    x_9_5     disj2_4_9_5  -1.0
    x_9_5     disj1_5_9_5  1.0
    x_9_5     disj2_5_9_5  -1.0
    x_9_5     disj1_6_9_5  1.0
    x_9_5     disj2_6_9_5  -1.0
    x_9_5     disj1_7_9_5  1.0
    x_9_5     disj2_7_9_5  -1.0
    x_9_5     disj1_8_9_5  1.0
    x_9_5     disj2_8_9_5  -1.0
    x_9_6     prec_9_5  1.0
    x_9_6     prec_9_6  -1.0
    x_9_6     disj1_0_9_6  1.0
    x_9_6     disj2_0_9_6  -1.0
    x_9_6     disj1_1_9_6  1.0
    x_9_6     disj2_1_9_6  -1.0
    x_9_6     disj1_2_9_6  1.0
    x_9_6     disj2_2_9_6  -1.0
    x_9_6     disj1_3_9_6  1.0
    x_9_6     disj2_3_9_6  -1.0
    x_9_6     disj1_4_9_6  1.0
    x_9_6     disj2_4_9_6  -1.0
    x_9_6     disj1_5_9_6  1.0
    x_9_6     disj2_5_9_6  -1.0
    x_9_6     disj1_6_9_6  1.0
    x_9_6     disj2_6_9_6  -1.0
    x_9_6     disj1_7_9_6  1.0
    x_9_6     disj2_7_9_6  -1.0
    x_9_6     disj1_8_9_6  1.0
    x_9_6     disj2_8_9_6  -1.0
    x_9_7     prec_9_6  1.0
    x_9_7     prec_9_7  -1.0
    x_9_7     disj1_0_9_7  1.0
    x_9_7     disj2_0_9_7  -1.0
    x_9_7     disj1_1_9_7  1.0
    x_9_7     disj2_1_9_7  -1.0
    x_9_7     disj1_2_9_7  1.0
    x_9_7     disj2_2_9_7  -1.0
    x_9_7     disj1_3_9_7  1.0
    x_9_7     disj2_3_9_7  -1.0
    x_9_7     disj1_4_9_7  1.0
    x_9_7     disj2_4_9_7  -1.0
    x_9_7     disj1_5_9_7  1.0
    x_9_7     disj2_5_9_7  -1.0
    x_9_7     disj1_6_9_7  1.0
    x_9_7     disj2_6_9_7  -1.0
    x_9_7     disj1_7_9_7  1.0
    x_9_7     disj2_7_9_7  -1.0
    x_9_7     disj1_8_9_7  1.0
    x_9_7     disj2_8_9_7  -1.0
    x_9_8     prec_9_7  1.0
    x_9_8     prec_9_8  -1.0
    x_9_8     disj1_0_9_8  1.0
    x_9_8     disj2_0_9_8  -1.0
    x_9_8     disj1_1_9_8  1.0
    x_9_8     disj2_1_9_8  -1.0
    x_9_8     disj1_2_9_8  1.0
    x_9_8     disj2_2_9_8  -1.0
    x_9_8     disj1_3_9_8  1.0
    x_9_8     disj2_3_9_8  -1.0
    x_9_8     disj1_4_9_8  1.0
    x_9_8     disj2_4_9_8  -1.0
    x_9_8     disj1_5_9_8  1.0
    x_9_8     disj2_5_9_8  -1.0
    x_9_8     disj1_6_9_8  1.0
    x_9_8     disj2_6_9_8  -1.0
    x_9_8     disj1_7_9_8  1.0
    x_9_8     disj2_7_9_8  -1.0
    x_9_8     disj1_8_9_8  1.0
    x_9_8     disj2_8_9_8  -1.0
    x_9_9     prec_9_8  1.0
    x_9_9     mksp_9    -1.0
    x_9_9     disj1_0_9_9  1.0
    x_9_9     disj2_0_9_9  -1.0
    x_9_9     disj1_1_9_9  1.0
    x_9_9     disj2_1_9_9  -1.0
    x_9_9     disj1_2_9_9  1.0
    x_9_9     disj2_2_9_9  -1.0
    x_9_9     disj1_3_9_9  1.0
    x_9_9     disj2_3_9_9  -1.0
    x_9_9     disj1_4_9_9  1.0
    x_9_9     disj2_4_9_9  -1.0
    x_9_9     disj1_5_9_9  1.0
    x_9_9     disj2_5_9_9  -1.0
    x_9_9     disj1_6_9_9  1.0
    x_9_9     disj2_6_9_9  -1.0
    x_9_9     disj1_7_9_9  1.0
    x_9_9     disj2_7_9_9  -1.0
    x_9_9     disj1_8_9_9  1.0
    x_9_9     disj2_8_9_9  -1.0
    MARK0002  'MARKER'                 'INTORG'
    y_0_1_0   disj1_0_1_0  5467
    y_0_1_0   disj2_0_1_0  -5467
    y_0_1_1   disj1_0_1_1  5467
    y_0_1_1   disj2_0_1_1  -5467
    y_0_1_2   disj1_0_1_2  5467
    y_0_1_2   disj2_0_1_2  -5467
    y_0_1_3   disj1_0_1_3  5467
    y_0_1_3   disj2_0_1_3  -5467
    y_0_1_4   disj1_0_1_4  5467
    y_0_1_4   disj2_0_1_4  -5467
    y_0_1_5   disj1_0_1_5  5467
    y_0_1_5   disj2_0_1_5  -5467
    y_0_1_6   disj1_0_1_6  5467
    y_0_1_6   disj2_0_1_6  -5467
    y_0_1_7   disj1_0_1_7  5467
    y_0_1_7   disj2_0_1_7  -5467
    y_0_1_8   disj1_0_1_8  5467
    y_0_1_8   disj2_0_1_8  -5467
    y_0_1_9   disj1_0_1_9  5467
    y_0_1_9   disj2_0_1_9  -5467
    y_0_2_0   disj1_0_2_0  5467
    y_0_2_0   disj2_0_2_0  -5467
    y_0_2_1   disj1_0_2_1  5467
    y_0_2_1   disj2_0_2_1  -5467
    y_0_2_2   disj1_0_2_2  5467
    y_0_2_2   disj2_0_2_2  -5467
    y_0_2_3   disj1_0_2_3  5467
    y_0_2_3   disj2_0_2_3  -5467
    y_0_2_4   disj1_0_2_4  5467
    y_0_2_4   disj2_0_2_4  -5467
    y_0_2_5   disj1_0_2_5  5467
    y_0_2_5   disj2_0_2_5  -5467
    y_0_2_6   disj1_0_2_6  5467
    y_0_2_6   disj2_0_2_6  -5467
    y_0_2_7   disj1_0_2_7  5467
    y_0_2_7   disj2_0_2_7  -5467
    y_0_2_8   disj1_0_2_8  5467
    y_0_2_8   disj2_0_2_8  -5467
    y_0_2_9   disj1_0_2_9  5467
    y_0_2_9   disj2_0_2_9  -5467
    y_0_3_0   disj1_0_3_0  5467
    y_0_3_0   disj2_0_3_0  -5467
    y_0_3_1   disj1_0_3_1  5467
    y_0_3_1   disj2_0_3_1  -5467
    y_0_3_2   disj1_0_3_2  5467
    y_0_3_2   disj2_0_3_2  -5467
    y_0_3_3   disj1_0_3_3  5467
    y_0_3_3   disj2_0_3_3  -5467
    y_0_3_4   disj1_0_3_4  5467
    y_0_3_4   disj2_0_3_4  -5467
    y_0_3_5   disj1_0_3_5  5467
    y_0_3_5   disj2_0_3_5  -5467
    y_0_3_6   disj1_0_3_6  5467
    y_0_3_6   disj2_0_3_6  -5467
    y_0_3_7   disj1_0_3_7  5467
    y_0_3_7   disj2_0_3_7  -5467
    y_0_3_8   disj1_0_3_8  5467
    y_0_3_8   disj2_0_3_8  -5467
    y_0_3_9   disj1_0_3_9  5467
    y_0_3_9   disj2_0_3_9  -5467
    y_0_4_0   disj1_0_4_0  5467
    y_0_4_0   disj2_0_4_0  -5467
    y_0_4_1   disj1_0_4_1  5467
    y_0_4_1   disj2_0_4_1  -5467
    y_0_4_2   disj1_0_4_2  5467
    y_0_4_2   disj2_0_4_2  -5467
    y_0_4_3   disj1_0_4_3  5467
    y_0_4_3   disj2_0_4_3  -5467
    y_0_4_4   disj1_0_4_4  5467
    y_0_4_4   disj2_0_4_4  -5467
    y_0_4_5   disj1_0_4_5  5467
    y_0_4_5   disj2_0_4_5  -5467
    y_0_4_6   disj1_0_4_6  5467
    y_0_4_6   disj2_0_4_6  -5467
    y_0_4_7   disj1_0_4_7  5467
    y_0_4_7   disj2_0_4_7  -5467
    y_0_4_8   disj1_0_4_8  5467
    y_0_4_8   disj2_0_4_8  -5467
    y_0_4_9   disj1_0_4_9  5467
    y_0_4_9   disj2_0_4_9  -5467
    y_0_5_0   disj1_0_5_0  5467
    y_0_5_0   disj2_0_5_0  -5467
    y_0_5_1   disj1_0_5_1  5467
    y_0_5_1   disj2_0_5_1  -5467
    y_0_5_2   disj1_0_5_2  5467
    y_0_5_2   disj2_0_5_2  -5467
    y_0_5_3   disj1_0_5_3  5467
    y_0_5_3   disj2_0_5_3  -5467
    y_0_5_4   disj1_0_5_4  5467
    y_0_5_4   disj2_0_5_4  -5467
    y_0_5_5   disj1_0_5_5  5467
    y_0_5_5   disj2_0_5_5  -5467
    y_0_5_6   disj1_0_5_6  5467
    y_0_5_6   disj2_0_5_6  -5467
    y_0_5_7   disj1_0_5_7  5467
    y_0_5_7   disj2_0_5_7  -5467
    y_0_5_8   disj1_0_5_8  5467
    y_0_5_8   disj2_0_5_8  -5467
    y_0_5_9   disj1_0_5_9  5467
    y_0_5_9   disj2_0_5_9  -5467
    y_0_6_0   disj1_0_6_0  5467
    y_0_6_0   disj2_0_6_0  -5467
    y_0_6_1   disj1_0_6_1  5467
    y_0_6_1   disj2_0_6_1  -5467
    y_0_6_2   disj1_0_6_2  5467
    y_0_6_2   disj2_0_6_2  -5467
    y_0_6_3   disj1_0_6_3  5467
    y_0_6_3   disj2_0_6_3  -5467
    y_0_6_4   disj1_0_6_4  5467
    y_0_6_4   disj2_0_6_4  -5467
    y_0_6_5   disj1_0_6_5  5467
    y_0_6_5   disj2_0_6_5  -5467
    y_0_6_6   disj1_0_6_6  5467
    y_0_6_6   disj2_0_6_6  -5467
    y_0_6_7   disj1_0_6_7  5467
    y_0_6_7   disj2_0_6_7  -5467
    y_0_6_8   disj1_0_6_8  5467
    y_0_6_8   disj2_0_6_8  -5467
    y_0_6_9   disj1_0_6_9  5467
    y_0_6_9   disj2_0_6_9  -5467
    y_0_7_0   disj1_0_7_0  5467
    y_0_7_0   disj2_0_7_0  -5467
    y_0_7_1   disj1_0_7_1  5467
    y_0_7_1   disj2_0_7_1  -5467
    y_0_7_2   disj1_0_7_2  5467
    y_0_7_2   disj2_0_7_2  -5467
    y_0_7_3   disj1_0_7_3  5467
    y_0_7_3   disj2_0_7_3  -5467
    y_0_7_4   disj1_0_7_4  5467
    y_0_7_4   disj2_0_7_4  -5467
    y_0_7_5   disj1_0_7_5  5467
    y_0_7_5   disj2_0_7_5  -5467
    y_0_7_6   disj1_0_7_6  5467
    y_0_7_6   disj2_0_7_6  -5467
    y_0_7_7   disj1_0_7_7  5467
    y_0_7_7   disj2_0_7_7  -5467
    y_0_7_8   disj1_0_7_8  5467
    y_0_7_8   disj2_0_7_8  -5467
    y_0_7_9   disj1_0_7_9  5467
    y_0_7_9   disj2_0_7_9  -5467
    y_0_8_0   disj1_0_8_0  5467
    y_0_8_0   disj2_0_8_0  -5467
    y_0_8_1   disj1_0_8_1  5467
    y_0_8_1   disj2_0_8_1  -5467
    y_0_8_2   disj1_0_8_2  5467
    y_0_8_2   disj2_0_8_2  -5467
    y_0_8_3   disj1_0_8_3  5467
    y_0_8_3   disj2_0_8_3  -5467
    y_0_8_4   disj1_0_8_4  5467
    y_0_8_4   disj2_0_8_4  -5467
    y_0_8_5   disj1_0_8_5  5467
    y_0_8_5   disj2_0_8_5  -5467
    y_0_8_6   disj1_0_8_6  5467
    y_0_8_6   disj2_0_8_6  -5467
    y_0_8_7   disj1_0_8_7  5467
    y_0_8_7   disj2_0_8_7  -5467
    y_0_8_8   disj1_0_8_8  5467
    y_0_8_8   disj2_0_8_8  -5467
    y_0_8_9   disj1_0_8_9  5467
    y_0_8_9   disj2_0_8_9  -5467
    y_0_9_0   disj1_0_9_0  5467
    y_0_9_0   disj2_0_9_0  -5467
    y_0_9_1   disj1_0_9_1  5467
    y_0_9_1   disj2_0_9_1  -5467
    y_0_9_2   disj1_0_9_2  5467
    y_0_9_2   disj2_0_9_2  -5467
    y_0_9_3   disj1_0_9_3  5467
    y_0_9_3   disj2_0_9_3  -5467
    y_0_9_4   disj1_0_9_4  5467
    y_0_9_4   disj2_0_9_4  -5467
    y_0_9_5   disj1_0_9_5  5467
    y_0_9_5   disj2_0_9_5  -5467
    y_0_9_6   disj1_0_9_6  5467
    y_0_9_6   disj2_0_9_6  -5467
    y_0_9_7   disj1_0_9_7  5467
    y_0_9_7   disj2_0_9_7  -5467
    y_0_9_8   disj1_0_9_8  5467
    y_0_9_8   disj2_0_9_8  -5467
    y_0_9_9   disj1_0_9_9  5467
    y_0_9_9   disj2_0_9_9  -5467
    y_1_2_0   disj1_1_2_0  5467
    y_1_2_0   disj2_1_2_0  -5467
    y_1_2_1   disj1_1_2_1  5467
    y_1_2_1   disj2_1_2_1  -5467
    y_1_2_2   disj1_1_2_2  5467
    y_1_2_2   disj2_1_2_2  -5467
    y_1_2_3   disj1_1_2_3  5467
    y_1_2_3   disj2_1_2_3  -5467
    y_1_2_4   disj1_1_2_4  5467
    y_1_2_4   disj2_1_2_4  -5467
    y_1_2_5   disj1_1_2_5  5467
    y_1_2_5   disj2_1_2_5  -5467
    y_1_2_6   disj1_1_2_6  5467
    y_1_2_6   disj2_1_2_6  -5467
    y_1_2_7   disj1_1_2_7  5467
    y_1_2_7   disj2_1_2_7  -5467
    y_1_2_8   disj1_1_2_8  5467
    y_1_2_8   disj2_1_2_8  -5467
    y_1_2_9   disj1_1_2_9  5467
    y_1_2_9   disj2_1_2_9  -5467
    y_1_3_0   disj1_1_3_0  5467
    y_1_3_0   disj2_1_3_0  -5467
    y_1_3_1   disj1_1_3_1  5467
    y_1_3_1   disj2_1_3_1  -5467
    y_1_3_2   disj1_1_3_2  5467
    y_1_3_2   disj2_1_3_2  -5467
    y_1_3_3   disj1_1_3_3  5467
    y_1_3_3   disj2_1_3_3  -5467
    y_1_3_4   disj1_1_3_4  5467
    y_1_3_4   disj2_1_3_4  -5467
    y_1_3_5   disj1_1_3_5  5467
    y_1_3_5   disj2_1_3_5  -5467
    y_1_3_6   disj1_1_3_6  5467
    y_1_3_6   disj2_1_3_6  -5467
    y_1_3_7   disj1_1_3_7  5467
    y_1_3_7   disj2_1_3_7  -5467
    y_1_3_8   disj1_1_3_8  5467
    y_1_3_8   disj2_1_3_8  -5467
    y_1_3_9   disj1_1_3_9  5467
    y_1_3_9   disj2_1_3_9  -5467
    y_1_4_0   disj1_1_4_0  5467
    y_1_4_0   disj2_1_4_0  -5467
    y_1_4_1   disj1_1_4_1  5467
    y_1_4_1   disj2_1_4_1  -5467
    y_1_4_2   disj1_1_4_2  5467
    y_1_4_2   disj2_1_4_2  -5467
    y_1_4_3   disj1_1_4_3  5467
    y_1_4_3   disj2_1_4_3  -5467
    y_1_4_4   disj1_1_4_4  5467
    y_1_4_4   disj2_1_4_4  -5467
    y_1_4_5   disj1_1_4_5  5467
    y_1_4_5   disj2_1_4_5  -5467
    y_1_4_6   disj1_1_4_6  5467
    y_1_4_6   disj2_1_4_6  -5467
    y_1_4_7   disj1_1_4_7  5467
    y_1_4_7   disj2_1_4_7  -5467
    y_1_4_8   disj1_1_4_8  5467
    y_1_4_8   disj2_1_4_8  -5467
    y_1_4_9   disj1_1_4_9  5467
    y_1_4_9   disj2_1_4_9  -5467
    y_1_5_0   disj1_1_5_0  5467
    y_1_5_0   disj2_1_5_0  -5467
    y_1_5_1   disj1_1_5_1  5467
    y_1_5_1   disj2_1_5_1  -5467
    y_1_5_2   disj1_1_5_2  5467
    y_1_5_2   disj2_1_5_2  -5467
    y_1_5_3   disj1_1_5_3  5467
    y_1_5_3   disj2_1_5_3  -5467
    y_1_5_4   disj1_1_5_4  5467
    y_1_5_4   disj2_1_5_4  -5467
    y_1_5_5   disj1_1_5_5  5467
    y_1_5_5   disj2_1_5_5  -5467
    y_1_5_6   disj1_1_5_6  5467
    y_1_5_6   disj2_1_5_6  -5467
    y_1_5_7   disj1_1_5_7  5467
    y_1_5_7   disj2_1_5_7  -5467
    y_1_5_8   disj1_1_5_8  5467
    y_1_5_8   disj2_1_5_8  -5467
    y_1_5_9   disj1_1_5_9  5467
    y_1_5_9   disj2_1_5_9  -5467
    y_1_6_0   disj1_1_6_0  5467
    y_1_6_0   disj2_1_6_0  -5467
    y_1_6_1   disj1_1_6_1  5467
    y_1_6_1   disj2_1_6_1  -5467
    y_1_6_2   disj1_1_6_2  5467
    y_1_6_2   disj2_1_6_2  -5467
    y_1_6_3   disj1_1_6_3  5467
    y_1_6_3   disj2_1_6_3  -5467
    y_1_6_4   disj1_1_6_4  5467
    y_1_6_4   disj2_1_6_4  -5467
    y_1_6_5   disj1_1_6_5  5467
    y_1_6_5   disj2_1_6_5  -5467
    y_1_6_6   disj1_1_6_6  5467
    y_1_6_6   disj2_1_6_6  -5467
    y_1_6_7   disj1_1_6_7  5467
    y_1_6_7   disj2_1_6_7  -5467
    y_1_6_8   disj1_1_6_8  5467
    y_1_6_8   disj2_1_6_8  -5467
    y_1_6_9   disj1_1_6_9  5467
    y_1_6_9   disj2_1_6_9  -5467
    y_1_7_0   disj1_1_7_0  5467
    y_1_7_0   disj2_1_7_0  -5467
    y_1_7_1   disj1_1_7_1  5467
    y_1_7_1   disj2_1_7_1  -5467
    y_1_7_2   disj1_1_7_2  5467
    y_1_7_2   disj2_1_7_2  -5467
    y_1_7_3   disj1_1_7_3  5467
    y_1_7_3   disj2_1_7_3  -5467
    y_1_7_4   disj1_1_7_4  5467
    y_1_7_4   disj2_1_7_4  -5467
    y_1_7_5   disj1_1_7_5  5467
    y_1_7_5   disj2_1_7_5  -5467
    y_1_7_6   disj1_1_7_6  5467
    y_1_7_6   disj2_1_7_6  -5467
    y_1_7_7   disj1_1_7_7  5467
    y_1_7_7   disj2_1_7_7  -5467
    y_1_7_8   disj1_1_7_8  5467
    y_1_7_8   disj2_1_7_8  -5467
    y_1_7_9   disj1_1_7_9  5467
    y_1_7_9   disj2_1_7_9  -5467
    y_1_8_0   disj1_1_8_0  5467
    y_1_8_0   disj2_1_8_0  -5467
    y_1_8_1   disj1_1_8_1  5467
    y_1_8_1   disj2_1_8_1  -5467
    y_1_8_2   disj1_1_8_2  5467
    y_1_8_2   disj2_1_8_2  -5467
    y_1_8_3   disj1_1_8_3  5467
    y_1_8_3   disj2_1_8_3  -5467
    y_1_8_4   disj1_1_8_4  5467
    y_1_8_4   disj2_1_8_4  -5467
    y_1_8_5   disj1_1_8_5  5467
    y_1_8_5   disj2_1_8_5  -5467
    y_1_8_6   disj1_1_8_6  5467
    y_1_8_6   disj2_1_8_6  -5467
    y_1_8_7   disj1_1_8_7  5467
    y_1_8_7   disj2_1_8_7  -5467
    y_1_8_8   disj1_1_8_8  5467
    y_1_8_8   disj2_1_8_8  -5467
    y_1_8_9   disj1_1_8_9  5467
    y_1_8_9   disj2_1_8_9  -5467
    y_1_9_0   disj1_1_9_0  5467
    y_1_9_0   disj2_1_9_0  -5467
    y_1_9_1   disj1_1_9_1  5467
    y_1_9_1   disj2_1_9_1  -5467
    y_1_9_2   disj1_1_9_2  5467
    y_1_9_2   disj2_1_9_2  -5467
    y_1_9_3   disj1_1_9_3  5467
    y_1_9_3   disj2_1_9_3  -5467
    y_1_9_4   disj1_1_9_4  5467
    y_1_9_4   disj2_1_9_4  -5467
    y_1_9_5   disj1_1_9_5  5467
    y_1_9_5   disj2_1_9_5  -5467
    y_1_9_6   disj1_1_9_6  5467
    y_1_9_6   disj2_1_9_6  -5467
    y_1_9_7   disj1_1_9_7  5467
    y_1_9_7   disj2_1_9_7  -5467
    y_1_9_8   disj1_1_9_8  5467
    y_1_9_8   disj2_1_9_8  -5467
    y_1_9_9   disj1_1_9_9  5467
    y_1_9_9   disj2_1_9_9  -5467
    y_2_3_0   disj1_2_3_0  5467
    y_2_3_0   disj2_2_3_0  -5467
    y_2_3_1   disj1_2_3_1  5467
    y_2_3_1   disj2_2_3_1  -5467
    y_2_3_2   disj1_2_3_2  5467
    y_2_3_2   disj2_2_3_2  -5467
    y_2_3_3   disj1_2_3_3  5467
    y_2_3_3   disj2_2_3_3  -5467
    y_2_3_4   disj1_2_3_4  5467
    y_2_3_4   disj2_2_3_4  -5467
    y_2_3_5   disj1_2_3_5  5467
    y_2_3_5   disj2_2_3_5  -5467
    y_2_3_6   disj1_2_3_6  5467
    y_2_3_6   disj2_2_3_6  -5467
    y_2_3_7   disj1_2_3_7  5467
    y_2_3_7   disj2_2_3_7  -5467
    y_2_3_8   disj1_2_3_8  5467
    y_2_3_8   disj2_2_3_8  -5467
    y_2_3_9   disj1_2_3_9  5467
    y_2_3_9   disj2_2_3_9  -5467
    y_2_4_0   disj1_2_4_0  5467
    y_2_4_0   disj2_2_4_0  -5467
    y_2_4_1   disj1_2_4_1  5467
    y_2_4_1   disj2_2_4_1  -5467
    y_2_4_2   disj1_2_4_2  5467
    y_2_4_2   disj2_2_4_2  -5467
    y_2_4_3   disj1_2_4_3  5467
    y_2_4_3   disj2_2_4_3  -5467
    y_2_4_4   disj1_2_4_4  5467
    y_2_4_4   disj2_2_4_4  -5467
    y_2_4_5   disj1_2_4_5  5467
    y_2_4_5   disj2_2_4_5  -5467
    y_2_4_6   disj1_2_4_6  5467
    y_2_4_6   disj2_2_4_6  -5467
    y_2_4_7   disj1_2_4_7  5467
    y_2_4_7   disj2_2_4_7  -5467
    y_2_4_8   disj1_2_4_8  5467
    y_2_4_8   disj2_2_4_8  -5467
    y_2_4_9   disj1_2_4_9  5467
    y_2_4_9   disj2_2_4_9  -5467
    y_2_5_0   disj1_2_5_0  5467
    y_2_5_0   disj2_2_5_0  -5467
    y_2_5_1   disj1_2_5_1  5467
    y_2_5_1   disj2_2_5_1  -5467
    y_2_5_2   disj1_2_5_2  5467
    y_2_5_2   disj2_2_5_2  -5467
    y_2_5_3   disj1_2_5_3  5467
    y_2_5_3   disj2_2_5_3  -5467
    y_2_5_4   disj1_2_5_4  5467
    y_2_5_4   disj2_2_5_4  -5467
    y_2_5_5   disj1_2_5_5  5467
    y_2_5_5   disj2_2_5_5  -5467
    y_2_5_6   disj1_2_5_6  5467
    y_2_5_6   disj2_2_5_6  -5467
    y_2_5_7   disj1_2_5_7  5467
    y_2_5_7   disj2_2_5_7  -5467
    y_2_5_8   disj1_2_5_8  5467
    y_2_5_8   disj2_2_5_8  -5467
    y_2_5_9   disj1_2_5_9  5467
    y_2_5_9   disj2_2_5_9  -5467
    y_2_6_0   disj1_2_6_0  5467
    y_2_6_0   disj2_2_6_0  -5467
    y_2_6_1   disj1_2_6_1  5467
    y_2_6_1   disj2_2_6_1  -5467
    y_2_6_2   disj1_2_6_2  5467
    y_2_6_2   disj2_2_6_2  -5467
    y_2_6_3   disj1_2_6_3  5467
    y_2_6_3   disj2_2_6_3  -5467
    y_2_6_4   disj1_2_6_4  5467
    y_2_6_4   disj2_2_6_4  -5467
    y_2_6_5   disj1_2_6_5  5467
    y_2_6_5   disj2_2_6_5  -5467
    y_2_6_6   disj1_2_6_6  5467
    y_2_6_6   disj2_2_6_6  -5467
    y_2_6_7   disj1_2_6_7  5467
    y_2_6_7   disj2_2_6_7  -5467
    y_2_6_8   disj1_2_6_8  5467
    y_2_6_8   disj2_2_6_8  -5467
    y_2_6_9   disj1_2_6_9  5467
    y_2_6_9   disj2_2_6_9  -5467
    y_2_7_0   disj1_2_7_0  5467
    y_2_7_0   disj2_2_7_0  -5467
    y_2_7_1   disj1_2_7_1  5467
    y_2_7_1   disj2_2_7_1  -5467
    y_2_7_2   disj1_2_7_2  5467
    y_2_7_2   disj2_2_7_2  -5467
    y_2_7_3   disj1_2_7_3  5467
    y_2_7_3   disj2_2_7_3  -5467
    y_2_7_4   disj1_2_7_4  5467
    y_2_7_4   disj2_2_7_4  -5467
    y_2_7_5   disj1_2_7_5  5467
    y_2_7_5   disj2_2_7_5  -5467
    y_2_7_6   disj1_2_7_6  5467
    y_2_7_6   disj2_2_7_6  -5467
    y_2_7_7   disj1_2_7_7  5467
    y_2_7_7   disj2_2_7_7  -5467
    y_2_7_8   disj1_2_7_8  5467
    y_2_7_8   disj2_2_7_8  -5467
    y_2_7_9   disj1_2_7_9  5467
    y_2_7_9   disj2_2_7_9  -5467
    y_2_8_0   disj1_2_8_0  5467
    y_2_8_0   disj2_2_8_0  -5467
    y_2_8_1   disj1_2_8_1  5467
    y_2_8_1   disj2_2_8_1  -5467
    y_2_8_2   disj1_2_8_2  5467
    y_2_8_2   disj2_2_8_2  -5467
    y_2_8_3   disj1_2_8_3  5467
    y_2_8_3   disj2_2_8_3  -5467
    y_2_8_4   disj1_2_8_4  5467
    y_2_8_4   disj2_2_8_4  -5467
    y_2_8_5   disj1_2_8_5  5467
    y_2_8_5   disj2_2_8_5  -5467
    y_2_8_6   disj1_2_8_6  5467
    y_2_8_6   disj2_2_8_6  -5467
    y_2_8_7   disj1_2_8_7  5467
    y_2_8_7   disj2_2_8_7  -5467
    y_2_8_8   disj1_2_8_8  5467
    y_2_8_8   disj2_2_8_8  -5467
    y_2_8_9   disj1_2_8_9  5467
    y_2_8_9   disj2_2_8_9  -5467
    y_2_9_0   disj1_2_9_0  5467
    y_2_9_0   disj2_2_9_0  -5467
    y_2_9_1   disj1_2_9_1  5467
    y_2_9_1   disj2_2_9_1  -5467
    y_2_9_2   disj1_2_9_2  5467
    y_2_9_2   disj2_2_9_2  -5467
    y_2_9_3   disj1_2_9_3  5467
    y_2_9_3   disj2_2_9_3  -5467
    y_2_9_4   disj1_2_9_4  5467
    y_2_9_4   disj2_2_9_4  -5467
    y_2_9_5   disj1_2_9_5  5467
    y_2_9_5   disj2_2_9_5  -5467
    y_2_9_6   disj1_2_9_6  5467
    y_2_9_6   disj2_2_9_6  -5467
    y_2_9_7   disj1_2_9_7  5467
    y_2_9_7   disj2_2_9_7  -5467
    y_2_9_8   disj1_2_9_8  5467
    y_2_9_8   disj2_2_9_8  -5467
    y_2_9_9   disj1_2_9_9  5467
    y_2_9_9   disj2_2_9_9  -5467
    y_3_4_0   disj1_3_4_0  5467
    y_3_4_0   disj2_3_4_0  -5467
    y_3_4_1   disj1_3_4_1  5467
    y_3_4_1   disj2_3_4_1  -5467
    y_3_4_2   disj1_3_4_2  5467
    y_3_4_2   disj2_3_4_2  -5467
    y_3_4_3   disj1_3_4_3  5467
    y_3_4_3   disj2_3_4_3  -5467
    y_3_4_4   disj1_3_4_4  5467
    y_3_4_4   disj2_3_4_4  -5467
    y_3_4_5   disj1_3_4_5  5467
    y_3_4_5   disj2_3_4_5  -5467
    y_3_4_6   disj1_3_4_6  5467
    y_3_4_6   disj2_3_4_6  -5467
    y_3_4_7   disj1_3_4_7  5467
    y_3_4_7   disj2_3_4_7  -5467
    y_3_4_8   disj1_3_4_8  5467
    y_3_4_8   disj2_3_4_8  -5467
    y_3_4_9   disj1_3_4_9  5467
    y_3_4_9   disj2_3_4_9  -5467
    y_3_5_0   disj1_3_5_0  5467
    y_3_5_0   disj2_3_5_0  -5467
    y_3_5_1   disj1_3_5_1  5467
    y_3_5_1   disj2_3_5_1  -5467
    y_3_5_2   disj1_3_5_2  5467
    y_3_5_2   disj2_3_5_2  -5467
    y_3_5_3   disj1_3_5_3  5467
    y_3_5_3   disj2_3_5_3  -5467
    y_3_5_4   disj1_3_5_4  5467
    y_3_5_4   disj2_3_5_4  -5467
    y_3_5_5   disj1_3_5_5  5467
    y_3_5_5   disj2_3_5_5  -5467
    y_3_5_6   disj1_3_5_6  5467
    y_3_5_6   disj2_3_5_6  -5467
    y_3_5_7   disj1_3_5_7  5467
    y_3_5_7   disj2_3_5_7  -5467
    y_3_5_8   disj1_3_5_8  5467
    y_3_5_8   disj2_3_5_8  -5467
    y_3_5_9   disj1_3_5_9  5467
    y_3_5_9   disj2_3_5_9  -5467
    y_3_6_0   disj1_3_6_0  5467
    y_3_6_0   disj2_3_6_0  -5467
    y_3_6_1   disj1_3_6_1  5467
    y_3_6_1   disj2_3_6_1  -5467
    y_3_6_2   disj1_3_6_2  5467
    y_3_6_2   disj2_3_6_2  -5467
    y_3_6_3   disj1_3_6_3  5467
    y_3_6_3   disj2_3_6_3  -5467
    y_3_6_4   disj1_3_6_4  5467
    y_3_6_4   disj2_3_6_4  -5467
    y_3_6_5   disj1_3_6_5  5467
    y_3_6_5   disj2_3_6_5  -5467
    y_3_6_6   disj1_3_6_6  5467
    y_3_6_6   disj2_3_6_6  -5467
    y_3_6_7   disj1_3_6_7  5467
    y_3_6_7   disj2_3_6_7  -5467
    y_3_6_8   disj1_3_6_8  5467
    y_3_6_8   disj2_3_6_8  -5467
    y_3_6_9   disj1_3_6_9  5467
    y_3_6_9   disj2_3_6_9  -5467
    y_3_7_0   disj1_3_7_0  5467
    y_3_7_0   disj2_3_7_0  -5467
    y_3_7_1   disj1_3_7_1  5467
    y_3_7_1   disj2_3_7_1  -5467
    y_3_7_2   disj1_3_7_2  5467
    y_3_7_2   disj2_3_7_2  -5467
    y_3_7_3   disj1_3_7_3  5467
    y_3_7_3   disj2_3_7_3  -5467
    y_3_7_4   disj1_3_7_4  5467
    y_3_7_4   disj2_3_7_4  -5467
    y_3_7_5   disj1_3_7_5  5467
    y_3_7_5   disj2_3_7_5  -5467
    y_3_7_6   disj1_3_7_6  5467
    y_3_7_6   disj2_3_7_6  -5467
    y_3_7_7   disj1_3_7_7  5467
    y_3_7_7   disj2_3_7_7  -5467
    y_3_7_8   disj1_3_7_8  5467
    y_3_7_8   disj2_3_7_8  -5467
    y_3_7_9   disj1_3_7_9  5467
    y_3_7_9   disj2_3_7_9  -5467
    y_3_8_0   disj1_3_8_0  5467
    y_3_8_0   disj2_3_8_0  -5467
    y_3_8_1   disj1_3_8_1  5467
    y_3_8_1   disj2_3_8_1  -5467
    y_3_8_2   disj1_3_8_2  5467
    y_3_8_2   disj2_3_8_2  -5467
    y_3_8_3   disj1_3_8_3  5467
    y_3_8_3   disj2_3_8_3  -5467
    y_3_8_4   disj1_3_8_4  5467
    y_3_8_4   disj2_3_8_4  -5467
    y_3_8_5   disj1_3_8_5  5467
    y_3_8_5   disj2_3_8_5  -5467
    y_3_8_6   disj1_3_8_6  5467
    y_3_8_6   disj2_3_8_6  -5467
    y_3_8_7   disj1_3_8_7  5467
    y_3_8_7   disj2_3_8_7  -5467
    y_3_8_8   disj1_3_8_8  5467
    y_3_8_8   disj2_3_8_8  -5467
    y_3_8_9   disj1_3_8_9  5467
    y_3_8_9   disj2_3_8_9  -5467
    y_3_9_0   disj1_3_9_0  5467
    y_3_9_0   disj2_3_9_0  -5467
    y_3_9_1   disj1_3_9_1  5467
    y_3_9_1   disj2_3_9_1  -5467
    y_3_9_2   disj1_3_9_2  5467
    y_3_9_2   disj2_3_9_2  -5467
    y_3_9_3   disj1_3_9_3  5467
    y_3_9_3   disj2_3_9_3  -5467
    y_3_9_4   disj1_3_9_4  5467
    y_3_9_4   disj2_3_9_4  -5467
    y_3_9_5   disj1_3_9_5  5467
    y_3_9_5   disj2_3_9_5  -5467
    y_3_9_6   disj1_3_9_6  5467
    y_3_9_6   disj2_3_9_6  -5467
    y_3_9_7   disj1_3_9_7  5467
    y_3_9_7   disj2_3_9_7  -5467
    y_3_9_8   disj1_3_9_8  5467
    y_3_9_8   disj2_3_9_8  -5467
    y_3_9_9   disj1_3_9_9  5467
    y_3_9_9   disj2_3_9_9  -5467
    y_4_5_0   disj1_4_5_0  5467
    y_4_5_0   disj2_4_5_0  -5467
    y_4_5_1   disj1_4_5_1  5467
    y_4_5_1   disj2_4_5_1  -5467
    y_4_5_2   disj1_4_5_2  5467
    y_4_5_2   disj2_4_5_2  -5467
    y_4_5_3   disj1_4_5_3  5467
    y_4_5_3   disj2_4_5_3  -5467
    y_4_5_4   disj1_4_5_4  5467
    y_4_5_4   disj2_4_5_4  -5467
    y_4_5_5   disj1_4_5_5  5467
    y_4_5_5   disj2_4_5_5  -5467
    y_4_5_6   disj1_4_5_6  5467
    y_4_5_6   disj2_4_5_6  -5467
    y_4_5_7   disj1_4_5_7  5467
    y_4_5_7   disj2_4_5_7  -5467
    y_4_5_8   disj1_4_5_8  5467
    y_4_5_8   disj2_4_5_8  -5467
    y_4_5_9   disj1_4_5_9  5467
    y_4_5_9   disj2_4_5_9  -5467
    y_4_6_0   disj1_4_6_0  5467
    y_4_6_0   disj2_4_6_0  -5467
    y_4_6_1   disj1_4_6_1  5467
    y_4_6_1   disj2_4_6_1  -5467
    y_4_6_2   disj1_4_6_2  5467
    y_4_6_2   disj2_4_6_2  -5467
    y_4_6_3   disj1_4_6_3  5467
    y_4_6_3   disj2_4_6_3  -5467
    y_4_6_4   disj1_4_6_4  5467
    y_4_6_4   disj2_4_6_4  -5467
    y_4_6_5   disj1_4_6_5  5467
    y_4_6_5   disj2_4_6_5  -5467
    y_4_6_6   disj1_4_6_6  5467
    y_4_6_6   disj2_4_6_6  -5467
    y_4_6_7   disj1_4_6_7  5467
    y_4_6_7   disj2_4_6_7  -5467
    y_4_6_8   disj1_4_6_8  5467
    y_4_6_8   disj2_4_6_8  -5467
    y_4_6_9   disj1_4_6_9  5467
    y_4_6_9   disj2_4_6_9  -5467
    y_4_7_0   disj1_4_7_0  5467
    y_4_7_0   disj2_4_7_0  -5467
    y_4_7_1   disj1_4_7_1  5467
    y_4_7_1   disj2_4_7_1  -5467
    y_4_7_2   disj1_4_7_2  5467
    y_4_7_2   disj2_4_7_2  -5467
    y_4_7_3   disj1_4_7_3  5467
    y_4_7_3   disj2_4_7_3  -5467
    y_4_7_4   disj1_4_7_4  5467
    y_4_7_4   disj2_4_7_4  -5467
    y_4_7_5   disj1_4_7_5  5467
    y_4_7_5   disj2_4_7_5  -5467
    y_4_7_6   disj1_4_7_6  5467
    y_4_7_6   disj2_4_7_6  -5467
    y_4_7_7   disj1_4_7_7  5467
    y_4_7_7   disj2_4_7_7  -5467
    y_4_7_8   disj1_4_7_8  5467
    y_4_7_8   disj2_4_7_8  -5467
    y_4_7_9   disj1_4_7_9  5467
    y_4_7_9   disj2_4_7_9  -5467
    y_4_8_0   disj1_4_8_0  5467
    y_4_8_0   disj2_4_8_0  -5467
    y_4_8_1   disj1_4_8_1  5467
    y_4_8_1   disj2_4_8_1  -5467
    y_4_8_2   disj1_4_8_2  5467
    y_4_8_2   disj2_4_8_2  -5467
    y_4_8_3   disj1_4_8_3  5467
    y_4_8_3   disj2_4_8_3  -5467
    y_4_8_4   disj1_4_8_4  5467
    y_4_8_4   disj2_4_8_4  -5467
    y_4_8_5   disj1_4_8_5  5467
    y_4_8_5   disj2_4_8_5  -5467
    y_4_8_6   disj1_4_8_6  5467
    y_4_8_6   disj2_4_8_6  -5467
    y_4_8_7   disj1_4_8_7  5467
    y_4_8_7   disj2_4_8_7  -5467
    y_4_8_8   disj1_4_8_8  5467
    y_4_8_8   disj2_4_8_8  -5467
    y_4_8_9   disj1_4_8_9  5467
    y_4_8_9   disj2_4_8_9  -5467
    y_4_9_0   disj1_4_9_0  5467
    y_4_9_0   disj2_4_9_0  -5467
    y_4_9_1   disj1_4_9_1  5467
    y_4_9_1   disj2_4_9_1  -5467
    y_4_9_2   disj1_4_9_2  5467
    y_4_9_2   disj2_4_9_2  -5467
    y_4_9_3   disj1_4_9_3  5467
    y_4_9_3   disj2_4_9_3  -5467
    y_4_9_4   disj1_4_9_4  5467
    y_4_9_4   disj2_4_9_4  -5467
    y_4_9_5   disj1_4_9_5  5467
    y_4_9_5   disj2_4_9_5  -5467
    y_4_9_6   disj1_4_9_6  5467
    y_4_9_6   disj2_4_9_6  -5467
    y_4_9_7   disj1_4_9_7  5467
    y_4_9_7   disj2_4_9_7  -5467
    y_4_9_8   disj1_4_9_8  5467
    y_4_9_8   disj2_4_9_8  -5467
    y_4_9_9   disj1_4_9_9  5467
    y_4_9_9   disj2_4_9_9  -5467
    y_5_6_0   disj1_5_6_0  5467
    y_5_6_0   disj2_5_6_0  -5467
    y_5_6_1   disj1_5_6_1  5467
    y_5_6_1   disj2_5_6_1  -5467
    y_5_6_2   disj1_5_6_2  5467
    y_5_6_2   disj2_5_6_2  -5467
    y_5_6_3   disj1_5_6_3  5467
    y_5_6_3   disj2_5_6_3  -5467
    y_5_6_4   disj1_5_6_4  5467
    y_5_6_4   disj2_5_6_4  -5467
    y_5_6_5   disj1_5_6_5  5467
    y_5_6_5   disj2_5_6_5  -5467
    y_5_6_6   disj1_5_6_6  5467
    y_5_6_6   disj2_5_6_6  -5467
    y_5_6_7   disj1_5_6_7  5467
    y_5_6_7   disj2_5_6_7  -5467
    y_5_6_8   disj1_5_6_8  5467
    y_5_6_8   disj2_5_6_8  -5467
    y_5_6_9   disj1_5_6_9  5467
    y_5_6_9   disj2_5_6_9  -5467
    y_5_7_0   disj1_5_7_0  5467
    y_5_7_0   disj2_5_7_0  -5467
    y_5_7_1   disj1_5_7_1  5467
    y_5_7_1   disj2_5_7_1  -5467
    y_5_7_2   disj1_5_7_2  5467
    y_5_7_2   disj2_5_7_2  -5467
    y_5_7_3   disj1_5_7_3  5467
    y_5_7_3   disj2_5_7_3  -5467
    y_5_7_4   disj1_5_7_4  5467
    y_5_7_4   disj2_5_7_4  -5467
    y_5_7_5   disj1_5_7_5  5467
    y_5_7_5   disj2_5_7_5  -5467
    y_5_7_6   disj1_5_7_6  5467
    y_5_7_6   disj2_5_7_6  -5467
    y_5_7_7   disj1_5_7_7  5467
    y_5_7_7   disj2_5_7_7  -5467
    y_5_7_8   disj1_5_7_8  5467
    y_5_7_8   disj2_5_7_8  -5467
    y_5_7_9   disj1_5_7_9  5467
    y_5_7_9   disj2_5_7_9  -5467
    y_5_8_0   disj1_5_8_0  5467
    y_5_8_0   disj2_5_8_0  -5467
    y_5_8_1   disj1_5_8_1  5467
    y_5_8_1   disj2_5_8_1  -5467
    y_5_8_2   disj1_5_8_2  5467
    y_5_8_2   disj2_5_8_2  -5467
    y_5_8_3   disj1_5_8_3  5467
    y_5_8_3   disj2_5_8_3  -5467
    y_5_8_4   disj1_5_8_4  5467
    y_5_8_4   disj2_5_8_4  -5467
    y_5_8_5   disj1_5_8_5  5467
    y_5_8_5   disj2_5_8_5  -5467
    y_5_8_6   disj1_5_8_6  5467
    y_5_8_6   disj2_5_8_6  -5467
    y_5_8_7   disj1_5_8_7  5467
    y_5_8_7   disj2_5_8_7  -5467
    y_5_8_8   disj1_5_8_8  5467
    y_5_8_8   disj2_5_8_8  -5467
    y_5_8_9   disj1_5_8_9  5467
    y_5_8_9   disj2_5_8_9  -5467
    y_5_9_0   disj1_5_9_0  5467
    y_5_9_0   disj2_5_9_0  -5467
    y_5_9_1   disj1_5_9_1  5467
    y_5_9_1   disj2_5_9_1  -5467
    y_5_9_2   disj1_5_9_2  5467
    y_5_9_2   disj2_5_9_2  -5467
    y_5_9_3   disj1_5_9_3  5467
    y_5_9_3   disj2_5_9_3  -5467
    y_5_9_4   disj1_5_9_4  5467
    y_5_9_4   disj2_5_9_4  -5467
    y_5_9_5   disj1_5_9_5  5467
    y_5_9_5   disj2_5_9_5  -5467
    y_5_9_6   disj1_5_9_6  5467
    y_5_9_6   disj2_5_9_6  -5467
    y_5_9_7   disj1_5_9_7  5467
    y_5_9_7   disj2_5_9_7  -5467
    y_5_9_8   disj1_5_9_8  5467
    y_5_9_8   disj2_5_9_8  -5467
    y_5_9_9   disj1_5_9_9  5467
    y_5_9_9   disj2_5_9_9  -5467
    y_6_7_0   disj1_6_7_0  5467
    y_6_7_0   disj2_6_7_0  -5467
    y_6_7_1   disj1_6_7_1  5467
    y_6_7_1   disj2_6_7_1  -5467
    y_6_7_2   disj1_6_7_2  5467
    y_6_7_2   disj2_6_7_2  -5467
    y_6_7_3   disj1_6_7_3  5467
    y_6_7_3   disj2_6_7_3  -5467
    y_6_7_4   disj1_6_7_4  5467
    y_6_7_4   disj2_6_7_4  -5467
    y_6_7_5   disj1_6_7_5  5467
    y_6_7_5   disj2_6_7_5  -5467
    y_6_7_6   disj1_6_7_6  5467
    y_6_7_6   disj2_6_7_6  -5467
    y_6_7_7   disj1_6_7_7  5467
    y_6_7_7   disj2_6_7_7  -5467
    y_6_7_8   disj1_6_7_8  5467
    y_6_7_8   disj2_6_7_8  -5467
    y_6_7_9   disj1_6_7_9  5467
    y_6_7_9   disj2_6_7_9  -5467
    y_6_8_0   disj1_6_8_0  5467
    y_6_8_0   disj2_6_8_0  -5467
    y_6_8_1   disj1_6_8_1  5467
    y_6_8_1   disj2_6_8_1  -5467
    y_6_8_2   disj1_6_8_2  5467
    y_6_8_2   disj2_6_8_2  -5467
    y_6_8_3   disj1_6_8_3  5467
    y_6_8_3   disj2_6_8_3  -5467
    y_6_8_4   disj1_6_8_4  5467
    y_6_8_4   disj2_6_8_4  -5467
    y_6_8_5   disj1_6_8_5  5467
    y_6_8_5   disj2_6_8_5  -5467
    y_6_8_6   disj1_6_8_6  5467
    y_6_8_6   disj2_6_8_6  -5467
    y_6_8_7   disj1_6_8_7  5467
    y_6_8_7   disj2_6_8_7  -5467
    y_6_8_8   disj1_6_8_8  5467
    y_6_8_8   disj2_6_8_8  -5467
    y_6_8_9   disj1_6_8_9  5467
    y_6_8_9   disj2_6_8_9  -5467
    y_6_9_0   disj1_6_9_0  5467
    y_6_9_0   disj2_6_9_0  -5467
    y_6_9_1   disj1_6_9_1  5467
    y_6_9_1   disj2_6_9_1  -5467
    y_6_9_2   disj1_6_9_2  5467
    y_6_9_2   disj2_6_9_2  -5467
    y_6_9_3   disj1_6_9_3  5467
    y_6_9_3   disj2_6_9_3  -5467
    y_6_9_4   disj1_6_9_4  5467
    y_6_9_4   disj2_6_9_4  -5467
    y_6_9_5   disj1_6_9_5  5467
    y_6_9_5   disj2_6_9_5  -5467
    y_6_9_6   disj1_6_9_6  5467
    y_6_9_6   disj2_6_9_6  -5467
    y_6_9_7   disj1_6_9_7  5467
    y_6_9_7   disj2_6_9_7  -5467
    y_6_9_8   disj1_6_9_8  5467
    y_6_9_8   disj2_6_9_8  -5467
    y_6_9_9   disj1_6_9_9  5467
    y_6_9_9   disj2_6_9_9  -5467
    y_7_8_0   disj1_7_8_0  5467
    y_7_8_0   disj2_7_8_0  -5467
    y_7_8_1   disj1_7_8_1  5467
    y_7_8_1   disj2_7_8_1  -5467
    y_7_8_2   disj1_7_8_2  5467
    y_7_8_2   disj2_7_8_2  -5467
    y_7_8_3   disj1_7_8_3  5467
    y_7_8_3   disj2_7_8_3  -5467
    y_7_8_4   disj1_7_8_4  5467
    y_7_8_4   disj2_7_8_4  -5467
    y_7_8_5   disj1_7_8_5  5467
    y_7_8_5   disj2_7_8_5  -5467
    y_7_8_6   disj1_7_8_6  5467
    y_7_8_6   disj2_7_8_6  -5467
    y_7_8_7   disj1_7_8_7  5467
    y_7_8_7   disj2_7_8_7  -5467
    y_7_8_8   disj1_7_8_8  5467
    y_7_8_8   disj2_7_8_8  -5467
    y_7_8_9   disj1_7_8_9  5467
    y_7_8_9   disj2_7_8_9  -5467
    y_7_9_0   disj1_7_9_0  5467
    y_7_9_0   disj2_7_9_0  -5467
    y_7_9_1   disj1_7_9_1  5467
    y_7_9_1   disj2_7_9_1  -5467
    y_7_9_2   disj1_7_9_2  5467
    y_7_9_2   disj2_7_9_2  -5467
    y_7_9_3   disj1_7_9_3  5467
    y_7_9_3   disj2_7_9_3  -5467
    y_7_9_4   disj1_7_9_4  5467
    y_7_9_4   disj2_7_9_4  -5467
    y_7_9_5   disj1_7_9_5  5467
    y_7_9_5   disj2_7_9_5  -5467
    y_7_9_6   disj1_7_9_6  5467
    y_7_9_6   disj2_7_9_6  -5467
    y_7_9_7   disj1_7_9_7  5467
    y_7_9_7   disj2_7_9_7  -5467
    y_7_9_8   disj1_7_9_8  5467
    y_7_9_8   disj2_7_9_8  -5467
    y_7_9_9   disj1_7_9_9  5467
    y_7_9_9   disj2_7_9_9  -5467
    y_8_9_0   disj1_8_9_0  5467
    y_8_9_0   disj2_8_9_0  -5467
    y_8_9_1   disj1_8_9_1  5467
    y_8_9_1   disj2_8_9_1  -5467
    y_8_9_2   disj1_8_9_2  5467
    y_8_9_2   disj2_8_9_2  -5467
    y_8_9_3   disj1_8_9_3  5467
    y_8_9_3   disj2_8_9_3  -5467
    y_8_9_4   disj1_8_9_4  5467
    y_8_9_4   disj2_8_9_4  -5467
    y_8_9_5   disj1_8_9_5  5467
    y_8_9_5   disj2_8_9_5  -5467
    y_8_9_6   disj1_8_9_6  5467
    y_8_9_6   disj2_8_9_6  -5467
    y_8_9_7   disj1_8_9_7  5467
    y_8_9_7   disj2_8_9_7  -5467
    y_8_9_8   disj1_8_9_8  5467
    y_8_9_8   disj2_8_9_8  -5467
    y_8_9_9   disj1_8_9_9  5467
    y_8_9_9   disj2_8_9_9  -5467
    MARK9999  'MARKER'                 'INTEND'
RHS
    RHS       prec_0_0  21
    RHS       prec_0_1  34
    RHS       prec_0_2  95
    RHS       prec_0_3  41
    RHS       prec_0_4  66
    RHS       prec_0_5  98
    RHS       prec_0_6  54
    RHS       prec_0_7  48
    RHS       prec_0_8  39
    RHS       prec_1_0  52
    RHS       prec_1_1  16
    RHS       prec_1_2  31
    RHS       prec_1_3  21
    RHS       prec_1_4  26
    RHS       prec_1_5  71
    RHS       prec_1_6  16
    RHS       prec_1_7  25
    RHS       prec_1_8  98
    RHS       prec_2_0  42
    RHS       prec_2_1  39
    RHS       prec_2_2  98
    RHS       prec_2_3  54
    RHS       prec_2_4  16
    RHS       prec_2_5  77
    RHS       prec_2_6  79
    RHS       prec_2_7  43
    RHS       prec_2_8  75
    RHS       prec_3_0  55
    RHS       prec_3_1  79
    RHS       prec_3_2  77
    RHS       prec_3_3  98
    RHS       prec_3_4  77
    RHS       prec_3_5  34
    RHS       prec_3_6  64
    RHS       prec_3_7  19
    RHS       prec_3_8  30
    RHS       prec_4_0  34
    RHS       prec_4_1  64
    RHS       prec_4_2  30
    RHS       prec_4_3  83
    RHS       prec_4_4  19
    RHS       prec_4_5  92
    RHS       prec_4_6  62
    RHS       prec_4_7  54
    RHS       prec_4_8  43
    RHS       prec_5_0  69
    RHS       prec_5_1  77
    RHS       prec_5_2  87
    RHS       prec_5_3  93
    RHS       prec_5_4  87
    RHS       prec_5_5  38
    RHS       prec_5_6  60
    RHS       prec_5_7  41
    RHS       prec_5_8  83
    RHS       prec_6_0  17
    RHS       prec_6_1  49
    RHS       prec_6_2  25
    RHS       prec_6_3  44
    RHS       prec_6_4  98
    RHS       prec_6_5  96
    RHS       prec_6_6  77
    RHS       prec_6_7  79
    RHS       prec_6_8  75
    RHS       prec_7_0  28
    RHS       prec_7_1  35
    RHS       prec_7_2  95
    RHS       prec_7_3  76
    RHS       prec_7_4  7
    RHS       prec_7_5  9
    RHS       prec_7_6  10
    RHS       prec_7_7  91
    RHS       prec_7_8  59
    RHS       prec_8_0  46
    RHS       prec_8_1  28
    RHS       prec_8_2  52
    RHS       prec_8_3  16
    RHS       prec_8_4  59
    RHS       prec_8_5  91
    RHS       prec_8_6  50
    RHS       prec_8_7  59
    RHS       prec_8_8  43
    RHS       prec_9_0  27
    RHS       prec_9_1  59
    RHS       prec_9_2  46
    RHS       prec_9_3  45
    RHS       prec_9_4  90
    RHS       prec_9_5  59
    RHS       prec_9_6  46
    RHS       prec_9_7  74
    RHS       prec_9_8  43
    RHS       mksp_0    17
    RHS       mksp_1    44
    RHS       mksp_2    96
    RHS       mksp_3    83
    RHS       mksp_4    79
    RHS       mksp_5    24
    RHS       mksp_6    43
    RHS       mksp_7    59
    RHS       mksp_8    50
    RHS       mksp_9    45
    RHS       disj1_0_1_0  34
    RHS       disj2_0_1_0  -5446
    RHS       disj1_0_2_0  34
    RHS       disj2_0_2_0  -5369
    RHS       disj1_0_3_0  34
    RHS       disj2_0_3_0  -5390
    RHS       disj1_0_4_0  34
    RHS       disj2_0_4_0  -5433
    RHS       disj1_0_5_0  34
    RHS       disj2_0_5_0  -5374
    RHS       disj1_0_6_0  34
    RHS       disj2_0_6_0  -5423
    RHS       disj1_0_7_0  34
    RHS       disj2_0_7_0  -5372
    RHS       disj1_0_8_0  34
    RHS       disj2_0_8_0  -5451
    RHS       disj1_0_9_0  34
    RHS       disj2_0_9_0  -5421
    RHS       disj1_1_2_0  21
    RHS       disj2_1_2_0  -5369
    RHS       disj1_1_3_0  21
    RHS       disj2_1_3_0  -5390
    RHS       disj1_1_4_0  21
    RHS       disj2_1_4_0  -5433
    RHS       disj1_1_5_0  21
    RHS       disj2_1_5_0  -5374
    RHS       disj1_1_6_0  21
    RHS       disj2_1_6_0  -5423
    RHS       disj1_1_7_0  21
    RHS       disj2_1_7_0  -5372
    RHS       disj1_1_8_0  21
    RHS       disj2_1_8_0  -5451
    RHS       disj1_1_9_0  21
    RHS       disj2_1_9_0  -5421
    RHS       disj1_2_3_0  98
    RHS       disj2_2_3_0  -5390
    RHS       disj1_2_4_0  98
    RHS       disj2_2_4_0  -5433
    RHS       disj1_2_5_0  98
    RHS       disj2_2_5_0  -5374
    RHS       disj1_2_6_0  98
    RHS       disj2_2_6_0  -5423
    RHS       disj1_2_7_0  98
    RHS       disj2_2_7_0  -5372
    RHS       disj1_2_8_0  98
    RHS       disj2_2_8_0  -5451
    RHS       disj1_2_9_0  98
    RHS       disj2_2_9_0  -5421
    RHS       disj1_3_4_0  77
    RHS       disj2_3_4_0  -5433
    RHS       disj1_3_5_0  77
    RHS       disj2_3_5_0  -5374
    RHS       disj1_3_6_0  77
    RHS       disj2_3_6_0  -5423
    RHS       disj1_3_7_0  77
    RHS       disj2_3_7_0  -5372
    RHS       disj1_3_8_0  77
    RHS       disj2_3_8_0  -5451
    RHS       disj1_3_9_0  77
    RHS       disj2_3_9_0  -5421
    RHS       disj1_4_5_0  34
    RHS       disj2_4_5_0  -5374
    RHS       disj1_4_6_0  34
    RHS       disj2_4_6_0  -5423
    RHS       disj1_4_7_0  34
    RHS       disj2_4_7_0  -5372
    RHS       disj1_4_8_0  34
    RHS       disj2_4_8_0  -5451
    RHS       disj1_4_9_0  34
    RHS       disj2_4_9_0  -5421
    RHS       disj1_5_6_0  93
    RHS       disj2_5_6_0  -5423
    RHS       disj1_5_7_0  93
    RHS       disj2_5_7_0  -5372
    RHS       disj1_5_8_0  93
    RHS       disj2_5_8_0  -5451
    RHS       disj1_5_9_0  93
    RHS       disj2_5_9_0  -5421
    RHS       disj1_6_7_0  44
    RHS       disj2_6_7_0  -5372
    RHS       disj1_6_8_0  44
    RHS       disj2_6_8_0  -5451
    RHS       disj1_6_9_0  44
    RHS       disj2_6_9_0  -5421
    RHS       disj1_7_8_0  95
    RHS       disj2_7_8_0  -5451
    RHS       disj1_7_9_0  95
    RHS       disj2_7_9_0  -5421
    RHS       disj1_8_9_0  16
    RHS       disj2_8_9_0  -5421
    RHS       disj1_0_1_1  41
    RHS       disj2_0_1_1  -5415
    RHS       disj1_0_2_1  41
    RHS       disj2_0_2_1  -5451
    RHS       disj1_0_3_1  41
    RHS       disj2_0_3_1  -5388
    RHS       disj1_0_4_1  41
    RHS       disj2_0_4_1  -5437
    RHS       disj1_0_5_1  41
    RHS       disj2_0_5_1  -5398
    RHS       disj1_0_6_1  41
    RHS       disj2_0_6_1  -5418
    RHS       disj1_0_7_1  41
    RHS       disj2_0_7_1  -5391
    RHS       disj1_0_8_1  41
    RHS       disj2_0_8_1  -5421
    RHS       disj1_0_9_1  41
    RHS       disj2_0_9_1  -5422
    RHS       disj1_1_2_1  52
    RHS       disj2_1_2_1  -5451
    RHS       disj1_1_3_1  52
    RHS       disj2_1_3_1  -5388
    RHS       disj1_1_4_1  52
    RHS       disj2_1_4_1  -5437
    RHS       disj1_1_5_1  52
    RHS       disj2_1_5_1  -5398
    RHS       disj1_1_6_1  52
    RHS       disj2_1_6_1  -5418
    RHS       disj1_1_7_1  52
    RHS       disj2_1_7_1  -5391
    RHS       disj1_1_8_1  52
    RHS       disj2_1_8_1  -5421
    RHS       disj1_1_9_1  52
    RHS       disj2_1_9_1  -5422
    RHS       disj1_2_3_1  16
    RHS       disj2_2_3_1  -5388
    RHS       disj1_2_4_1  16
    RHS       disj2_2_4_1  -5437
    RHS       disj1_2_5_1  16
    RHS       disj2_2_5_1  -5398
    RHS       disj1_2_6_1  16
    RHS       disj2_2_6_1  -5418
    RHS       disj1_2_7_1  16
    RHS       disj2_2_7_1  -5391
    RHS       disj1_2_8_1  16
    RHS       disj2_2_8_1  -5421
    RHS       disj1_2_9_1  16
    RHS       disj2_2_9_1  -5422
    RHS       disj1_3_4_1  79
    RHS       disj2_3_4_1  -5437
    RHS       disj1_3_5_1  79
    RHS       disj2_3_5_1  -5398
    RHS       disj1_3_6_1  79
    RHS       disj2_3_6_1  -5418
    RHS       disj1_3_7_1  79
    RHS       disj2_3_7_1  -5391
    RHS       disj1_3_8_1  79
    RHS       disj2_3_8_1  -5421
    RHS       disj1_3_9_1  79
    RHS       disj2_3_9_1  -5422
    RHS       disj1_4_5_1  30
    RHS       disj2_4_5_1  -5398
    RHS       disj1_4_6_1  30
    RHS       disj2_4_6_1  -5418
    RHS       disj1_4_7_1  30
    RHS       disj2_4_7_1  -5391
    RHS       disj1_4_8_1  30
    RHS       disj2_4_8_1  -5421
    RHS       disj1_4_9_1  30
    RHS       disj2_4_9_1  -5422
    RHS       disj1_5_6_1  69
    RHS       disj2_5_6_1  -5418
    RHS       disj1_5_7_1  69
    RHS       disj2_5_7_1  -5391
    RHS       disj1_5_8_1  69
    RHS       disj2_5_8_1  -5421
    RHS       disj1_5_9_1  69
    RHS       disj2_5_9_1  -5422
    RHS       disj1_6_7_1  49
    RHS       disj2_6_7_1  -5391
    RHS       disj1_6_8_1  49
    RHS       disj2_6_8_1  -5421
    RHS       disj1_6_9_1  49
    RHS       disj2_6_9_1  -5422
    RHS       disj1_7_8_1  76
    RHS       disj2_7_8_1  -5421
    RHS       disj1_7_9_1  76
    RHS       disj2_7_9_1  -5422
    RHS       disj1_8_9_1  46
    RHS       disj2_8_9_1  -5422
    RHS       disj1_0_1_2  21
    RHS       disj2_0_1_2  -5441
    RHS       disj1_0_2_2  21
    RHS       disj2_0_2_2  -5428
    RHS       disj1_0_3_2  21
    RHS       disj2_0_3_2  -5390
    RHS       disj1_0_4_2  21
    RHS       disj2_0_4_2  -5384
    RHS       disj1_0_5_2  21
    RHS       disj2_0_5_2  -5380
    RHS       disj1_0_6_2  21
    RHS       disj2_0_6_2  -5450
    RHS       disj1_0_7_2  21
    RHS       disj2_0_7_2  -5460
    RHS       disj1_0_8_2  21
    RHS       disj2_0_8_2  -5415
    RHS       disj1_0_9_2  21
    RHS       disj2_0_9_2  -5440
    RHS       disj1_1_2_2  26
    RHS       disj2_1_2_2  -5428
    RHS       disj1_1_3_2  26
    RHS       disj2_1_3_2  -5390
    RHS       disj1_1_4_2  26
    RHS       disj2_1_4_2  -5384
    RHS       disj1_1_5_2  26
    RHS       disj2_1_5_2  -5380
    RHS       disj1_1_6_2  26
    RHS       disj2_1_6_2  -5450
    RHS       disj1_1_7_2  26
    RHS       disj2_1_7_2  -5460
    RHS       disj1_1_8_2  26
    RHS       disj2_1_8_2  -5415
    RHS       disj1_1_9_2  26
    RHS       disj2_1_9_2  -5440
    RHS       disj1_2_3_2  39
    RHS       disj2_2_3_2  -5390
    RHS       disj1_2_4_2  39
    RHS       disj2_2_4_2  -5384
    RHS       disj1_2_5_2  39
    RHS       disj2_2_5_2  -5380
    RHS       disj1_2_6_2  39
    RHS       disj2_2_6_2  -5450
    RHS       disj1_2_7_2  39
    RHS       disj2_2_7_2  -5460
    RHS       disj1_2_8_2  39
    RHS       disj2_2_8_2  -5415
    RHS       disj1_2_9_2  39
    RHS       disj2_2_9_2  -5440
    RHS       disj1_3_4_2  77
    RHS       disj2_3_4_2  -5384
    RHS       disj1_3_5_2  77
    RHS       disj2_3_5_2  -5380
    RHS       disj1_3_6_2  77
    RHS       disj2_3_6_2  -5450
    RHS       disj1_3_7_2  77
    RHS       disj2_3_7_2  -5460
    RHS       disj1_3_8_2  77
    RHS       disj2_3_8_2  -5415
    RHS       disj1_3_9_2  77
    RHS       disj2_3_9_2  -5440
    RHS       disj1_4_5_2  83
    RHS       disj2_4_5_2  -5380
    RHS       disj1_4_6_2  83
    RHS       disj2_4_6_2  -5450
    RHS       disj1_4_7_2  83
    RHS       disj2_4_7_2  -5460
    RHS       disj1_4_8_2  83
    RHS       disj2_4_8_2  -5415
    RHS       disj1_4_9_2  83
    RHS       disj2_4_9_2  -5440
    RHS       disj1_5_6_2  87
    RHS       disj2_5_6_2  -5450
    RHS       disj1_5_7_2  87
    RHS       disj2_5_7_2  -5460
    RHS       disj1_5_8_2  87
    RHS       disj2_5_8_2  -5415
    RHS       disj1_5_9_2  87
    RHS       disj2_5_9_2  -5440
    RHS       disj1_6_7_2  17
    RHS       disj2_6_7_2  -5460
    RHS       disj1_6_8_2  17
    RHS       disj2_6_8_2  -5415
    RHS       disj1_6_9_2  17
    RHS       disj2_6_9_2  -5440
    RHS       disj1_7_8_2  7
    RHS       disj2_7_8_2  -5415
    RHS       disj1_7_9_2  7
    RHS       disj2_7_9_2  -5440
    RHS       disj1_8_9_2  52
    RHS       disj2_8_9_2  -5440
    RHS       disj1_0_1_3  95
    RHS       disj2_0_1_3  -5436
    RHS       disj1_0_2_3  95
    RHS       disj2_0_2_3  -5425
    RHS       disj1_0_3_3  95
    RHS       disj2_0_3_3  -5369
    RHS       disj1_0_4_3  95
    RHS       disj2_0_4_3  -5403
    RHS       disj1_0_5_3  95
    RHS       disj2_0_5_3  -5390
    RHS       disj1_0_6_3  95
    RHS       disj2_0_6_3  -5369
    RHS       disj1_0_7_3  95
    RHS       disj2_0_7_3  -5439
    RHS       disj1_0_8_3  95
    RHS       disj2_0_8_3  -5439
    RHS       disj1_0_9_3  95
    RHS       disj2_0_9_3  -5408
    RHS       disj1_1_2_3  31
    RHS       disj2_1_2_3  -5425
    RHS       disj1_1_3_3  31
    RHS       disj2_1_3_3  -5369
    RHS       disj1_1_4_3  31
    RHS       disj2_1_4_3  -5403
    RHS       disj1_1_5_3  31
    RHS       disj2_1_5_3  -5390
    RHS       disj1_1_6_3  31
    RHS       disj2_1_6_3  -5369
    RHS       disj1_1_7_3  31
    RHS       disj2_1_7_3  -5439
    RHS       disj1_1_8_3  31
    RHS       disj2_1_8_3  -5439
    RHS       disj1_1_9_3  31
    RHS       disj2_1_9_3  -5408
    RHS       disj1_2_3_3  42
    RHS       disj2_2_3_3  -5369
    RHS       disj1_2_4_3  42
    RHS       disj2_2_4_3  -5403
    RHS       disj1_2_5_3  42
    RHS       disj2_2_5_3  -5390
    RHS       disj1_2_6_3  42
    RHS       disj2_2_6_3  -5369
    RHS       disj1_2_7_3  42
    RHS       disj2_2_7_3  -5439
    RHS       disj1_2_8_3  42
    RHS       disj2_2_8_3  -5439
    RHS       disj1_2_9_3  42
    RHS       disj2_2_9_3  -5408
    RHS       disj1_3_4_3  98
    RHS       disj2_3_4_3  -5403
    RHS       disj1_3_5_3  98
    RHS       disj2_3_5_3  -5390
    RHS       disj1_3_6_3  98
    RHS       disj2_3_6_3  -5369
    RHS       disj1_3_7_3  98
    RHS       disj2_3_7_3  -5439
    RHS       disj1_3_8_3  98
    RHS       disj2_3_8_3  -5439
    RHS       disj1_3_9_3  98
    RHS       disj2_3_9_3  -5408
    RHS       disj1_4_5_3  64
    RHS       disj2_4_5_3  -5390
    RHS       disj1_4_6_3  64
    RHS       disj2_4_6_3  -5369
    RHS       disj1_4_7_3  64
    RHS       disj2_4_7_3  -5439
    RHS       disj1_4_8_3  64
    RHS       disj2_4_8_3  -5439
    RHS       disj1_4_9_3  64
    RHS       disj2_4_9_3  -5408
    RHS       disj1_5_6_3  77
    RHS       disj2_5_6_3  -5369
    RHS       disj1_5_7_3  77
    RHS       disj2_5_7_3  -5439
    RHS       disj1_5_8_3  77
    RHS       disj2_5_8_3  -5439
    RHS       disj1_5_9_3  77
    RHS       disj2_5_9_3  -5408
    RHS       disj1_6_7_3  98
    RHS       disj2_6_7_3  -5439
    RHS       disj1_6_8_3  98
    RHS       disj2_6_8_3  -5439
    RHS       disj1_6_9_3  98
    RHS       disj2_6_9_3  -5408
    RHS       disj1_7_8_3  28
    RHS       disj2_7_8_3  -5439
    RHS       disj1_7_9_3  28
    RHS       disj2_7_9_3  -5408
    RHS       disj1_8_9_3  28
    RHS       disj2_8_9_3  -5408
    RHS       disj1_0_1_4  66
    RHS       disj2_0_1_4  -5451
    RHS       disj1_0_2_4  66
    RHS       disj2_0_2_4  -5413
    RHS       disj1_0_3_4  66
    RHS       disj2_0_3_4  -5412
    RHS       disj1_0_4_4  66
    RHS       disj2_0_4_4  -5448
    RHS       disj1_0_5_4  66
    RHS       disj2_0_5_4  -5380
    RHS       disj1_0_6_4  66
    RHS       disj2_0_6_4  -5442
    RHS       disj1_0_7_4  66
    RHS       disj2_0_7_4  -5432
    RHS       disj1_0_8_4  66
    RHS       disj2_0_8_4  -5408
    RHS       disj1_0_9_4  66
    RHS       disj2_0_9_4  -5377
    RHS       disj1_1_2_4  16
    RHS       disj2_1_2_4  -5413
    RHS       disj1_1_3_4  16
    RHS       disj2_1_3_4  -5412
    RHS       disj1_1_4_4  16
    RHS       disj2_1_4_4  -5448
    RHS       disj1_1_5_4  16
    RHS       disj2_1_5_4  -5380
    RHS       disj1_1_6_4  16
    RHS       disj2_1_6_4  -5442
    RHS       disj1_1_7_4  16
    RHS       disj2_1_7_4  -5432
    RHS       disj1_1_8_4  16
    RHS       disj2_1_8_4  -5408
    RHS       disj1_1_9_4  16
    RHS       disj2_1_9_4  -5377
    RHS       disj1_2_3_4  54
    RHS       disj2_2_3_4  -5412
    RHS       disj1_2_4_4  54
    RHS       disj2_2_4_4  -5448
    RHS       disj1_2_5_4  54
    RHS       disj2_2_5_4  -5380
    RHS       disj1_2_6_4  54
    RHS       disj2_2_6_4  -5442
    RHS       disj1_2_7_4  54
    RHS       disj2_2_7_4  -5432
    RHS       disj1_2_8_4  54
    RHS       disj2_2_8_4  -5408
    RHS       disj1_2_9_4  54
    RHS       disj2_2_9_4  -5377
    RHS       disj1_3_4_4  55
    RHS       disj2_3_4_4  -5448
    RHS       disj1_3_5_4  55
    RHS       disj2_3_5_4  -5380
    RHS       disj1_3_6_4  55
    RHS       disj2_3_6_4  -5442
    RHS       disj1_3_7_4  55
    RHS       disj2_3_7_4  -5432
    RHS       disj1_3_8_4  55
    RHS       disj2_3_8_4  -5408
    RHS       disj1_3_9_4  55
    RHS       disj2_3_9_4  -5377
    RHS       disj1_4_5_4  19
    RHS       disj2_4_5_4  -5380
    RHS       disj1_4_6_4  19
    RHS       disj2_4_6_4  -5442
    RHS       disj1_4_7_4  19
    RHS       disj2_4_7_4  -5432
    RHS       disj1_4_8_4  19
    RHS       disj2_4_8_4  -5408
    RHS       disj1_4_9_4  19
    RHS       disj2_4_9_4  -5377
    RHS       disj1_5_6_4  87
    RHS       disj2_5_6_4  -5442
    RHS       disj1_5_7_4  87
    RHS       disj2_5_7_4  -5432
    RHS       disj1_5_8_4  87
    RHS       disj2_5_8_4  -5408
    RHS       disj1_5_9_4  87
    RHS       disj2_5_9_4  -5377
    RHS       disj1_6_7_4  25
    RHS       disj2_6_7_4  -5432
    RHS       disj1_6_8_4  25
    RHS       disj2_6_8_4  -5408
    RHS       disj1_6_9_4  25
    RHS       disj2_6_9_4  -5377
    RHS       disj1_7_8_4  35
    RHS       disj2_7_8_4  -5408
    RHS       disj1_7_9_4  35
    RHS       disj2_7_9_4  -5377
    RHS       disj1_8_9_4  59
    RHS       disj2_8_9_4  -5377
    RHS       disj1_0_1_5  98
    RHS       disj2_0_1_5  -5451
    RHS       disj1_0_2_5  98
    RHS       disj2_0_2_5  -5424
    RHS       disj1_0_3_5  98
    RHS       disj2_0_3_5  -5433
    RHS       disj1_0_4_5  98
    RHS       disj2_0_4_5  -5413
    RHS       disj1_0_5_5  98
    RHS       disj2_0_5_5  -5407
    RHS       disj1_0_6_5  98
    RHS       disj2_0_6_5  -5371
    RHS       disj1_0_7_5  98
    RHS       disj2_0_7_5  -5457
    RHS       disj1_0_8_5  98
    RHS       disj2_0_8_5  -5408
    RHS       disj1_0_9_5  98
    RHS       disj2_0_9_5  -5408
    RHS       disj1_1_2_5  16
    RHS       disj2_1_2_5  -5424
    RHS       disj1_1_3_5  16
    RHS       disj2_1_3_5  -5433
    RHS       disj1_1_4_5  16
    RHS       disj2_1_4_5  -5413
    RHS       disj1_1_5_5  16
    RHS       disj2_1_5_5  -5407
    RHS       disj1_1_6_5  16
    RHS       disj2_1_6_5  -5371
    RHS       disj1_1_7_5  16
    RHS       disj2_1_7_5  -5457
    RHS       disj1_1_8_5  16
    RHS       disj2_1_8_5  -5408
    RHS       disj1_1_9_5  16
    RHS       disj2_1_9_5  -5408
    RHS       disj1_2_3_5  43
    RHS       disj2_2_3_5  -5433
    RHS       disj1_2_4_5  43
    RHS       disj2_2_4_5  -5413
    RHS       disj1_2_5_5  43
    RHS       disj2_2_5_5  -5407
    RHS       disj1_2_6_5  43
    RHS       disj2_2_6_5  -5371
    RHS       disj1_2_7_5  43
    RHS       disj2_2_7_5  -5457
    RHS       disj1_2_8_5  43
    RHS       disj2_2_8_5  -5408
    RHS       disj1_2_9_5  43
    RHS       disj2_2_9_5  -5408
    RHS       disj1_3_4_5  34
    RHS       disj2_3_4_5  -5413
    RHS       disj1_3_5_5  34
    RHS       disj2_3_5_5  -5407
    RHS       disj1_3_6_5  34
    RHS       disj2_3_6_5  -5371
    RHS       disj1_3_7_5  34
    RHS       disj2_3_7_5  -5457
    RHS       disj1_3_8_5  34
    RHS       disj2_3_8_5  -5408
    RHS       disj1_3_9_5  34
    RHS       disj2_3_9_5  -5408
    RHS       disj1_4_5_5  54
    RHS       disj2_4_5_5  -5407
    RHS       disj1_4_6_5  54
    RHS       disj2_4_6_5  -5371
    RHS       disj1_4_7_5  54
    RHS       disj2_4_7_5  -5457
    RHS       disj1_4_8_5  54
    RHS       disj2_4_8_5  -5408
    RHS       disj1_4_9_5  54
    RHS       disj2_4_9_5  -5408
    RHS       disj1_5_6_5  60
    RHS       disj2_5_6_5  -5371
    RHS       disj1_5_7_5  60
    RHS       disj2_5_7_5  -5457
    RHS       disj1_5_8_5  60
    RHS       disj2_5_8_5  -5408
    RHS       disj1_5_9_5  60
    RHS       disj2_5_9_5  -5408
    RHS       disj1_6_7_5  96
    RHS       disj2_6_7_5  -5457
    RHS       disj1_6_8_5  96
    RHS       disj2_6_8_5  -5408
    RHS       disj1_6_9_5  96
    RHS       disj2_6_9_5  -5408
    RHS       disj1_7_8_5  10
    RHS       disj2_7_8_5  -5408
    RHS       disj1_7_9_5  10
    RHS       disj2_7_9_5  -5408
    RHS       disj1_8_9_5  59
    RHS       disj2_8_9_5  -5408
    RHS       disj1_0_1_6  48
    RHS       disj2_0_1_6  -5396
    RHS       disj1_0_2_6  48
    RHS       disj2_0_2_6  -5388
    RHS       disj1_0_3_6  48
    RHS       disj2_0_3_6  -5448
    RHS       disj1_0_4_6  48
    RHS       disj2_0_4_6  -5375
    RHS       disj1_0_5_6  48
    RHS       disj2_0_5_6  -5426
    RHS       disj1_0_6_6  48
    RHS       disj2_0_6_6  -5390
    RHS       disj1_0_7_6  48
    RHS       disj2_0_7_6  -5458
    RHS       disj1_0_8_6  48
    RHS       disj2_0_8_6  -5417
    RHS       disj1_0_9_6  48
    RHS       disj2_0_9_6  -5421
    RHS       disj1_1_2_6  71
    RHS       disj2_1_2_6  -5388
    RHS       disj1_1_3_6  71
    RHS       disj2_1_3_6  -5448
    RHS       disj1_1_4_6  71
    RHS       disj2_1_4_6  -5375
    RHS       disj1_1_5_6  71
    RHS       disj2_1_5_6  -5426
    RHS       disj1_1_6_6  71
    RHS       disj2_1_6_6  -5390
    RHS       disj1_1_7_6  71
    RHS       disj2_1_7_6  -5458
    RHS       disj1_1_8_6  71
    RHS       disj2_1_8_6  -5417
    RHS       disj1_1_9_6  71
    RHS       disj2_1_9_6  -5421
    RHS       disj1_2_3_6  79
    RHS       disj2_2_3_6  -5448
    RHS       disj1_2_4_6  79
    RHS       disj2_2_4_6  -5375
    RHS       disj1_2_5_6  79
    RHS       disj2_2_5_6  -5426
    RHS       disj1_2_6_6  79
    RHS       disj2_2_6_6  -5390
    RHS       disj1_2_7_6  79
    RHS       disj2_2_7_6  -5458
    RHS       disj1_2_8_6  79
    RHS       disj2_2_8_6  -5417
    RHS       disj1_2_9_6  79
    RHS       disj2_2_9_6  -5421
    RHS       disj1_3_4_6  19
    RHS       disj2_3_4_6  -5375
    RHS       disj1_3_5_6  19
    RHS       disj2_3_5_6  -5426
    RHS       disj1_3_6_6  19
    RHS       disj2_3_6_6  -5390
    RHS       disj1_3_7_6  19
    RHS       disj2_3_7_6  -5458
    RHS       disj1_3_8_6  19
    RHS       disj2_3_8_6  -5417
    RHS       disj1_3_9_6  19
    RHS       disj2_3_9_6  -5421
    RHS       disj1_4_5_6  92
    RHS       disj2_4_5_6  -5426
    RHS       disj1_4_6_6  92
    RHS       disj2_4_6_6  -5390
    RHS       disj1_4_7_6  92
    RHS       disj2_4_7_6  -5458
    RHS       disj1_4_8_6  92
    RHS       disj2_4_8_6  -5417
    RHS       disj1_4_9_6  92
    RHS       disj2_4_9_6  -5421
    RHS       disj1_5_6_6  41
    RHS       disj2_5_6_6  -5390
    RHS       disj1_5_7_6  41
    RHS       disj2_5_7_6  -5458
    RHS       disj1_5_8_6  41
    RHS       disj2_5_8_6  -5417
    RHS       disj1_5_9_6  41
    RHS       disj2_5_9_6  -5421
    RHS       disj1_6_7_6  77
    RHS       disj2_6_7_6  -5458
    RHS       disj1_6_8_6  77
    RHS       disj2_6_8_6  -5417
    RHS       disj1_6_9_6  77
    RHS       disj2_6_9_6  -5421
    RHS       disj1_7_8_6  9
    RHS       disj2_7_8_6  -5417
    RHS       disj1_7_9_6  9
    RHS       disj2_7_9_6  -5421
    RHS       disj1_8_9_6  50
    RHS       disj2_8_9_6  -5421
    RHS       disj1_0_1_7  54
    RHS       disj2_0_1_7  -5423
    RHS       disj1_0_2_7  54
    RHS       disj2_0_2_7  -5390
    RHS       disj1_0_3_7  54
    RHS       disj2_0_3_7  -5403
    RHS       disj1_0_4_7  54
    RHS       disj2_0_4_7  -5405
    RHS       disj1_0_5_7  54
    RHS       disj2_0_5_7  -5429
    RHS       disj1_0_6_7  54
    RHS       disj2_0_6_7  -5388
    RHS       disj1_0_7_7  54
    RHS       disj2_0_7_7  -5376
    RHS       disj1_0_8_7  54
    RHS       disj2_0_8_7  -5376
    RHS       disj1_0_9_7  54
    RHS       disj2_0_9_7  -5393
    RHS       disj1_1_2_7  44
    RHS       disj2_1_2_7  -5390
    RHS       disj1_1_3_7  44
    RHS       disj2_1_3_7  -5403
    RHS       disj1_1_4_7  44
    RHS       disj2_1_4_7  -5405
    RHS       disj1_1_5_7  44
    RHS       disj2_1_5_7  -5429
    RHS       disj1_1_6_7  44
    RHS       disj2_1_6_7  -5388
    RHS       disj1_1_7_7  44
    RHS       disj2_1_7_7  -5376
    RHS       disj1_1_8_7  44
    RHS       disj2_1_8_7  -5376
    RHS       disj1_1_9_7  44
    RHS       disj2_1_9_7  -5393
    RHS       disj1_2_3_7  77
    RHS       disj2_2_3_7  -5403
    RHS       disj1_2_4_7  77
    RHS       disj2_2_4_7  -5405
    RHS       disj1_2_5_7  77
    RHS       disj2_2_5_7  -5429
    RHS       disj1_2_6_7  77
    RHS       disj2_2_6_7  -5388
    RHS       disj1_2_7_7  77
    RHS       disj2_2_7_7  -5376
    RHS       disj1_2_8_7  77
    RHS       disj2_2_8_7  -5376
    RHS       disj1_2_9_7  77
    RHS       disj2_2_9_7  -5393
    RHS       disj1_3_4_7  64
    RHS       disj2_3_4_7  -5405
    RHS       disj1_3_5_7  64
    RHS       disj2_3_5_7  -5429
    RHS       disj1_3_6_7  64
    RHS       disj2_3_6_7  -5388
    RHS       disj1_3_7_7  64
    RHS       disj2_3_7_7  -5376
    RHS       disj1_3_8_7  64
    RHS       disj2_3_8_7  -5376
    RHS       disj1_3_9_7  64
    RHS       disj2_3_9_7  -5393
    RHS       disj1_4_5_7  62
    RHS       disj2_4_5_7  -5429
    RHS       disj1_4_6_7  62
    RHS       disj2_4_6_7  -5388
    RHS       disj1_4_7_7  62
    RHS       disj2_4_7_7  -5376
    RHS       disj1_4_8_7  62
    RHS       disj2_4_8_7  -5376
    RHS       disj1_4_9_7  62
    RHS       disj2_4_9_7  -5393
    RHS       disj1_5_6_7  38
    RHS       disj2_5_6_7  -5388
    RHS       disj1_5_7_7  38
    RHS       disj2_5_7_7  -5376
    RHS       disj1_5_8_7  38
    RHS       disj2_5_8_7  -5376
    RHS       disj1_5_9_7  38
    RHS       disj2_5_9_7  -5393
    RHS       disj1_6_7_7  79
    RHS       disj2_6_7_7  -5376
    RHS       disj1_6_8_7  79
    RHS       disj2_6_8_7  -5376
    RHS       disj1_6_9_7  79
    RHS       disj2_6_9_7  -5393
    RHS       disj1_7_8_7  91
    RHS       disj2_7_8_7  -5376
    RHS       disj1_7_9_7  91
    RHS       disj2_7_9_7  -5393
    RHS       disj1_8_9_7  91
    RHS       disj2_8_9_7  -5393
    RHS       disj1_0_1_8  17
    RHS       disj2_0_1_8  -5442
    RHS       disj1_0_2_8  17
    RHS       disj2_0_2_8  -5392
    RHS       disj1_0_3_8  17
    RHS       disj2_0_3_8  -5384
    RHS       disj1_0_4_8  17
    RHS       disj2_0_4_8  -5424
    RHS       disj1_0_5_8  17
    RHS       disj2_0_5_8  -5443
    RHS       disj1_0_6_8  17
    RHS       disj2_0_6_8  -5392
    RHS       disj1_0_7_8  17
    RHS       disj2_0_7_8  -5408
    RHS       disj1_0_8_8  17
    RHS       disj2_0_8_8  -5424
    RHS       disj1_0_9_8  17
    RHS       disj2_0_9_8  -5424
    RHS       disj1_1_2_8  25
    RHS       disj2_1_2_8  -5392
    RHS       disj1_1_3_8  25
    RHS       disj2_1_3_8  -5384
    RHS       disj1_1_4_8  25
    RHS       disj2_1_4_8  -5424
    RHS       disj1_1_5_8  25
    RHS       disj2_1_5_8  -5443
    RHS       disj1_1_6_8  25
    RHS       disj2_1_6_8  -5392
    RHS       disj1_1_7_8  25
    RHS       disj2_1_7_8  -5408
    RHS       disj1_1_8_8  25
    RHS       disj2_1_8_8  -5424
    RHS       disj1_1_9_8  25
    RHS       disj2_1_9_8  -5424
    RHS       disj1_2_3_8  75
    RHS       disj2_2_3_8  -5384
    RHS       disj1_2_4_8  75
    RHS       disj2_2_4_8  -5424
    RHS       disj1_2_5_8  75
    RHS       disj2_2_5_8  -5443
    RHS       disj1_2_6_8  75
    RHS       disj2_2_6_8  -5392
    RHS       disj1_2_7_8  75
    RHS       disj2_2_7_8  -5408
    RHS       disj1_2_8_8  75
    RHS       disj2_2_8_8  -5424
    RHS       disj1_2_9_8  75
    RHS       disj2_2_9_8  -5424
    RHS       disj1_3_4_8  83
    RHS       disj2_3_4_8  -5424
    RHS       disj1_3_5_8  83
    RHS       disj2_3_5_8  -5443
    RHS       disj1_3_6_8  83
    RHS       disj2_3_6_8  -5392
    RHS       disj1_3_7_8  83
    RHS       disj2_3_7_8  -5408
    RHS       disj1_3_8_8  83
    RHS       disj2_3_8_8  -5424
    RHS       disj1_3_9_8  83
    RHS       disj2_3_9_8  -5424
    RHS       disj1_4_5_8  43
    RHS       disj2_4_5_8  -5443
    RHS       disj1_4_6_8  43
    RHS       disj2_4_6_8  -5392
    RHS       disj1_4_7_8  43
    RHS       disj2_4_7_8  -5408
    RHS       disj1_4_8_8  43
    RHS       disj2_4_8_8  -5424
    RHS       disj1_4_9_8  43
    RHS       disj2_4_9_8  -5424
    RHS       disj1_5_6_8  24
    RHS       disj2_5_6_8  -5392
    RHS       disj1_5_7_8  24
    RHS       disj2_5_7_8  -5408
    RHS       disj1_5_8_8  24
    RHS       disj2_5_8_8  -5424
    RHS       disj1_5_9_8  24
    RHS       disj2_5_9_8  -5424
    RHS       disj1_6_7_8  75
    RHS       disj2_6_7_8  -5408
    RHS       disj1_6_8_8  75
    RHS       disj2_6_8_8  -5424
    RHS       disj1_6_9_8  75
    RHS       disj2_6_9_8  -5424
    RHS       disj1_7_8_8  59
    RHS       disj2_7_8_8  -5424
    RHS       disj1_7_9_8  59
    RHS       disj2_7_9_8  -5424
    RHS       disj1_8_9_8  43
    RHS       disj2_8_9_8  -5424
    RHS       disj1_0_1_9  39
    RHS       disj2_0_1_9  -5369
    RHS       disj1_0_2_9  39
    RHS       disj2_0_2_9  -5371
    RHS       disj1_0_3_9  39
    RHS       disj2_0_3_9  -5437
    RHS       disj1_0_4_9  39
    RHS       disj2_0_4_9  -5388
    RHS       disj1_0_5_9  39
    RHS       disj2_0_5_9  -5384
    RHS       disj1_0_6_9  39
    RHS       disj2_0_6_9  -5424
    RHS       disj1_0_7_9  39
    RHS       disj2_0_7_9  -5408
    RHS       disj1_0_8_9  39
    RHS       disj2_0_8_9  -5417
    RHS       disj1_0_9_9  39
    RHS       disj2_0_9_9  -5422
    RHS       disj1_1_2_9  98
    RHS       disj2_1_2_9  -5371
    RHS       disj1_1_3_9  98
    RHS       disj2_1_3_9  -5437
    RHS       disj1_1_4_9  98
    RHS       disj2_1_4_9  -5388
    RHS       disj1_1_5_9  98
    RHS       disj2_1_5_9  -5384
    RHS       disj1_1_6_9  98
    RHS       disj2_1_6_9  -5424
    RHS       disj1_1_7_9  98
    RHS       disj2_1_7_9  -5408
    RHS       disj1_1_8_9  98
    RHS       disj2_1_8_9  -5417
    RHS       disj1_1_9_9  98
    RHS       disj2_1_9_9  -5422
    RHS       disj1_2_3_9  96
    RHS       disj2_2_3_9  -5437
    RHS       disj1_2_4_9  96
    RHS       disj2_2_4_9  -5388
    RHS       disj1_2_5_9  96
    RHS       disj2_2_5_9  -5384
    RHS       disj1_2_6_9  96
    RHS       disj2_2_6_9  -5424
    RHS       disj1_2_7_9  96
    RHS       disj2_2_7_9  -5408
    RHS       disj1_2_8_9  96
    RHS       disj2_2_8_9  -5417
    RHS       disj1_2_9_9  96
    RHS       disj2_2_9_9  -5422
    RHS       disj1_3_4_9  30
    RHS       disj2_3_4_9  -5388
    RHS       disj1_3_5_9  30
    RHS       disj2_3_5_9  -5384
    RHS       disj1_3_6_9  30
    RHS       disj2_3_6_9  -5424
    RHS       disj1_3_7_9  30
    RHS       disj2_3_7_9  -5408
    RHS       disj1_3_8_9  30
    RHS       disj2_3_8_9  -5417
    RHS       disj1_3_9_9  30
    RHS       disj2_3_9_9  -5422
    RHS       disj1_4_5_9  79
    RHS       disj2_4_5_9  -5384
    RHS       disj1_4_6_9  79
    RHS       disj2_4_6_9  -5424
    RHS       disj1_4_7_9  79
    RHS       disj2_4_7_9  -5408
    RHS       disj1_4_8_9  79
    RHS       disj2_4_8_9  -5417
    RHS       disj1_4_9_9  79
    RHS       disj2_4_9_9  -5422
    RHS       disj1_5_6_9  83
    RHS       disj2_5_6_9  -5424
    RHS       disj1_5_7_9  83
    RHS       disj2_5_7_9  -5408
    RHS       disj1_5_8_9  83
    RHS       disj2_5_8_9  -5417
    RHS       disj1_5_9_9  83
    RHS       disj2_5_9_9  -5422
    RHS       disj1_6_7_9  43
    RHS       disj2_6_7_9  -5408
    RHS       disj1_6_8_9  43
    RHS       disj2_6_8_9  -5417
    RHS       disj1_6_9_9  43
    RHS       disj2_6_9_9  -5422
    RHS       disj1_7_8_9  59
    RHS       disj2_7_8_9  -5417
    RHS       disj1_7_9_9  59
    RHS       disj2_7_9_9  -5422
    RHS       disj1_8_9_9  50
    RHS       disj2_8_9_9  -5422
BOUNDS
 BV BOUND     y_0_0_0
 BV BOUND     y_0_0_1
 BV BOUND     y_0_0_2
 BV BOUND     y_0_0_3
 BV BOUND     y_0_0_4
 BV BOUND     y_0_0_5
 BV BOUND     y_0_0_6
 BV BOUND     y_0_0_7
 BV BOUND     y_0_0_8
 BV BOUND     y_0_0_9
 BV BOUND     y_0_1_0
 BV BOUND     y_0_1_1
 BV BOUND     y_0_1_2
 BV BOUND     y_0_1_3
 BV BOUND     y_0_1_4
 BV BOUND     y_0_1_5
 BV BOUND     y_0_1_6
 BV BOUND     y_0_1_7
 BV BOUND     y_0_1_8
 BV BOUND     y_0_1_9
 BV BOUND     y_0_2_0
 BV BOUND     y_0_2_1
 BV BOUND     y_0_2_2
 BV BOUND     y_0_2_3
 BV BOUND     y_0_2_4
 BV BOUND     y_0_2_5
 BV BOUND     y_0_2_6
 BV BOUND     y_0_2_7
 BV BOUND     y_0_2_8
 BV BOUND     y_0_2_9
 BV BOUND     y_0_3_0
 BV BOUND     y_0_3_1
 BV BOUND     y_0_3_2
 BV BOUND     y_0_3_3
 BV BOUND     y_0_3_4
 BV BOUND     y_0_3_5
 BV BOUND     y_0_3_6
 BV BOUND     y_0_3_7
 BV BOUND     y_0_3_8
 BV BOUND     y_0_3_9
 BV BOUND     y_0_4_0
 BV BOUND     y_0_4_1
 BV BOUND     y_0_4_2
 BV BOUND     y_0_4_3
 BV BOUND     y_0_4_4
 BV BOUND     y_0_4_5
 BV BOUND     y_0_4_6
 BV BOUND     y_0_4_7
 BV BOUND     y_0_4_8
 BV BOUND     y_0_4_9
 BV BOUND     y_0_5_0
 BV BOUND     y_0_5_1
 BV BOUND     y_0_5_2
 BV BOUND     y_0_5_3
 BV BOUND     y_0_5_4
 BV BOUND     y_0_5_5
 BV BOUND     y_0_5_6
 BV BOUND     y_0_5_7
 BV BOUND     y_0_5_8
 BV BOUND     y_0_5_9
 BV BOUND     y_0_6_0
 BV BOUND     y_0_6_1
 BV BOUND     y_0_6_2
 BV BOUND     y_0_6_3
 BV BOUND     y_0_6_4
 BV BOUND     y_0_6_5
 BV BOUND     y_0_6_6
 BV BOUND     y_0_6_7
 BV BOUND     y_0_6_8
 BV BOUND     y_0_6_9
 BV BOUND     y_0_7_0
 BV BOUND     y_0_7_1
 BV BOUND     y_0_7_2
 BV BOUND     y_0_7_3
 BV BOUND     y_0_7_4
 BV BOUND     y_0_7_5
 BV BOUND     y_0_7_6
 BV BOUND     y_0_7_7
 BV BOUND     y_0_7_8
 BV BOUND     y_0_7_9
 BV BOUND     y_0_8_0
 BV BOUND     y_0_8_1
 BV BOUND     y_0_8_2
 BV BOUND     y_0_8_3
 BV BOUND     y_0_8_4
 BV BOUND     y_0_8_5
 BV BOUND     y_0_8_6
 BV BOUND     y_0_8_7
 BV BOUND     y_0_8_8
 BV BOUND     y_0_8_9
 BV BOUND     y_0_9_0
 BV BOUND     y_0_9_1
 BV BOUND     y_0_9_2
 BV BOUND     y_0_9_3
 BV BOUND     y_0_9_4
 BV BOUND     y_0_9_5
 BV BOUND     y_0_9_6
 BV BOUND     y_0_9_7
 BV BOUND     y_0_9_8
 BV BOUND     y_0_9_9
 BV BOUND     y_1_0_0
 BV BOUND     y_1_0_1
 BV BOUND     y_1_0_2
 BV BOUND     y_1_0_3
 BV BOUND     y_1_0_4
 BV BOUND     y_1_0_5
 BV BOUND     y_1_0_6
 BV BOUND     y_1_0_7
 BV BOUND     y_1_0_8
 BV BOUND     y_1_0_9
 BV BOUND     y_1_1_0
 BV BOUND     y_1_1_1
 BV BOUND     y_1_1_2
 BV BOUND     y_1_1_3
 BV BOUND     y_1_1_4
 BV BOUND     y_1_1_5
 BV BOUND     y_1_1_6
 BV BOUND     y_1_1_7
 BV BOUND     y_1_1_8
 BV BOUND     y_1_1_9
 BV BOUND     y_1_2_0
 BV BOUND     y_1_2_1
 BV BOUND     y_1_2_2
 BV BOUND     y_1_2_3
 BV BOUND     y_1_2_4
 BV BOUND     y_1_2_5
 BV BOUND     y_1_2_6
 BV BOUND     y_1_2_7
 BV BOUND     y_1_2_8
 BV BOUND     y_1_2_9
 BV BOUND     y_1_3_0
 BV BOUND     y_1_3_1
 BV BOUND     y_1_3_2
 BV BOUND     y_1_3_3
 BV BOUND     y_1_3_4
 BV BOUND     y_1_3_5
 BV BOUND     y_1_3_6
 BV BOUND     y_1_3_7
 BV BOUND     y_1_3_8
 BV BOUND     y_1_3_9
 BV BOUND     y_1_4_0
 BV BOUND     y_1_4_1
 BV BOUND     y_1_4_2
 BV BOUND     y_1_4_3
 BV BOUND     y_1_4_4
 BV BOUND     y_1_4_5
 BV BOUND     y_1_4_6
 BV BOUND     y_1_4_7
 BV BOUND     y_1_4_8
 BV BOUND     y_1_4_9
 BV BOUND     y_1_5_0
 BV BOUND     y_1_5_1
 BV BOUND     y_1_5_2
 BV BOUND     y_1_5_3
 BV BOUND     y_1_5_4
 BV BOUND     y_1_5_5
 BV BOUND     y_1_5_6
 BV BOUND     y_1_5_7
 BV BOUND     y_1_5_8
 BV BOUND     y_1_5_9
 BV BOUND     y_1_6_0
 BV BOUND     y_1_6_1
 BV BOUND     y_1_6_2
 BV BOUND     y_1_6_3
 BV BOUND     y_1_6_4
 BV BOUND     y_1_6_5
 BV BOUND     y_1_6_6
 BV BOUND     y_1_6_7
 BV BOUND     y_1_6_8
 BV BOUND     y_1_6_9
 BV BOUND     y_1_7_0
 BV BOUND     y_1_7_1
 BV BOUND     y_1_7_2
 BV BOUND     y_1_7_3
 BV BOUND     y_1_7_4
 BV BOUND     y_1_7_5
 BV BOUND     y_1_7_6
 BV BOUND     y_1_7_7
 BV BOUND     y_1_7_8
 BV BOUND     y_1_7_9
 BV BOUND     y_1_8_0
 BV BOUND     y_1_8_1
 BV BOUND     y_1_8_2
 BV BOUND     y_1_8_3
 BV BOUND     y_1_8_4
 BV BOUND     y_1_8_5
 BV BOUND     y_1_8_6
 BV BOUND     y_1_8_7
 BV BOUND     y_1_8_8
 BV BOUND     y_1_8_9
 BV BOUND     y_1_9_0
 BV BOUND     y_1_9_1
 BV BOUND     y_1_9_2
 BV BOUND     y_1_9_3
 BV BOUND     y_1_9_4
 BV BOUND     y_1_9_5
 BV BOUND     y_1_9_6
 BV BOUND     y_1_9_7
 BV BOUND     y_1_9_8
 BV BOUND     y_1_9_9
 BV BOUND     y_2_0_0
 BV BOUND     y_2_0_1
 BV BOUND     y_2_0_2
 BV BOUND     y_2_0_3
 BV BOUND     y_2_0_4
 BV BOUND     y_2_0_5
 BV BOUND     y_2_0_6
 BV BOUND     y_2_0_7
 BV BOUND     y_2_0_8
 BV BOUND     y_2_0_9
 BV BOUND     y_2_1_0
 BV BOUND     y_2_1_1
 BV BOUND     y_2_1_2
 BV BOUND     y_2_1_3
 BV BOUND     y_2_1_4
 BV BOUND     y_2_1_5
 BV BOUND     y_2_1_6
 BV BOUND     y_2_1_7
 BV BOUND     y_2_1_8
 BV BOUND     y_2_1_9
 BV BOUND     y_2_2_0
 BV BOUND     y_2_2_1
 BV BOUND     y_2_2_2
 BV BOUND     y_2_2_3
 BV BOUND     y_2_2_4
 BV BOUND     y_2_2_5
 BV BOUND     y_2_2_6
 BV BOUND     y_2_2_7
 BV BOUND     y_2_2_8
 BV BOUND     y_2_2_9
 BV BOUND     y_2_3_0
 BV BOUND     y_2_3_1
 BV BOUND     y_2_3_2
 BV BOUND     y_2_3_3
 BV BOUND     y_2_3_4
 BV BOUND     y_2_3_5
 BV BOUND     y_2_3_6
 BV BOUND     y_2_3_7
 BV BOUND     y_2_3_8
 BV BOUND     y_2_3_9
 BV BOUND     y_2_4_0
 BV BOUND     y_2_4_1
 BV BOUND     y_2_4_2
 BV BOUND     y_2_4_3
 BV BOUND     y_2_4_4
 BV BOUND     y_2_4_5
 BV BOUND     y_2_4_6
 BV BOUND     y_2_4_7
 BV BOUND     y_2_4_8
 BV BOUND     y_2_4_9
 BV BOUND     y_2_5_0
 BV BOUND     y_2_5_1
 BV BOUND     y_2_5_2
 BV BOUND     y_2_5_3
 BV BOUND     y_2_5_4
 BV BOUND     y_2_5_5
 BV BOUND     y_2_5_6
 BV BOUND     y_2_5_7
 BV BOUND     y_2_5_8
 BV BOUND     y_2_5_9
 BV BOUND     y_2_6_0
 BV BOUND     y_2_6_1
 BV BOUND     y_2_6_2
 BV BOUND     y_2_6_3
 BV BOUND     y_2_6_4
 BV BOUND     y_2_6_5
 BV BOUND     y_2_6_6
 BV BOUND     y_2_6_7
 BV BOUND     y_2_6_8
 BV BOUND     y_2_6_9
 BV BOUND     y_2_7_0
 BV BOUND     y_2_7_1
 BV BOUND     y_2_7_2
 BV BOUND     y_2_7_3
 BV BOUND     y_2_7_4
 BV BOUND     y_2_7_5
 BV BOUND     y_2_7_6
 BV BOUND     y_2_7_7
 BV BOUND     y_2_7_8
 BV BOUND     y_2_7_9
 BV BOUND     y_2_8_0
 BV BOUND     y_2_8_1
 BV BOUND     y_2_8_2
 BV BOUND     y_2_8_3
 BV BOUND     y_2_8_4
 BV BOUND     y_2_8_5
 BV BOUND     y_2_8_6
 BV BOUND     y_2_8_7
 BV BOUND     y_2_8_8
 BV BOUND     y_2_8_9
 BV BOUND     y_2_9_0
 BV BOUND     y_2_9_1
 BV BOUND     y_2_9_2
 BV BOUND     y_2_9_3
 BV BOUND     y_2_9_4
 BV BOUND     y_2_9_5
 BV BOUND     y_2_9_6
 BV BOUND     y_2_9_7
 BV BOUND     y_2_9_8
 BV BOUND     y_2_9_9
 BV BOUND     y_3_0_0
 BV BOUND     y_3_0_1
 BV BOUND     y_3_0_2
 BV BOUND     y_3_0_3
 BV BOUND     y_3_0_4
 BV BOUND     y_3_0_5
 BV BOUND     y_3_0_6
 BV BOUND     y_3_0_7
 BV BOUND     y_3_0_8
 BV BOUND     y_3_0_9
 BV BOUND     y_3_1_0
 BV BOUND     y_3_1_1
 BV BOUND     y_3_1_2
 BV BOUND     y_3_1_3
 BV BOUND     y_3_1_4
 BV BOUND     y_3_1_5
 BV BOUND     y_3_1_6
 BV BOUND     y_3_1_7
 BV BOUND     y_3_1_8
 BV BOUND     y_3_1_9
 BV BOUND     y_3_2_0
 BV BOUND     y_3_2_1
 BV BOUND     y_3_2_2
 BV BOUND     y_3_2_3
 BV BOUND     y_3_2_4
 BV BOUND     y_3_2_5
 BV BOUND     y_3_2_6
 BV BOUND     y_3_2_7
 BV BOUND     y_3_2_8
 BV BOUND     y_3_2_9
 BV BOUND     y_3_3_0
 BV BOUND     y_3_3_1
 BV BOUND     y_3_3_2
 BV BOUND     y_3_3_3
 BV BOUND     y_3_3_4
 BV BOUND     y_3_3_5
 BV BOUND     y_3_3_6
 BV BOUND     y_3_3_7
 BV BOUND     y_3_3_8
 BV BOUND     y_3_3_9
 BV BOUND     y_3_4_0
 BV BOUND     y_3_4_1
 BV BOUND     y_3_4_2
 BV BOUND     y_3_4_3
 BV BOUND     y_3_4_4
 BV BOUND     y_3_4_5
 BV BOUND     y_3_4_6
 BV BOUND     y_3_4_7
 BV BOUND     y_3_4_8
 BV BOUND     y_3_4_9
 BV BOUND     y_3_5_0
 BV BOUND     y_3_5_1
 BV BOUND     y_3_5_2
 BV BOUND     y_3_5_3
 BV BOUND     y_3_5_4
 BV BOUND     y_3_5_5
 BV BOUND     y_3_5_6
 BV BOUND     y_3_5_7
 BV BOUND     y_3_5_8
 BV BOUND     y_3_5_9
 BV BOUND     y_3_6_0
 BV BOUND     y_3_6_1
 BV BOUND     y_3_6_2
 BV BOUND     y_3_6_3
 BV BOUND     y_3_6_4
 BV BOUND     y_3_6_5
 BV BOUND     y_3_6_6
 BV BOUND     y_3_6_7
 BV BOUND     y_3_6_8
 BV BOUND     y_3_6_9
 BV BOUND     y_3_7_0
 BV BOUND     y_3_7_1
 BV BOUND     y_3_7_2
 BV BOUND     y_3_7_3
 BV BOUND     y_3_7_4
 BV BOUND     y_3_7_5
 BV BOUND     y_3_7_6
 BV BOUND     y_3_7_7
 BV BOUND     y_3_7_8
 BV BOUND     y_3_7_9
 BV BOUND     y_3_8_0
 BV BOUND     y_3_8_1
 BV BOUND     y_3_8_2
 BV BOUND     y_3_8_3
 BV BOUND     y_3_8_4
 BV BOUND     y_3_8_5
 BV BOUND     y_3_8_6
 BV BOUND     y_3_8_7
 BV BOUND     y_3_8_8
 BV BOUND     y_3_8_9
 BV BOUND     y_3_9_0
 BV BOUND     y_3_9_1
 BV BOUND     y_3_9_2
 BV BOUND     y_3_9_3
 BV BOUND     y_3_9_4
 BV BOUND     y_3_9_5
 BV BOUND     y_3_9_6
 BV BOUND     y_3_9_7
 BV BOUND     y_3_9_8
 BV BOUND     y_3_9_9
 BV BOUND     y_4_0_0
 BV BOUND     y_4_0_1
 BV BOUND     y_4_0_2
 BV BOUND     y_4_0_3
 BV BOUND     y_4_0_4
 BV BOUND     y_4_0_5
 BV BOUND     y_4_0_6
 BV BOUND     y_4_0_7
 BV BOUND     y_4_0_8
 BV BOUND     y_4_0_9
 BV BOUND     y_4_1_0
 BV BOUND     y_4_1_1
 BV BOUND     y_4_1_2
 BV BOUND     y_4_1_3
 BV BOUND     y_4_1_4
 BV BOUND     y_4_1_5
 BV BOUND     y_4_1_6
 BV BOUND     y_4_1_7
 BV BOUND     y_4_1_8
 BV BOUND     y_4_1_9
 BV BOUND     y_4_2_0
 BV BOUND     y_4_2_1
 BV BOUND     y_4_2_2
 BV BOUND     y_4_2_3
 BV BOUND     y_4_2_4
 BV BOUND     y_4_2_5
 BV BOUND     y_4_2_6
 BV BOUND     y_4_2_7
 BV BOUND     y_4_2_8
 BV BOUND     y_4_2_9
 BV BOUND     y_4_3_0
 BV BOUND     y_4_3_1
 BV BOUND     y_4_3_2
 BV BOUND     y_4_3_3
 BV BOUND     y_4_3_4
 BV BOUND     y_4_3_5
 BV BOUND     y_4_3_6
 BV BOUND     y_4_3_7
 BV BOUND     y_4_3_8
 BV BOUND     y_4_3_9
 BV BOUND     y_4_4_0
 BV BOUND     y_4_4_1
 BV BOUND     y_4_4_2
 BV BOUND     y_4_4_3
 BV BOUND     y_4_4_4
 BV BOUND     y_4_4_5
 BV BOUND     y_4_4_6
 BV BOUND     y_4_4_7
 BV BOUND     y_4_4_8
 BV BOUND     y_4_4_9
 BV BOUND     y_4_5_0
 BV BOUND     y_4_5_1
 BV BOUND     y_4_5_2
 BV BOUND     y_4_5_3
 BV BOUND     y_4_5_4
 BV BOUND     y_4_5_5
 BV BOUND     y_4_5_6
 BV BOUND     y_4_5_7
 BV BOUND     y_4_5_8
 BV BOUND     y_4_5_9
 BV BOUND     y_4_6_0
 BV BOUND     y_4_6_1
 BV BOUND     y_4_6_2
 BV BOUND     y_4_6_3
 BV BOUND     y_4_6_4
 BV BOUND     y_4_6_5
 BV BOUND     y_4_6_6
 BV BOUND     y_4_6_7
 BV BOUND     y_4_6_8
 BV BOUND     y_4_6_9
 BV BOUND     y_4_7_0
 BV BOUND     y_4_7_1
 BV BOUND     y_4_7_2
 BV BOUND     y_4_7_3
 BV BOUND     y_4_7_4
 BV BOUND     y_4_7_5
 BV BOUND     y_4_7_6
 BV BOUND     y_4_7_7
 BV BOUND     y_4_7_8
 BV BOUND     y_4_7_9
 BV BOUND     y_4_8_0
 BV BOUND     y_4_8_1
 BV BOUND     y_4_8_2
 BV BOUND     y_4_8_3
 BV BOUND     y_4_8_4
 BV BOUND     y_4_8_5
 BV BOUND     y_4_8_6
 BV BOUND     y_4_8_7
 BV BOUND     y_4_8_8
 BV BOUND     y_4_8_9
 BV BOUND     y_4_9_0
 BV BOUND     y_4_9_1
 BV BOUND     y_4_9_2
 BV BOUND     y_4_9_3
 BV BOUND     y_4_9_4
 BV BOUND     y_4_9_5
 BV BOUND     y_4_9_6
 BV BOUND     y_4_9_7
 BV BOUND     y_4_9_8
 BV BOUND     y_4_9_9
 BV BOUND     y_5_0_0
 BV BOUND     y_5_0_1
 BV BOUND     y_5_0_2
 BV BOUND     y_5_0_3
 BV BOUND     y_5_0_4
 BV BOUND     y_5_0_5
 BV BOUND     y_5_0_6
 BV BOUND     y_5_0_7
 BV BOUND     y_5_0_8
 BV BOUND     y_5_0_9
 BV BOUND     y_5_1_0
 BV BOUND     y_5_1_1
 BV BOUND     y_5_1_2
 BV BOUND     y_5_1_3
 BV BOUND     y_5_1_4
 BV BOUND     y_5_1_5
 BV BOUND     y_5_1_6
 BV BOUND     y_5_1_7
 BV BOUND     y_5_1_8
 BV BOUND     y_5_1_9
 BV BOUND     y_5_2_0
 BV BOUND     y_5_2_1
 BV BOUND     y_5_2_2
 BV BOUND     y_5_2_3
 BV BOUND     y_5_2_4
 BV BOUND     y_5_2_5
 BV BOUND     y_5_2_6
 BV BOUND     y_5_2_7
 BV BOUND     y_5_2_8
 BV BOUND     y_5_2_9
 BV BOUND     y_5_3_0
 BV BOUND     y_5_3_1
 BV BOUND     y_5_3_2
 BV BOUND     y_5_3_3
 BV BOUND     y_5_3_4
 BV BOUND     y_5_3_5
 BV BOUND     y_5_3_6
 BV BOUND     y_5_3_7
 BV BOUND     y_5_3_8
 BV BOUND     y_5_3_9
 BV BOUND     y_5_4_0
 BV BOUND     y_5_4_1
 BV BOUND     y_5_4_2
 BV BOUND     y_5_4_3
 BV BOUND     y_5_4_4
 BV BOUND     y_5_4_5
 BV BOUND     y_5_4_6
 BV BOUND     y_5_4_7
 BV BOUND     y_5_4_8
 BV BOUND     y_5_4_9
 BV BOUND     y_5_5_0
 BV BOUND     y_5_5_1
 BV BOUND     y_5_5_2
 BV BOUND     y_5_5_3
 BV BOUND     y_5_5_4
 BV BOUND     y_5_5_5
 BV BOUND     y_5_5_6
 BV BOUND     y_5_5_7
 BV BOUND     y_5_5_8
 BV BOUND     y_5_5_9
 BV BOUND     y_5_6_0
 BV BOUND     y_5_6_1
 BV BOUND     y_5_6_2
 BV BOUND     y_5_6_3
 BV BOUND     y_5_6_4
 BV BOUND     y_5_6_5
 BV BOUND     y_5_6_6
 BV BOUND     y_5_6_7
 BV BOUND     y_5_6_8
 BV BOUND     y_5_6_9
 BV BOUND     y_5_7_0
 BV BOUND     y_5_7_1
 BV BOUND     y_5_7_2
 BV BOUND     y_5_7_3
 BV BOUND     y_5_7_4
 BV BOUND     y_5_7_5
 BV BOUND     y_5_7_6
 BV BOUND     y_5_7_7
 BV BOUND     y_5_7_8
 BV BOUND     y_5_7_9
 BV BOUND     y_5_8_0
 BV BOUND     y_5_8_1
 BV BOUND     y_5_8_2
 BV BOUND     y_5_8_3
 BV BOUND     y_5_8_4
 BV BOUND     y_5_8_5
 BV BOUND     y_5_8_6
 BV BOUND     y_5_8_7
 BV BOUND     y_5_8_8
 BV BOUND     y_5_8_9
 BV BOUND     y_5_9_0
 BV BOUND     y_5_9_1
 BV BOUND     y_5_9_2
 BV BOUND     y_5_9_3
 BV BOUND     y_5_9_4
 BV BOUND     y_5_9_5
 BV BOUND     y_5_9_6
 BV BOUND     y_5_9_7
 BV BOUND     y_5_9_8
 BV BOUND     y_5_9_9
 BV BOUND     y_6_0_0
 BV BOUND     y_6_0_1
 BV BOUND     y_6_0_2
 BV BOUND     y_6_0_3
 BV BOUND     y_6_0_4
 BV BOUND     y_6_0_5
 BV BOUND     y_6_0_6
 BV BOUND     y_6_0_7
 BV BOUND     y_6_0_8
 BV BOUND     y_6_0_9
 BV BOUND     y_6_1_0
 BV BOUND     y_6_1_1
 BV BOUND     y_6_1_2
 BV BOUND     y_6_1_3
 BV BOUND     y_6_1_4
 BV BOUND     y_6_1_5
 BV BOUND     y_6_1_6
 BV BOUND     y_6_1_7
 BV BOUND     y_6_1_8
 BV BOUND     y_6_1_9
 BV BOUND     y_6_2_0
 BV BOUND     y_6_2_1
 BV BOUND     y_6_2_2
 BV BOUND     y_6_2_3
 BV BOUND     y_6_2_4
 BV BOUND     y_6_2_5
 BV BOUND     y_6_2_6
 BV BOUND     y_6_2_7
 BV BOUND     y_6_2_8
 BV BOUND     y_6_2_9
 BV BOUND     y_6_3_0
 BV BOUND     y_6_3_1
 BV BOUND     y_6_3_2
 BV BOUND     y_6_3_3
 BV BOUND     y_6_3_4
 BV BOUND     y_6_3_5
 BV BOUND     y_6_3_6
 BV BOUND     y_6_3_7
 BV BOUND     y_6_3_8
 BV BOUND     y_6_3_9
 BV BOUND     y_6_4_0
 BV BOUND     y_6_4_1
 BV BOUND     y_6_4_2
 BV BOUND     y_6_4_3
 BV BOUND     y_6_4_4
 BV BOUND     y_6_4_5
 BV BOUND     y_6_4_6
 BV BOUND     y_6_4_7
 BV BOUND     y_6_4_8
 BV BOUND     y_6_4_9
 BV BOUND     y_6_5_0
 BV BOUND     y_6_5_1
 BV BOUND     y_6_5_2
 BV BOUND     y_6_5_3
 BV BOUND     y_6_5_4
 BV BOUND     y_6_5_5
 BV BOUND     y_6_5_6
 BV BOUND     y_6_5_7
 BV BOUND     y_6_5_8
 BV BOUND     y_6_5_9
 BV BOUND     y_6_6_0
 BV BOUND     y_6_6_1
 BV BOUND     y_6_6_2
 BV BOUND     y_6_6_3
 BV BOUND     y_6_6_4
 BV BOUND     y_6_6_5
 BV BOUND     y_6_6_6
 BV BOUND     y_6_6_7
 BV BOUND     y_6_6_8
 BV BOUND     y_6_6_9
 BV BOUND     y_6_7_0
 BV BOUND     y_6_7_1
 BV BOUND     y_6_7_2
 BV BOUND     y_6_7_3
 BV BOUND     y_6_7_4
 BV BOUND     y_6_7_5
 BV BOUND     y_6_7_6
 BV BOUND     y_6_7_7
 BV BOUND     y_6_7_8
 BV BOUND     y_6_7_9
 BV BOUND     y_6_8_0
 BV BOUND     y_6_8_1
 BV BOUND     y_6_8_2
 BV BOUND     y_6_8_3
 BV BOUND     y_6_8_4
 BV BOUND     y_6_8_5
 BV BOUND     y_6_8_6
 BV BOUND     y_6_8_7
 BV BOUND     y_6_8_8
 BV BOUND     y_6_8_9
 BV BOUND     y_6_9_0
 BV BOUND     y_6_9_1
 BV BOUND     y_6_9_2
 BV BOUND     y_6_9_3
 BV BOUND     y_6_9_4
 BV BOUND     y_6_9_5
 BV BOUND     y_6_9_6
 BV BOUND     y_6_9_7
 BV BOUND     y_6_9_8
 BV BOUND     y_6_9_9
 BV BOUND     y_7_0_0
 BV BOUND     y_7_0_1
 BV BOUND     y_7_0_2
 BV BOUND     y_7_0_3
 BV BOUND     y_7_0_4
 BV BOUND     y_7_0_5
 BV BOUND     y_7_0_6
 BV BOUND     y_7_0_7
 BV BOUND     y_7_0_8
 BV BOUND     y_7_0_9
 BV BOUND     y_7_1_0
 BV BOUND     y_7_1_1
 BV BOUND     y_7_1_2
 BV BOUND     y_7_1_3
 BV BOUND     y_7_1_4
 BV BOUND     y_7_1_5
 BV BOUND     y_7_1_6
 BV BOUND     y_7_1_7
 BV BOUND     y_7_1_8
 BV BOUND     y_7_1_9
 BV BOUND     y_7_2_0
 BV BOUND     y_7_2_1
 BV BOUND     y_7_2_2
 BV BOUND     y_7_2_3
 BV BOUND     y_7_2_4
 BV BOUND     y_7_2_5
 BV BOUND     y_7_2_6
 BV BOUND     y_7_2_7
 BV BOUND     y_7_2_8
 BV BOUND     y_7_2_9
 BV BOUND     y_7_3_0
 BV BOUND     y_7_3_1
 BV BOUND     y_7_3_2
 BV BOUND     y_7_3_3
 BV BOUND     y_7_3_4
 BV BOUND     y_7_3_5
 BV BOUND     y_7_3_6
 BV BOUND     y_7_3_7
 BV BOUND     y_7_3_8
 BV BOUND     y_7_3_9
 BV BOUND     y_7_4_0
 BV BOUND     y_7_4_1
 BV BOUND     y_7_4_2
 BV BOUND     y_7_4_3
 BV BOUND     y_7_4_4
 BV BOUND     y_7_4_5
 BV BOUND     y_7_4_6
 BV BOUND     y_7_4_7
 BV BOUND     y_7_4_8
 BV BOUND     y_7_4_9
 BV BOUND     y_7_5_0
 BV BOUND     y_7_5_1
 BV BOUND     y_7_5_2
 BV BOUND     y_7_5_3
 BV BOUND     y_7_5_4
 BV BOUND     y_7_5_5
 BV BOUND     y_7_5_6
 BV BOUND     y_7_5_7
 BV BOUND     y_7_5_8
 BV BOUND     y_7_5_9
 BV BOUND     y_7_6_0
 BV BOUND     y_7_6_1
 BV BOUND     y_7_6_2
 BV BOUND     y_7_6_3
 BV BOUND     y_7_6_4
 BV BOUND     y_7_6_5
 BV BOUND     y_7_6_6
 BV BOUND     y_7_6_7
 BV BOUND     y_7_6_8
 BV BOUND     y_7_6_9
 BV BOUND     y_7_7_0
 BV BOUND     y_7_7_1
 BV BOUND     y_7_7_2
 BV BOUND     y_7_7_3
 BV BOUND     y_7_7_4
 BV BOUND     y_7_7_5
 BV BOUND     y_7_7_6
 BV BOUND     y_7_7_7
 BV BOUND     y_7_7_8
 BV BOUND     y_7_7_9
 BV BOUND     y_7_8_0
 BV BOUND     y_7_8_1
 BV BOUND     y_7_8_2
 BV BOUND     y_7_8_3
 BV BOUND     y_7_8_4
 BV BOUND     y_7_8_5
 BV BOUND     y_7_8_6
 BV BOUND     y_7_8_7
 BV BOUND     y_7_8_8
 BV BOUND     y_7_8_9
 BV BOUND     y_7_9_0
 BV BOUND     y_7_9_1
 BV BOUND     y_7_9_2
 BV BOUND     y_7_9_3
 BV BOUND     y_7_9_4
 BV BOUND     y_7_9_5
 BV BOUND     y_7_9_6
 BV BOUND     y_7_9_7
 BV BOUND     y_7_9_8
 BV BOUND     y_7_9_9
 BV BOUND     y_8_0_0
 BV BOUND     y_8_0_1
 BV BOUND     y_8_0_2
 BV BOUND     y_8_0_3
 BV BOUND     y_8_0_4
 BV BOUND     y_8_0_5
 BV BOUND     y_8_0_6
 BV BOUND     y_8_0_7
 BV BOUND     y_8_0_8
 BV BOUND     y_8_0_9
 BV BOUND     y_8_1_0
 BV BOUND     y_8_1_1
 BV BOUND     y_8_1_2
 BV BOUND     y_8_1_3
 BV BOUND     y_8_1_4
 BV BOUND     y_8_1_5
 BV BOUND     y_8_1_6
 BV BOUND     y_8_1_7
 BV BOUND     y_8_1_8
 BV BOUND     y_8_1_9
 BV BOUND     y_8_2_0
 BV BOUND     y_8_2_1
 BV BOUND     y_8_2_2
 BV BOUND     y_8_2_3
 BV BOUND     y_8_2_4
 BV BOUND     y_8_2_5
 BV BOUND     y_8_2_6
 BV BOUND     y_8_2_7
 BV BOUND     y_8_2_8
 BV BOUND     y_8_2_9
 BV BOUND     y_8_3_0
 BV BOUND     y_8_3_1
 BV BOUND     y_8_3_2
 BV BOUND     y_8_3_3
 BV BOUND     y_8_3_4
 BV BOUND     y_8_3_5
 BV BOUND     y_8_3_6
 BV BOUND     y_8_3_7
 BV BOUND     y_8_3_8
 BV BOUND     y_8_3_9
 BV BOUND     y_8_4_0
 BV BOUND     y_8_4_1
 BV BOUND     y_8_4_2
 BV BOUND     y_8_4_3
 BV BOUND     y_8_4_4
 BV BOUND     y_8_4_5
 BV BOUND     y_8_4_6
 BV BOUND     y_8_4_7
 BV BOUND     y_8_4_8
 BV BOUND     y_8_4_9
 BV BOUND     y_8_5_0
 BV BOUND     y_8_5_1
 BV BOUND     y_8_5_2
 BV BOUND     y_8_5_3
 BV BOUND     y_8_5_4
 BV BOUND     y_8_5_5
 BV BOUND     y_8_5_6
 BV BOUND     y_8_5_7
 BV BOUND     y_8_5_8
 BV BOUND     y_8_5_9
 BV BOUND     y_8_6_0
 BV BOUND     y_8_6_1
 BV BOUND     y_8_6_2
 BV BOUND     y_8_6_3
 BV BOUND     y_8_6_4
 BV BOUND     y_8_6_5
 BV BOUND     y_8_6_6
 BV BOUND     y_8_6_7
 BV BOUND     y_8_6_8
 BV BOUND     y_8_6_9
 BV BOUND     y_8_7_0
 BV BOUND     y_8_7_1
 BV BOUND     y_8_7_2
 BV BOUND     y_8_7_3
 BV BOUND     y_8_7_4
 BV BOUND     y_8_7_5
 BV BOUND     y_8_7_6
 BV BOUND     y_8_7_7
 BV BOUND     y_8_7_8
 BV BOUND     y_8_7_9
 BV BOUND     y_8_8_0
 BV BOUND     y_8_8_1
 BV BOUND     y_8_8_2
 BV BOUND     y_8_8_3
 BV BOUND     y_8_8_4
 BV BOUND     y_8_8_5
 BV BOUND     y_8_8_6
 BV BOUND     y_8_8_7
 BV BOUND     y_8_8_8
 BV BOUND     y_8_8_9
 BV BOUND     y_8_9_0
 BV BOUND     y_8_9_1
 BV BOUND     y_8_9_2
 BV BOUND     y_8_9_3
 BV BOUND     y_8_9_4
 BV BOUND     y_8_9_5
 BV BOUND     y_8_9_6
 BV BOUND     y_8_9_7
 BV BOUND     y_8_9_8
 BV BOUND     y_8_9_9
 BV BOUND     y_9_0_0
 BV BOUND     y_9_0_1
 BV BOUND     y_9_0_2
 BV BOUND     y_9_0_3
 BV BOUND     y_9_0_4
 BV BOUND     y_9_0_5
 BV BOUND     y_9_0_6
 BV BOUND     y_9_0_7
 BV BOUND     y_9_0_8
 BV BOUND     y_9_0_9
 BV BOUND     y_9_1_0
 BV BOUND     y_9_1_1
 BV BOUND     y_9_1_2
 BV BOUND     y_9_1_3
 BV BOUND     y_9_1_4
 BV BOUND     y_9_1_5
 BV BOUND     y_9_1_6
 BV BOUND     y_9_1_7
 BV BOUND     y_9_1_8
 BV BOUND     y_9_1_9
 BV BOUND     y_9_2_0
 BV BOUND     y_9_2_1
 BV BOUND     y_9_2_2
 BV BOUND     y_9_2_3
 BV BOUND     y_9_2_4
 BV BOUND     y_9_2_5
 BV BOUND     y_9_2_6
 BV BOUND     y_9_2_7
 BV BOUND     y_9_2_8
 BV BOUND     y_9_2_9
 BV BOUND     y_9_3_0
 BV BOUND     y_9_3_1
 BV BOUND     y_9_3_2
 BV BOUND     y_9_3_3
 BV BOUND     y_9_3_4
 BV BOUND     y_9_3_5
 BV BOUND     y_9_3_6
 BV BOUND     y_9_3_7
 BV BOUND     y_9_3_8
 BV BOUND     y_9_3_9
 BV BOUND     y_9_4_0
 BV BOUND     y_9_4_1
 BV BOUND     y_9_4_2
 BV BOUND     y_9_4_3
 BV BOUND     y_9_4_4
 BV BOUND     y_9_4_5
 BV BOUND     y_9_4_6
 BV BOUND     y_9_4_7
 BV BOUND     y_9_4_8
 BV BOUND     y_9_4_9
 BV BOUND     y_9_5_0
 BV BOUND     y_9_5_1
 BV BOUND     y_9_5_2
 BV BOUND     y_9_5_3
 BV BOUND     y_9_5_4
 BV BOUND     y_9_5_5
 BV BOUND     y_9_5_6
 BV BOUND     y_9_5_7
 BV BOUND     y_9_5_8
 BV BOUND     y_9_5_9
 BV BOUND     y_9_6_0
 BV BOUND     y_9_6_1
 BV BOUND     y_9_6_2
 BV BOUND     y_9_6_3
 BV BOUND     y_9_6_4
 BV BOUND     y_9_6_5
 BV BOUND     y_9_6_6
 BV BOUND     y_9_6_7
 BV BOUND     y_9_6_8
 BV BOUND     y_9_6_9
 BV BOUND     y_9_7_0
 BV BOUND     y_9_7_1
 BV BOUND     y_9_7_2
 BV BOUND     y_9_7_3
 BV BOUND     y_9_7_4
 BV BOUND     y_9_7_5
 BV BOUND     y_9_7_6
 BV BOUND     y_9_7_7
 BV BOUND     y_9_7_8
 BV BOUND     y_9_7_9
 BV BOUND     y_9_8_0
 BV BOUND     y_9_8_1
 BV BOUND     y_9_8_2
 BV BOUND     y_9_8_3
 BV BOUND     y_9_8_4
 BV BOUND     y_9_8_5
 BV BOUND     y_9_8_6
 BV BOUND     y_9_8_7
 BV BOUND     y_9_8_8
 BV BOUND     y_9_8_9
 BV BOUND     y_9_9_0
 BV BOUND     y_9_9_1
 BV BOUND     y_9_9_2
 BV BOUND     y_9_9_3
 BV BOUND     y_9_9_4
 BV BOUND     y_9_9_5
 BV BOUND     y_9_9_6
 BV BOUND     y_9_9_7
 BV BOUND     y_9_9_8
 BV BOUND     y_9_9_9
ENDATA
