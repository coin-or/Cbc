NAME          la01
ROWS
 N  OBJ
 G  prec_0_0
 G  prec_0_1
 G  prec_0_2
 G  prec_0_3
 G  prec_1_0
 G  prec_1_1
 G  prec_1_2
 G  prec_1_3
 G  prec_2_0
 G  prec_2_1
 G  prec_2_2
 G  prec_2_3
 G  prec_3_0
 G  prec_3_1
 G  prec_3_2
 G  prec_3_3
 G  prec_4_0
 G  prec_4_1
 G  prec_4_2
 G  prec_4_3
 G  prec_5_0
 G  prec_5_1
 G  prec_5_2
 G  prec_5_3
 G  prec_6_0
 G  prec_6_1
 G  prec_6_2
 G  prec_6_3
 G  prec_7_0
 G  prec_7_1
 G  prec_7_2
 G  prec_7_3
 G  prec_8_0
 G  prec_8_1
 G  prec_8_2
 G  prec_8_3
 G  prec_9_0
 G  prec_9_1
 G  prec_9_2
 G  prec_9_3
 G  mksp_0
 G  mksp_1
 G  mksp_2
 G  mksp_3
 G  mksp_4
 G  mksp_5
 G  mksp_6
 G  mksp_7
 G  mksp_8
 G  mksp_9
 G  disj1_0_1_0
 G  disj2_0_1_0
 G  disj1_0_2_0
 G  disj2_0_2_0
 G  disj1_0_3_0
 G  disj2_0_3_0
 G  disj1_0_4_0
 G  disj2_0_4_0
 G  disj1_0_5_0
 G  disj2_0_5_0
 G  disj1_0_6_0
 G  disj2_0_6_0
 G  disj1_0_7_0
 G  disj2_0_7_0
 G  disj1_0_8_0
 G  disj2_0_8_0
 G  disj1_0_9_0
 G  disj2_0_9_0
 G  disj1_1_2_0
 G  disj2_1_2_0
 G  disj1_1_3_0
 G  disj2_1_3_0
 G  disj1_1_4_0
 G  disj2_1_4_0
 G  disj1_1_5_0
 G  disj2_1_5_0
 G  disj1_1_6_0
 G  disj2_1_6_0
 G  disj1_1_7_0
 G  disj2_1_7_0
 G  disj1_1_8_0
 G  disj2_1_8_0
 G  disj1_1_9_0
 G  disj2_1_9_0
 G  disj1_2_3_0
 G  disj2_2_3_0
 G  disj1_2_4_0
 G  disj2_2_4_0
 G  disj1_2_5_0
 G  disj2_2_5_0
 G  disj1_2_6_0
 G  disj2_2_6_0
 G  disj1_2_7_0
 G  disj2_2_7_0
 G  disj1_2_8_0
 G  disj2_2_8_0
 G  disj1_2_9_0
 G  disj2_2_9_0
 G  disj1_3_4_0
 G  disj2_3_4_0
 G  disj1_3_5_0
 G  disj2_3_5_0
 G  disj1_3_6_0
 G  disj2_3_6_0
 G  disj1_3_7_0
 G  disj2_3_7_0
 G  disj1_3_8_0
 G  disj2_3_8_0
 G  disj1_3_9_0
 G  disj2_3_9_0
 G  disj1_4_5_0
 G  disj2_4_5_0
 G  disj1_4_6_0
 G  disj2_4_6_0
 G  disj1_4_7_0
 G  disj2_4_7_0
 G  disj1_4_8_0
 G  disj2_4_8_0
 G  disj1_4_9_0
 G  disj2_4_9_0
 G  disj1_5_6_0
 G  disj2_5_6_0
 G  disj1_5_7_0
 G  disj2_5_7_0
 G  disj1_5_8_0
 G  disj2_5_8_0
 G  disj1_5_9_0
 G  disj2_5_9_0
 G  disj1_6_7_0
 G  disj2_6_7_0
 G  disj1_6_8_0
 G  disj2_6_8_0
 G  disj1_6_9_0
 G  disj2_6_9_0
 G  disj1_7_8_0
 G  disj2_7_8_0
 G  disj1_7_9_0
 G  disj2_7_9_0
 G  disj1_8_9_0
 G  disj2_8_9_0
 G  disj1_0_1_1
 G  disj2_0_1_1
 G  disj1_0_2_1
 G  disj2_0_2_1
 G  disj1_0_3_1
 G  disj2_0_3_1
 G  disj1_0_4_1
 G  disj2_0_4_1
 G  disj1_0_5_1
 G  disj2_0_5_1
 G  disj1_0_6_1
 G  disj2_0_6_1
 G  disj1_0_7_1
 G  disj2_0_7_1
 G  disj1_0_8_1
 G  disj2_0_8_1
 G  disj1_0_9_1
 G  disj2_0_9_1
 G  disj1_1_2_1
 G  disj2_1_2_1
 G  disj1_1_3_1
 G  disj2_1_3_1
 G  disj1_1_4_1
 G  disj2_1_4_1
 G  disj1_1_5_1
 G  disj2_1_5_1
 G  disj1_1_6_1
 G  disj2_1_6_1
 G  disj1_1_7_1
 G  disj2_1_7_1
 G  disj1_1_8_1
 G  disj2_1_8_1
 G  disj1_1_9_1
 G  disj2_1_9_1
 G  disj1_2_3_1
 G  disj2_2_3_1
 G  disj1_2_4_1
 G  disj2_2_4_1
 G  disj1_2_5_1
 G  disj2_2_5_1
 G  disj1_2_6_1
 G  disj2_2_6_1
 G  disj1_2_7_1
 G  disj2_2_7_1
 G  disj1_2_8_1
 G  disj2_2_8_1
 G  disj1_2_9_1
 G  disj2_2_9_1
 G  disj1_3_4_1
 G  disj2_3_4_1
 G  disj1_3_5_1
 G  disj2_3_5_1
 G  disj1_3_6_1
 G  disj2_3_6_1
 G  disj1_3_7_1
 G  disj2_3_7_1
 G  disj1_3_8_1
 G  disj2_3_8_1
 G  disj1_3_9_1
 G  disj2_3_9_1
 G  disj1_4_5_1
 G  disj2_4_5_1
 G  disj1_4_6_1
 G  disj2_4_6_1
 G  disj1_4_7_1
 G  disj2_4_7_1
 G  disj1_4_8_1
 G  disj2_4_8_1
 G  disj1_4_9_1
 G  disj2_4_9_1
 G  disj1_5_6_1
 G  disj2_5_6_1
 G  disj1_5_7_1
 G  disj2_5_7_1
 G  disj1_5_8_1
 G  disj2_5_8_1
 G  disj1_5_9_1
 G  disj2_5_9_1
 G  disj1_6_7_1
 G  disj2_6_7_1
 G  disj1_6_8_1
 G  disj2_6_8_1
 G  disj1_6_9_1
 G  disj2_6_9_1
 G  disj1_7_8_1
 G  disj2_7_8_1
 G  disj1_7_9_1
 G  disj2_7_9_1
 G  disj1_8_9_1
 G  disj2_8_9_1
 G  disj1_0_1_2
 G  disj2_0_1_2
 G  disj1_0_2_2
 G  disj2_0_2_2
 G  disj1_0_3_2
 G  disj2_0_3_2
 G  disj1_0_4_2
 G  disj2_0_4_2
 G  disj1_0_5_2
 G  disj2_0_5_2
 G  disj1_0_6_2
 G  disj2_0_6_2
 G  disj1_0_7_2
 G  disj2_0_7_2
 G  disj1_0_8_2
 G  disj2_0_8_2
 G  disj1_0_9_2
 G  disj2_0_9_2
 G  disj1_1_2_2
 G  disj2_1_2_2
 G  disj1_1_3_2
 G  disj2_1_3_2
 G  disj1_1_4_2
 G  disj2_1_4_2
 G  disj1_1_5_2
 G  disj2_1_5_2
 G  disj1_1_6_2
 G  disj2_1_6_2
 G  disj1_1_7_2
 G  disj2_1_7_2
 G  disj1_1_8_2
 G  disj2_1_8_2
 G  disj1_1_9_2
 G  disj2_1_9_2
 G  disj1_2_3_2
 G  disj2_2_3_2
 G  disj1_2_4_2
 G  disj2_2_4_2
 G  disj1_2_5_2
 G  disj2_2_5_2
 G  disj1_2_6_2
 G  disj2_2_6_2
 G  disj1_2_7_2
 G  disj2_2_7_2
 G  disj1_2_8_2
 G  disj2_2_8_2
 G  disj1_2_9_2
 G  disj2_2_9_2
 G  disj1_3_4_2
 G  disj2_3_4_2
 G  disj1_3_5_2
 G  disj2_3_5_2
 G  disj1_3_6_2
 G  disj2_3_6_2
 G  disj1_3_7_2
 G  disj2_3_7_2
 G  disj1_3_8_2
 G  disj2_3_8_2
 G  disj1_3_9_2
 G  disj2_3_9_2
 G  disj1_4_5_2
 G  disj2_4_5_2
 G  disj1_4_6_2
 G  disj2_4_6_2
 G  disj1_4_7_2
 G  disj2_4_7_2
 G  disj1_4_8_2
 G  disj2_4_8_2
 G  disj1_4_9_2
 G  disj2_4_9_2
 G  disj1_5_6_2
 G  disj2_5_6_2
 G  disj1_5_7_2
 G  disj2_5_7_2
 G  disj1_5_8_2
 G  disj2_5_8_2
 G  disj1_5_9_2
 G  disj2_5_9_2
 G  disj1_6_7_2
 G  disj2_6_7_2
 G  disj1_6_8_2
 G  disj2_6_8_2
 G  disj1_6_9_2
 G  disj2_6_9_2
 G  disj1_7_8_2
 G  disj2_7_8_2
 G  disj1_7_9_2
 G  disj2_7_9_2
 G  disj1_8_9_2
 G  disj2_8_9_2
 G  disj1_0_1_3
 G  disj2_0_1_3
 G  disj1_0_2_3
 G  disj2_0_2_3
 G  disj1_0_3_3
 G  disj2_0_3_3
 G  disj1_0_4_3
 G  disj2_0_4_3
 G  disj1_0_5_3
 G  disj2_0_5_3
 G  disj1_0_6_3
 G  disj2_0_6_3
 G  disj1_0_7_3
 G  disj2_0_7_3
 G  disj1_0_8_3
 G  disj2_0_8_3
 G  disj1_0_9_3
 G  disj2_0_9_3
 G  disj1_1_2_3
 G  disj2_1_2_3
 G  disj1_1_3_3
 G  disj2_1_3_3
 G  disj1_1_4_3
 G  disj2_1_4_3
 G  disj1_1_5_3
 G  disj2_1_5_3
 G  disj1_1_6_3
 G  disj2_1_6_3
 G  disj1_1_7_3
 G  disj2_1_7_3
 G  disj1_1_8_3
 G  disj2_1_8_3
 G  disj1_1_9_3
 G  disj2_1_9_3
 G  disj1_2_3_3
 G  disj2_2_3_3
 G  disj1_2_4_3
 G  disj2_2_4_3
 G  disj1_2_5_3
 G  disj2_2_5_3
 G  disj1_2_6_3
 G  disj2_2_6_3
 G  disj1_2_7_3
 G  disj2_2_7_3
 G  disj1_2_8_3
 G  disj2_2_8_3
 G  disj1_2_9_3
 G  disj2_2_9_3
 G  disj1_3_4_3
 G  disj2_3_4_3
 G  disj1_3_5_3
 G  disj2_3_5_3
 G  disj1_3_6_3
 G  disj2_3_6_3
 G  disj1_3_7_3
 G  disj2_3_7_3
 G  disj1_3_8_3
 G  disj2_3_8_3
 G  disj1_3_9_3
 G  disj2_3_9_3
 G  disj1_4_5_3
 G  disj2_4_5_3
 G  disj1_4_6_3
 G  disj2_4_6_3
 G  disj1_4_7_3
 G  disj2_4_7_3
 G  disj1_4_8_3
 G  disj2_4_8_3
 G  disj1_4_9_3
 G  disj2_4_9_3
 G  disj1_5_6_3
 G  disj2_5_6_3
 G  disj1_5_7_3
 G  disj2_5_7_3
 G  disj1_5_8_3
 G  disj2_5_8_3
 G  disj1_5_9_3
 G  disj2_5_9_3
 G  disj1_6_7_3
 G  disj2_6_7_3
 G  disj1_6_8_3
 G  disj2_6_8_3
 G  disj1_6_9_3
 G  disj2_6_9_3
 G  disj1_7_8_3
 G  disj2_7_8_3
 G  disj1_7_9_3
 G  disj2_7_9_3
 G  disj1_8_9_3
 G  disj2_8_9_3
 G  disj1_0_1_4
 G  disj2_0_1_4
 G  disj1_0_2_4
 G  disj2_0_2_4
 G  disj1_0_3_4
 G  disj2_0_3_4
 G  disj1_0_4_4
 G  disj2_0_4_4
 G  disj1_0_5_4
 G  disj2_0_5_4
 G  disj1_0_6_4
 G  disj2_0_6_4
 G  disj1_0_7_4
 G  disj2_0_7_4
 G  disj1_0_8_4
 G  disj2_0_8_4
 G  disj1_0_9_4
 G  disj2_0_9_4
 G  disj1_1_2_4
 G  disj2_1_2_4
 G  disj1_1_3_4
 G  disj2_1_3_4
 G  disj1_1_4_4
 G  disj2_1_4_4
 G  disj1_1_5_4
 G  disj2_1_5_4
 G  disj1_1_6_4
 G  disj2_1_6_4
 G  disj1_1_7_4
 G  disj2_1_7_4
 G  disj1_1_8_4
 G  disj2_1_8_4
 G  disj1_1_9_4
 G  disj2_1_9_4
 G  disj1_2_3_4
 G  disj2_2_3_4
 G  disj1_2_4_4
 G  disj2_2_4_4
 G  disj1_2_5_4
 G  disj2_2_5_4
 G  disj1_2_6_4
 G  disj2_2_6_4
 G  disj1_2_7_4
 G  disj2_2_7_4
 G  disj1_2_8_4
 G  disj2_2_8_4
 G  disj1_2_9_4
 G  disj2_2_9_4
 G  disj1_3_4_4
 G  disj2_3_4_4
 G  disj1_3_5_4
 G  disj2_3_5_4
 G  disj1_3_6_4
 G  disj2_3_6_4
 G  disj1_3_7_4
 G  disj2_3_7_4
 G  disj1_3_8_4
 G  disj2_3_8_4
 G  disj1_3_9_4
 G  disj2_3_9_4
 G  disj1_4_5_4
 G  disj2_4_5_4
 G  disj1_4_6_4
 G  disj2_4_6_4
 G  disj1_4_7_4
 G  disj2_4_7_4
 G  disj1_4_8_4
 G  disj2_4_8_4
 G  disj1_4_9_4
 G  disj2_4_9_4
 G  disj1_5_6_4
 G  disj2_5_6_4
 G  disj1_5_7_4
 G  disj2_5_7_4
 G  disj1_5_8_4
 G  disj2_5_8_4
 G  disj1_5_9_4
 G  disj2_5_9_4
 G  disj1_6_7_4
 G  disj2_6_7_4
 G  disj1_6_8_4
 G  disj2_6_8_4
 G  disj1_6_9_4
 G  disj2_6_9_4
 G  disj1_7_8_4
 G  disj2_7_8_4
 G  disj1_7_9_4
 G  disj2_7_9_4
 G  disj1_8_9_4
 G  disj2_8_9_4
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    C         OBJ       1.0
    C         mksp_0    1.0
    C         mksp_1    1.0
    C         mksp_2    1.0
    C         mksp_3    1.0
    C         mksp_4    1.0
    C         mksp_5    1.0
    C         mksp_6    1.0
    C         mksp_7    1.0
    C         mksp_8    1.0
    C         mksp_9    1.0
    x_0_0     prec_0_0  -1.0
    x_0_0     disj1_0_1_0  -1.0
    x_0_0     disj2_0_1_0  1.0
    x_0_0     disj1_0_2_0  -1.0
    x_0_0     disj2_0_2_0  1.0
    x_0_0     disj1_0_3_0  -1.0
    x_0_0     disj2_0_3_0  1.0
    x_0_0     disj1_0_4_0  -1.0
    x_0_0     disj2_0_4_0  1.0
    x_0_0     disj1_0_5_0  -1.0
    x_0_0     disj2_0_5_0  1.0
    x_0_0     disj1_0_6_0  -1.0
    x_0_0     disj2_0_6_0  1.0
    x_0_0     disj1_0_7_0  -1.0
    x_0_0     disj2_0_7_0  1.0
    x_0_0     disj1_0_8_0  -1.0
    x_0_0     disj2_0_8_0  1.0
    x_0_0     disj1_0_9_0  -1.0
    x_0_0     disj2_0_9_0  1.0
    x_0_1     prec_0_0  1.0
    x_0_1     prec_0_1  -1.0
    x_0_1     disj1_0_1_1  -1.0
    x_0_1     disj2_0_1_1  1.0
    x_0_1     disj1_0_2_1  -1.0
    x_0_1     disj2_0_2_1  1.0
    x_0_1     disj1_0_3_1  -1.0
    x_0_1     disj2_0_3_1  1.0
    x_0_1     disj1_0_4_1  -1.0
    x_0_1     disj2_0_4_1  1.0
    x_0_1     disj1_0_5_1  -1.0
    x_0_1     disj2_0_5_1  1.0
    x_0_1     disj1_0_6_1  -1.0
    x_0_1     disj2_0_6_1  1.0
    x_0_1     disj1_0_7_1  -1.0
    x_0_1     disj2_0_7_1  1.0
    x_0_1     disj1_0_8_1  -1.0
    x_0_1     disj2_0_8_1  1.0
    x_0_1     disj1_0_9_1  -1.0
    x_0_1     disj2_0_9_1  1.0
    x_0_2     prec_0_1  1.0
    x_0_2     prec_0_2  -1.0
    x_0_2     disj1_0_1_2  -1.0
    x_0_2     disj2_0_1_2  1.0
    x_0_2     disj1_0_2_2  -1.0
    x_0_2     disj2_0_2_2  1.0
    x_0_2     disj1_0_3_2  -1.0
    x_0_2     disj2_0_3_2  1.0
    x_0_2     disj1_0_4_2  -1.0
    x_0_2     disj2_0_4_2  1.0
    x_0_2     disj1_0_5_2  -1.0
    x_0_2     disj2_0_5_2  1.0
    x_0_2     disj1_0_6_2  -1.0
    x_0_2     disj2_0_6_2  1.0
    x_0_2     disj1_0_7_2  -1.0
    x_0_2     disj2_0_7_2  1.0
    x_0_2     disj1_0_8_2  -1.0
    x_0_2     disj2_0_8_2  1.0
    x_0_2     disj1_0_9_2  -1.0
    x_0_2     disj2_0_9_2  1.0
    x_0_3     prec_0_2  1.0
    x_0_3     prec_0_3  -1.0
    x_0_3     disj1_0_1_3  -1.0
    x_0_3     disj2_0_1_3  1.0
    x_0_3     disj1_0_2_3  -1.0
    x_0_3     disj2_0_2_3  1.0
    x_0_3     disj1_0_3_3  -1.0
    x_0_3     disj2_0_3_3  1.0
    x_0_3     disj1_0_4_3  -1.0
    x_0_3     disj2_0_4_3  1.0
    x_0_3     disj1_0_5_3  -1.0
    x_0_3     disj2_0_5_3  1.0
    x_0_3     disj1_0_6_3  -1.0
    x_0_3     disj2_0_6_3  1.0
    x_0_3     disj1_0_7_3  -1.0
    x_0_3     disj2_0_7_3  1.0
    x_0_3     disj1_0_8_3  -1.0
    x_0_3     disj2_0_8_3  1.0
    x_0_3     disj1_0_9_3  -1.0
    x_0_3     disj2_0_9_3  1.0
    x_0_4     prec_0_3  1.0
    x_0_4     mksp_0    -1.0
    x_0_4     disj1_0_1_4  -1.0
    x_0_4     disj2_0_1_4  1.0
    x_0_4     disj1_0_2_4  -1.0
    x_0_4     disj2_0_2_4  1.0
    x_0_4     disj1_0_3_4  -1.0
    x_0_4     disj2_0_3_4  1.0
    x_0_4     disj1_0_4_4  -1.0
    x_0_4     disj2_0_4_4  1.0
    x_0_4     disj1_0_5_4  -1.0
    x_0_4     disj2_0_5_4  1.0
    x_0_4     disj1_0_6_4  -1.0
    x_0_4     disj2_0_6_4  1.0
    x_0_4     disj1_0_7_4  -1.0
    x_0_4     disj2_0_7_4  1.0
    x_0_4     disj1_0_8_4  -1.0
    x_0_4     disj2_0_8_4  1.0
    x_0_4     disj1_0_9_4  -1.0
    x_0_4     disj2_0_9_4  1.0
    x_1_0     prec_1_0  -1.0
    x_1_0     disj1_0_1_1  1.0
    x_1_0     disj2_0_1_1  -1.0
    x_1_0     disj1_1_2_1  -1.0
    x_1_0     disj2_1_2_1  1.0
    x_1_0     disj1_1_3_1  -1.0
    x_1_0     disj2_1_3_1  1.0
    x_1_0     disj1_1_4_1  -1.0
    x_1_0     disj2_1_4_1  1.0
    x_1_0     disj1_1_5_1  -1.0
    x_1_0     disj2_1_5_1  1.0
    x_1_0     disj1_1_6_1  -1.0
    x_1_0     disj2_1_6_1  1.0
    x_1_0     disj1_1_7_1  -1.0
    x_1_0     disj2_1_7_1  1.0
    x_1_0     disj1_1_8_1  -1.0
    x_1_0     disj2_1_8_1  1.0
    x_1_0     disj1_1_9_1  -1.0
    x_1_0     disj2_1_9_1  1.0
    x_1_1     prec_1_0  1.0
    x_1_1     prec_1_1  -1.0
    x_1_1     disj1_0_1_0  1.0
    x_1_1     disj2_0_1_0  -1.0
    x_1_1     disj1_1_2_0  -1.0
    x_1_1     disj2_1_2_0  1.0
    x_1_1     disj1_1_3_0  -1.0
    x_1_1     disj2_1_3_0  1.0
    x_1_1     disj1_1_4_0  -1.0
    x_1_1     disj2_1_4_0  1.0
    x_1_1     disj1_1_5_0  -1.0
    x_1_1     disj2_1_5_0  1.0
    x_1_1     disj1_1_6_0  -1.0
    x_1_1     disj2_1_6_0  1.0
    x_1_1     disj1_1_7_0  -1.0
    x_1_1     disj2_1_7_0  1.0
    x_1_1     disj1_1_8_0  -1.0
    x_1_1     disj2_1_8_0  1.0
    x_1_1     disj1_1_9_0  -1.0
    x_1_1     disj2_1_9_0  1.0
    x_1_2     prec_1_1  1.0
    x_1_2     prec_1_2  -1.0
    x_1_2     disj1_0_1_3  1.0
    x_1_2     disj2_0_1_3  -1.0
    x_1_2     disj1_1_2_3  -1.0
    x_1_2     disj2_1_2_3  1.0
    x_1_2     disj1_1_3_3  -1.0
    x_1_2     disj2_1_3_3  1.0
    x_1_2     disj1_1_4_3  -1.0
    x_1_2     disj2_1_4_3  1.0
    x_1_2     disj1_1_5_3  -1.0
    x_1_2     disj2_1_5_3  1.0
    x_1_2     disj1_1_6_3  -1.0
    x_1_2     disj2_1_6_3  1.0
    x_1_2     disj1_1_7_3  -1.0
    x_1_2     disj2_1_7_3  1.0
    x_1_2     disj1_1_8_3  -1.0
    x_1_2     disj2_1_8_3  1.0
    x_1_2     disj1_1_9_3  -1.0
    x_1_2     disj2_1_9_3  1.0
    x_1_3     prec_1_2  1.0
    x_1_3     prec_1_3  -1.0
    x_1_3     disj1_0_1_2  1.0
    x_1_3     disj2_0_1_2  -1.0
    x_1_3     disj1_1_2_2  -1.0
    x_1_3     disj2_1_2_2  1.0
    x_1_3     disj1_1_3_2  -1.0
    x_1_3     disj2_1_3_2  1.0
    x_1_3     disj1_1_4_2  -1.0
    x_1_3     disj2_1_4_2  1.0
    x_1_3     disj1_1_5_2  -1.0
    x_1_3     disj2_1_5_2  1.0
    x_1_3     disj1_1_6_2  -1.0
    x_1_3     disj2_1_6_2  1.0
    x_1_3     disj1_1_7_2  -1.0
    x_1_3     disj2_1_7_2  1.0
    x_1_3     disj1_1_8_2  -1.0
    x_1_3     disj2_1_8_2  1.0
    x_1_3     disj1_1_9_2  -1.0
    x_1_3     disj2_1_9_2  1.0
    x_1_4     prec_1_3  1.0
    x_1_4     mksp_1    -1.0
    x_1_4     disj1_0_1_4  1.0
    x_1_4     disj2_0_1_4  -1.0
    x_1_4     disj1_1_2_4  -1.0
    x_1_4     disj2_1_2_4  1.0
    x_1_4     disj1_1_3_4  -1.0
    x_1_4     disj2_1_3_4  1.0
    x_1_4     disj1_1_4_4  -1.0
    x_1_4     disj2_1_4_4  1.0
    x_1_4     disj1_1_5_4  -1.0
    x_1_4     disj2_1_5_4  1.0
    x_1_4     disj1_1_6_4  -1.0
    x_1_4     disj2_1_6_4  1.0
    x_1_4     disj1_1_7_4  -1.0
    x_1_4     disj2_1_7_4  1.0
    x_1_4     disj1_1_8_4  -1.0
    x_1_4     disj2_1_8_4  1.0
    x_1_4     disj1_1_9_4  -1.0
    x_1_4     disj2_1_9_4  1.0
    x_2_0     prec_2_0  -1.0
    x_2_0     disj1_0_2_2  1.0
    x_2_0     disj2_0_2_2  -1.0
    x_2_0     disj1_1_2_2  1.0
    x_2_0     disj2_1_2_2  -1.0
    x_2_0     disj1_2_3_2  -1.0
    x_2_0     disj2_2_3_2  1.0
    x_2_0     disj1_2_4_2  -1.0
    x_2_0     disj2_2_4_2  1.0
    x_2_0     disj1_2_5_2  -1.0
    x_2_0     disj2_2_5_2  1.0
    x_2_0     disj1_2_6_2  -1.0
    x_2_0     disj2_2_6_2  1.0
    x_2_0     disj1_2_7_2  -1.0
    x_2_0     disj2_2_7_2  1.0
    x_2_0     disj1_2_8_2  -1.0
    x_2_0     disj2_2_8_2  1.0
    x_2_0     disj1_2_9_2  -1.0
    x_2_0     disj2_2_9_2  1.0
    x_2_1     prec_2_0  1.0
    x_2_1     prec_2_1  -1.0
    x_2_1     disj1_0_2_3  1.0
    x_2_1     disj2_0_2_3  -1.0
    x_2_1     disj1_1_2_3  1.0
    x_2_1     disj2_1_2_3  -1.0
    x_2_1     disj1_2_3_3  -1.0
    x_2_1     disj2_2_3_3  1.0
    x_2_1     disj1_2_4_3  -1.0
    x_2_1     disj2_2_4_3  1.0
    x_2_1     disj1_2_5_3  -1.0
    x_2_1     disj2_2_5_3  1.0
    x_2_1     disj1_2_6_3  -1.0
    x_2_1     disj2_2_6_3  1.0
    x_2_1     disj1_2_7_3  -1.0
    x_2_1     disj2_2_7_3  1.0
    x_2_1     disj1_2_8_3  -1.0
    x_2_1     disj2_2_8_3  1.0
    x_2_1     disj1_2_9_3  -1.0
    x_2_1     disj2_2_9_3  1.0
    x_2_2     prec_2_1  1.0
    x_2_2     prec_2_2  -1.0
    x_2_2     disj1_0_2_1  1.0
    x_2_2     disj2_0_2_1  -1.0
    x_2_2     disj1_1_2_1  1.0
    x_2_2     disj2_1_2_1  -1.0
    x_2_2     disj1_2_3_1  -1.0
    x_2_2     disj2_2_3_1  1.0
    x_2_2     disj1_2_4_1  -1.0
    x_2_2     disj2_2_4_1  1.0
    x_2_2     disj1_2_5_1  -1.0
    x_2_2     disj2_2_5_1  1.0
    x_2_2     disj1_2_6_1  -1.0
    x_2_2     disj2_2_6_1  1.0
    x_2_2     disj1_2_7_1  -1.0
    x_2_2     disj2_2_7_1  1.0
    x_2_2     disj1_2_8_1  -1.0
    x_2_2     disj2_2_8_1  1.0
    x_2_2     disj1_2_9_1  -1.0
    x_2_2     disj2_2_9_1  1.0
    x_2_3     prec_2_2  1.0
    x_2_3     prec_2_3  -1.0
    x_2_3     disj1_0_2_4  1.0
    x_2_3     disj2_0_2_4  -1.0
    x_2_3     disj1_1_2_4  1.0
    x_2_3     disj2_1_2_4  -1.0
    x_2_3     disj1_2_3_4  -1.0
    x_2_3     disj2_2_3_4  1.0
    x_2_3     disj1_2_4_4  -1.0
    x_2_3     disj2_2_4_4  1.0
    x_2_3     disj1_2_5_4  -1.0
    x_2_3     disj2_2_5_4  1.0
    x_2_3     disj1_2_6_4  -1.0
    x_2_3     disj2_2_6_4  1.0
    x_2_3     disj1_2_7_4  -1.0
    x_2_3     disj2_2_7_4  1.0
    x_2_3     disj1_2_8_4  -1.0
    x_2_3     disj2_2_8_4  1.0
    x_2_3     disj1_2_9_4  -1.0
    x_2_3     disj2_2_9_4  1.0
    x_2_4     prec_2_3  1.0
    x_2_4     mksp_2    -1.0
    x_2_4     disj1_0_2_0  1.0
    x_2_4     disj2_0_2_0  -1.0
    x_2_4     disj1_1_2_0  1.0
    x_2_4     disj2_1_2_0  -1.0
    x_2_4     disj1_2_3_0  -1.0
    x_2_4     disj2_2_3_0  1.0
    x_2_4     disj1_2_4_0  -1.0
    x_2_4     disj2_2_4_0  1.0
    x_2_4     disj1_2_5_0  -1.0
    x_2_4     disj2_2_5_0  1.0
    x_2_4     disj1_2_6_0  -1.0
    x_2_4     disj2_2_6_0  1.0
    x_2_4     disj1_2_7_0  -1.0
    x_2_4     disj2_2_7_0  1.0
    x_2_4     disj1_2_8_0  -1.0
    x_2_4     disj2_2_8_0  1.0
    x_2_4     disj1_2_9_0  -1.0
    x_2_4     disj2_2_9_0  1.0
    x_3_0     prec_3_0  -1.0
    x_3_0     disj1_0_3_1  1.0
    x_3_0     disj2_0_3_1  -1.0
    x_3_0     disj1_1_3_1  1.0
    x_3_0     disj2_1_3_1  -1.0
    x_3_0     disj1_2_3_1  1.0
    x_3_0     disj2_2_3_1  -1.0
    x_3_0     disj1_3_4_1  -1.0
    x_3_0     disj2_3_4_1  1.0
    x_3_0     disj1_3_5_1  -1.0
    x_3_0     disj2_3_5_1  1.0
    x_3_0     disj1_3_6_1  -1.0
    x_3_0     disj2_3_6_1  1.0
    x_3_0     disj1_3_7_1  -1.0
    x_3_0     disj2_3_7_1  1.0
    x_3_0     disj1_3_8_1  -1.0
    x_3_0     disj2_3_8_1  1.0
    x_3_0     disj1_3_9_1  -1.0
    x_3_0     disj2_3_9_1  1.0
    x_3_1     prec_3_0  1.0
    x_3_1     prec_3_1  -1.0
    x_3_1     disj1_0_3_0  1.0
    x_3_1     disj2_0_3_0  -1.0
    x_3_1     disj1_1_3_0  1.0
    x_3_1     disj2_1_3_0  -1.0
    x_3_1     disj1_2_3_0  1.0
    x_3_1     disj2_2_3_0  -1.0
    x_3_1     disj1_3_4_0  -1.0
    x_3_1     disj2_3_4_0  1.0
    x_3_1     disj1_3_5_0  -1.0
    x_3_1     disj2_3_5_0  1.0
    x_3_1     disj1_3_6_0  -1.0
    x_3_1     disj2_3_6_0  1.0
    x_3_1     disj1_3_7_0  -1.0
    x_3_1     disj2_3_7_0  1.0
    x_3_1     disj1_3_8_0  -1.0
    x_3_1     disj2_3_8_0  1.0
    x_3_1     disj1_3_9_0  -1.0
    x_3_1     disj2_3_9_0  1.0
    x_3_2     prec_3_1  1.0
    x_3_2     prec_3_2  -1.0
    x_3_2     disj1_0_3_4  1.0
    x_3_2     disj2_0_3_4  -1.0
    x_3_2     disj1_1_3_4  1.0
    x_3_2     disj2_1_3_4  -1.0
    x_3_2     disj1_2_3_4  1.0
    x_3_2     disj2_2_3_4  -1.0
    x_3_2     disj1_3_4_4  -1.0
    x_3_2     disj2_3_4_4  1.0
    x_3_2     disj1_3_5_4  -1.0
    x_3_2     disj2_3_5_4  1.0
    x_3_2     disj1_3_6_4  -1.0
    x_3_2     disj2_3_6_4  1.0
    x_3_2     disj1_3_7_4  -1.0
    x_3_2     disj2_3_7_4  1.0
    x_3_2     disj1_3_8_4  -1.0
    x_3_2     disj2_3_8_4  1.0
    x_3_2     disj1_3_9_4  -1.0
    x_3_2     disj2_3_9_4  1.0
    x_3_3     prec_3_2  1.0
    x_3_3     prec_3_3  -1.0
    x_3_3     disj1_0_3_2  1.0
    x_3_3     disj2_0_3_2  -1.0
    x_3_3     disj1_1_3_2  1.0
    x_3_3     disj2_1_3_2  -1.0
    x_3_3     disj1_2_3_2  1.0
    x_3_3     disj2_2_3_2  -1.0
    x_3_3     disj1_3_4_2  -1.0
    x_3_3     disj2_3_4_2  1.0
    x_3_3     disj1_3_5_2  -1.0
    x_3_3     disj2_3_5_2  1.0
    x_3_3     disj1_3_6_2  -1.0
    x_3_3     disj2_3_6_2  1.0
    x_3_3     disj1_3_7_2  -1.0
    x_3_3     disj2_3_7_2  1.0
    x_3_3     disj1_3_8_2  -1.0
    x_3_3     disj2_3_8_2  1.0
    x_3_3     disj1_3_9_2  -1.0
    x_3_3     disj2_3_9_2  1.0
    x_3_4     prec_3_3  1.0
    x_3_4     mksp_3    -1.0
    x_3_4     disj1_0_3_3  1.0
    x_3_4     disj2_0_3_3  -1.0
    x_3_4     disj1_1_3_3  1.0
    x_3_4     disj2_1_3_3  -1.0
    x_3_4     disj1_2_3_3  1.0
    x_3_4     disj2_2_3_3  -1.0
    x_3_4     disj1_3_4_3  -1.0
    x_3_4     disj2_3_4_3  1.0
    x_3_4     disj1_3_5_3  -1.0
    x_3_4     disj2_3_5_3  1.0
    x_3_4     disj1_3_6_3  -1.0
    x_3_4     disj2_3_6_3  1.0
    x_3_4     disj1_3_7_3  -1.0
    x_3_4     disj2_3_7_3  1.0
    x_3_4     disj1_3_8_3  -1.0
    x_3_4     disj2_3_8_3  1.0
    x_3_4     disj1_3_9_3  -1.0
    x_3_4     disj2_3_9_3  1.0
    x_4_0     prec_4_0  -1.0
    x_4_0     disj1_0_4_0  1.0
    x_4_0     disj2_0_4_0  -1.0
    x_4_0     disj1_1_4_0  1.0
    x_4_0     disj2_1_4_0  -1.0
    x_4_0     disj1_2_4_0  1.0
    x_4_0     disj2_2_4_0  -1.0
    x_4_0     disj1_3_4_0  1.0
    x_4_0     disj2_3_4_0  -1.0
    x_4_0     disj1_4_5_0  -1.0
    x_4_0     disj2_4_5_0  1.0
    x_4_0     disj1_4_6_0  -1.0
    x_4_0     disj2_4_6_0  1.0
    x_4_0     disj1_4_7_0  -1.0
    x_4_0     disj2_4_7_0  1.0
    x_4_0     disj1_4_8_0  -1.0
    x_4_0     disj2_4_8_0  1.0
    x_4_0     disj1_4_9_0  -1.0
    x_4_0     disj2_4_9_0  1.0
    x_4_1     prec_4_0  1.0
    x_4_1     prec_4_1  -1.0
    x_4_1     disj1_0_4_3  1.0
    x_4_1     disj2_0_4_3  -1.0
    x_4_1     disj1_1_4_3  1.0
    x_4_1     disj2_1_4_3  -1.0
    x_4_1     disj1_2_4_3  1.0
    x_4_1     disj2_2_4_3  -1.0
    x_4_1     disj1_3_4_3  1.0
    x_4_1     disj2_3_4_3  -1.0
    x_4_1     disj1_4_5_3  -1.0
    x_4_1     disj2_4_5_3  1.0
    x_4_1     disj1_4_6_3  -1.0
    x_4_1     disj2_4_6_3  1.0
    x_4_1     disj1_4_7_3  -1.0
    x_4_1     disj2_4_7_3  1.0
    x_4_1     disj1_4_8_3  -1.0
    x_4_1     disj2_4_8_3  1.0
    x_4_1     disj1_4_9_3  -1.0
    x_4_1     disj2_4_9_3  1.0
    x_4_2     prec_4_1  1.0
    x_4_2     prec_4_2  -1.0
    x_4_2     disj1_0_4_2  1.0
    x_4_2     disj2_0_4_2  -1.0
    x_4_2     disj1_1_4_2  1.0
    x_4_2     disj2_1_4_2  -1.0
    x_4_2     disj1_2_4_2  1.0
    x_4_2     disj2_2_4_2  -1.0
    x_4_2     disj1_3_4_2  1.0
    x_4_2     disj2_3_4_2  -1.0
    x_4_2     disj1_4_5_2  -1.0
    x_4_2     disj2_4_5_2  1.0
    x_4_2     disj1_4_6_2  -1.0
    x_4_2     disj2_4_6_2  1.0
    x_4_2     disj1_4_7_2  -1.0
    x_4_2     disj2_4_7_2  1.0
    x_4_2     disj1_4_8_2  -1.0
    x_4_2     disj2_4_8_2  1.0
    x_4_2     disj1_4_9_2  -1.0
    x_4_2     disj2_4_9_2  1.0
    x_4_3     prec_4_2  1.0
    x_4_3     prec_4_3  -1.0
    x_4_3     disj1_0_4_1  1.0
    x_4_3     disj2_0_4_1  -1.0
    x_4_3     disj1_1_4_1  1.0
    x_4_3     disj2_1_4_1  -1.0
    x_4_3     disj1_2_4_1  1.0
    x_4_3     disj2_2_4_1  -1.0
    x_4_3     disj1_3_4_1  1.0
    x_4_3     disj2_3_4_1  -1.0
    x_4_3     disj1_4_5_1  -1.0
    x_4_3     disj2_4_5_1  1.0
    x_4_3     disj1_4_6_1  -1.0
    x_4_3     disj2_4_6_1  1.0
    x_4_3     disj1_4_7_1  -1.0
    x_4_3     disj2_4_7_1  1.0
    x_4_3     disj1_4_8_1  -1.0
    x_4_3     disj2_4_8_1  1.0
    x_4_3     disj1_4_9_1  -1.0
    x_4_3     disj2_4_9_1  1.0
    x_4_4     prec_4_3  1.0
    x_4_4     mksp_4    -1.0
    x_4_4     disj1_0_4_4  1.0
    x_4_4     disj2_0_4_4  -1.0
    x_4_4     disj1_1_4_4  1.0
    x_4_4     disj2_1_4_4  -1.0
    x_4_4     disj1_2_4_4  1.0
    x_4_4     disj2_2_4_4  -1.0
    x_4_4     disj1_3_4_4  1.0
    x_4_4     disj2_3_4_4  -1.0
    x_4_4     disj1_4_5_4  -1.0
    x_4_4     disj2_4_5_4  1.0
    x_4_4     disj1_4_6_4  -1.0
    x_4_4     disj2_4_6_4  1.0
    x_4_4     disj1_4_7_4  -1.0
    x_4_4     disj2_4_7_4  1.0
    x_4_4     disj1_4_8_4  -1.0
    x_4_4     disj2_4_8_4  1.0
    x_4_4     disj1_4_9_4  -1.0
    x_4_4     disj2_4_9_4  1.0
    x_5_0     prec_5_0  -1.0
    x_5_0     disj1_0_5_1  1.0
    x_5_0     disj2_0_5_1  -1.0
    x_5_0     disj1_1_5_1  1.0
    x_5_0     disj2_1_5_1  -1.0
    x_5_0     disj1_2_5_1  1.0
    x_5_0     disj2_2_5_1  -1.0
    x_5_0     disj1_3_5_1  1.0
    x_5_0     disj2_3_5_1  -1.0
    x_5_0     disj1_4_5_1  1.0
    x_5_0     disj2_4_5_1  -1.0
    x_5_0     disj1_5_6_1  -1.0
    x_5_0     disj2_5_6_1  1.0
    x_5_0     disj1_5_7_1  -1.0
    x_5_0     disj2_5_7_1  1.0
    x_5_0     disj1_5_8_1  -1.0
    x_5_0     disj2_5_8_1  1.0
    x_5_0     disj1_5_9_1  -1.0
    x_5_0     disj2_5_9_1  1.0
    x_5_1     prec_5_0  1.0
    x_5_1     prec_5_1  -1.0
    x_5_1     disj1_0_5_2  1.0
    x_5_1     disj2_0_5_2  -1.0
    x_5_1     disj1_1_5_2  1.0
    x_5_1     disj2_1_5_2  -1.0
    x_5_1     disj1_2_5_2  1.0
    x_5_1     disj2_2_5_2  -1.0
    x_5_1     disj1_3_5_2  1.0
    x_5_1     disj2_3_5_2  -1.0
    x_5_1     disj1_4_5_2  1.0
    x_5_1     disj2_4_5_2  -1.0
    x_5_1     disj1_5_6_2  -1.0
    x_5_1     disj2_5_6_2  1.0
    x_5_1     disj1_5_7_2  -1.0
    x_5_1     disj2_5_7_2  1.0
    x_5_1     disj1_5_8_2  -1.0
    x_5_1     disj2_5_8_2  1.0
    x_5_1     disj1_5_9_2  -1.0
    x_5_1     disj2_5_9_2  1.0
    x_5_2     prec_5_1  1.0
    x_5_2     prec_5_2  -1.0
    x_5_2     disj1_0_5_4  1.0
    x_5_2     disj2_0_5_4  -1.0
    x_5_2     disj1_1_5_4  1.0
    x_5_2     disj2_1_5_4  -1.0
    x_5_2     disj1_2_5_4  1.0
    x_5_2     disj2_2_5_4  -1.0
    x_5_2     disj1_3_5_4  1.0
    x_5_2     disj2_3_5_4  -1.0
    x_5_2     disj1_4_5_4  1.0
    x_5_2     disj2_4_5_4  -1.0
    x_5_2     disj1_5_6_4  -1.0
    x_5_2     disj2_5_6_4  1.0
    x_5_2     disj1_5_7_4  -1.0
    x_5_2     disj2_5_7_4  1.0
    x_5_2     disj1_5_8_4  -1.0
    x_5_2     disj2_5_8_4  1.0
    x_5_2     disj1_5_9_4  -1.0
    x_5_2     disj2_5_9_4  1.0
    x_5_3     prec_5_2  1.0
    x_5_3     prec_5_3  -1.0
    x_5_3     disj1_0_5_0  1.0
    x_5_3     disj2_0_5_0  -1.0
    x_5_3     disj1_1_5_0  1.0
    x_5_3     disj2_1_5_0  -1.0
    x_5_3     disj1_2_5_0  1.0
    x_5_3     disj2_2_5_0  -1.0
    x_5_3     disj1_3_5_0  1.0
    x_5_3     disj2_3_5_0  -1.0
    x_5_3     disj1_4_5_0  1.0
    x_5_3     disj2_4_5_0  -1.0
    x_5_3     disj1_5_6_0  -1.0
    x_5_3     disj2_5_6_0  1.0
    x_5_3     disj1_5_7_0  -1.0
    x_5_3     disj2_5_7_0  1.0
    x_5_3     disj1_5_8_0  -1.0
    x_5_3     disj2_5_8_0  1.0
    x_5_3     disj1_5_9_0  -1.0
    x_5_3     disj2_5_9_0  1.0
    x_5_4     prec_5_3  1.0
    x_5_4     mksp_5    -1.0
    x_5_4     disj1_0_5_3  1.0
    x_5_4     disj2_0_5_3  -1.0
    x_5_4     disj1_1_5_3  1.0
    x_5_4     disj2_1_5_3  -1.0
    x_5_4     disj1_2_5_3  1.0
    x_5_4     disj2_2_5_3  -1.0
    x_5_4     disj1_3_5_3  1.0
    x_5_4     disj2_3_5_3  -1.0
    x_5_4     disj1_4_5_3  1.0
    x_5_4     disj2_4_5_3  -1.0
    x_5_4     disj1_5_6_3  -1.0
    x_5_4     disj2_5_6_3  1.0
    x_5_4     disj1_5_7_3  -1.0
    x_5_4     disj2_5_7_3  1.0
    x_5_4     disj1_5_8_3  -1.0
    x_5_4     disj2_5_8_3  1.0
    x_5_4     disj1_5_9_3  -1.0
    x_5_4     disj2_5_9_3  1.0
    x_6_0     prec_6_0  -1.0
    x_6_0     disj1_0_6_1  1.0
    x_6_0     disj2_0_6_1  -1.0
    x_6_0     disj1_1_6_1  1.0
    x_6_0     disj2_1_6_1  -1.0
    x_6_0     disj1_2_6_1  1.0
    x_6_0     disj2_2_6_1  -1.0
    x_6_0     disj1_3_6_1  1.0
    x_6_0     disj2_3_6_1  -1.0
    x_6_0     disj1_4_6_1  1.0
    x_6_0     disj2_4_6_1  -1.0
    x_6_0     disj1_5_6_1  1.0
    x_6_0     disj2_5_6_1  -1.0
    x_6_0     disj1_6_7_1  -1.0
    x_6_0     disj2_6_7_1  1.0
    x_6_0     disj1_6_8_1  -1.0
    x_6_0     disj2_6_8_1  1.0
    x_6_0     disj1_6_9_1  -1.0
    x_6_0     disj2_6_9_1  1.0
    x_6_1     prec_6_0  1.0
    x_6_1     prec_6_1  -1.0
    x_6_1     disj1_0_6_4  1.0
    x_6_1     disj2_0_6_4  -1.0
    x_6_1     disj1_1_6_4  1.0
    x_6_1     disj2_1_6_4  -1.0
    x_6_1     disj1_2_6_4  1.0
    x_6_1     disj2_2_6_4  -1.0
    x_6_1     disj1_3_6_4  1.0
    x_6_1     disj2_3_6_4  -1.0
    x_6_1     disj1_4_6_4  1.0
    x_6_1     disj2_4_6_4  -1.0
    x_6_1     disj1_5_6_4  1.0
    x_6_1     disj2_5_6_4  -1.0
    x_6_1     disj1_6_7_4  -1.0
    x_6_1     disj2_6_7_4  1.0
    x_6_1     disj1_6_8_4  -1.0
    x_6_1     disj2_6_8_4  1.0
    x_6_1     disj1_6_9_4  -1.0
    x_6_1     disj2_6_9_4  1.0
    x_6_2     prec_6_1  1.0
    x_6_2     prec_6_2  -1.0
    x_6_2     disj1_0_6_3  1.0
    x_6_2     disj2_0_6_3  -1.0
    x_6_2     disj1_1_6_3  1.0
    x_6_2     disj2_1_6_3  -1.0
    x_6_2     disj1_2_6_3  1.0
    x_6_2     disj2_2_6_3  -1.0
    x_6_2     disj1_3_6_3  1.0
    x_6_2     disj2_3_6_3  -1.0
    x_6_2     disj1_4_6_3  1.0
    x_6_2     disj2_4_6_3  -1.0
    x_6_2     disj1_5_6_3  1.0
    x_6_2     disj2_5_6_3  -1.0
    x_6_2     disj1_6_7_3  -1.0
    x_6_2     disj2_6_7_3  1.0
    x_6_2     disj1_6_8_3  -1.0
    x_6_2     disj2_6_8_3  1.0
    x_6_2     disj1_6_9_3  -1.0
    x_6_2     disj2_6_9_3  1.0
    x_6_3     prec_6_2  1.0
    x_6_3     prec_6_3  -1.0
    x_6_3     disj1_0_6_2  1.0
    x_6_3     disj2_0_6_2  -1.0
    x_6_3     disj1_1_6_2  1.0
    x_6_3     disj2_1_6_2  -1.0
    x_6_3     disj1_2_6_2  1.0
    x_6_3     disj2_2_6_2  -1.0
    x_6_3     disj1_3_6_2  1.0
    x_6_3     disj2_3_6_2  -1.0
    x_6_3     disj1_4_6_2  1.0
    x_6_3     disj2_4_6_2  -1.0
    x_6_3     disj1_5_6_2  1.0
    x_6_3     disj2_5_6_2  -1.0
    x_6_3     disj1_6_7_2  -1.0
    x_6_3     disj2_6_7_2  1.0
    x_6_3     disj1_6_8_2  -1.0
    x_6_3     disj2_6_8_2  1.0
    x_6_3     disj1_6_9_2  -1.0
    x_6_3     disj2_6_9_2  1.0
    x_6_4     prec_6_3  1.0
    x_6_4     mksp_6    -1.0
    x_6_4     disj1_0_6_0  1.0
    x_6_4     disj2_0_6_0  -1.0
    x_6_4     disj1_1_6_0  1.0
    x_6_4     disj2_1_6_0  -1.0
    x_6_4     disj1_2_6_0  1.0
    x_6_4     disj2_2_6_0  -1.0
    x_6_4     disj1_3_6_0  1.0
    x_6_4     disj2_3_6_0  -1.0
    x_6_4     disj1_4_6_0  1.0
    x_6_4     disj2_4_6_0  -1.0
    x_6_4     disj1_5_6_0  1.0
    x_6_4     disj2_5_6_0  -1.0
    x_6_4     disj1_6_7_0  -1.0
    x_6_4     disj2_6_7_0  1.0
    x_6_4     disj1_6_8_0  -1.0
    x_6_4     disj2_6_8_0  1.0
    x_6_4     disj1_6_9_0  -1.0
    x_6_4     disj2_6_9_0  1.0
    x_7_0     prec_7_0  -1.0
    x_7_0     disj1_0_7_2  1.0
    x_7_0     disj2_0_7_2  -1.0
    x_7_0     disj1_1_7_2  1.0
    x_7_0     disj2_1_7_2  -1.0
    x_7_0     disj1_2_7_2  1.0
    x_7_0     disj2_2_7_2  -1.0
    x_7_0     disj1_3_7_2  1.0
    x_7_0     disj2_3_7_2  -1.0
    x_7_0     disj1_4_7_2  1.0
    x_7_0     disj2_4_7_2  -1.0
    x_7_0     disj1_5_7_2  1.0
    x_7_0     disj2_5_7_2  -1.0
    x_7_0     disj1_6_7_2  1.0
    x_7_0     disj2_6_7_2  -1.0
    x_7_0     disj1_7_8_2  -1.0
    x_7_0     disj2_7_8_2  1.0
    x_7_0     disj1_7_9_2  -1.0
    x_7_0     disj2_7_9_2  1.0
    x_7_1     prec_7_0  1.0
    x_7_1     prec_7_1  -1.0
    x_7_1     disj1_0_7_0  1.0
    x_7_1     disj2_0_7_0  -1.0
    x_7_1     disj1_1_7_0  1.0
    x_7_1     disj2_1_7_0  -1.0
    x_7_1     disj1_2_7_0  1.0
    x_7_1     disj2_2_7_0  -1.0
    x_7_1     disj1_3_7_0  1.0
    x_7_1     disj2_3_7_0  -1.0
    x_7_1     disj1_4_7_0  1.0
    x_7_1     disj2_4_7_0  -1.0
    x_7_1     disj1_5_7_0  1.0
    x_7_1     disj2_5_7_0  -1.0
    x_7_1     disj1_6_7_0  1.0
    x_7_1     disj2_6_7_0  -1.0
    x_7_1     disj1_7_8_0  -1.0
    x_7_1     disj2_7_8_0  1.0
    x_7_1     disj1_7_9_0  -1.0
    x_7_1     disj2_7_9_0  1.0
    x_7_2     prec_7_1  1.0
    x_7_2     prec_7_2  -1.0
    x_7_2     disj1_0_7_1  1.0
    x_7_2     disj2_0_7_1  -1.0
    x_7_2     disj1_1_7_1  1.0
    x_7_2     disj2_1_7_1  -1.0
    x_7_2     disj1_2_7_1  1.0
    x_7_2     disj2_2_7_1  -1.0
    x_7_2     disj1_3_7_1  1.0
    x_7_2     disj2_3_7_1  -1.0
    x_7_2     disj1_4_7_1  1.0
    x_7_2     disj2_4_7_1  -1.0
    x_7_2     disj1_5_7_1  1.0
    x_7_2     disj2_5_7_1  -1.0
    x_7_2     disj1_6_7_1  1.0
    x_7_2     disj2_6_7_1  -1.0
    x_7_2     disj1_7_8_1  -1.0
    x_7_2     disj2_7_8_1  1.0
    x_7_2     disj1_7_9_1  -1.0
    x_7_2     disj2_7_9_1  1.0
    x_7_3     prec_7_2  1.0
    x_7_3     prec_7_3  -1.0
    x_7_3     disj1_0_7_3  1.0
    x_7_3     disj2_0_7_3  -1.0
    x_7_3     disj1_1_7_3  1.0
    x_7_3     disj2_1_7_3  -1.0
    x_7_3     disj1_2_7_3  1.0
    x_7_3     disj2_2_7_3  -1.0
    x_7_3     disj1_3_7_3  1.0
    x_7_3     disj2_3_7_3  -1.0
    x_7_3     disj1_4_7_3  1.0
    x_7_3     disj2_4_7_3  -1.0
    x_7_3     disj1_5_7_3  1.0
    x_7_3     disj2_5_7_3  -1.0
    x_7_3     disj1_6_7_3  1.0
    x_7_3     disj2_6_7_3  -1.0
    x_7_3     disj1_7_8_3  -1.0
    x_7_3     disj2_7_8_3  1.0
    x_7_3     disj1_7_9_3  -1.0
    x_7_3     disj2_7_9_3  1.0
    x_7_4     prec_7_3  1.0
    x_7_4     mksp_7    -1.0
    x_7_4     disj1_0_7_4  1.0
    x_7_4     disj2_0_7_4  -1.0
    x_7_4     disj1_1_7_4  1.0
    x_7_4     disj2_1_7_4  -1.0
    x_7_4     disj1_2_7_4  1.0
    x_7_4     disj2_2_7_4  -1.0
    x_7_4     disj1_3_7_4  1.0
    x_7_4     disj2_3_7_4  -1.0
    x_7_4     disj1_4_7_4  1.0
    x_7_4     disj2_4_7_4  -1.0
    x_7_4     disj1_5_7_4  1.0
    x_7_4     disj2_5_7_4  -1.0
    x_7_4     disj1_6_7_4  1.0
    x_7_4     disj2_6_7_4  -1.0
    x_7_4     disj1_7_8_4  -1.0
    x_7_4     disj2_7_8_4  1.0
    x_7_4     disj1_7_9_4  -1.0
    x_7_4     disj2_7_9_4  1.0
    x_8_0     prec_8_0  -1.0
    x_8_0     disj1_0_8_3  1.0
    x_8_0     disj2_0_8_3  -1.0
    x_8_0     disj1_1_8_3  1.0
    x_8_0     disj2_1_8_3  -1.0
    x_8_0     disj1_2_8_3  1.0
    x_8_0     disj2_2_8_3  -1.0
    x_8_0     disj1_3_8_3  1.0
    x_8_0     disj2_3_8_3  -1.0
    x_8_0     disj1_4_8_3  1.0
    x_8_0     disj2_4_8_3  -1.0
    x_8_0     disj1_5_8_3  1.0
    x_8_0     disj2_5_8_3  -1.0
    x_8_0     disj1_6_8_3  1.0
    x_8_0     disj2_6_8_3  -1.0
    x_8_0     disj1_7_8_3  1.0
    x_8_0     disj2_7_8_3  -1.0
    x_8_0     disj1_8_9_3  -1.0
    x_8_0     disj2_8_9_3  1.0
    x_8_1     prec_8_0  1.0
    x_8_1     prec_8_1  -1.0
    x_8_1     disj1_0_8_1  1.0
    x_8_1     disj2_0_8_1  -1.0
    x_8_1     disj1_1_8_1  1.0
    x_8_1     disj2_1_8_1  -1.0
    x_8_1     disj1_2_8_1  1.0
    x_8_1     disj2_2_8_1  -1.0
    x_8_1     disj1_3_8_1  1.0
    x_8_1     disj2_3_8_1  -1.0
    x_8_1     disj1_4_8_1  1.0
    x_8_1     disj2_4_8_1  -1.0
    x_8_1     disj1_5_8_1  1.0
    x_8_1     disj2_5_8_1  -1.0
    x_8_1     disj1_6_8_1  1.0
    x_8_1     disj2_6_8_1  -1.0
    x_8_1     disj1_7_8_1  1.0
    x_8_1     disj2_7_8_1  -1.0
    x_8_1     disj1_8_9_1  -1.0
    x_8_1     disj2_8_9_1  1.0
    x_8_2     prec_8_1  1.0
    x_8_2     prec_8_2  -1.0
    x_8_2     disj1_0_8_4  1.0
    x_8_2     disj2_0_8_4  -1.0
    x_8_2     disj1_1_8_4  1.0
    x_8_2     disj2_1_8_4  -1.0
    x_8_2     disj1_2_8_4  1.0
    x_8_2     disj2_2_8_4  -1.0
    x_8_2     disj1_3_8_4  1.0
    x_8_2     disj2_3_8_4  -1.0
    x_8_2     disj1_4_8_4  1.0
    x_8_2     disj2_4_8_4  -1.0
    x_8_2     disj1_5_8_4  1.0
    x_8_2     disj2_5_8_4  -1.0
    x_8_2     disj1_6_8_4  1.0
    x_8_2     disj2_6_8_4  -1.0
    x_8_2     disj1_7_8_4  1.0
    x_8_2     disj2_7_8_4  -1.0
    x_8_2     disj1_8_9_4  -1.0
    x_8_2     disj2_8_9_4  1.0
    x_8_3     prec_8_2  1.0
    x_8_3     prec_8_3  -1.0
    x_8_3     disj1_0_8_0  1.0
    x_8_3     disj2_0_8_0  -1.0
    x_8_3     disj1_1_8_0  1.0
    x_8_3     disj2_1_8_0  -1.0
    x_8_3     disj1_2_8_0  1.0
    x_8_3     disj2_2_8_0  -1.0
    x_8_3     disj1_3_8_0  1.0
    x_8_3     disj2_3_8_0  -1.0
    x_8_3     disj1_4_8_0  1.0
    x_8_3     disj2_4_8_0  -1.0
    x_8_3     disj1_5_8_0  1.0
    x_8_3     disj2_5_8_0  -1.0
    x_8_3     disj1_6_8_0  1.0
    x_8_3     disj2_6_8_0  -1.0
    x_8_3     disj1_7_8_0  1.0
    x_8_3     disj2_7_8_0  -1.0
    x_8_3     disj1_8_9_0  -1.0
    x_8_3     disj2_8_9_0  1.0
    x_8_4     prec_8_3  1.0
    x_8_4     mksp_8    -1.0
    x_8_4     disj1_0_8_2  1.0
    x_8_4     disj2_0_8_2  -1.0
    x_8_4     disj1_1_8_2  1.0
    x_8_4     disj2_1_8_2  -1.0
    x_8_4     disj1_2_8_2  1.0
    x_8_4     disj2_2_8_2  -1.0
    x_8_4     disj1_3_8_2  1.0
    x_8_4     disj2_3_8_2  -1.0
    x_8_4     disj1_4_8_2  1.0
    x_8_4     disj2_4_8_2  -1.0
    x_8_4     disj1_5_8_2  1.0
    x_8_4     disj2_5_8_2  -1.0
    x_8_4     disj1_6_8_2  1.0
    x_8_4     disj2_6_8_2  -1.0
    x_8_4     disj1_7_8_2  1.0
    x_8_4     disj2_7_8_2  -1.0
    x_8_4     disj1_8_9_2  -1.0
    x_8_4     disj2_8_9_2  1.0
    x_9_0     prec_9_0  -1.0
    x_9_0     disj1_0_9_4  1.0
    x_9_0     disj2_0_9_4  -1.0
    x_9_0     disj1_1_9_4  1.0
    x_9_0     disj2_1_9_4  -1.0
    x_9_0     disj1_2_9_4  1.0
    x_9_0     disj2_2_9_4  -1.0
    x_9_0     disj1_3_9_4  1.0
    x_9_0     disj2_3_9_4  -1.0
    x_9_0     disj1_4_9_4  1.0
    x_9_0     disj2_4_9_4  -1.0
    x_9_0     disj1_5_9_4  1.0
    x_9_0     disj2_5_9_4  -1.0
    x_9_0     disj1_6_9_4  1.0
    x_9_0     disj2_6_9_4  -1.0
    x_9_0     disj1_7_9_4  1.0
    x_9_0     disj2_7_9_4  -1.0
    x_9_0     disj1_8_9_4  1.0
    x_9_0     disj2_8_9_4  -1.0
    x_9_1     prec_9_0  1.0
    x_9_1     prec_9_1  -1.0
    x_9_1     disj1_0_9_3  1.0
    x_9_1     disj2_0_9_3  -1.0
    x_9_1     disj1_1_9_3  1.0
    x_9_1     disj2_1_9_3  -1.0
    x_9_1     disj1_2_9_3  1.0
    x_9_1     disj2_2_9_3  -1.0
    x_9_1     disj1_3_9_3  1.0
    x_9_1     disj2_3_9_3  -1.0
    x_9_1     disj1_4_9_3  1.0
    x_9_1     disj2_4_9_3  -1.0
    x_9_1     disj1_5_9_3  1.0
    x_9_1     disj2_5_9_3  -1.0
    x_9_1     disj1_6_9_3  1.0
    x_9_1     disj2_6_9_3  -1.0
    x_9_1     disj1_7_9_3  1.0
    x_9_1     disj2_7_9_3  -1.0
    x_9_1     disj1_8_9_3  1.0
    x_9_1     disj2_8_9_3  -1.0
    x_9_2     prec_9_1  1.0
    x_9_2     prec_9_2  -1.0
    x_9_2     disj1_0_9_2  1.0
    x_9_2     disj2_0_9_2  -1.0
    x_9_2     disj1_1_9_2  1.0
    x_9_2     disj2_1_9_2  -1.0
    x_9_2     disj1_2_9_2  1.0
    x_9_2     disj2_2_9_2  -1.0
    x_9_2     disj1_3_9_2  1.0
    x_9_2     disj2_3_9_2  -1.0
    x_9_2     disj1_4_9_2  1.0
    x_9_2     disj2_4_9_2  -1.0
    x_9_2     disj1_5_9_2  1.0
    x_9_2     disj2_5_9_2  -1.0
    x_9_2     disj1_6_9_2  1.0
    x_9_2     disj2_6_9_2  -1.0
    x_9_2     disj1_7_9_2  1.0
    x_9_2     disj2_7_9_2  -1.0
    x_9_2     disj1_8_9_2  1.0
    x_9_2     disj2_8_9_2  -1.0
    x_9_3     prec_9_2  1.0
    x_9_3     prec_9_3  -1.0
    x_9_3     disj1_0_9_1  1.0
    x_9_3     disj2_0_9_1  -1.0
    x_9_3     disj1_1_9_1  1.0
    x_9_3     disj2_1_9_1  -1.0
    x_9_3     disj1_2_9_1  1.0
    x_9_3     disj2_2_9_1  -1.0
    x_9_3     disj1_3_9_1  1.0
    x_9_3     disj2_3_9_1  -1.0
    x_9_3     disj1_4_9_1  1.0
    x_9_3     disj2_4_9_1  -1.0
    x_9_3     disj1_5_9_1  1.0
    x_9_3     disj2_5_9_1  -1.0
    x_9_3     disj1_6_9_1  1.0
    x_9_3     disj2_6_9_1  -1.0
    x_9_3     disj1_7_9_1  1.0
    x_9_3     disj2_7_9_1  -1.0
    x_9_3     disj1_8_9_1  1.0
    x_9_3     disj2_8_9_1  -1.0
    x_9_4     prec_9_3  1.0
    x_9_4     mksp_9    -1.0
    x_9_4     disj1_0_9_0  1.0
    x_9_4     disj2_0_9_0  -1.0
    x_9_4     disj1_1_9_0  1.0
    x_9_4     disj2_1_9_0  -1.0
    x_9_4     disj1_2_9_0  1.0
    x_9_4     disj2_2_9_0  -1.0
    x_9_4     disj1_3_9_0  1.0
    x_9_4     disj2_3_9_0  -1.0
    x_9_4     disj1_4_9_0  1.0
    x_9_4     disj2_4_9_0  -1.0
    x_9_4     disj1_5_9_0  1.0
    x_9_4     disj2_5_9_0  -1.0
    x_9_4     disj1_6_9_0  1.0
    x_9_4     disj2_6_9_0  -1.0
    x_9_4     disj1_7_9_0  1.0
    x_9_4     disj2_7_9_0  -1.0
    x_9_4     disj1_8_9_0  1.0
    x_9_4     disj2_8_9_0  -1.0
    MARK0002  'MARKER'                 'INTORG'
    y_0_1_0   disj1_0_1_0  2849
    y_0_1_0   disj2_0_1_0  -2849
    y_0_1_1   disj1_0_1_1  2849
    y_0_1_1   disj2_0_1_1  -2849
    y_0_1_2   disj1_0_1_2  2849
    y_0_1_2   disj2_0_1_2  -2849
    y_0_1_3   disj1_0_1_3  2849
    y_0_1_3   disj2_0_1_3  -2849
    y_0_1_4   disj1_0_1_4  2849
    y_0_1_4   disj2_0_1_4  -2849
    y_0_2_0   disj1_0_2_0  2849
    y_0_2_0   disj2_0_2_0  -2849
    y_0_2_1   disj1_0_2_1  2849
    y_0_2_1   disj2_0_2_1  -2849
    y_0_2_2   disj1_0_2_2  2849
    y_0_2_2   disj2_0_2_2  -2849
    y_0_2_3   disj1_0_2_3  2849
    y_0_2_3   disj2_0_2_3  -2849
    y_0_2_4   disj1_0_2_4  2849
    y_0_2_4   disj2_0_2_4  -2849
    y_0_3_0   disj1_0_3_0  2849
    y_0_3_0   disj2_0_3_0  -2849
    y_0_3_1   disj1_0_3_1  2849
    y_0_3_1   disj2_0_3_1  -2849
    y_0_3_2   disj1_0_3_2  2849
    y_0_3_2   disj2_0_3_2  -2849
    y_0_3_3   disj1_0_3_3  2849
    y_0_3_3   disj2_0_3_3  -2849
    y_0_3_4   disj1_0_3_4  2849
    y_0_3_4   disj2_0_3_4  -2849
    y_0_4_0   disj1_0_4_0  2849
    y_0_4_0   disj2_0_4_0  -2849
    y_0_4_1   disj1_0_4_1  2849
    y_0_4_1   disj2_0_4_1  -2849
    y_0_4_2   disj1_0_4_2  2849
    y_0_4_2   disj2_0_4_2  -2849
    y_0_4_3   disj1_0_4_3  2849
    y_0_4_3   disj2_0_4_3  -2849
    y_0_4_4   disj1_0_4_4  2849
    y_0_4_4   disj2_0_4_4  -2849
    y_0_5_0   disj1_0_5_0  2849
    y_0_5_0   disj2_0_5_0  -2849
    y_0_5_1   disj1_0_5_1  2849
    y_0_5_1   disj2_0_5_1  -2849
    y_0_5_2   disj1_0_5_2  2849
    y_0_5_2   disj2_0_5_2  -2849
    y_0_5_3   disj1_0_5_3  2849
    y_0_5_3   disj2_0_5_3  -2849
    y_0_5_4   disj1_0_5_4  2849
    y_0_5_4   disj2_0_5_4  -2849
    y_0_6_0   disj1_0_6_0  2849
    y_0_6_0   disj2_0_6_0  -2849
    y_0_6_1   disj1_0_6_1  2849
    y_0_6_1   disj2_0_6_1  -2849
    y_0_6_2   disj1_0_6_2  2849
    y_0_6_2   disj2_0_6_2  -2849
    y_0_6_3   disj1_0_6_3  2849
    y_0_6_3   disj2_0_6_3  -2849
    y_0_6_4   disj1_0_6_4  2849
    y_0_6_4   disj2_0_6_4  -2849
    y_0_7_0   disj1_0_7_0  2849
    y_0_7_0   disj2_0_7_0  -2849
    y_0_7_1   disj1_0_7_1  2849
    y_0_7_1   disj2_0_7_1  -2849
    y_0_7_2   disj1_0_7_2  2849
    y_0_7_2   disj2_0_7_2  -2849
    y_0_7_3   disj1_0_7_3  2849
    y_0_7_3   disj2_0_7_3  -2849
    y_0_7_4   disj1_0_7_4  2849
    y_0_7_4   disj2_0_7_4  -2849
    y_0_8_0   disj1_0_8_0  2849
    y_0_8_0   disj2_0_8_0  -2849
    y_0_8_1   disj1_0_8_1  2849
    y_0_8_1   disj2_0_8_1  -2849
    y_0_8_2   disj1_0_8_2  2849
    y_0_8_2   disj2_0_8_2  -2849
    y_0_8_3   disj1_0_8_3  2849
    y_0_8_3   disj2_0_8_3  -2849
    y_0_8_4   disj1_0_8_4  2849
    y_0_8_4   disj2_0_8_4  -2849
    y_0_9_0   disj1_0_9_0  2849
    y_0_9_0   disj2_0_9_0  -2849
    y_0_9_1   disj1_0_9_1  2849
    y_0_9_1   disj2_0_9_1  -2849
    y_0_9_2   disj1_0_9_2  2849
    y_0_9_2   disj2_0_9_2  -2849
    y_0_9_3   disj1_0_9_3  2849
    y_0_9_3   disj2_0_9_3  -2849
    y_0_9_4   disj1_0_9_4  2849
    y_0_9_4   disj2_0_9_4  -2849
    y_1_2_0   disj1_1_2_0  2849
    y_1_2_0   disj2_1_2_0  -2849
    y_1_2_1   disj1_1_2_1  2849
    y_1_2_1   disj2_1_2_1  -2849
    y_1_2_2   disj1_1_2_2  2849
    y_1_2_2   disj2_1_2_2  -2849
    y_1_2_3   disj1_1_2_3  2849
    y_1_2_3   disj2_1_2_3  -2849
    y_1_2_4   disj1_1_2_4  2849
    y_1_2_4   disj2_1_2_4  -2849
    y_1_3_0   disj1_1_3_0  2849
    y_1_3_0   disj2_1_3_0  -2849
    y_1_3_1   disj1_1_3_1  2849
    y_1_3_1   disj2_1_3_1  -2849
    y_1_3_2   disj1_1_3_2  2849
    y_1_3_2   disj2_1_3_2  -2849
    y_1_3_3   disj1_1_3_3  2849
    y_1_3_3   disj2_1_3_3  -2849
    y_1_3_4   disj1_1_3_4  2849
    y_1_3_4   disj2_1_3_4  -2849
    y_1_4_0   disj1_1_4_0  2849
    y_1_4_0   disj2_1_4_0  -2849
    y_1_4_1   disj1_1_4_1  2849
    y_1_4_1   disj2_1_4_1  -2849
    y_1_4_2   disj1_1_4_2  2849
    y_1_4_2   disj2_1_4_2  -2849
    y_1_4_3   disj1_1_4_3  2849
    y_1_4_3   disj2_1_4_3  -2849
    y_1_4_4   disj1_1_4_4  2849
    y_1_4_4   disj2_1_4_4  -2849
    y_1_5_0   disj1_1_5_0  2849
    y_1_5_0   disj2_1_5_0  -2849
    y_1_5_1   disj1_1_5_1  2849
    y_1_5_1   disj2_1_5_1  -2849
    y_1_5_2   disj1_1_5_2  2849
    y_1_5_2   disj2_1_5_2  -2849
    y_1_5_3   disj1_1_5_3  2849
    y_1_5_3   disj2_1_5_3  -2849
    y_1_5_4   disj1_1_5_4  2849
    y_1_5_4   disj2_1_5_4  -2849
    y_1_6_0   disj1_1_6_0  2849
    y_1_6_0   disj2_1_6_0  -2849
    y_1_6_1   disj1_1_6_1  2849
    y_1_6_1   disj2_1_6_1  -2849
    y_1_6_2   disj1_1_6_2  2849
    y_1_6_2   disj2_1_6_2  -2849
    y_1_6_3   disj1_1_6_3  2849
    y_1_6_3   disj2_1_6_3  -2849
    y_1_6_4   disj1_1_6_4  2849
    y_1_6_4   disj2_1_6_4  -2849
    y_1_7_0   disj1_1_7_0  2849
    y_1_7_0   disj2_1_7_0  -2849
    y_1_7_1   disj1_1_7_1  2849
    y_1_7_1   disj2_1_7_1  -2849
    y_1_7_2   disj1_1_7_2  2849
    y_1_7_2   disj2_1_7_2  -2849
    y_1_7_3   disj1_1_7_3  2849
    y_1_7_3   disj2_1_7_3  -2849
    y_1_7_4   disj1_1_7_4  2849
    y_1_7_4   disj2_1_7_4  -2849
    y_1_8_0   disj1_1_8_0  2849
    y_1_8_0   disj2_1_8_0  -2849
    y_1_8_1   disj1_1_8_1  2849
    y_1_8_1   disj2_1_8_1  -2849
    y_1_8_2   disj1_1_8_2  2849
    y_1_8_2   disj2_1_8_2  -2849
    y_1_8_3   disj1_1_8_3  2849
    y_1_8_3   disj2_1_8_3  -2849
    y_1_8_4   disj1_1_8_4  2849
    y_1_8_4   disj2_1_8_4  -2849
    y_1_9_0   disj1_1_9_0  2849
    y_1_9_0   disj2_1_9_0  -2849
    y_1_9_1   disj1_1_9_1  2849
    y_1_9_1   disj2_1_9_1  -2849
    y_1_9_2   disj1_1_9_2  2849
    y_1_9_2   disj2_1_9_2  -2849
    y_1_9_3   disj1_1_9_3  2849
    y_1_9_3   disj2_1_9_3  -2849
    y_1_9_4   disj1_1_9_4  2849
    y_1_9_4   disj2_1_9_4  -2849
    y_2_3_0   disj1_2_3_0  2849
    y_2_3_0   disj2_2_3_0  -2849
    y_2_3_1   disj1_2_3_1  2849
    y_2_3_1   disj2_2_3_1  -2849
    y_2_3_2   disj1_2_3_2  2849
    y_2_3_2   disj2_2_3_2  -2849
    y_2_3_3   disj1_2_3_3  2849
    y_2_3_3   disj2_2_3_3  -2849
    y_2_3_4   disj1_2_3_4  2849
    y_2_3_4   disj2_2_3_4  -2849
    y_2_4_0   disj1_2_4_0  2849
    y_2_4_0   disj2_2_4_0  -2849
    y_2_4_1   disj1_2_4_1  2849
    y_2_4_1   disj2_2_4_1  -2849
    y_2_4_2   disj1_2_4_2  2849
    y_2_4_2   disj2_2_4_2  -2849
    y_2_4_3   disj1_2_4_3  2849
    y_2_4_3   disj2_2_4_3  -2849
    y_2_4_4   disj1_2_4_4  2849
    y_2_4_4   disj2_2_4_4  -2849
    y_2_5_0   disj1_2_5_0  2849
    y_2_5_0   disj2_2_5_0  -2849
    y_2_5_1   disj1_2_5_1  2849
    y_2_5_1   disj2_2_5_1  -2849
    y_2_5_2   disj1_2_5_2  2849
    y_2_5_2   disj2_2_5_2  -2849
    y_2_5_3   disj1_2_5_3  2849
    y_2_5_3   disj2_2_5_3  -2849
    y_2_5_4   disj1_2_5_4  2849
    y_2_5_4   disj2_2_5_4  -2849
    y_2_6_0   disj1_2_6_0  2849
    y_2_6_0   disj2_2_6_0  -2849
    y_2_6_1   disj1_2_6_1  2849
    y_2_6_1   disj2_2_6_1  -2849
    y_2_6_2   disj1_2_6_2  2849
    y_2_6_2   disj2_2_6_2  -2849
    y_2_6_3   disj1_2_6_3  2849
    y_2_6_3   disj2_2_6_3  -2849
    y_2_6_4   disj1_2_6_4  2849
    y_2_6_4   disj2_2_6_4  -2849
    y_2_7_0   disj1_2_7_0  2849
    y_2_7_0   disj2_2_7_0  -2849
    y_2_7_1   disj1_2_7_1  2849
    y_2_7_1   disj2_2_7_1  -2849
    y_2_7_2   disj1_2_7_2  2849
    y_2_7_2   disj2_2_7_2  -2849
    y_2_7_3   disj1_2_7_3  2849
    y_2_7_3   disj2_2_7_3  -2849
    y_2_7_4   disj1_2_7_4  2849
    y_2_7_4   disj2_2_7_4  -2849
    y_2_8_0   disj1_2_8_0  2849
    y_2_8_0   disj2_2_8_0  -2849
    y_2_8_1   disj1_2_8_1  2849
    y_2_8_1   disj2_2_8_1  -2849
    y_2_8_2   disj1_2_8_2  2849
    y_2_8_2   disj2_2_8_2  -2849
    y_2_8_3   disj1_2_8_3  2849
    y_2_8_3   disj2_2_8_3  -2849
    y_2_8_4   disj1_2_8_4  2849
    y_2_8_4   disj2_2_8_4  -2849
    y_2_9_0   disj1_2_9_0  2849
    y_2_9_0   disj2_2_9_0  -2849
    y_2_9_1   disj1_2_9_1  2849
    y_2_9_1   disj2_2_9_1  -2849
    y_2_9_2   disj1_2_9_2  2849
    y_2_9_2   disj2_2_9_2  -2849
    y_2_9_3   disj1_2_9_3  2849
    y_2_9_3   disj2_2_9_3  -2849
    y_2_9_4   disj1_2_9_4  2849
    y_2_9_4   disj2_2_9_4  -2849
    y_3_4_0   disj1_3_4_0  2849
    y_3_4_0   disj2_3_4_0  -2849
    y_3_4_1   disj1_3_4_1  2849
    y_3_4_1   disj2_3_4_1  -2849
    y_3_4_2   disj1_3_4_2  2849
    y_3_4_2   disj2_3_4_2  -2849
    y_3_4_3   disj1_3_4_3  2849
    y_3_4_3   disj2_3_4_3  -2849
    y_3_4_4   disj1_3_4_4  2849
    y_3_4_4   disj2_3_4_4  -2849
    y_3_5_0   disj1_3_5_0  2849
    y_3_5_0   disj2_3_5_0  -2849
    y_3_5_1   disj1_3_5_1  2849
    y_3_5_1   disj2_3_5_1  -2849
    y_3_5_2   disj1_3_5_2  2849
    y_3_5_2   disj2_3_5_2  -2849
    y_3_5_3   disj1_3_5_3  2849
    y_3_5_3   disj2_3_5_3  -2849
    y_3_5_4   disj1_3_5_4  2849
    y_3_5_4   disj2_3_5_4  -2849
    y_3_6_0   disj1_3_6_0  2849
    y_3_6_0   disj2_3_6_0  -2849
    y_3_6_1   disj1_3_6_1  2849
    y_3_6_1   disj2_3_6_1  -2849
    y_3_6_2   disj1_3_6_2  2849
    y_3_6_2   disj2_3_6_2  -2849
    y_3_6_3   disj1_3_6_3  2849
    y_3_6_3   disj2_3_6_3  -2849
    y_3_6_4   disj1_3_6_4  2849
    y_3_6_4   disj2_3_6_4  -2849
    y_3_7_0   disj1_3_7_0  2849
    y_3_7_0   disj2_3_7_0  -2849
    y_3_7_1   disj1_3_7_1  2849
    y_3_7_1   disj2_3_7_1  -2849
    y_3_7_2   disj1_3_7_2  2849
    y_3_7_2   disj2_3_7_2  -2849
    y_3_7_3   disj1_3_7_3  2849
    y_3_7_3   disj2_3_7_3  -2849
    y_3_7_4   disj1_3_7_4  2849
    y_3_7_4   disj2_3_7_4  -2849
    y_3_8_0   disj1_3_8_0  2849
    y_3_8_0   disj2_3_8_0  -2849
    y_3_8_1   disj1_3_8_1  2849
    y_3_8_1   disj2_3_8_1  -2849
    y_3_8_2   disj1_3_8_2  2849
    y_3_8_2   disj2_3_8_2  -2849
    y_3_8_3   disj1_3_8_3  2849
    y_3_8_3   disj2_3_8_3  -2849
    y_3_8_4   disj1_3_8_4  2849
    y_3_8_4   disj2_3_8_4  -2849
    y_3_9_0   disj1_3_9_0  2849
    y_3_9_0   disj2_3_9_0  -2849
    y_3_9_1   disj1_3_9_1  2849
    y_3_9_1   disj2_3_9_1  -2849
    y_3_9_2   disj1_3_9_2  2849
    y_3_9_2   disj2_3_9_2  -2849
    y_3_9_3   disj1_3_9_3  2849
    y_3_9_3   disj2_3_9_3  -2849
    y_3_9_4   disj1_3_9_4  2849
    y_3_9_4   disj2_3_9_4  -2849
    y_4_5_0   disj1_4_5_0  2849
    y_4_5_0   disj2_4_5_0  -2849
    y_4_5_1   disj1_4_5_1  2849
    y_4_5_1   disj2_4_5_1  -2849
    y_4_5_2   disj1_4_5_2  2849
    y_4_5_2   disj2_4_5_2  -2849
    y_4_5_3   disj1_4_5_3  2849
    y_4_5_3   disj2_4_5_3  -2849
    y_4_5_4   disj1_4_5_4  2849
    y_4_5_4   disj2_4_5_4  -2849
    y_4_6_0   disj1_4_6_0  2849
    y_4_6_0   disj2_4_6_0  -2849
    y_4_6_1   disj1_4_6_1  2849
    y_4_6_1   disj2_4_6_1  -2849
    y_4_6_2   disj1_4_6_2  2849
    y_4_6_2   disj2_4_6_2  -2849
    y_4_6_3   disj1_4_6_3  2849
    y_4_6_3   disj2_4_6_3  -2849
    y_4_6_4   disj1_4_6_4  2849
    y_4_6_4   disj2_4_6_4  -2849
    y_4_7_0   disj1_4_7_0  2849
    y_4_7_0   disj2_4_7_0  -2849
    y_4_7_1   disj1_4_7_1  2849
    y_4_7_1   disj2_4_7_1  -2849
    y_4_7_2   disj1_4_7_2  2849
    y_4_7_2   disj2_4_7_2  -2849
    y_4_7_3   disj1_4_7_3  2849
    y_4_7_3   disj2_4_7_3  -2849
    y_4_7_4   disj1_4_7_4  2849
    y_4_7_4   disj2_4_7_4  -2849
    y_4_8_0   disj1_4_8_0  2849
    y_4_8_0   disj2_4_8_0  -2849
    y_4_8_1   disj1_4_8_1  2849
    y_4_8_1   disj2_4_8_1  -2849
    y_4_8_2   disj1_4_8_2  2849
    y_4_8_2   disj2_4_8_2  -2849
    y_4_8_3   disj1_4_8_3  2849
    y_4_8_3   disj2_4_8_3  -2849
    y_4_8_4   disj1_4_8_4  2849
    y_4_8_4   disj2_4_8_4  -2849
    y_4_9_0   disj1_4_9_0  2849
    y_4_9_0   disj2_4_9_0  -2849
    y_4_9_1   disj1_4_9_1  2849
    y_4_9_1   disj2_4_9_1  -2849
    y_4_9_2   disj1_4_9_2  2849
    y_4_9_2   disj2_4_9_2  -2849
    y_4_9_3   disj1_4_9_3  2849
    y_4_9_3   disj2_4_9_3  -2849
    y_4_9_4   disj1_4_9_4  2849
    y_4_9_4   disj2_4_9_4  -2849
    y_5_6_0   disj1_5_6_0  2849
    y_5_6_0   disj2_5_6_0  -2849
    y_5_6_1   disj1_5_6_1  2849
    y_5_6_1   disj2_5_6_1  -2849
    y_5_6_2   disj1_5_6_2  2849
    y_5_6_2   disj2_5_6_2  -2849
    y_5_6_3   disj1_5_6_3  2849
    y_5_6_3   disj2_5_6_3  -2849
    y_5_6_4   disj1_5_6_4  2849
    y_5_6_4   disj2_5_6_4  -2849
    y_5_7_0   disj1_5_7_0  2849
    y_5_7_0   disj2_5_7_0  -2849
    y_5_7_1   disj1_5_7_1  2849
    y_5_7_1   disj2_5_7_1  -2849
    y_5_7_2   disj1_5_7_2  2849
    y_5_7_2   disj2_5_7_2  -2849
    y_5_7_3   disj1_5_7_3  2849
    y_5_7_3   disj2_5_7_3  -2849
    y_5_7_4   disj1_5_7_4  2849
    y_5_7_4   disj2_5_7_4  -2849
    y_5_8_0   disj1_5_8_0  2849
    y_5_8_0   disj2_5_8_0  -2849
    y_5_8_1   disj1_5_8_1  2849
    y_5_8_1   disj2_5_8_1  -2849
    y_5_8_2   disj1_5_8_2  2849
    y_5_8_2   disj2_5_8_2  -2849
    y_5_8_3   disj1_5_8_3  2849
    y_5_8_3   disj2_5_8_3  -2849
    y_5_8_4   disj1_5_8_4  2849
    y_5_8_4   disj2_5_8_4  -2849
    y_5_9_0   disj1_5_9_0  2849
    y_5_9_0   disj2_5_9_0  -2849
    y_5_9_1   disj1_5_9_1  2849
    y_5_9_1   disj2_5_9_1  -2849
    y_5_9_2   disj1_5_9_2  2849
    y_5_9_2   disj2_5_9_2  -2849
    y_5_9_3   disj1_5_9_3  2849
    y_5_9_3   disj2_5_9_3  -2849
    y_5_9_4   disj1_5_9_4  2849
    y_5_9_4   disj2_5_9_4  -2849
    y_6_7_0   disj1_6_7_0  2849
    y_6_7_0   disj2_6_7_0  -2849
    y_6_7_1   disj1_6_7_1  2849
    y_6_7_1   disj2_6_7_1  -2849
    y_6_7_2   disj1_6_7_2  2849
    y_6_7_2   disj2_6_7_2  -2849
    y_6_7_3   disj1_6_7_3  2849
    y_6_7_3   disj2_6_7_3  -2849
    y_6_7_4   disj1_6_7_4  2849
    y_6_7_4   disj2_6_7_4  -2849
    y_6_8_0   disj1_6_8_0  2849
    y_6_8_0   disj2_6_8_0  -2849
    y_6_8_1   disj1_6_8_1  2849
    y_6_8_1   disj2_6_8_1  -2849
    y_6_8_2   disj1_6_8_2  2849
    y_6_8_2   disj2_6_8_2  -2849
    y_6_8_3   disj1_6_8_3  2849
    y_6_8_3   disj2_6_8_3  -2849
    y_6_8_4   disj1_6_8_4  2849
    y_6_8_4   disj2_6_8_4  -2849
    y_6_9_0   disj1_6_9_0  2849
    y_6_9_0   disj2_6_9_0  -2849
    y_6_9_1   disj1_6_9_1  2849
    y_6_9_1   disj2_6_9_1  -2849
    y_6_9_2   disj1_6_9_2  2849
    y_6_9_2   disj2_6_9_2  -2849
    y_6_9_3   disj1_6_9_3  2849
    y_6_9_3   disj2_6_9_3  -2849
    y_6_9_4   disj1_6_9_4  2849
    y_6_9_4   disj2_6_9_4  -2849
    y_7_8_0   disj1_7_8_0  2849
    y_7_8_0   disj2_7_8_0  -2849
    y_7_8_1   disj1_7_8_1  2849
    y_7_8_1   disj2_7_8_1  -2849
    y_7_8_2   disj1_7_8_2  2849
    y_7_8_2   disj2_7_8_2  -2849
    y_7_8_3   disj1_7_8_3  2849
    y_7_8_3   disj2_7_8_3  -2849
    y_7_8_4   disj1_7_8_4  2849
    y_7_8_4   disj2_7_8_4  -2849
    y_7_9_0   disj1_7_9_0  2849
    y_7_9_0   disj2_7_9_0  -2849
    y_7_9_1   disj1_7_9_1  2849
    y_7_9_1   disj2_7_9_1  -2849
    y_7_9_2   disj1_7_9_2  2849
    y_7_9_2   disj2_7_9_2  -2849
    y_7_9_3   disj1_7_9_3  2849
    y_7_9_3   disj2_7_9_3  -2849
    y_7_9_4   disj1_7_9_4  2849
    y_7_9_4   disj2_7_9_4  -2849
    y_8_9_0   disj1_8_9_0  2849
    y_8_9_0   disj2_8_9_0  -2849
    y_8_9_1   disj1_8_9_1  2849
    y_8_9_1   disj2_8_9_1  -2849
    y_8_9_2   disj1_8_9_2  2849
    y_8_9_2   disj2_8_9_2  -2849
    y_8_9_3   disj1_8_9_3  2849
    y_8_9_3   disj2_8_9_3  -2849
    y_8_9_4   disj1_8_9_4  2849
    y_8_9_4   disj2_8_9_4  -2849
    MARK9999  'MARKER'                 'INTEND'
RHS
    RHS       prec_0_0  21
    RHS       prec_0_1  53
    RHS       prec_0_2  95
    RHS       prec_0_3  55
    RHS       prec_1_0  21
    RHS       prec_1_1  52
    RHS       prec_1_2  16
    RHS       prec_1_3  26
    RHS       prec_2_0  39
    RHS       prec_2_1  98
    RHS       prec_2_2  42
    RHS       prec_2_3  31
    RHS       prec_3_0  77
    RHS       prec_3_1  55
    RHS       prec_3_2  79
    RHS       prec_3_3  66
    RHS       prec_4_0  83
    RHS       prec_4_1  34
    RHS       prec_4_2  64
    RHS       prec_4_3  19
    RHS       prec_5_0  54
    RHS       prec_5_1  43
    RHS       prec_5_2  79
    RHS       prec_5_3  92
    RHS       prec_6_0  69
    RHS       prec_6_1  77
    RHS       prec_6_2  87
    RHS       prec_6_3  87
    RHS       prec_7_0  38
    RHS       prec_7_1  60
    RHS       prec_7_2  41
    RHS       prec_7_3  24
    RHS       prec_8_0  17
    RHS       prec_8_1  49
    RHS       prec_8_2  25
    RHS       prec_8_3  44
    RHS       prec_9_0  77
    RHS       prec_9_1  79
    RHS       prec_9_2  43
    RHS       prec_9_3  75
    RHS       mksp_0    34
    RHS       mksp_1    71
    RHS       mksp_2    12
    RHS       mksp_3    77
    RHS       mksp_4    37
    RHS       mksp_5    62
    RHS       mksp_6    93
    RHS       mksp_7    83
    RHS       mksp_8    98
    RHS       mksp_9    96
    RHS       disj1_0_1_0  21
    RHS       disj2_0_1_0  -2797
    RHS       disj1_0_2_0  21
    RHS       disj2_0_2_0  -2837
    RHS       disj1_0_3_0  21
    RHS       disj2_0_3_0  -2794
    RHS       disj1_0_4_0  21
    RHS       disj2_0_4_0  -2766
    RHS       disj1_0_5_0  21
    RHS       disj2_0_5_0  -2757
    RHS       disj1_0_6_0  21
    RHS       disj2_0_6_0  -2756
    RHS       disj1_0_7_0  21
    RHS       disj2_0_7_0  -2789
    RHS       disj1_0_8_0  21
    RHS       disj2_0_8_0  -2805
    RHS       disj1_0_9_0  21
    RHS       disj2_0_9_0  -2753
    RHS       disj1_1_2_0  52
    RHS       disj2_1_2_0  -2837
    RHS       disj1_1_3_0  52
    RHS       disj2_1_3_0  -2794
    RHS       disj1_1_4_0  52
    RHS       disj2_1_4_0  -2766
    RHS       disj1_1_5_0  52
    RHS       disj2_1_5_0  -2757
    RHS       disj1_1_6_0  52
    RHS       disj2_1_6_0  -2756
    RHS       disj1_1_7_0  52
    RHS       disj2_1_7_0  -2789
    RHS       disj1_1_8_0  52
    RHS       disj2_1_8_0  -2805
    RHS       disj1_1_9_0  52
    RHS       disj2_1_9_0  -2753
    RHS       disj1_2_3_0  12
    RHS       disj2_2_3_0  -2794
    RHS       disj1_2_4_0  12
    RHS       disj2_2_4_0  -2766
    RHS       disj1_2_5_0  12
    RHS       disj2_2_5_0  -2757
    RHS       disj1_2_6_0  12
    RHS       disj2_2_6_0  -2756
    RHS       disj1_2_7_0  12
    RHS       disj2_2_7_0  -2789
    RHS       disj1_2_8_0  12
    RHS       disj2_2_8_0  -2805
    RHS       disj1_2_9_0  12
    RHS       disj2_2_9_0  -2753
    RHS       disj1_3_4_0  55
    RHS       disj2_3_4_0  -2766
    RHS       disj1_3_5_0  55
    RHS       disj2_3_5_0  -2757
    RHS       disj1_3_6_0  55
    RHS       disj2_3_6_0  -2756
    RHS       disj1_3_7_0  55
    RHS       disj2_3_7_0  -2789
    RHS       disj1_3_8_0  55
    RHS       disj2_3_8_0  -2805
    RHS       disj1_3_9_0  55
    RHS       disj2_3_9_0  -2753
    RHS       disj1_4_5_0  83
    RHS       disj2_4_5_0  -2757
    RHS       disj1_4_6_0  83
    RHS       disj2_4_6_0  -2756
    RHS       disj1_4_7_0  83
    RHS       disj2_4_7_0  -2789
    RHS       disj1_4_8_0  83
    RHS       disj2_4_8_0  -2805
    RHS       disj1_4_9_0  83
    RHS       disj2_4_9_0  -2753
    RHS       disj1_5_6_0  92
    RHS       disj2_5_6_0  -2756
    RHS       disj1_5_7_0  92
    RHS       disj2_5_7_0  -2789
    RHS       disj1_5_8_0  92
    RHS       disj2_5_8_0  -2805
    RHS       disj1_5_9_0  92
    RHS       disj2_5_9_0  -2753
    RHS       disj1_6_7_0  93
    RHS       disj2_6_7_0  -2789
    RHS       disj1_6_8_0  93
    RHS       disj2_6_8_0  -2805
    RHS       disj1_6_9_0  93
    RHS       disj2_6_9_0  -2753
    RHS       disj1_7_8_0  60
    RHS       disj2_7_8_0  -2805
    RHS       disj1_7_9_0  60
    RHS       disj2_7_9_0  -2753
    RHS       disj1_8_9_0  44
    RHS       disj2_8_9_0  -2753
    RHS       disj1_0_1_1  53
    RHS       disj2_0_1_1  -2828
    RHS       disj1_0_2_1  53
    RHS       disj2_0_2_1  -2807
    RHS       disj1_0_3_1  53
    RHS       disj2_0_3_1  -2772
    RHS       disj1_0_4_1  53
    RHS       disj2_0_4_1  -2830
    RHS       disj1_0_5_1  53
    RHS       disj2_0_5_1  -2795
    RHS       disj1_0_6_1  53
    RHS       disj2_0_6_1  -2780
    RHS       disj1_0_7_1  53
    RHS       disj2_0_7_1  -2808
    RHS       disj1_0_8_1  53
    RHS       disj2_0_8_1  -2800
    RHS       disj1_0_9_1  53
    RHS       disj2_0_9_1  -2774
    RHS       disj1_1_2_1  21
    RHS       disj2_1_2_1  -2807
    RHS       disj1_1_3_1  21
    RHS       disj2_1_3_1  -2772
    RHS       disj1_1_4_1  21
    RHS       disj2_1_4_1  -2830
    RHS       disj1_1_5_1  21
    RHS       disj2_1_5_1  -2795
    RHS       disj1_1_6_1  21
    RHS       disj2_1_6_1  -2780
    RHS       disj1_1_7_1  21
    RHS       disj2_1_7_1  -2808
    RHS       disj1_1_8_1  21
    RHS       disj2_1_8_1  -2800
    RHS       disj1_1_9_1  21
    RHS       disj2_1_9_1  -2774
    RHS       disj1_2_3_1  42
    RHS       disj2_2_3_1  -2772
    RHS       disj1_2_4_1  42
    RHS       disj2_2_4_1  -2830
    RHS       disj1_2_5_1  42
    RHS       disj2_2_5_1  -2795
    RHS       disj1_2_6_1  42
    RHS       disj2_2_6_1  -2780
    RHS       disj1_2_7_1  42
    RHS       disj2_2_7_1  -2808
    RHS       disj1_2_8_1  42
    RHS       disj2_2_8_1  -2800
    RHS       disj1_2_9_1  42
    RHS       disj2_2_9_1  -2774
    RHS       disj1_3_4_1  77
    RHS       disj2_3_4_1  -2830
    RHS       disj1_3_5_1  77
    RHS       disj2_3_5_1  -2795
    RHS       disj1_3_6_1  77
    RHS       disj2_3_6_1  -2780
    RHS       disj1_3_7_1  77
    RHS       disj2_3_7_1  -2808
    RHS       disj1_3_8_1  77
    RHS       disj2_3_8_1  -2800
    RHS       disj1_3_9_1  77
    RHS       disj2_3_9_1  -2774
    RHS       disj1_4_5_1  19
    RHS       disj2_4_5_1  -2795
    RHS       disj1_4_6_1  19
    RHS       disj2_4_6_1  -2780
    RHS       disj1_4_7_1  19
    RHS       disj2_4_7_1  -2808
    RHS       disj1_4_8_1  19
    RHS       disj2_4_8_1  -2800
    RHS       disj1_4_9_1  19
    RHS       disj2_4_9_1  -2774
    RHS       disj1_5_6_1  54
    RHS       disj2_5_6_1  -2780
    RHS       disj1_5_7_1  54
    RHS       disj2_5_7_1  -2808
    RHS       disj1_5_8_1  54
    RHS       disj2_5_8_1  -2800
    RHS       disj1_5_9_1  54
    RHS       disj2_5_9_1  -2774
    RHS       disj1_6_7_1  69
    RHS       disj2_6_7_1  -2808
    RHS       disj1_6_8_1  69
    RHS       disj2_6_8_1  -2800
    RHS       disj1_6_9_1  69
    RHS       disj2_6_9_1  -2774
    RHS       disj1_7_8_1  41
    RHS       disj2_7_8_1  -2800
    RHS       disj1_7_9_1  41
    RHS       disj2_7_9_1  -2774
    RHS       disj1_8_9_1  49
    RHS       disj2_8_9_1  -2774
    RHS       disj1_0_1_2  95
    RHS       disj2_0_1_2  -2823
    RHS       disj1_0_2_2  95
    RHS       disj2_0_2_2  -2810
    RHS       disj1_0_3_2  95
    RHS       disj2_0_3_2  -2783
    RHS       disj1_0_4_2  95
    RHS       disj2_0_4_2  -2785
    RHS       disj1_0_5_2  95
    RHS       disj2_0_5_2  -2806
    RHS       disj1_0_6_2  95
    RHS       disj2_0_6_2  -2762
    RHS       disj1_0_7_2  95
    RHS       disj2_0_7_2  -2811
    RHS       disj1_0_8_2  95
    RHS       disj2_0_8_2  -2751
    RHS       disj1_0_9_2  95
    RHS       disj2_0_9_2  -2806
    RHS       disj1_1_2_2  26
    RHS       disj2_1_2_2  -2810
    RHS       disj1_1_3_2  26
    RHS       disj2_1_3_2  -2783
    RHS       disj1_1_4_2  26
    RHS       disj2_1_4_2  -2785
    RHS       disj1_1_5_2  26
    RHS       disj2_1_5_2  -2806
    RHS       disj1_1_6_2  26
    RHS       disj2_1_6_2  -2762
    RHS       disj1_1_7_2  26
    RHS       disj2_1_7_2  -2811
    RHS       disj1_1_8_2  26
    RHS       disj2_1_8_2  -2751
    RHS       disj1_1_9_2  26
    RHS       disj2_1_9_2  -2806
    RHS       disj1_2_3_2  39
    RHS       disj2_2_3_2  -2783
    RHS       disj1_2_4_2  39
    RHS       disj2_2_4_2  -2785
    RHS       disj1_2_5_2  39
    RHS       disj2_2_5_2  -2806
    RHS       disj1_2_6_2  39
    RHS       disj2_2_6_2  -2762
    RHS       disj1_2_7_2  39
    RHS       disj2_2_7_2  -2811
    RHS       disj1_2_8_2  39
    RHS       disj2_2_8_2  -2751
    RHS       disj1_2_9_2  39
    RHS       disj2_2_9_2  -2806
    RHS       disj1_3_4_2  66
    RHS       disj2_3_4_2  -2785
    RHS       disj1_3_5_2  66
    RHS       disj2_3_5_2  -2806
    RHS       disj1_3_6_2  66
    RHS       disj2_3_6_2  -2762
    RHS       disj1_3_7_2  66
    RHS       disj2_3_7_2  -2811
    RHS       disj1_3_8_2  66
    RHS       disj2_3_8_2  -2751
    RHS       disj1_3_9_2  66
    RHS       disj2_3_9_2  -2806
    RHS       disj1_4_5_2  64
    RHS       disj2_4_5_2  -2806
    RHS       disj1_4_6_2  64
    RHS       disj2_4_6_2  -2762
    RHS       disj1_4_7_2  64
    RHS       disj2_4_7_2  -2811
    RHS       disj1_4_8_2  64
    RHS       disj2_4_8_2  -2751
    RHS       disj1_4_9_2  64
    RHS       disj2_4_9_2  -2806
    RHS       disj1_5_6_2  43
    RHS       disj2_5_6_2  -2762
    RHS       disj1_5_7_2  43
    RHS       disj2_5_7_2  -2811
    RHS       disj1_5_8_2  43
    RHS       disj2_5_8_2  -2751
    RHS       disj1_5_9_2  43
    RHS       disj2_5_9_2  -2806
    RHS       disj1_6_7_2  87
    RHS       disj2_6_7_2  -2811
    RHS       disj1_6_8_2  87
    RHS       disj2_6_8_2  -2751
    RHS       disj1_6_9_2  87
    RHS       disj2_6_9_2  -2806
    RHS       disj1_7_8_2  38
    RHS       disj2_7_8_2  -2751
    RHS       disj1_7_9_2  38
    RHS       disj2_7_9_2  -2806
    RHS       disj1_8_9_2  98
    RHS       disj2_8_9_2  -2806
    RHS       disj1_0_1_3  55
    RHS       disj2_0_1_3  -2833
    RHS       disj1_0_2_3  55
    RHS       disj2_0_2_3  -2751
    RHS       disj1_0_3_3  55
    RHS       disj2_0_3_3  -2772
    RHS       disj1_0_4_3  55
    RHS       disj2_0_4_3  -2815
    RHS       disj1_0_5_3  55
    RHS       disj2_0_5_3  -2787
    RHS       disj1_0_6_3  55
    RHS       disj2_0_6_3  -2762
    RHS       disj1_0_7_3  55
    RHS       disj2_0_7_3  -2825
    RHS       disj1_0_8_3  55
    RHS       disj2_0_8_3  -2832
    RHS       disj1_0_9_3  55
    RHS       disj2_0_9_3  -2770
    RHS       disj1_1_2_3  16
    RHS       disj2_1_2_3  -2751
    RHS       disj1_1_3_3  16
    RHS       disj2_1_3_3  -2772
    RHS       disj1_1_4_3  16
    RHS       disj2_1_4_3  -2815
    RHS       disj1_1_5_3  16
    RHS       disj2_1_5_3  -2787
    RHS       disj1_1_6_3  16
    RHS       disj2_1_6_3  -2762
    RHS       disj1_1_7_3  16
    RHS       disj2_1_7_3  -2825
    RHS       disj1_1_8_3  16
    RHS       disj2_1_8_3  -2832
    RHS       disj1_1_9_3  16
    RHS       disj2_1_9_3  -2770
    RHS       disj1_2_3_3  98
    RHS       disj2_2_3_3  -2772
    RHS       disj1_2_4_3  98
    RHS       disj2_2_4_3  -2815
    RHS       disj1_2_5_3  98
    RHS       disj2_2_5_3  -2787
    RHS       disj1_2_6_3  98
    RHS       disj2_2_6_3  -2762
    RHS       disj1_2_7_3  98
    RHS       disj2_2_7_3  -2825
    RHS       disj1_2_8_3  98
    RHS       disj2_2_8_3  -2832
    RHS       disj1_2_9_3  98
    RHS       disj2_2_9_3  -2770
    RHS       disj1_3_4_3  77
    RHS       disj2_3_4_3  -2815
    RHS       disj1_3_5_3  77
    RHS       disj2_3_5_3  -2787
    RHS       disj1_3_6_3  77
    RHS       disj2_3_6_3  -2762
    RHS       disj1_3_7_3  77
    RHS       disj2_3_7_3  -2825
    RHS       disj1_3_8_3  77
    RHS       disj2_3_8_3  -2832
    RHS       disj1_3_9_3  77
    RHS       disj2_3_9_3  -2770
    RHS       disj1_4_5_3  34
    RHS       disj2_4_5_3  -2787
    RHS       disj1_4_6_3  34
    RHS       disj2_4_6_3  -2762
    RHS       disj1_4_7_3  34
    RHS       disj2_4_7_3  -2825
    RHS       disj1_4_8_3  34
    RHS       disj2_4_8_3  -2832
    RHS       disj1_4_9_3  34
    RHS       disj2_4_9_3  -2770
    RHS       disj1_5_6_3  62
    RHS       disj2_5_6_3  -2762
    RHS       disj1_5_7_3  62
    RHS       disj2_5_7_3  -2825
    RHS       disj1_5_8_3  62
    RHS       disj2_5_8_3  -2832
    RHS       disj1_5_9_3  62
    RHS       disj2_5_9_3  -2770
    RHS       disj1_6_7_3  87
    RHS       disj2_6_7_3  -2825
    RHS       disj1_6_8_3  87
    RHS       disj2_6_8_3  -2832
    RHS       disj1_6_9_3  87
    RHS       disj2_6_9_3  -2770
    RHS       disj1_7_8_3  24
    RHS       disj2_7_8_3  -2832
    RHS       disj1_7_9_3  24
    RHS       disj2_7_9_3  -2770
    RHS       disj1_8_9_3  17
    RHS       disj2_8_9_3  -2770
    RHS       disj1_0_1_4  34
    RHS       disj2_0_1_4  -2778
    RHS       disj1_0_2_4  34
    RHS       disj2_0_2_4  -2818
    RHS       disj1_0_3_4  34
    RHS       disj2_0_3_4  -2770
    RHS       disj1_0_4_4  34
    RHS       disj2_0_4_4  -2812
    RHS       disj1_0_5_4  34
    RHS       disj2_0_5_4  -2770
    RHS       disj1_0_6_4  34
    RHS       disj2_0_6_4  -2772
    RHS       disj1_0_7_4  34
    RHS       disj2_0_7_4  -2766
    RHS       disj1_0_8_4  34
    RHS       disj2_0_8_4  -2824
    RHS       disj1_0_9_4  34
    RHS       disj2_0_9_4  -2772
    RHS       disj1_1_2_4  71
    RHS       disj2_1_2_4  -2818
    RHS       disj1_1_3_4  71
    RHS       disj2_1_3_4  -2770
    RHS       disj1_1_4_4  71
    RHS       disj2_1_4_4  -2812
    RHS       disj1_1_5_4  71
    RHS       disj2_1_5_4  -2770
    RHS       disj1_1_6_4  71
    RHS       disj2_1_6_4  -2772
    RHS       disj1_1_7_4  71
    RHS       disj2_1_7_4  -2766
    RHS       disj1_1_8_4  71
    RHS       disj2_1_8_4  -2824
    RHS       disj1_1_9_4  71
    RHS       disj2_1_9_4  -2772
    RHS       disj1_2_3_4  31
    RHS       disj2_2_3_4  -2770
    RHS       disj1_2_4_4  31
    RHS       disj2_2_4_4  -2812
    RHS       disj1_2_5_4  31
    RHS       disj2_2_5_4  -2770
    RHS       disj1_2_6_4  31
    RHS       disj2_2_6_4  -2772
    RHS       disj1_2_7_4  31
    RHS       disj2_2_7_4  -2766
    RHS       disj1_2_8_4  31
    RHS       disj2_2_8_4  -2824
    RHS       disj1_2_9_4  31
    RHS       disj2_2_9_4  -2772
    RHS       disj1_3_4_4  79
    RHS       disj2_3_4_4  -2812
    RHS       disj1_3_5_4  79
    RHS       disj2_3_5_4  -2770
    RHS       disj1_3_6_4  79
    RHS       disj2_3_6_4  -2772
    RHS       disj1_3_7_4  79
    RHS       disj2_3_7_4  -2766
    RHS       disj1_3_8_4  79
    RHS       disj2_3_8_4  -2824
    RHS       disj1_3_9_4  79
    RHS       disj2_3_9_4  -2772
    RHS       disj1_4_5_4  37
    RHS       disj2_4_5_4  -2770
    RHS       disj1_4_6_4  37
    RHS       disj2_4_6_4  -2772
    RHS       disj1_4_7_4  37
    RHS       disj2_4_7_4  -2766
    RHS       disj1_4_8_4  37
    RHS       disj2_4_8_4  -2824
    RHS       disj1_4_9_4  37
    RHS       disj2_4_9_4  -2772
    RHS       disj1_5_6_4  79
    RHS       disj2_5_6_4  -2772
    RHS       disj1_5_7_4  79
    RHS       disj2_5_7_4  -2766
    RHS       disj1_5_8_4  79
    RHS       disj2_5_8_4  -2824
    RHS       disj1_5_9_4  79
    RHS       disj2_5_9_4  -2772
    RHS       disj1_6_7_4  77
    RHS       disj2_6_7_4  -2766
    RHS       disj1_6_8_4  77
    RHS       disj2_6_8_4  -2824
    RHS       disj1_6_9_4  77
    RHS       disj2_6_9_4  -2772
    RHS       disj1_7_8_4  83
    RHS       disj2_7_8_4  -2824
    RHS       disj1_7_9_4  83
    RHS       disj2_7_9_4  -2772
    RHS       disj1_8_9_4  25
    RHS       disj2_8_9_4  -2772
BOUNDS
 BV BOUND     y_0_1_0
 BV BOUND     y_0_1_1
 BV BOUND     y_0_1_2
 BV BOUND     y_0_1_3
 BV BOUND     y_0_1_4
 BV BOUND     y_0_2_0
 BV BOUND     y_0_2_1
 BV BOUND     y_0_2_2
 BV BOUND     y_0_2_3
 BV BOUND     y_0_2_4
 BV BOUND     y_0_3_0
 BV BOUND     y_0_3_1
 BV BOUND     y_0_3_2
 BV BOUND     y_0_3_3
 BV BOUND     y_0_3_4
 BV BOUND     y_0_4_0
 BV BOUND     y_0_4_1
 BV BOUND     y_0_4_2
 BV BOUND     y_0_4_3
 BV BOUND     y_0_4_4
 BV BOUND     y_0_5_0
 BV BOUND     y_0_5_1
 BV BOUND     y_0_5_2
 BV BOUND     y_0_5_3
 BV BOUND     y_0_5_4
 BV BOUND     y_0_6_0
 BV BOUND     y_0_6_1
 BV BOUND     y_0_6_2
 BV BOUND     y_0_6_3
 BV BOUND     y_0_6_4
 BV BOUND     y_0_7_0
 BV BOUND     y_0_7_1
 BV BOUND     y_0_7_2
 BV BOUND     y_0_7_3
 BV BOUND     y_0_7_4
 BV BOUND     y_0_8_0
 BV BOUND     y_0_8_1
 BV BOUND     y_0_8_2
 BV BOUND     y_0_8_3
 BV BOUND     y_0_8_4
 BV BOUND     y_0_9_0
 BV BOUND     y_0_9_1
 BV BOUND     y_0_9_2
 BV BOUND     y_0_9_3
 BV BOUND     y_0_9_4
 BV BOUND     y_1_2_0
 BV BOUND     y_1_2_1
 BV BOUND     y_1_2_2
 BV BOUND     y_1_2_3
 BV BOUND     y_1_2_4
 BV BOUND     y_1_3_0
 BV BOUND     y_1_3_1
 BV BOUND     y_1_3_2
 BV BOUND     y_1_3_3
 BV BOUND     y_1_3_4
 BV BOUND     y_1_4_0
 BV BOUND     y_1_4_1
 BV BOUND     y_1_4_2
 BV BOUND     y_1_4_3
 BV BOUND     y_1_4_4
 BV BOUND     y_1_5_0
 BV BOUND     y_1_5_1
 BV BOUND     y_1_5_2
 BV BOUND     y_1_5_3
 BV BOUND     y_1_5_4
 BV BOUND     y_1_6_0
 BV BOUND     y_1_6_1
 BV BOUND     y_1_6_2
 BV BOUND     y_1_6_3
 BV BOUND     y_1_6_4
 BV BOUND     y_1_7_0
 BV BOUND     y_1_7_1
 BV BOUND     y_1_7_2
 BV BOUND     y_1_7_3
 BV BOUND     y_1_7_4
 BV BOUND     y_1_8_0
 BV BOUND     y_1_8_1
 BV BOUND     y_1_8_2
 BV BOUND     y_1_8_3
 BV BOUND     y_1_8_4
 BV BOUND     y_1_9_0
 BV BOUND     y_1_9_1
 BV BOUND     y_1_9_2
 BV BOUND     y_1_9_3
 BV BOUND     y_1_9_4
 BV BOUND     y_2_3_0
 BV BOUND     y_2_3_1
 BV BOUND     y_2_3_2
 BV BOUND     y_2_3_3
 BV BOUND     y_2_3_4
 BV BOUND     y_2_4_0
 BV BOUND     y_2_4_1
 BV BOUND     y_2_4_2
 BV BOUND     y_2_4_3
 BV BOUND     y_2_4_4
 BV BOUND     y_2_5_0
 BV BOUND     y_2_5_1
 BV BOUND     y_2_5_2
 BV BOUND     y_2_5_3
 BV BOUND     y_2_5_4
 BV BOUND     y_2_6_0
 BV BOUND     y_2_6_1
 BV BOUND     y_2_6_2
 BV BOUND     y_2_6_3
 BV BOUND     y_2_6_4
 BV BOUND     y_2_7_0
 BV BOUND     y_2_7_1
 BV BOUND     y_2_7_2
 BV BOUND     y_2_7_3
 BV BOUND     y_2_7_4
 BV BOUND     y_2_8_0
 BV BOUND     y_2_8_1
 BV BOUND     y_2_8_2
 BV BOUND     y_2_8_3
 BV BOUND     y_2_8_4
 BV BOUND     y_2_9_0
 BV BOUND     y_2_9_1
 BV BOUND     y_2_9_2
 BV BOUND     y_2_9_3
 BV BOUND     y_2_9_4
 BV BOUND     y_3_4_0
 BV BOUND     y_3_4_1
 BV BOUND     y_3_4_2
 BV BOUND     y_3_4_3
 BV BOUND     y_3_4_4
 BV BOUND     y_3_5_0
 BV BOUND     y_3_5_1
 BV BOUND     y_3_5_2
 BV BOUND     y_3_5_3
 BV BOUND     y_3_5_4
 BV BOUND     y_3_6_0
 BV BOUND     y_3_6_1
 BV BOUND     y_3_6_2
 BV BOUND     y_3_6_3
 BV BOUND     y_3_6_4
 BV BOUND     y_3_7_0
 BV BOUND     y_3_7_1
 BV BOUND     y_3_7_2
 BV BOUND     y_3_7_3
 BV BOUND     y_3_7_4
 BV BOUND     y_3_8_0
 BV BOUND     y_3_8_1
 BV BOUND     y_3_8_2
 BV BOUND     y_3_8_3
 BV BOUND     y_3_8_4
 BV BOUND     y_3_9_0
 BV BOUND     y_3_9_1
 BV BOUND     y_3_9_2
 BV BOUND     y_3_9_3
 BV BOUND     y_3_9_4
 BV BOUND     y_4_5_0
 BV BOUND     y_4_5_1
 BV BOUND     y_4_5_2
 BV BOUND     y_4_5_3
 BV BOUND     y_4_5_4
 BV BOUND     y_4_6_0
 BV BOUND     y_4_6_1
 BV BOUND     y_4_6_2
 BV BOUND     y_4_6_3
 BV BOUND     y_4_6_4
 BV BOUND     y_4_7_0
 BV BOUND     y_4_7_1
 BV BOUND     y_4_7_2
 BV BOUND     y_4_7_3
 BV BOUND     y_4_7_4
 BV BOUND     y_4_8_0
 BV BOUND     y_4_8_1
 BV BOUND     y_4_8_2
 BV BOUND     y_4_8_3
 BV BOUND     y_4_8_4
 BV BOUND     y_4_9_0
 BV BOUND     y_4_9_1
 BV BOUND     y_4_9_2
 BV BOUND     y_4_9_3
 BV BOUND     y_4_9_4
 BV BOUND     y_5_6_0
 BV BOUND     y_5_6_1
 BV BOUND     y_5_6_2
 BV BOUND     y_5_6_3
 BV BOUND     y_5_6_4
 BV BOUND     y_5_7_0
 BV BOUND     y_5_7_1
 BV BOUND     y_5_7_2
 BV BOUND     y_5_7_3
 BV BOUND     y_5_7_4
 BV BOUND     y_5_8_0
 BV BOUND     y_5_8_1
 BV BOUND     y_5_8_2
 BV BOUND     y_5_8_3
 BV BOUND     y_5_8_4
 BV BOUND     y_5_9_0
 BV BOUND     y_5_9_1
 BV BOUND     y_5_9_2
 BV BOUND     y_5_9_3
 BV BOUND     y_5_9_4
 BV BOUND     y_6_7_0
 BV BOUND     y_6_7_1
 BV BOUND     y_6_7_2
 BV BOUND     y_6_7_3
 BV BOUND     y_6_7_4
 BV BOUND     y_6_8_0
 BV BOUND     y_6_8_1
 BV BOUND     y_6_8_2
 BV BOUND     y_6_8_3
 BV BOUND     y_6_8_4
 BV BOUND     y_6_9_0
 BV BOUND     y_6_9_1
 BV BOUND     y_6_9_2
 BV BOUND     y_6_9_3
 BV BOUND     y_6_9_4
 BV BOUND     y_7_8_0
 BV BOUND     y_7_8_1
 BV BOUND     y_7_8_2
 BV BOUND     y_7_8_3
 BV BOUND     y_7_8_4
 BV BOUND     y_7_9_0
 BV BOUND     y_7_9_1
 BV BOUND     y_7_9_2
 BV BOUND     y_7_9_3
 BV BOUND     y_7_9_4
 BV BOUND     y_8_9_0
 BV BOUND     y_8_9_1
 BV BOUND     y_8_9_2
 BV BOUND     y_8_9_3
 BV BOUND     y_8_9_4
ENDATA
