NAME          steiner_sparse25_p025_t6
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 E  flow_20
 E  flow_21
 E  flow_22
 E  flow_23
 E  flow_24
 L  cap_0_1
 L  cap_0_3
 L  cap_0_11
 L  cap_0_20
 L  cap_0_24
 L  cap_1_5
 L  cap_1_11
 L  cap_1_17
 L  cap_1_18
 L  cap_2_15
 L  cap_2_16
 L  cap_2_17
 L  cap_3_4
 L  cap_3_5
 L  cap_3_16
 L  cap_4_12
 L  cap_4_14
 L  cap_4_15
 L  cap_4_17
 L  cap_4_23
 L  cap_4_24
 L  cap_5_18
 L  cap_6_10
 L  cap_6_11
 L  cap_6_12
 L  cap_6_16
 L  cap_6_18
 L  cap_7_9
 L  cap_7_18
 L  cap_7_23
 L  cap_7_24
 L  cap_8_10
 L  cap_8_15
 L  cap_8_17
 L  cap_8_20
 L  cap_8_23
 L  cap_9_17
 L  cap_9_19
 L  cap_9_23
 L  cap_10_11
 L  cap_10_14
 L  cap_10_15
 L  cap_10_17
 L  cap_10_18
 L  cap_10_21
 L  cap_11_19
 L  cap_12_13
 L  cap_12_17
 L  cap_12_21
 L  cap_13_19
 L  cap_13_20
 L  cap_13_23
 L  cap_14_17
 L  cap_14_19
 L  cap_14_23
 L  cap_16_17
 L  cap_16_18
 L  cap_16_22
 L  cap_17_19
 L  cap_17_24
 L  cap_18_19
 L  cap_18_22
 L  cap_19_20
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x_0_1     OBJ       7
    x_0_1     cap_0_1   -6
    x_0_3     OBJ       8
    x_0_3     cap_0_3   -6
    x_0_11    OBJ       7
    x_0_11    cap_0_11  -6
    x_0_20    OBJ       8
    x_0_20    cap_0_20  -6
    x_0_24    OBJ       7
    x_0_24    cap_0_24  -6
    x_1_5     OBJ       1
    x_1_5     cap_1_5   -6
    x_1_11    OBJ       13
    x_1_11    cap_1_11  -6
    x_1_17    OBJ       6
    x_1_17    cap_1_17  -6
    x_1_18    OBJ       15
    x_1_18    cap_1_18  -6
    x_2_15    OBJ       7
    x_2_15    cap_2_15  -6
    x_2_16    OBJ       11
    x_2_16    cap_2_16  -6
    x_2_17    OBJ       2
    x_2_17    cap_2_17  -6
    x_3_4     OBJ       12
    x_3_4     cap_3_4   -6
    x_3_5     OBJ       12
    x_3_5     cap_3_5   -6
    x_3_16    OBJ       13
    x_3_16    cap_3_16  -6
    x_4_12    OBJ       11
    x_4_12    cap_4_12  -6
    x_4_14    OBJ       1
    x_4_14    cap_4_14  -6
    x_4_15    OBJ       6
    x_4_15    cap_4_15  -6
    x_4_17    OBJ       8
    x_4_17    cap_4_17  -6
    x_4_23    OBJ       14
    x_4_23    cap_4_23  -6
    x_4_24    OBJ       5
    x_4_24    cap_4_24  -6
    x_5_18    OBJ       7
    x_5_18    cap_5_18  -6
    x_6_10    OBJ       6
    x_6_10    cap_6_10  -6
    x_6_11    OBJ       4
    x_6_11    cap_6_11  -6
    x_6_12    OBJ       14
    x_6_12    cap_6_12  -6
    x_6_16    OBJ       12
    x_6_16    cap_6_16  -6
    x_6_18    OBJ       4
    x_6_18    cap_6_18  -6
    x_7_9     OBJ       3
    x_7_9     cap_7_9   -6
    x_7_18    OBJ       15
    x_7_18    cap_7_18  -6
    x_7_23    OBJ       2
    x_7_23    cap_7_23  -6
    x_7_24    OBJ       12
    x_7_24    cap_7_24  -6
    x_8_10    OBJ       15
    x_8_10    cap_8_10  -6
    x_8_15    OBJ       15
    x_8_15    cap_8_15  -6
    x_8_17    OBJ       14
    x_8_17    cap_8_17  -6
    x_8_20    OBJ       9
    x_8_20    cap_8_20  -6
    x_8_23    OBJ       2
    x_8_23    cap_8_23  -6
    x_9_17    OBJ       1
    x_9_17    cap_9_17  -6
    x_9_19    OBJ       9
    x_9_19    cap_9_19  -6
    x_9_23    OBJ       10
    x_9_23    cap_9_23  -6
    x_10_11   OBJ       5
    x_10_11   cap_10_11  -6
    x_10_14   OBJ       13
    x_10_14   cap_10_14  -6
    x_10_15   OBJ       4
    x_10_15   cap_10_15  -6
    x_10_17   OBJ       9
    x_10_17   cap_10_17  -6
    x_10_18   OBJ       15
    x_10_18   cap_10_18  -6
    x_10_21   OBJ       9
    x_10_21   cap_10_21  -6
    x_11_19   OBJ       9
    x_11_19   cap_11_19  -6
    x_12_13   OBJ       4
    x_12_13   cap_12_13  -6
    x_12_17   OBJ       1
    x_12_17   cap_12_17  -6
    x_12_21   OBJ       12
    x_12_21   cap_12_21  -6
    x_13_19   OBJ       14
    x_13_19   cap_13_19  -6
    x_13_20   OBJ       3
    x_13_20   cap_13_20  -6
    x_13_23   OBJ       3
    x_13_23   cap_13_23  -6
    x_14_17   OBJ       7
    x_14_17   cap_14_17  -6
    x_14_19   OBJ       15
    x_14_19   cap_14_19  -6
    x_14_23   OBJ       10
    x_14_23   cap_14_23  -6
    x_16_17   OBJ       4
    x_16_17   cap_16_17  -6
    x_16_18   OBJ       3
    x_16_18   cap_16_18  -6
    x_16_22   OBJ       2
    x_16_22   cap_16_22  -6
    x_17_19   OBJ       6
    x_17_19   cap_17_19  -6
    x_17_24   OBJ       8
    x_17_24   cap_17_24  -6
    x_18_19   OBJ       7
    x_18_19   cap_18_19  -6
    x_18_22   OBJ       9
    x_18_22   cap_18_22  -6
    x_19_20   OBJ       8
    x_19_20   cap_19_20  -6
    MARK0001  'MARKER'                 'INTEND'
    f_0_1     flow_0    1.0
    f_0_1     flow_1    -1.0
    f_0_1     cap_0_1   1.0
    f_1_0     flow_0    -1.0
    f_1_0     flow_1    1.0
    f_1_0     cap_0_1   1.0
    f_0_3     flow_0    1.0
    f_0_3     flow_3    -1.0
    f_0_3     cap_0_3   1.0
    f_3_0     flow_0    -1.0
    f_3_0     flow_3    1.0
    f_3_0     cap_0_3   1.0
    f_0_11    flow_0    1.0
    f_0_11    flow_11   -1.0
    f_0_11    cap_0_11  1.0
    f_11_0    flow_0    -1.0
    f_11_0    flow_11   1.0
    f_11_0    cap_0_11  1.0
    f_0_20    flow_0    1.0
    f_0_20    flow_20   -1.0
    f_0_20    cap_0_20  1.0
    f_20_0    flow_0    -1.0
    f_20_0    flow_20   1.0
    f_20_0    cap_0_20  1.0
    f_0_24    flow_0    1.0
    f_0_24    flow_24   -1.0
    f_0_24    cap_0_24  1.0
    f_24_0    flow_0    -1.0
    f_24_0    flow_24   1.0
    f_24_0    cap_0_24  1.0
    f_1_5     flow_1    1.0
    f_1_5     flow_5    -1.0
    f_1_5     cap_1_5   1.0
    f_5_1     flow_1    -1.0
    f_5_1     flow_5    1.0
    f_5_1     cap_1_5   1.0
    f_1_11    flow_1    1.0
    f_1_11    flow_11   -1.0
    f_1_11    cap_1_11  1.0
    f_11_1    flow_1    -1.0
    f_11_1    flow_11   1.0
    f_11_1    cap_1_11  1.0
    f_1_17    flow_1    1.0
    f_1_17    flow_17   -1.0
    f_1_17    cap_1_17  1.0
    f_17_1    flow_1    -1.0
    f_17_1    flow_17   1.0
    f_17_1    cap_1_17  1.0
    f_1_18    flow_1    1.0
    f_1_18    flow_18   -1.0
    f_1_18    cap_1_18  1.0
    f_18_1    flow_1    -1.0
    f_18_1    flow_18   1.0
    f_18_1    cap_1_18  1.0
    f_2_15    flow_2    1.0
    f_2_15    flow_15   -1.0
    f_2_15    cap_2_15  1.0
    f_15_2    flow_2    -1.0
    f_15_2    flow_15   1.0
    f_15_2    cap_2_15  1.0
    f_2_16    flow_2    1.0
    f_2_16    flow_16   -1.0
    f_2_16    cap_2_16  1.0
    f_16_2    flow_2    -1.0
    f_16_2    flow_16   1.0
    f_16_2    cap_2_16  1.0
    f_2_17    flow_2    1.0
    f_2_17    flow_17   -1.0
    f_2_17    cap_2_17  1.0
    f_17_2    flow_2    -1.0
    f_17_2    flow_17   1.0
    f_17_2    cap_2_17  1.0
    f_3_4     flow_3    1.0
    f_3_4     flow_4    -1.0
    f_3_4     cap_3_4   1.0
    f_4_3     flow_3    -1.0
    f_4_3     flow_4    1.0
    f_4_3     cap_3_4   1.0
    f_3_5     flow_3    1.0
    f_3_5     flow_5    -1.0
    f_3_5     cap_3_5   1.0
    f_5_3     flow_3    -1.0
    f_5_3     flow_5    1.0
    f_5_3     cap_3_5   1.0
    f_3_16    flow_3    1.0
    f_3_16    flow_16   -1.0
    f_3_16    cap_3_16  1.0
    f_16_3    flow_3    -1.0
    f_16_3    flow_16   1.0
    f_16_3    cap_3_16  1.0
    f_4_12    flow_4    1.0
    f_4_12    flow_12   -1.0
    f_4_12    cap_4_12  1.0
    f_12_4    flow_4    -1.0
    f_12_4    flow_12   1.0
    f_12_4    cap_4_12  1.0
    f_4_14    flow_4    1.0
    f_4_14    flow_14   -1.0
    f_4_14    cap_4_14  1.0
    f_14_4    flow_4    -1.0
    f_14_4    flow_14   1.0
    f_14_4    cap_4_14  1.0
    f_4_15    flow_4    1.0
    f_4_15    flow_15   -1.0
    f_4_15    cap_4_15  1.0
    f_15_4    flow_4    -1.0
    f_15_4    flow_15   1.0
    f_15_4    cap_4_15  1.0
    f_4_17    flow_4    1.0
    f_4_17    flow_17   -1.0
    f_4_17    cap_4_17  1.0
    f_17_4    flow_4    -1.0
    f_17_4    flow_17   1.0
    f_17_4    cap_4_17  1.0
    f_4_23    flow_4    1.0
    f_4_23    flow_23   -1.0
    f_4_23    cap_4_23  1.0
    f_23_4    flow_4    -1.0
    f_23_4    flow_23   1.0
    f_23_4    cap_4_23  1.0
    f_4_24    flow_4    1.0
    f_4_24    flow_24   -1.0
    f_4_24    cap_4_24  1.0
    f_24_4    flow_4    -1.0
    f_24_4    flow_24   1.0
    f_24_4    cap_4_24  1.0
    f_5_18    flow_5    1.0
    f_5_18    flow_18   -1.0
    f_5_18    cap_5_18  1.0
    f_18_5    flow_5    -1.0
    f_18_5    flow_18   1.0
    f_18_5    cap_5_18  1.0
    f_6_10    flow_6    1.0
    f_6_10    flow_10   -1.0
    f_6_10    cap_6_10  1.0
    f_10_6    flow_6    -1.0
    f_10_6    flow_10   1.0
    f_10_6    cap_6_10  1.0
    f_6_11    flow_6    1.0
    f_6_11    flow_11   -1.0
    f_6_11    cap_6_11  1.0
    f_11_6    flow_6    -1.0
    f_11_6    flow_11   1.0
    f_11_6    cap_6_11  1.0
    f_6_12    flow_6    1.0
    f_6_12    flow_12   -1.0
    f_6_12    cap_6_12  1.0
    f_12_6    flow_6    -1.0
    f_12_6    flow_12   1.0
    f_12_6    cap_6_12  1.0
    f_6_16    flow_6    1.0
    f_6_16    flow_16   -1.0
    f_6_16    cap_6_16  1.0
    f_16_6    flow_6    -1.0
    f_16_6    flow_16   1.0
    f_16_6    cap_6_16  1.0
    f_6_18    flow_6    1.0
    f_6_18    flow_18   -1.0
    f_6_18    cap_6_18  1.0
    f_18_6    flow_6    -1.0
    f_18_6    flow_18   1.0
    f_18_6    cap_6_18  1.0
    f_7_9     flow_7    1.0
    f_7_9     flow_9    -1.0
    f_7_9     cap_7_9   1.0
    f_9_7     flow_7    -1.0
    f_9_7     flow_9    1.0
    f_9_7     cap_7_9   1.0
    f_7_18    flow_7    1.0
    f_7_18    flow_18   -1.0
    f_7_18    cap_7_18  1.0
    f_18_7    flow_7    -1.0
    f_18_7    flow_18   1.0
    f_18_7    cap_7_18  1.0
    f_7_23    flow_7    1.0
    f_7_23    flow_23   -1.0
    f_7_23    cap_7_23  1.0
    f_23_7    flow_7    -1.0
    f_23_7    flow_23   1.0
    f_23_7    cap_7_23  1.0
    f_7_24    flow_7    1.0
    f_7_24    flow_24   -1.0
    f_7_24    cap_7_24  1.0
    f_24_7    flow_7    -1.0
    f_24_7    flow_24   1.0
    f_24_7    cap_7_24  1.0
    f_8_10    flow_8    1.0
    f_8_10    flow_10   -1.0
    f_8_10    cap_8_10  1.0
    f_10_8    flow_8    -1.0
    f_10_8    flow_10   1.0
    f_10_8    cap_8_10  1.0
    f_8_15    flow_8    1.0
    f_8_15    flow_15   -1.0
    f_8_15    cap_8_15  1.0
    f_15_8    flow_8    -1.0
    f_15_8    flow_15   1.0
    f_15_8    cap_8_15  1.0
    f_8_17    flow_8    1.0
    f_8_17    flow_17   -1.0
    f_8_17    cap_8_17  1.0
    f_17_8    flow_8    -1.0
    f_17_8    flow_17   1.0
    f_17_8    cap_8_17  1.0
    f_8_20    flow_8    1.0
    f_8_20    flow_20   -1.0
    f_8_20    cap_8_20  1.0
    f_20_8    flow_8    -1.0
    f_20_8    flow_20   1.0
    f_20_8    cap_8_20  1.0
    f_8_23    flow_8    1.0
    f_8_23    flow_23   -1.0
    f_8_23    cap_8_23  1.0
    f_23_8    flow_8    -1.0
    f_23_8    flow_23   1.0
    f_23_8    cap_8_23  1.0
    f_9_17    flow_9    1.0
    f_9_17    flow_17   -1.0
    f_9_17    cap_9_17  1.0
    f_17_9    flow_9    -1.0
    f_17_9    flow_17   1.0
    f_17_9    cap_9_17  1.0
    f_9_19    flow_9    1.0
    f_9_19    flow_19   -1.0
    f_9_19    cap_9_19  1.0
    f_19_9    flow_9    -1.0
    f_19_9    flow_19   1.0
    f_19_9    cap_9_19  1.0
    f_9_23    flow_9    1.0
    f_9_23    flow_23   -1.0
    f_9_23    cap_9_23  1.0
    f_23_9    flow_9    -1.0
    f_23_9    flow_23   1.0
    f_23_9    cap_9_23  1.0
    f_10_11   flow_10   1.0
    f_10_11   flow_11   -1.0
    f_10_11   cap_10_11  1.0
    f_11_10   flow_10   -1.0
    f_11_10   flow_11   1.0
    f_11_10   cap_10_11  1.0
    f_10_14   flow_10   1.0
    f_10_14   flow_14   -1.0
    f_10_14   cap_10_14  1.0
    f_14_10   flow_10   -1.0
    f_14_10   flow_14   1.0
    f_14_10   cap_10_14  1.0
    f_10_15   flow_10   1.0
    f_10_15   flow_15   -1.0
    f_10_15   cap_10_15  1.0
    f_15_10   flow_10   -1.0
    f_15_10   flow_15   1.0
    f_15_10   cap_10_15  1.0
    f_10_17   flow_10   1.0
    f_10_17   flow_17   -1.0
    f_10_17   cap_10_17  1.0
    f_17_10   flow_10   -1.0
    f_17_10   flow_17   1.0
    f_17_10   cap_10_17  1.0
    f_10_18   flow_10   1.0
    f_10_18   flow_18   -1.0
    f_10_18   cap_10_18  1.0
    f_18_10   flow_10   -1.0
    f_18_10   flow_18   1.0
    f_18_10   cap_10_18  1.0
    f_10_21   flow_10   1.0
    f_10_21   flow_21   -1.0
    f_10_21   cap_10_21  1.0
    f_21_10   flow_10   -1.0
    f_21_10   flow_21   1.0
    f_21_10   cap_10_21  1.0
    f_11_19   flow_11   1.0
    f_11_19   flow_19   -1.0
    f_11_19   cap_11_19  1.0
    f_19_11   flow_11   -1.0
    f_19_11   flow_19   1.0
    f_19_11   cap_11_19  1.0
    f_12_13   flow_12   1.0
    f_12_13   flow_13   -1.0
    f_12_13   cap_12_13  1.0
    f_13_12   flow_12   -1.0
    f_13_12   flow_13   1.0
    f_13_12   cap_12_13  1.0
    f_12_17   flow_12   1.0
    f_12_17   flow_17   -1.0
    f_12_17   cap_12_17  1.0
    f_17_12   flow_12   -1.0
    f_17_12   flow_17   1.0
    f_17_12   cap_12_17  1.0
    f_12_21   flow_12   1.0
    f_12_21   flow_21   -1.0
    f_12_21   cap_12_21  1.0
    f_21_12   flow_12   -1.0
    f_21_12   flow_21   1.0
    f_21_12   cap_12_21  1.0
    f_13_19   flow_13   1.0
    f_13_19   flow_19   -1.0
    f_13_19   cap_13_19  1.0
    f_19_13   flow_13   -1.0
    f_19_13   flow_19   1.0
    f_19_13   cap_13_19  1.0
    f_13_20   flow_13   1.0
    f_13_20   flow_20   -1.0
    f_13_20   cap_13_20  1.0
    f_20_13   flow_13   -1.0
    f_20_13   flow_20   1.0
    f_20_13   cap_13_20  1.0
    f_13_23   flow_13   1.0
    f_13_23   flow_23   -1.0
    f_13_23   cap_13_23  1.0
    f_23_13   flow_13   -1.0
    f_23_13   flow_23   1.0
    f_23_13   cap_13_23  1.0
    f_14_17   flow_14   1.0
    f_14_17   flow_17   -1.0
    f_14_17   cap_14_17  1.0
    f_17_14   flow_14   -1.0
    f_17_14   flow_17   1.0
    f_17_14   cap_14_17  1.0
    f_14_19   flow_14   1.0
    f_14_19   flow_19   -1.0
    f_14_19   cap_14_19  1.0
    f_19_14   flow_14   -1.0
    f_19_14   flow_19   1.0
    f_19_14   cap_14_19  1.0
    f_14_23   flow_14   1.0
    f_14_23   flow_23   -1.0
    f_14_23   cap_14_23  1.0
    f_23_14   flow_14   -1.0
    f_23_14   flow_23   1.0
    f_23_14   cap_14_23  1.0
    f_16_17   flow_16   1.0
    f_16_17   flow_17   -1.0
    f_16_17   cap_16_17  1.0
    f_17_16   flow_16   -1.0
    f_17_16   flow_17   1.0
    f_17_16   cap_16_17  1.0
    f_16_18   flow_16   1.0
    f_16_18   flow_18   -1.0
    f_16_18   cap_16_18  1.0
    f_18_16   flow_16   -1.0
    f_18_16   flow_18   1.0
    f_18_16   cap_16_18  1.0
    f_16_22   flow_16   1.0
    f_16_22   flow_22   -1.0
    f_16_22   cap_16_22  1.0
    f_22_16   flow_16   -1.0
    f_22_16   flow_22   1.0
    f_22_16   cap_16_22  1.0
    f_17_19   flow_17   1.0
    f_17_19   flow_19   -1.0
    f_17_19   cap_17_19  1.0
    f_19_17   flow_17   -1.0
    f_19_17   flow_19   1.0
    f_19_17   cap_17_19  1.0
    f_17_24   flow_17   1.0
    f_17_24   flow_24   -1.0
    f_17_24   cap_17_24  1.0
    f_24_17   flow_17   -1.0
    f_24_17   flow_24   1.0
    f_24_17   cap_17_24  1.0
    f_18_19   flow_18   1.0
    f_18_19   flow_19   -1.0
    f_18_19   cap_18_19  1.0
    f_19_18   flow_18   -1.0
    f_19_18   flow_19   1.0
    f_19_18   cap_18_19  1.0
    f_18_22   flow_18   1.0
    f_18_22   flow_22   -1.0
    f_18_22   cap_18_22  1.0
    f_22_18   flow_18   -1.0
    f_22_18   flow_22   1.0
    f_22_18   cap_18_22  1.0
    f_19_20   flow_19   1.0
    f_19_20   flow_20   -1.0
    f_19_20   cap_19_20  1.0
    f_20_19   flow_19   -1.0
    f_20_19   flow_20   1.0
    f_20_19   cap_19_20  1.0
RHS
    RHS       flow_0    6
    RHS       flow_3    -1
    RHS       flow_6    -1
    RHS       flow_7    -1
    RHS       flow_8    -1
    RHS       flow_11   -1
    RHS       flow_14   -1
BOUNDS
 BV BOUND     x_0_1
 BV BOUND     x_0_3
 BV BOUND     x_0_11
 BV BOUND     x_0_20
 BV BOUND     x_0_24
 BV BOUND     x_1_5
 BV BOUND     x_1_11
 BV BOUND     x_1_17
 BV BOUND     x_1_18
 BV BOUND     x_2_15
 BV BOUND     x_2_16
 BV BOUND     x_2_17
 BV BOUND     x_3_4
 BV BOUND     x_3_5
 BV BOUND     x_3_16
 BV BOUND     x_4_12
 BV BOUND     x_4_14
 BV BOUND     x_4_15
 BV BOUND     x_4_17
 BV BOUND     x_4_23
 BV BOUND     x_4_24
 BV BOUND     x_5_18
 BV BOUND     x_6_10
 BV BOUND     x_6_11
 BV BOUND     x_6_12
 BV BOUND     x_6_16
 BV BOUND     x_6_18
 BV BOUND     x_7_9
 BV BOUND     x_7_18
 BV BOUND     x_7_23
 BV BOUND     x_7_24
 BV BOUND     x_8_10
 BV BOUND     x_8_15
 BV BOUND     x_8_17
 BV BOUND     x_8_20
 BV BOUND     x_8_23
 BV BOUND     x_9_17
 BV BOUND     x_9_19
 BV BOUND     x_9_23
 BV BOUND     x_10_11
 BV BOUND     x_10_14
 BV BOUND     x_10_15
 BV BOUND     x_10_17
 BV BOUND     x_10_18
 BV BOUND     x_10_21
 BV BOUND     x_11_19
 BV BOUND     x_12_13
 BV BOUND     x_12_17
 BV BOUND     x_12_21
 BV BOUND     x_13_19
 BV BOUND     x_13_20
 BV BOUND     x_13_23
 BV BOUND     x_14_17
 BV BOUND     x_14_19
 BV BOUND     x_14_23
 BV BOUND     x_16_17
 BV BOUND     x_16_18
 BV BOUND     x_16_22
 BV BOUND     x_17_19
 BV BOUND     x_17_24
 BV BOUND     x_18_19
 BV BOUND     x_18_22
 BV BOUND     x_19_20
 UP BOUND     f_0_1     6
 UP BOUND     f_1_0     6
 UP BOUND     f_0_3     6
 UP BOUND     f_3_0     6
 UP BOUND     f_0_11    6
 UP BOUND     f_11_0    6
 UP BOUND     f_0_20    6
 UP BOUND     f_20_0    6
 UP BOUND     f_0_24    6
 UP BOUND     f_24_0    6
 UP BOUND     f_1_5     6
 UP BOUND     f_5_1     6
 UP BOUND     f_1_11    6
 UP BOUND     f_11_1    6
 UP BOUND     f_1_17    6
 UP BOUND     f_17_1    6
 UP BOUND     f_1_18    6
 UP BOUND     f_18_1    6
 UP BOUND     f_2_15    6
 UP BOUND     f_15_2    6
 UP BOUND     f_2_16    6
 UP BOUND     f_16_2    6
 UP BOUND     f_2_17    6
 UP BOUND     f_17_2    6
 UP BOUND     f_3_4     6
 UP BOUND     f_4_3     6
 UP BOUND     f_3_5     6
 UP BOUND     f_5_3     6
 UP BOUND     f_3_16    6
 UP BOUND     f_16_3    6
 UP BOUND     f_4_12    6
 UP BOUND     f_12_4    6
 UP BOUND     f_4_14    6
 UP BOUND     f_14_4    6
 UP BOUND     f_4_15    6
 UP BOUND     f_15_4    6
 UP BOUND     f_4_17    6
 UP BOUND     f_17_4    6
 UP BOUND     f_4_23    6
 UP BOUND     f_23_4    6
 UP BOUND     f_4_24    6
 UP BOUND     f_24_4    6
 UP BOUND     f_5_18    6
 UP BOUND     f_18_5    6
 UP BOUND     f_6_10    6
 UP BOUND     f_10_6    6
 UP BOUND     f_6_11    6
 UP BOUND     f_11_6    6
 UP BOUND     f_6_12    6
 UP BOUND     f_12_6    6
 UP BOUND     f_6_16    6
 UP BOUND     f_16_6    6
 UP BOUND     f_6_18    6
 UP BOUND     f_18_6    6
 UP BOUND     f_7_9     6
 UP BOUND     f_9_7     6
 UP BOUND     f_7_18    6
 UP BOUND     f_18_7    6
 UP BOUND     f_7_23    6
 UP BOUND     f_23_7    6
 UP BOUND     f_7_24    6
 UP BOUND     f_24_7    6
 UP BOUND     f_8_10    6
 UP BOUND     f_10_8    6
 UP BOUND     f_8_15    6
 UP BOUND     f_15_8    6
 UP BOUND     f_8_17    6
 UP BOUND     f_17_8    6
 UP BOUND     f_8_20    6
 UP BOUND     f_20_8    6
 UP BOUND     f_8_23    6
 UP BOUND     f_23_8    6
 UP BOUND     f_9_17    6
 UP BOUND     f_17_9    6
 UP BOUND     f_9_19    6
 UP BOUND     f_19_9    6
 UP BOUND     f_9_23    6
 UP BOUND     f_23_9    6
 UP BOUND     f_10_11   6
 UP BOUND     f_11_10   6
 UP BOUND     f_10_14   6
 UP BOUND     f_14_10   6
 UP BOUND     f_10_15   6
 UP BOUND     f_15_10   6
 UP BOUND     f_10_17   6
 UP BOUND     f_17_10   6
 UP BOUND     f_10_18   6
 UP BOUND     f_18_10   6
 UP BOUND     f_10_21   6
 UP BOUND     f_21_10   6
 UP BOUND     f_11_19   6
 UP BOUND     f_19_11   6
 UP BOUND     f_12_13   6
 UP BOUND     f_13_12   6
 UP BOUND     f_12_17   6
 UP BOUND     f_17_12   6
 UP BOUND     f_12_21   6
 UP BOUND     f_21_12   6
 UP BOUND     f_13_19   6
 UP BOUND     f_19_13   6
 UP BOUND     f_13_20   6
 UP BOUND     f_20_13   6
 UP BOUND     f_13_23   6
 UP BOUND     f_23_13   6
 UP BOUND     f_14_17   6
 UP BOUND     f_17_14   6
 UP BOUND     f_14_19   6
 UP BOUND     f_19_14   6
 UP BOUND     f_14_23   6
 UP BOUND     f_23_14   6
 UP BOUND     f_16_17   6
 UP BOUND     f_17_16   6
 UP BOUND     f_16_18   6
 UP BOUND     f_18_16   6
 UP BOUND     f_16_22   6
 UP BOUND     f_22_16   6
 UP BOUND     f_17_19   6
 UP BOUND     f_19_17   6
 UP BOUND     f_17_24   6
 UP BOUND     f_24_17   6
 UP BOUND     f_18_19   6
 UP BOUND     f_19_18   6
 UP BOUND     f_18_22   6
 UP BOUND     f_22_18   6
 UP BOUND     f_19_20   6
 UP BOUND     f_20_19   6
ENDATA
