NAME          SETPACK
ROWS
 N  OBJ
 L  PACK_0
 L  PACK_1
 L  PACK_2
 L  PACK_3
 L  PACK_4
 L  PACK_5
 L  PACK_6
 L  PACK_7
 L  PACK_8
 L  PACK_9
 L  PACK_10
 L  PACK_11
 L  PACK_12
 L  PACK_13
 L  PACK_14
COLUMNS
    x_0         OBJ       -10
    x_0         PACK_9  1.0
    x_0         PACK_10  1.0
    x_1         OBJ       -24
    x_1         PACK_10  1.0
    x_1         PACK_11  1.0
    x_2         OBJ       -53
    x_2         PACK_7  1.0
    x_2         PACK_8  1.0
    x_2         PACK_9  1.0
    x_3         OBJ       -42
    x_3         PACK_2  1.0
    x_3         PACK_3  1.0
    x_3         PACK_4  1.0
    x_3         PACK_5  1.0
    x_4         OBJ       -25
    x_4         PACK_12  1.0
    x_4         PACK_13  1.0
    x_4         PACK_14  1.0
    x_5         OBJ       -30
    x_5         PACK_13  1.0
    x_5         PACK_14  1.0
    x_6         OBJ       -63
    x_6         PACK_6  1.0
    x_6         PACK_7  1.0
    x_6         PACK_8  1.0
    x_6         PACK_9  1.0
    x_6         PACK_10  1.0
    x_7         OBJ       -45
    x_7         PACK_5  1.0
    x_7         PACK_6  1.0
    x_7         PACK_7  1.0
    x_7         PACK_8  1.0
    x_8         OBJ       -2
    x_8         PACK_11  1.0
    x_8         PACK_12  1.0
    x_9         OBJ       -52
    x_9         PACK_5  1.0
    x_9         PACK_6  1.0
    x_9         PACK_7  1.0
    x_9         PACK_8  1.0
    x_9         PACK_9  1.0
    x_10        OBJ       -66
    x_10        PACK_11  1.0
    x_10        PACK_12  1.0
    x_11        OBJ       -42
    x_11        PACK_11  1.0
    x_11        PACK_12  1.0
    x_11        PACK_13  1.0
    x_11        PACK_14  1.0
    x_12        OBJ       -51
    x_12        PACK_3  1.0
    x_12        PACK_4  1.0
    x_13        OBJ       -68
    x_13        PACK_9  1.0
    x_13        PACK_10  1.0
    x_14        OBJ       -61
    x_14        PACK_14  1.0
    x_15        OBJ       -18
    x_15        PACK_0  1.0
    x_15        PACK_1  1.0
    x_15        PACK_2  1.0
    x_15        PACK_3  1.0
    x_16        OBJ       -55
    x_16        PACK_12  1.0
    x_16        PACK_13  1.0
    x_16        PACK_14  1.0
    x_17        OBJ       -67
    x_17        PACK_6  1.0
    x_17        PACK_7  1.0
    x_18        OBJ       -67
    x_18        PACK_11  1.0
    x_18        PACK_12  1.0
    x_19        OBJ       -43
    x_19        PACK_13  1.0
    x_19        PACK_14  1.0
RHS
    RHS1      PACK_0  1.0
    RHS1      PACK_1  1.0
    RHS1      PACK_2  1.0
    RHS1      PACK_3  1.0
    RHS1      PACK_4  1.0
    RHS1      PACK_5  1.0
    RHS1      PACK_6  1.0
    RHS1      PACK_7  1.0
    RHS1      PACK_8  1.0
    RHS1      PACK_9  1.0
    RHS1      PACK_10  1.0
    RHS1      PACK_11  1.0
    RHS1      PACK_12  1.0
    RHS1      PACK_13  1.0
    RHS1      PACK_14  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
ENDATA
