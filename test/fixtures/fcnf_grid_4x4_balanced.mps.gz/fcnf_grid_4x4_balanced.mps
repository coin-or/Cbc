NAME          fcnf_grid_4x4_balanced
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
 L  link_42
 L  link_43
 L  link_44
 L  link_45
 L  link_46
 L  link_47
COLUMNS
    x_0         OBJ       1.15
    x_0         flow_0      1.0
    x_0         flow_1      -1.0
    x_0         link_0      1.0
    x_1         OBJ       4.84
    x_1         flow_0      1.0
    x_1         flow_4      -1.0
    x_1         link_1      1.0
    x_2         OBJ       2.81
    x_2         flow_1      1.0
    x_2         flow_2      -1.0
    x_2         link_2      1.0
    x_3         OBJ       3.06
    x_3         flow_1      1.0
    x_3         flow_5      -1.0
    x_3         link_3      1.0
    x_4         OBJ       4.41
    x_4         flow_1      1.0
    x_4         flow_0      -1.0
    x_4         link_4      1.0
    x_5         OBJ       2.58
    x_5         flow_2      1.0
    x_5         flow_3      -1.0
    x_5         link_5      1.0
    x_6         OBJ       4.28
    x_6         flow_2      1.0
    x_6         flow_6      -1.0
    x_6         link_6      1.0
    x_7         OBJ       1.64
    x_7         flow_2      1.0
    x_7         flow_1      -1.0
    x_7         link_7      1.0
    x_8         OBJ       4.09
    x_8         flow_3      1.0
    x_8         flow_7      -1.0
    x_8         link_8      1.0
    x_9         OBJ       2.09
    x_9         flow_3      1.0
    x_9         flow_2      -1.0
    x_9         link_9      1.0
    x_10        OBJ       1.2
    x_10        flow_4      1.0
    x_10        flow_5      -1.0
    x_10        link_10     1.0
    x_11        OBJ       4.36
    x_11        flow_4      1.0
    x_11        flow_8      -1.0
    x_11        link_11     1.0
    x_12        OBJ       3.09
    x_12        flow_4      1.0
    x_12        flow_0      -1.0
    x_12        link_12     1.0
    x_13        OBJ       3.62
    x_13        flow_5      1.0
    x_13        flow_6      -1.0
    x_13        link_13     1.0
    x_14        OBJ       1.38
    x_14        flow_5      1.0
    x_14        flow_9      -1.0
    x_14        link_14     1.0
    x_15        OBJ       2.32
    x_15        flow_5      1.0
    x_15        flow_4      -1.0
    x_15        link_15     1.0
    x_16        OBJ       1.67
    x_16        flow_5      1.0
    x_16        flow_1      -1.0
    x_16        link_16     1.0
    x_17        OBJ       1.2
    x_17        flow_6      1.0
    x_17        flow_7      -1.0
    x_17        link_17     1.0
    x_18        OBJ       3.91
    x_18        flow_6      1.0
    x_18        flow_10     -1.0
    x_18        link_18     1.0
    x_19        OBJ       4.88
    x_19        flow_6      1.0
    x_19        flow_5      -1.0
    x_19        link_19     1.0
    x_20        OBJ       2.19
    x_20        flow_6      1.0
    x_20        flow_2      -1.0
    x_20        link_20     1.0
    x_21        OBJ       3.86
    x_21        flow_7      1.0
    x_21        flow_11     -1.0
    x_21        link_21     1.0
    x_22        OBJ       3.41
    x_22        flow_7      1.0
    x_22        flow_6      -1.0
    x_22        link_22     1.0
    x_23        OBJ       3.58
    x_23        flow_7      1.0
    x_23        flow_3      -1.0
    x_23        link_23     1.0
    x_24        OBJ       3.3
    x_24        flow_8      1.0
    x_24        flow_9      -1.0
    x_24        link_24     1.0
    x_25        OBJ       2.7
    x_25        flow_8      1.0
    x_25        flow_12     -1.0
    x_25        link_25     1.0
    x_26        OBJ       1.01
    x_26        flow_8      1.0
    x_26        flow_4      -1.0
    x_26        link_26     1.0
    x_27        OBJ       1.5
    x_27        flow_9      1.0
    x_27        flow_10     -1.0
    x_27        link_27     1.0
    x_28        OBJ       1.47
    x_28        flow_9      1.0
    x_28        flow_13     -1.0
    x_28        link_28     1.0
    x_29        OBJ       4.75
    x_29        flow_9      1.0
    x_29        flow_8      -1.0
    x_29        link_29     1.0
    x_30        OBJ       4.43
    x_30        flow_9      1.0
    x_30        flow_5      -1.0
    x_30        link_30     1.0
    x_31        OBJ       1.37
    x_31        flow_10     1.0
    x_31        flow_11     -1.0
    x_31        link_31     1.0
    x_32        OBJ       1.78
    x_32        flow_10     1.0
    x_32        flow_14     -1.0
    x_32        link_32     1.0
    x_33        OBJ       2.04
    x_33        flow_10     1.0
    x_33        flow_9      -1.0
    x_33        link_33     1.0
    x_34        OBJ       2.59
    x_34        flow_10     1.0
    x_34        flow_6      -1.0
    x_34        link_34     1.0
    x_35        OBJ       1.71
    x_35        flow_11     1.0
    x_35        flow_15     -1.0
    x_35        link_35     1.0
    x_36        OBJ       3.68
    x_36        flow_11     1.0
    x_36        flow_10     -1.0
    x_36        link_36     1.0
    x_37        OBJ       2.38
    x_37        flow_11     1.0
    x_37        flow_7      -1.0
    x_37        link_37     1.0
    x_38        OBJ       4.29
    x_38        flow_12     1.0
    x_38        flow_13     -1.0
    x_38        link_38     1.0
    x_39        OBJ       2.83
    x_39        flow_12     1.0
    x_39        flow_8      -1.0
    x_39        link_39     1.0
    x_40        OBJ       1.09
    x_40        flow_13     1.0
    x_40        flow_14     -1.0
    x_40        link_40     1.0
    x_41        OBJ       4.55
    x_41        flow_13     1.0
    x_41        flow_12     -1.0
    x_41        link_41     1.0
    x_42        OBJ       4.8
    x_42        flow_13     1.0
    x_42        flow_9      -1.0
    x_42        link_42     1.0
    x_43        OBJ       1.88
    x_43        flow_14     1.0
    x_43        flow_15     -1.0
    x_43        link_43     1.0
    x_44        OBJ       1.62
    x_44        flow_14     1.0
    x_44        flow_13     -1.0
    x_44        link_44     1.0
    x_45        OBJ       1.5
    x_45        flow_14     1.0
    x_45        flow_10     -1.0
    x_45        link_45     1.0
    x_46        OBJ       2.51
    x_46        flow_15     1.0
    x_46        flow_14     -1.0
    x_46        link_46     1.0
    x_47        OBJ       2.5
    x_47        flow_15     1.0
    x_47        flow_11     -1.0
    x_47        link_47     1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       4.78
    y_0         link_0      -5.0
    y_1         OBJ       3.48
    y_1         link_1      -4.0
    y_2         OBJ       3.99
    y_2         link_2      -3.0
    y_3         OBJ       4.31
    y_3         link_3      -12.0
    y_4         OBJ       4.19
    y_4         link_4      -9.0
    y_5         OBJ       2.23
    y_5         link_5      -4.0
    y_6         OBJ       3.5
    y_6         link_6      -4.0
    y_7         OBJ       5.34
    y_7         link_7      -5.0
    y_8         OBJ       4.39
    y_8         link_8      -11.0
    y_9         OBJ       2.73
    y_9         link_9      -4.0
    y_10        OBJ       2.24
    y_10        link_10     -3.0
    y_11        OBJ       3.18
    y_11        link_11     -4.0
    y_12        OBJ       2.41
    y_12        link_12     -12.0
    y_13        OBJ       4.6
    y_13        link_13     -3.0
    y_14        OBJ       4.49
    y_14        link_14     -8.0
    y_15        OBJ       4.66
    y_15        link_15     -10.0
    y_16        OBJ       5.39
    y_16        link_16     -8.0
    y_17        OBJ       4.37
    y_17        link_17     -8.0
    y_18        OBJ       4.69
    y_18        link_18     -4.0
    y_19        OBJ       4.21
    y_19        link_19     -4.0
    y_20        OBJ       5.6
    y_20        link_20     -8.0
    y_21        OBJ       2.17
    y_21        link_21     -9.0
    y_22        OBJ       2.33
    y_22        link_22     -5.0
    y_23        OBJ       5.49
    y_23        link_23     -5.0
    y_24        OBJ       3.23
    y_24        link_24     -11.0
    y_25        OBJ       4.35
    y_25        link_25     -5.0
    y_26        OBJ       5.61
    y_26        link_26     -4.0
    y_27        OBJ       2.07
    y_27        link_27     -8.0
    y_28        OBJ       4.13
    y_28        link_28     -7.0
    y_29        OBJ       4.81
    y_29        link_29     -8.0
    y_30        OBJ       3.54
    y_30        link_30     -3.0
    y_31        OBJ       2.82
    y_31        link_31     -9.0
    y_32        OBJ       5.74
    y_32        link_32     -9.0
    y_33        OBJ       4.35
    y_33        link_33     -8.0
    y_34        OBJ       2.21
    y_34        link_34     -11.0
    y_35        OBJ       5.31
    y_35        link_35     -3.0
    y_36        OBJ       5.84
    y_36        link_36     -6.0
    y_37        OBJ       5.11
    y_37        link_37     -9.0
    y_38        OBJ       3.56
    y_38        link_38     -3.0
    y_39        OBJ       2.24
    y_39        link_39     -3.0
    y_40        OBJ       5.44
    y_40        link_40     -11.0
    y_41        OBJ       4.01
    y_41        link_41     -11.0
    y_42        OBJ       4.32
    y_42        link_42     -7.0
    y_43        OBJ       3.8
    y_43        link_43     -9.0
    y_44        OBJ       2.02
    y_44        link_44     -6.0
    y_45        OBJ       4.49
    y_45        link_45     -6.0
    y_46        OBJ       2.42
    y_46        link_46     -5.0
    y_47        OBJ       3.31
    y_47        link_47     -7.0
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_0      6
    RHS       flow_5      -2
    RHS       flow_10     -2
    RHS       flow_15     -2
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
 BV BOUND     y_42
 BV BOUND     y_43
 BV BOUND     y_44
 BV BOUND     y_45
 BV BOUND     y_46
 BV BOUND     y_47
ENDATA
