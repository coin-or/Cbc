NAME          BPC
ROWS
 N  OBJ
 E  ASSIGN_0
 E  ASSIGN_1
 E  ASSIGN_2
 E  ASSIGN_3
 E  ASSIGN_4
 E  ASSIGN_5
 E  ASSIGN_6
 E  ASSIGN_7
 E  ASSIGN_8
 E  ASSIGN_9
 E  ASSIGN_10
 E  ASSIGN_11
 E  ASSIGN_12
 E  ASSIGN_13
 E  ASSIGN_14
 E  ASSIGN_15
 E  ASSIGN_16
 E  ASSIGN_17
 E  ASSIGN_18
 E  ASSIGN_19
 L  CAP_0
 L  CAP_1
 L  CAP_2
 L  CAP_3
 L  CAP_4
 L  CAP_5
 L  CAP_6
 L  CAP_7
 L  CAP_8
 L  CAP_9
 L  CAP_10
 L  CAP_11
 L  CAP_12
 L  CAP_13
 L  CAP_14
 L  CAP_15
 L  CAP_16
 L  CAP_17
 L  CAP_18
 L  CAP_19
 L  CONF_6_15_0
 L  CONF_6_15_1
 L  CONF_6_15_2
 L  CONF_6_15_3
 L  CONF_6_15_4
 L  CONF_6_15_5
 L  CONF_6_15_6
 L  CONF_6_15_7
 L  CONF_6_15_8
 L  CONF_6_15_9
 L  CONF_6_15_10
 L  CONF_6_15_11
 L  CONF_6_15_12
 L  CONF_6_15_13
 L  CONF_6_15_14
 L  CONF_6_15_15
 L  CONF_6_15_16
 L  CONF_6_15_17
 L  CONF_6_15_18
 L  CONF_6_15_19
 L  CONF_4_12_0
 L  CONF_4_12_1
 L  CONF_4_12_2
 L  CONF_4_12_3
 L  CONF_4_12_4
 L  CONF_4_12_5
 L  CONF_4_12_6
 L  CONF_4_12_7
 L  CONF_4_12_8
 L  CONF_4_12_9
 L  CONF_4_12_10
 L  CONF_4_12_11
 L  CONF_4_12_12
 L  CONF_4_12_13
 L  CONF_4_12_14
 L  CONF_4_12_15
 L  CONF_4_12_16
 L  CONF_4_12_17
 L  CONF_4_12_18
 L  CONF_4_12_19
 L  CONF_14_16_0
 L  CONF_14_16_1
 L  CONF_14_16_2
 L  CONF_14_16_3
 L  CONF_14_16_4
 L  CONF_14_16_5
 L  CONF_14_16_6
 L  CONF_14_16_7
 L  CONF_14_16_8
 L  CONF_14_16_9
 L  CONF_14_16_10
 L  CONF_14_16_11
 L  CONF_14_16_12
 L  CONF_14_16_13
 L  CONF_14_16_14
 L  CONF_14_16_15
 L  CONF_14_16_16
 L  CONF_14_16_17
 L  CONF_14_16_18
 L  CONF_14_16_19
 L  CONF_0_2_0
 L  CONF_0_2_1
 L  CONF_0_2_2
 L  CONF_0_2_3
 L  CONF_0_2_4
 L  CONF_0_2_5
 L  CONF_0_2_6
 L  CONF_0_2_7
 L  CONF_0_2_8
 L  CONF_0_2_9
 L  CONF_0_2_10
 L  CONF_0_2_11
 L  CONF_0_2_12
 L  CONF_0_2_13
 L  CONF_0_2_14
 L  CONF_0_2_15
 L  CONF_0_2_16
 L  CONF_0_2_17
 L  CONF_0_2_18
 L  CONF_0_2_19
 L  CONF_8_9_0
 L  CONF_8_9_1
 L  CONF_8_9_2
 L  CONF_8_9_3
 L  CONF_8_9_4
 L  CONF_8_9_5
 L  CONF_8_9_6
 L  CONF_8_9_7
 L  CONF_8_9_8
 L  CONF_8_9_9
 L  CONF_8_9_10
 L  CONF_8_9_11
 L  CONF_8_9_12
 L  CONF_8_9_13
 L  CONF_8_9_14
 L  CONF_8_9_15
 L  CONF_8_9_16
 L  CONF_8_9_17
 L  CONF_8_9_18
 L  CONF_8_9_19
 L  CONF_8_12_0
 L  CONF_8_12_1
 L  CONF_8_12_2
 L  CONF_8_12_3
 L  CONF_8_12_4
 L  CONF_8_12_5
 L  CONF_8_12_6
 L  CONF_8_12_7
 L  CONF_8_12_8
 L  CONF_8_12_9
 L  CONF_8_12_10
 L  CONF_8_12_11
 L  CONF_8_12_12
 L  CONF_8_12_13
 L  CONF_8_12_14
 L  CONF_8_12_15
 L  CONF_8_12_16
 L  CONF_8_12_17
 L  CONF_8_12_18
 L  CONF_8_12_19
 L  CONF_0_8_0
 L  CONF_0_8_1
 L  CONF_0_8_2
 L  CONF_0_8_3
 L  CONF_0_8_4
 L  CONF_0_8_5
 L  CONF_0_8_6
 L  CONF_0_8_7
 L  CONF_0_8_8
 L  CONF_0_8_9
 L  CONF_0_8_10
 L  CONF_0_8_11
 L  CONF_0_8_12
 L  CONF_0_8_13
 L  CONF_0_8_14
 L  CONF_0_8_15
 L  CONF_0_8_16
 L  CONF_0_8_17
 L  CONF_0_8_18
 L  CONF_0_8_19
 L  CONF_9_17_0
 L  CONF_9_17_1
 L  CONF_9_17_2
 L  CONF_9_17_3
 L  CONF_9_17_4
 L  CONF_9_17_5
 L  CONF_9_17_6
 L  CONF_9_17_7
 L  CONF_9_17_8
 L  CONF_9_17_9
 L  CONF_9_17_10
 L  CONF_9_17_11
 L  CONF_9_17_12
 L  CONF_9_17_13
 L  CONF_9_17_14
 L  CONF_9_17_15
 L  CONF_9_17_16
 L  CONF_9_17_17
 L  CONF_9_17_18
 L  CONF_9_17_19
 L  CONF_1_12_0
 L  CONF_1_12_1
 L  CONF_1_12_2
 L  CONF_1_12_3
 L  CONF_1_12_4
 L  CONF_1_12_5
 L  CONF_1_12_6
 L  CONF_1_12_7
 L  CONF_1_12_8
 L  CONF_1_12_9
 L  CONF_1_12_10
 L  CONF_1_12_11
 L  CONF_1_12_12
 L  CONF_1_12_13
 L  CONF_1_12_14
 L  CONF_1_12_15
 L  CONF_1_12_16
 L  CONF_1_12_17
 L  CONF_1_12_18
 L  CONF_1_12_19
 L  CONF_1_15_0
 L  CONF_1_15_1
 L  CONF_1_15_2
 L  CONF_1_15_3
 L  CONF_1_15_4
 L  CONF_1_15_5
 L  CONF_1_15_6
 L  CONF_1_15_7
 L  CONF_1_15_8
 L  CONF_1_15_9
 L  CONF_1_15_10
 L  CONF_1_15_11
 L  CONF_1_15_12
 L  CONF_1_15_13
 L  CONF_1_15_14
 L  CONF_1_15_15
 L  CONF_1_15_16
 L  CONF_1_15_17
 L  CONF_1_15_18
 L  CONF_1_15_19
 L  CONF_7_10_0
 L  CONF_7_10_1
 L  CONF_7_10_2
 L  CONF_7_10_3
 L  CONF_7_10_4
 L  CONF_7_10_5
 L  CONF_7_10_6
 L  CONF_7_10_7
 L  CONF_7_10_8
 L  CONF_7_10_9
 L  CONF_7_10_10
 L  CONF_7_10_11
 L  CONF_7_10_12
 L  CONF_7_10_13
 L  CONF_7_10_14
 L  CONF_7_10_15
 L  CONF_7_10_16
 L  CONF_7_10_17
 L  CONF_7_10_18
 L  CONF_7_10_19
 L  CONF_12_15_0
 L  CONF_12_15_1
 L  CONF_12_15_2
 L  CONF_12_15_3
 L  CONF_12_15_4
 L  CONF_12_15_5
 L  CONF_12_15_6
 L  CONF_12_15_7
 L  CONF_12_15_8
 L  CONF_12_15_9
 L  CONF_12_15_10
 L  CONF_12_15_11
 L  CONF_12_15_12
 L  CONF_12_15_13
 L  CONF_12_15_14
 L  CONF_12_15_15
 L  CONF_12_15_16
 L  CONF_12_15_17
 L  CONF_12_15_18
 L  CONF_12_15_19
 L  CONF_5_9_0
 L  CONF_5_9_1
 L  CONF_5_9_2
 L  CONF_5_9_3
 L  CONF_5_9_4
 L  CONF_5_9_5
 L  CONF_5_9_6
 L  CONF_5_9_7
 L  CONF_5_9_8
 L  CONF_5_9_9
 L  CONF_5_9_10
 L  CONF_5_9_11
 L  CONF_5_9_12
 L  CONF_5_9_13
 L  CONF_5_9_14
 L  CONF_5_9_15
 L  CONF_5_9_16
 L  CONF_5_9_17
 L  CONF_5_9_18
 L  CONF_5_9_19
 L  CONF_4_11_0
 L  CONF_4_11_1
 L  CONF_4_11_2
 L  CONF_4_11_3
 L  CONF_4_11_4
 L  CONF_4_11_5
 L  CONF_4_11_6
 L  CONF_4_11_7
 L  CONF_4_11_8
 L  CONF_4_11_9
 L  CONF_4_11_10
 L  CONF_4_11_11
 L  CONF_4_11_12
 L  CONF_4_11_13
 L  CONF_4_11_14
 L  CONF_4_11_15
 L  CONF_4_11_16
 L  CONF_4_11_17
 L  CONF_4_11_18
 L  CONF_4_11_19
 L  CONF_4_17_0
 L  CONF_4_17_1
 L  CONF_4_17_2
 L  CONF_4_17_3
 L  CONF_4_17_4
 L  CONF_4_17_5
 L  CONF_4_17_6
 L  CONF_4_17_7
 L  CONF_4_17_8
 L  CONF_4_17_9
 L  CONF_4_17_10
 L  CONF_4_17_11
 L  CONF_4_17_12
 L  CONF_4_17_13
 L  CONF_4_17_14
 L  CONF_4_17_15
 L  CONF_4_17_16
 L  CONF_4_17_17
 L  CONF_4_17_18
 L  CONF_4_17_19
 L  CONF_0_1_0
 L  CONF_0_1_1
 L  CONF_0_1_2
 L  CONF_0_1_3
 L  CONF_0_1_4
 L  CONF_0_1_5
 L  CONF_0_1_6
 L  CONF_0_1_7
 L  CONF_0_1_8
 L  CONF_0_1_9
 L  CONF_0_1_10
 L  CONF_0_1_11
 L  CONF_0_1_12
 L  CONF_0_1_13
 L  CONF_0_1_14
 L  CONF_0_1_15
 L  CONF_0_1_16
 L  CONF_0_1_17
 L  CONF_0_1_18
 L  CONF_0_1_19
 L  CONF_5_15_0
 L  CONF_5_15_1
 L  CONF_5_15_2
 L  CONF_5_15_3
 L  CONF_5_15_4
 L  CONF_5_15_5
 L  CONF_5_15_6
 L  CONF_5_15_7
 L  CONF_5_15_8
 L  CONF_5_15_9
 L  CONF_5_15_10
 L  CONF_5_15_11
 L  CONF_5_15_12
 L  CONF_5_15_13
 L  CONF_5_15_14
 L  CONF_5_15_15
 L  CONF_5_15_16
 L  CONF_5_15_17
 L  CONF_5_15_18
 L  CONF_5_15_19
 L  CONF_0_16_0
 L  CONF_0_16_1
 L  CONF_0_16_2
 L  CONF_0_16_3
 L  CONF_0_16_4
 L  CONF_0_16_5
 L  CONF_0_16_6
 L  CONF_0_16_7
 L  CONF_0_16_8
 L  CONF_0_16_9
 L  CONF_0_16_10
 L  CONF_0_16_11
 L  CONF_0_16_12
 L  CONF_0_16_13
 L  CONF_0_16_14
 L  CONF_0_16_15
 L  CONF_0_16_16
 L  CONF_0_16_17
 L  CONF_0_16_18
 L  CONF_0_16_19
 L  CONF_10_14_0
 L  CONF_10_14_1
 L  CONF_10_14_2
 L  CONF_10_14_3
 L  CONF_10_14_4
 L  CONF_10_14_5
 L  CONF_10_14_6
 L  CONF_10_14_7
 L  CONF_10_14_8
 L  CONF_10_14_9
 L  CONF_10_14_10
 L  CONF_10_14_11
 L  CONF_10_14_12
 L  CONF_10_14_13
 L  CONF_10_14_14
 L  CONF_10_14_15
 L  CONF_10_14_16
 L  CONF_10_14_17
 L  CONF_10_14_18
 L  CONF_10_14_19
 L  CONF_2_10_0
 L  CONF_2_10_1
 L  CONF_2_10_2
 L  CONF_2_10_3
 L  CONF_2_10_4
 L  CONF_2_10_5
 L  CONF_2_10_6
 L  CONF_2_10_7
 L  CONF_2_10_8
 L  CONF_2_10_9
 L  CONF_2_10_10
 L  CONF_2_10_11
 L  CONF_2_10_12
 L  CONF_2_10_13
 L  CONF_2_10_14
 L  CONF_2_10_15
 L  CONF_2_10_16
 L  CONF_2_10_17
 L  CONF_2_10_18
 L  CONF_2_10_19
 L  CONF_13_16_0
 L  CONF_13_16_1
 L  CONF_13_16_2
 L  CONF_13_16_3
 L  CONF_13_16_4
 L  CONF_13_16_5
 L  CONF_13_16_6
 L  CONF_13_16_7
 L  CONF_13_16_8
 L  CONF_13_16_9
 L  CONF_13_16_10
 L  CONF_13_16_11
 L  CONF_13_16_12
 L  CONF_13_16_13
 L  CONF_13_16_14
 L  CONF_13_16_15
 L  CONF_13_16_16
 L  CONF_13_16_17
 L  CONF_13_16_18
 L  CONF_13_16_19
 L  CONF_1_17_0
 L  CONF_1_17_1
 L  CONF_1_17_2
 L  CONF_1_17_3
 L  CONF_1_17_4
 L  CONF_1_17_5
 L  CONF_1_17_6
 L  CONF_1_17_7
 L  CONF_1_17_8
 L  CONF_1_17_9
 L  CONF_1_17_10
 L  CONF_1_17_11
 L  CONF_1_17_12
 L  CONF_1_17_13
 L  CONF_1_17_14
 L  CONF_1_17_15
 L  CONF_1_17_16
 L  CONF_1_17_17
 L  CONF_1_17_18
 L  CONF_1_17_19
 L  CONF_16_18_0
 L  CONF_16_18_1
 L  CONF_16_18_2
 L  CONF_16_18_3
 L  CONF_16_18_4
 L  CONF_16_18_5
 L  CONF_16_18_6
 L  CONF_16_18_7
 L  CONF_16_18_8
 L  CONF_16_18_9
 L  CONF_16_18_10
 L  CONF_16_18_11
 L  CONF_16_18_12
 L  CONF_16_18_13
 L  CONF_16_18_14
 L  CONF_16_18_15
 L  CONF_16_18_16
 L  CONF_16_18_17
 L  CONF_16_18_18
 L  CONF_16_18_19
 L  CONF_7_15_0
 L  CONF_7_15_1
 L  CONF_7_15_2
 L  CONF_7_15_3
 L  CONF_7_15_4
 L  CONF_7_15_5
 L  CONF_7_15_6
 L  CONF_7_15_7
 L  CONF_7_15_8
 L  CONF_7_15_9
 L  CONF_7_15_10
 L  CONF_7_15_11
 L  CONF_7_15_12
 L  CONF_7_15_13
 L  CONF_7_15_14
 L  CONF_7_15_15
 L  CONF_7_15_16
 L  CONF_7_15_17
 L  CONF_7_15_18
 L  CONF_7_15_19
 L  CONF_7_18_0
 L  CONF_7_18_1
 L  CONF_7_18_2
 L  CONF_7_18_3
 L  CONF_7_18_4
 L  CONF_7_18_5
 L  CONF_7_18_6
 L  CONF_7_18_7
 L  CONF_7_18_8
 L  CONF_7_18_9
 L  CONF_7_18_10
 L  CONF_7_18_11
 L  CONF_7_18_12
 L  CONF_7_18_13
 L  CONF_7_18_14
 L  CONF_7_18_15
 L  CONF_7_18_16
 L  CONF_7_18_17
 L  CONF_7_18_18
 L  CONF_7_18_19
 L  CONF_3_5_0
 L  CONF_3_5_1
 L  CONF_3_5_2
 L  CONF_3_5_3
 L  CONF_3_5_4
 L  CONF_3_5_5
 L  CONF_3_5_6
 L  CONF_3_5_7
 L  CONF_3_5_8
 L  CONF_3_5_9
 L  CONF_3_5_10
 L  CONF_3_5_11
 L  CONF_3_5_12
 L  CONF_3_5_13
 L  CONF_3_5_14
 L  CONF_3_5_15
 L  CONF_3_5_16
 L  CONF_3_5_17
 L  CONF_3_5_18
 L  CONF_3_5_19
 L  CONF_12_14_0
 L  CONF_12_14_1
 L  CONF_12_14_2
 L  CONF_12_14_3
 L  CONF_12_14_4
 L  CONF_12_14_5
 L  CONF_12_14_6
 L  CONF_12_14_7
 L  CONF_12_14_8
 L  CONF_12_14_9
 L  CONF_12_14_10
 L  CONF_12_14_11
 L  CONF_12_14_12
 L  CONF_12_14_13
 L  CONF_12_14_14
 L  CONF_12_14_15
 L  CONF_12_14_16
 L  CONF_12_14_17
 L  CONF_12_14_18
 L  CONF_12_14_19
 L  CONF_4_13_0
 L  CONF_4_13_1
 L  CONF_4_13_2
 L  CONF_4_13_3
 L  CONF_4_13_4
 L  CONF_4_13_5
 L  CONF_4_13_6
 L  CONF_4_13_7
 L  CONF_4_13_8
 L  CONF_4_13_9
 L  CONF_4_13_10
 L  CONF_4_13_11
 L  CONF_4_13_12
 L  CONF_4_13_13
 L  CONF_4_13_14
 L  CONF_4_13_15
 L  CONF_4_13_16
 L  CONF_4_13_17
 L  CONF_4_13_18
 L  CONF_4_13_19
 L  CONF_0_12_0
 L  CONF_0_12_1
 L  CONF_0_12_2
 L  CONF_0_12_3
 L  CONF_0_12_4
 L  CONF_0_12_5
 L  CONF_0_12_6
 L  CONF_0_12_7
 L  CONF_0_12_8
 L  CONF_0_12_9
 L  CONF_0_12_10
 L  CONF_0_12_11
 L  CONF_0_12_12
 L  CONF_0_12_13
 L  CONF_0_12_14
 L  CONF_0_12_15
 L  CONF_0_12_16
 L  CONF_0_12_17
 L  CONF_0_12_18
 L  CONF_0_12_19
 L  CONF_0_15_0
 L  CONF_0_15_1
 L  CONF_0_15_2
 L  CONF_0_15_3
 L  CONF_0_15_4
 L  CONF_0_15_5
 L  CONF_0_15_6
 L  CONF_0_15_7
 L  CONF_0_15_8
 L  CONF_0_15_9
 L  CONF_0_15_10
 L  CONF_0_15_11
 L  CONF_0_15_12
 L  CONF_0_15_13
 L  CONF_0_15_14
 L  CONF_0_15_15
 L  CONF_0_15_16
 L  CONF_0_15_17
 L  CONF_0_15_18
 L  CONF_0_15_19
 L  CONF_2_12_0
 L  CONF_2_12_1
 L  CONF_2_12_2
 L  CONF_2_12_3
 L  CONF_2_12_4
 L  CONF_2_12_5
 L  CONF_2_12_6
 L  CONF_2_12_7
 L  CONF_2_12_8
 L  CONF_2_12_9
 L  CONF_2_12_10
 L  CONF_2_12_11
 L  CONF_2_12_12
 L  CONF_2_12_13
 L  CONF_2_12_14
 L  CONF_2_12_15
 L  CONF_2_12_16
 L  CONF_2_12_17
 L  CONF_2_12_18
 L  CONF_2_12_19
 L  CONF_10_19_0
 L  CONF_10_19_1
 L  CONF_10_19_2
 L  CONF_10_19_3
 L  CONF_10_19_4
 L  CONF_10_19_5
 L  CONF_10_19_6
 L  CONF_10_19_7
 L  CONF_10_19_8
 L  CONF_10_19_9
 L  CONF_10_19_10
 L  CONF_10_19_11
 L  CONF_10_19_12
 L  CONF_10_19_13
 L  CONF_10_19_14
 L  CONF_10_19_15
 L  CONF_10_19_16
 L  CONF_10_19_17
 L  CONF_10_19_18
 L  CONF_10_19_19
 L  CONF_11_15_0
 L  CONF_11_15_1
 L  CONF_11_15_2
 L  CONF_11_15_3
 L  CONF_11_15_4
 L  CONF_11_15_5
 L  CONF_11_15_6
 L  CONF_11_15_7
 L  CONF_11_15_8
 L  CONF_11_15_9
 L  CONF_11_15_10
 L  CONF_11_15_11
 L  CONF_11_15_12
 L  CONF_11_15_13
 L  CONF_11_15_14
 L  CONF_11_15_15
 L  CONF_11_15_16
 L  CONF_11_15_17
 L  CONF_11_15_18
 L  CONF_11_15_19
 L  CONF_6_9_0
 L  CONF_6_9_1
 L  CONF_6_9_2
 L  CONF_6_9_3
 L  CONF_6_9_4
 L  CONF_6_9_5
 L  CONF_6_9_6
 L  CONF_6_9_7
 L  CONF_6_9_8
 L  CONF_6_9_9
 L  CONF_6_9_10
 L  CONF_6_9_11
 L  CONF_6_9_12
 L  CONF_6_9_13
 L  CONF_6_9_14
 L  CONF_6_9_15
 L  CONF_6_9_16
 L  CONF_6_9_17
 L  CONF_6_9_18
 L  CONF_6_9_19
 L  CONF_7_8_0
 L  CONF_7_8_1
 L  CONF_7_8_2
 L  CONF_7_8_3
 L  CONF_7_8_4
 L  CONF_7_8_5
 L  CONF_7_8_6
 L  CONF_7_8_7
 L  CONF_7_8_8
 L  CONF_7_8_9
 L  CONF_7_8_10
 L  CONF_7_8_11
 L  CONF_7_8_12
 L  CONF_7_8_13
 L  CONF_7_8_14
 L  CONF_7_8_15
 L  CONF_7_8_16
 L  CONF_7_8_17
 L  CONF_7_8_18
 L  CONF_7_8_19
COLUMNS
    y_0         OBJ       1.0
    y_1         OBJ       1.0
    y_2         OBJ       1.0
    y_3         OBJ       1.0
    y_4         OBJ       1.0
    y_5         OBJ       1.0
    y_6         OBJ       1.0
    y_7         OBJ       1.0
    y_8         OBJ       1.0
    y_9         OBJ       1.0
    y_10        OBJ       1.0
    y_11        OBJ       1.0
    y_12        OBJ       1.0
    y_13        OBJ       1.0
    y_14        OBJ       1.0
    y_15        OBJ       1.0
    y_16        OBJ       1.0
    y_17        OBJ       1.0
    y_18        OBJ       1.0
    y_19        OBJ       1.0
    x_0_0       ASSIGN_0  1.0
    x_0_0       CAP_0  8
    x_0_0       CONF_0_1_0  1.0
    x_0_0       CONF_0_2_0  1.0
    x_0_0       CONF_0_8_0  1.0
    x_0_0       CONF_0_12_0  1.0
    x_0_0       CONF_0_15_0  1.0
    x_0_0       CONF_0_16_0  1.0
    x_0_1       ASSIGN_0  1.0
    x_0_1       CAP_1  8
    x_0_1       CONF_0_1_1  1.0
    x_0_1       CONF_0_2_1  1.0
    x_0_1       CONF_0_8_1  1.0
    x_0_1       CONF_0_12_1  1.0
    x_0_1       CONF_0_15_1  1.0
    x_0_1       CONF_0_16_1  1.0
    x_0_2       ASSIGN_0  1.0
    x_0_2       CAP_2  8
    x_0_2       CONF_0_1_2  1.0
    x_0_2       CONF_0_2_2  1.0
    x_0_2       CONF_0_8_2  1.0
    x_0_2       CONF_0_12_2  1.0
    x_0_2       CONF_0_15_2  1.0
    x_0_2       CONF_0_16_2  1.0
    x_0_3       ASSIGN_0  1.0
    x_0_3       CAP_3  8
    x_0_3       CONF_0_1_3  1.0
    x_0_3       CONF_0_2_3  1.0
    x_0_3       CONF_0_8_3  1.0
    x_0_3       CONF_0_12_3  1.0
    x_0_3       CONF_0_15_3  1.0
    x_0_3       CONF_0_16_3  1.0
    x_0_4       ASSIGN_0  1.0
    x_0_4       CAP_4  8
    x_0_4       CONF_0_1_4  1.0
    x_0_4       CONF_0_2_4  1.0
    x_0_4       CONF_0_8_4  1.0
    x_0_4       CONF_0_12_4  1.0
    x_0_4       CONF_0_15_4  1.0
    x_0_4       CONF_0_16_4  1.0
    x_0_5       ASSIGN_0  1.0
    x_0_5       CAP_5  8
    x_0_5       CONF_0_1_5  1.0
    x_0_5       CONF_0_2_5  1.0
    x_0_5       CONF_0_8_5  1.0
    x_0_5       CONF_0_12_5  1.0
    x_0_5       CONF_0_15_5  1.0
    x_0_5       CONF_0_16_5  1.0
    x_0_6       ASSIGN_0  1.0
    x_0_6       CAP_6  8
    x_0_6       CONF_0_1_6  1.0
    x_0_6       CONF_0_2_6  1.0
    x_0_6       CONF_0_8_6  1.0
    x_0_6       CONF_0_12_6  1.0
    x_0_6       CONF_0_15_6  1.0
    x_0_6       CONF_0_16_6  1.0
    x_0_7       ASSIGN_0  1.0
    x_0_7       CAP_7  8
    x_0_7       CONF_0_1_7  1.0
    x_0_7       CONF_0_2_7  1.0
    x_0_7       CONF_0_8_7  1.0
    x_0_7       CONF_0_12_7  1.0
    x_0_7       CONF_0_15_7  1.0
    x_0_7       CONF_0_16_7  1.0
    x_0_8       ASSIGN_0  1.0
    x_0_8       CAP_8  8
    x_0_8       CONF_0_1_8  1.0
    x_0_8       CONF_0_2_8  1.0
    x_0_8       CONF_0_8_8  1.0
    x_0_8       CONF_0_12_8  1.0
    x_0_8       CONF_0_15_8  1.0
    x_0_8       CONF_0_16_8  1.0
    x_0_9       ASSIGN_0  1.0
    x_0_9       CAP_9  8
    x_0_9       CONF_0_1_9  1.0
    x_0_9       CONF_0_2_9  1.0
    x_0_9       CONF_0_8_9  1.0
    x_0_9       CONF_0_12_9  1.0
    x_0_9       CONF_0_15_9  1.0
    x_0_9       CONF_0_16_9  1.0
    x_0_10      ASSIGN_0  1.0
    x_0_10      CAP_10  8
    x_0_10      CONF_0_1_10  1.0
    x_0_10      CONF_0_2_10  1.0
    x_0_10      CONF_0_8_10  1.0
    x_0_10      CONF_0_12_10  1.0
    x_0_10      CONF_0_15_10  1.0
    x_0_10      CONF_0_16_10  1.0
    x_0_11      ASSIGN_0  1.0
    x_0_11      CAP_11  8
    x_0_11      CONF_0_1_11  1.0
    x_0_11      CONF_0_2_11  1.0
    x_0_11      CONF_0_8_11  1.0
    x_0_11      CONF_0_12_11  1.0
    x_0_11      CONF_0_15_11  1.0
    x_0_11      CONF_0_16_11  1.0
    x_0_12      ASSIGN_0  1.0
    x_0_12      CAP_12  8
    x_0_12      CONF_0_1_12  1.0
    x_0_12      CONF_0_2_12  1.0
    x_0_12      CONF_0_8_12  1.0
    x_0_12      CONF_0_12_12  1.0
    x_0_12      CONF_0_15_12  1.0
    x_0_12      CONF_0_16_12  1.0
    x_0_13      ASSIGN_0  1.0
    x_0_13      CAP_13  8
    x_0_13      CONF_0_1_13  1.0
    x_0_13      CONF_0_2_13  1.0
    x_0_13      CONF_0_8_13  1.0
    x_0_13      CONF_0_12_13  1.0
    x_0_13      CONF_0_15_13  1.0
    x_0_13      CONF_0_16_13  1.0
    x_0_14      ASSIGN_0  1.0
    x_0_14      CAP_14  8
    x_0_14      CONF_0_1_14  1.0
    x_0_14      CONF_0_2_14  1.0
    x_0_14      CONF_0_8_14  1.0
    x_0_14      CONF_0_12_14  1.0
    x_0_14      CONF_0_15_14  1.0
    x_0_14      CONF_0_16_14  1.0
    x_0_15      ASSIGN_0  1.0
    x_0_15      CAP_15  8
    x_0_15      CONF_0_1_15  1.0
    x_0_15      CONF_0_2_15  1.0
    x_0_15      CONF_0_8_15  1.0
    x_0_15      CONF_0_12_15  1.0
    x_0_15      CONF_0_15_15  1.0
    x_0_15      CONF_0_16_15  1.0
    x_0_16      ASSIGN_0  1.0
    x_0_16      CAP_16  8
    x_0_16      CONF_0_1_16  1.0
    x_0_16      CONF_0_2_16  1.0
    x_0_16      CONF_0_8_16  1.0
    x_0_16      CONF_0_12_16  1.0
    x_0_16      CONF_0_15_16  1.0
    x_0_16      CONF_0_16_16  1.0
    x_0_17      ASSIGN_0  1.0
    x_0_17      CAP_17  8
    x_0_17      CONF_0_1_17  1.0
    x_0_17      CONF_0_2_17  1.0
    x_0_17      CONF_0_8_17  1.0
    x_0_17      CONF_0_12_17  1.0
    x_0_17      CONF_0_15_17  1.0
    x_0_17      CONF_0_16_17  1.0
    x_0_18      ASSIGN_0  1.0
    x_0_18      CAP_18  8
    x_0_18      CONF_0_1_18  1.0
    x_0_18      CONF_0_2_18  1.0
    x_0_18      CONF_0_8_18  1.0
    x_0_18      CONF_0_12_18  1.0
    x_0_18      CONF_0_15_18  1.0
    x_0_18      CONF_0_16_18  1.0
    x_0_19      ASSIGN_0  1.0
    x_0_19      CAP_19  8
    x_0_19      CONF_0_1_19  1.0
    x_0_19      CONF_0_2_19  1.0
    x_0_19      CONF_0_8_19  1.0
    x_0_19      CONF_0_12_19  1.0
    x_0_19      CONF_0_15_19  1.0
    x_0_19      CONF_0_16_19  1.0
    x_1_0       ASSIGN_1  1.0
    x_1_0       CAP_0  30
    x_1_0       CONF_0_1_0  1.0
    x_1_0       CONF_1_12_0  1.0
    x_1_0       CONF_1_15_0  1.0
    x_1_0       CONF_1_17_0  1.0
    x_1_1       ASSIGN_1  1.0
    x_1_1       CAP_1  30
    x_1_1       CONF_0_1_1  1.0
    x_1_1       CONF_1_12_1  1.0
    x_1_1       CONF_1_15_1  1.0
    x_1_1       CONF_1_17_1  1.0
    x_1_2       ASSIGN_1  1.0
    x_1_2       CAP_2  30
    x_1_2       CONF_0_1_2  1.0
    x_1_2       CONF_1_12_2  1.0
    x_1_2       CONF_1_15_2  1.0
    x_1_2       CONF_1_17_2  1.0
    x_1_3       ASSIGN_1  1.0
    x_1_3       CAP_3  30
    x_1_3       CONF_0_1_3  1.0
    x_1_3       CONF_1_12_3  1.0
    x_1_3       CONF_1_15_3  1.0
    x_1_3       CONF_1_17_3  1.0
    x_1_4       ASSIGN_1  1.0
    x_1_4       CAP_4  30
    x_1_4       CONF_0_1_4  1.0
    x_1_4       CONF_1_12_4  1.0
    x_1_4       CONF_1_15_4  1.0
    x_1_4       CONF_1_17_4  1.0
    x_1_5       ASSIGN_1  1.0
    x_1_5       CAP_5  30
    x_1_5       CONF_0_1_5  1.0
    x_1_5       CONF_1_12_5  1.0
    x_1_5       CONF_1_15_5  1.0
    x_1_5       CONF_1_17_5  1.0
    x_1_6       ASSIGN_1  1.0
    x_1_6       CAP_6  30
    x_1_6       CONF_0_1_6  1.0
    x_1_6       CONF_1_12_6  1.0
    x_1_6       CONF_1_15_6  1.0
    x_1_6       CONF_1_17_6  1.0
    x_1_7       ASSIGN_1  1.0
    x_1_7       CAP_7  30
    x_1_7       CONF_0_1_7  1.0
    x_1_7       CONF_1_12_7  1.0
    x_1_7       CONF_1_15_7  1.0
    x_1_7       CONF_1_17_7  1.0
    x_1_8       ASSIGN_1  1.0
    x_1_8       CAP_8  30
    x_1_8       CONF_0_1_8  1.0
    x_1_8       CONF_1_12_8  1.0
    x_1_8       CONF_1_15_8  1.0
    x_1_8       CONF_1_17_8  1.0
    x_1_9       ASSIGN_1  1.0
    x_1_9       CAP_9  30
    x_1_9       CONF_0_1_9  1.0
    x_1_9       CONF_1_12_9  1.0
    x_1_9       CONF_1_15_9  1.0
    x_1_9       CONF_1_17_9  1.0
    x_1_10      ASSIGN_1  1.0
    x_1_10      CAP_10  30
    x_1_10      CONF_0_1_10  1.0
    x_1_10      CONF_1_12_10  1.0
    x_1_10      CONF_1_15_10  1.0
    x_1_10      CONF_1_17_10  1.0
    x_1_11      ASSIGN_1  1.0
    x_1_11      CAP_11  30
    x_1_11      CONF_0_1_11  1.0
    x_1_11      CONF_1_12_11  1.0
    x_1_11      CONF_1_15_11  1.0
    x_1_11      CONF_1_17_11  1.0
    x_1_12      ASSIGN_1  1.0
    x_1_12      CAP_12  30
    x_1_12      CONF_0_1_12  1.0
    x_1_12      CONF_1_12_12  1.0
    x_1_12      CONF_1_15_12  1.0
    x_1_12      CONF_1_17_12  1.0
    x_1_13      ASSIGN_1  1.0
    x_1_13      CAP_13  30
    x_1_13      CONF_0_1_13  1.0
    x_1_13      CONF_1_12_13  1.0
    x_1_13      CONF_1_15_13  1.0
    x_1_13      CONF_1_17_13  1.0
    x_1_14      ASSIGN_1  1.0
    x_1_14      CAP_14  30
    x_1_14      CONF_0_1_14  1.0
    x_1_14      CONF_1_12_14  1.0
    x_1_14      CONF_1_15_14  1.0
    x_1_14      CONF_1_17_14  1.0
    x_1_15      ASSIGN_1  1.0
    x_1_15      CAP_15  30
    x_1_15      CONF_0_1_15  1.0
    x_1_15      CONF_1_12_15  1.0
    x_1_15      CONF_1_15_15  1.0
    x_1_15      CONF_1_17_15  1.0
    x_1_16      ASSIGN_1  1.0
    x_1_16      CAP_16  30
    x_1_16      CONF_0_1_16  1.0
    x_1_16      CONF_1_12_16  1.0
    x_1_16      CONF_1_15_16  1.0
    x_1_16      CONF_1_17_16  1.0
    x_1_17      ASSIGN_1  1.0
    x_1_17      CAP_17  30
    x_1_17      CONF_0_1_17  1.0
    x_1_17      CONF_1_12_17  1.0
    x_1_17      CONF_1_15_17  1.0
    x_1_17      CONF_1_17_17  1.0
    x_1_18      ASSIGN_1  1.0
    x_1_18      CAP_18  30
    x_1_18      CONF_0_1_18  1.0
    x_1_18      CONF_1_12_18  1.0
    x_1_18      CONF_1_15_18  1.0
    x_1_18      CONF_1_17_18  1.0
    x_1_19      ASSIGN_1  1.0
    x_1_19      CAP_19  30
    x_1_19      CONF_0_1_19  1.0
    x_1_19      CONF_1_12_19  1.0
    x_1_19      CONF_1_15_19  1.0
    x_1_19      CONF_1_17_19  1.0
    x_2_0       ASSIGN_2  1.0
    x_2_0       CAP_0  98
    x_2_0       CONF_0_2_0  1.0
    x_2_0       CONF_2_10_0  1.0
    x_2_0       CONF_2_12_0  1.0
    x_2_1       ASSIGN_2  1.0
    x_2_1       CAP_1  98
    x_2_1       CONF_0_2_1  1.0
    x_2_1       CONF_2_10_1  1.0
    x_2_1       CONF_2_12_1  1.0
    x_2_2       ASSIGN_2  1.0
    x_2_2       CAP_2  98
    x_2_2       CONF_0_2_2  1.0
    x_2_2       CONF_2_10_2  1.0
    x_2_2       CONF_2_12_2  1.0
    x_2_3       ASSIGN_2  1.0
    x_2_3       CAP_3  98
    x_2_3       CONF_0_2_3  1.0
    x_2_3       CONF_2_10_3  1.0
    x_2_3       CONF_2_12_3  1.0
    x_2_4       ASSIGN_2  1.0
    x_2_4       CAP_4  98
    x_2_4       CONF_0_2_4  1.0
    x_2_4       CONF_2_10_4  1.0
    x_2_4       CONF_2_12_4  1.0
    x_2_5       ASSIGN_2  1.0
    x_2_5       CAP_5  98
    x_2_5       CONF_0_2_5  1.0
    x_2_5       CONF_2_10_5  1.0
    x_2_5       CONF_2_12_5  1.0
    x_2_6       ASSIGN_2  1.0
    x_2_6       CAP_6  98
    x_2_6       CONF_0_2_6  1.0
    x_2_6       CONF_2_10_6  1.0
    x_2_6       CONF_2_12_6  1.0
    x_2_7       ASSIGN_2  1.0
    x_2_7       CAP_7  98
    x_2_7       CONF_0_2_7  1.0
    x_2_7       CONF_2_10_7  1.0
    x_2_7       CONF_2_12_7  1.0
    x_2_8       ASSIGN_2  1.0
    x_2_8       CAP_8  98
    x_2_8       CONF_0_2_8  1.0
    x_2_8       CONF_2_10_8  1.0
    x_2_8       CONF_2_12_8  1.0
    x_2_9       ASSIGN_2  1.0
    x_2_9       CAP_9  98
    x_2_9       CONF_0_2_9  1.0
    x_2_9       CONF_2_10_9  1.0
    x_2_9       CONF_2_12_9  1.0
    x_2_10      ASSIGN_2  1.0
    x_2_10      CAP_10  98
    x_2_10      CONF_0_2_10  1.0
    x_2_10      CONF_2_10_10  1.0
    x_2_10      CONF_2_12_10  1.0
    x_2_11      ASSIGN_2  1.0
    x_2_11      CAP_11  98
    x_2_11      CONF_0_2_11  1.0
    x_2_11      CONF_2_10_11  1.0
    x_2_11      CONF_2_12_11  1.0
    x_2_12      ASSIGN_2  1.0
    x_2_12      CAP_12  98
    x_2_12      CONF_0_2_12  1.0
    x_2_12      CONF_2_10_12  1.0
    x_2_12      CONF_2_12_12  1.0
    x_2_13      ASSIGN_2  1.0
    x_2_13      CAP_13  98
    x_2_13      CONF_0_2_13  1.0
    x_2_13      CONF_2_10_13  1.0
    x_2_13      CONF_2_12_13  1.0
    x_2_14      ASSIGN_2  1.0
    x_2_14      CAP_14  98
    x_2_14      CONF_0_2_14  1.0
    x_2_14      CONF_2_10_14  1.0
    x_2_14      CONF_2_12_14  1.0
    x_2_15      ASSIGN_2  1.0
    x_2_15      CAP_15  98
    x_2_15      CONF_0_2_15  1.0
    x_2_15      CONF_2_10_15  1.0
    x_2_15      CONF_2_12_15  1.0
    x_2_16      ASSIGN_2  1.0
    x_2_16      CAP_16  98
    x_2_16      CONF_0_2_16  1.0
    x_2_16      CONF_2_10_16  1.0
    x_2_16      CONF_2_12_16  1.0
    x_2_17      ASSIGN_2  1.0
    x_2_17      CAP_17  98
    x_2_17      CONF_0_2_17  1.0
    x_2_17      CONF_2_10_17  1.0
    x_2_17      CONF_2_12_17  1.0
    x_2_18      ASSIGN_2  1.0
    x_2_18      CAP_18  98
    x_2_18      CONF_0_2_18  1.0
    x_2_18      CONF_2_10_18  1.0
    x_2_18      CONF_2_12_18  1.0
    x_2_19      ASSIGN_2  1.0
    x_2_19      CAP_19  98
    x_2_19      CONF_0_2_19  1.0
    x_2_19      CONF_2_10_19  1.0
    x_2_19      CONF_2_12_19  1.0
    x_3_0       ASSIGN_3  1.0
    x_3_0       CAP_0  11
    x_3_0       CONF_3_5_0  1.0
    x_3_1       ASSIGN_3  1.0
    x_3_1       CAP_1  11
    x_3_1       CONF_3_5_1  1.0
    x_3_2       ASSIGN_3  1.0
    x_3_2       CAP_2  11
    x_3_2       CONF_3_5_2  1.0
    x_3_3       ASSIGN_3  1.0
    x_3_3       CAP_3  11
    x_3_3       CONF_3_5_3  1.0
    x_3_4       ASSIGN_3  1.0
    x_3_4       CAP_4  11
    x_3_4       CONF_3_5_4  1.0
    x_3_5       ASSIGN_3  1.0
    x_3_5       CAP_5  11
    x_3_5       CONF_3_5_5  1.0
    x_3_6       ASSIGN_3  1.0
    x_3_6       CAP_6  11
    x_3_6       CONF_3_5_6  1.0
    x_3_7       ASSIGN_3  1.0
    x_3_7       CAP_7  11
    x_3_7       CONF_3_5_7  1.0
    x_3_8       ASSIGN_3  1.0
    x_3_8       CAP_8  11
    x_3_8       CONF_3_5_8  1.0
    x_3_9       ASSIGN_3  1.0
    x_3_9       CAP_9  11
    x_3_9       CONF_3_5_9  1.0
    x_3_10      ASSIGN_3  1.0
    x_3_10      CAP_10  11
    x_3_10      CONF_3_5_10  1.0
    x_3_11      ASSIGN_3  1.0
    x_3_11      CAP_11  11
    x_3_11      CONF_3_5_11  1.0
    x_3_12      ASSIGN_3  1.0
    x_3_12      CAP_12  11
    x_3_12      CONF_3_5_12  1.0
    x_3_13      ASSIGN_3  1.0
    x_3_13      CAP_13  11
    x_3_13      CONF_3_5_13  1.0
    x_3_14      ASSIGN_3  1.0
    x_3_14      CAP_14  11
    x_3_14      CONF_3_5_14  1.0
    x_3_15      ASSIGN_3  1.0
    x_3_15      CAP_15  11
    x_3_15      CONF_3_5_15  1.0
    x_3_16      ASSIGN_3  1.0
    x_3_16      CAP_16  11
    x_3_16      CONF_3_5_16  1.0
    x_3_17      ASSIGN_3  1.0
    x_3_17      CAP_17  11
    x_3_17      CONF_3_5_17  1.0
    x_3_18      ASSIGN_3  1.0
    x_3_18      CAP_18  11
    x_3_18      CONF_3_5_18  1.0
    x_3_19      ASSIGN_3  1.0
    x_3_19      CAP_19  11
    x_3_19      CONF_3_5_19  1.0
    x_4_0       ASSIGN_4  1.0
    x_4_0       CAP_0  37
    x_4_0       CONF_4_11_0  1.0
    x_4_0       CONF_4_12_0  1.0
    x_4_0       CONF_4_13_0  1.0
    x_4_0       CONF_4_17_0  1.0
    x_4_1       ASSIGN_4  1.0
    x_4_1       CAP_1  37
    x_4_1       CONF_4_11_1  1.0
    x_4_1       CONF_4_12_1  1.0
    x_4_1       CONF_4_13_1  1.0
    x_4_1       CONF_4_17_1  1.0
    x_4_2       ASSIGN_4  1.0
    x_4_2       CAP_2  37
    x_4_2       CONF_4_11_2  1.0
    x_4_2       CONF_4_12_2  1.0
    x_4_2       CONF_4_13_2  1.0
    x_4_2       CONF_4_17_2  1.0
    x_4_3       ASSIGN_4  1.0
    x_4_3       CAP_3  37
    x_4_3       CONF_4_11_3  1.0
    x_4_3       CONF_4_12_3  1.0
    x_4_3       CONF_4_13_3  1.0
    x_4_3       CONF_4_17_3  1.0
    x_4_4       ASSIGN_4  1.0
    x_4_4       CAP_4  37
    x_4_4       CONF_4_11_4  1.0
    x_4_4       CONF_4_12_4  1.0
    x_4_4       CONF_4_13_4  1.0
    x_4_4       CONF_4_17_4  1.0
    x_4_5       ASSIGN_4  1.0
    x_4_5       CAP_5  37
    x_4_5       CONF_4_11_5  1.0
    x_4_5       CONF_4_12_5  1.0
    x_4_5       CONF_4_13_5  1.0
    x_4_5       CONF_4_17_5  1.0
    x_4_6       ASSIGN_4  1.0
    x_4_6       CAP_6  37
    x_4_6       CONF_4_11_6  1.0
    x_4_6       CONF_4_12_6  1.0
    x_4_6       CONF_4_13_6  1.0
    x_4_6       CONF_4_17_6  1.0
    x_4_7       ASSIGN_4  1.0
    x_4_7       CAP_7  37
    x_4_7       CONF_4_11_7  1.0
    x_4_7       CONF_4_12_7  1.0
    x_4_7       CONF_4_13_7  1.0
    x_4_7       CONF_4_17_7  1.0
    x_4_8       ASSIGN_4  1.0
    x_4_8       CAP_8  37
    x_4_8       CONF_4_11_8  1.0
    x_4_8       CONF_4_12_8  1.0
    x_4_8       CONF_4_13_8  1.0
    x_4_8       CONF_4_17_8  1.0
    x_4_9       ASSIGN_4  1.0
    x_4_9       CAP_9  37
    x_4_9       CONF_4_11_9  1.0
    x_4_9       CONF_4_12_9  1.0
    x_4_9       CONF_4_13_9  1.0
    x_4_9       CONF_4_17_9  1.0
    x_4_10      ASSIGN_4  1.0
    x_4_10      CAP_10  37
    x_4_10      CONF_4_11_10  1.0
    x_4_10      CONF_4_12_10  1.0
    x_4_10      CONF_4_13_10  1.0
    x_4_10      CONF_4_17_10  1.0
    x_4_11      ASSIGN_4  1.0
    x_4_11      CAP_11  37
    x_4_11      CONF_4_11_11  1.0
    x_4_11      CONF_4_12_11  1.0
    x_4_11      CONF_4_13_11  1.0
    x_4_11      CONF_4_17_11  1.0
    x_4_12      ASSIGN_4  1.0
    x_4_12      CAP_12  37
    x_4_12      CONF_4_11_12  1.0
    x_4_12      CONF_4_12_12  1.0
    x_4_12      CONF_4_13_12  1.0
    x_4_12      CONF_4_17_12  1.0
    x_4_13      ASSIGN_4  1.0
    x_4_13      CAP_13  37
    x_4_13      CONF_4_11_13  1.0
    x_4_13      CONF_4_12_13  1.0
    x_4_13      CONF_4_13_13  1.0
    x_4_13      CONF_4_17_13  1.0
    x_4_14      ASSIGN_4  1.0
    x_4_14      CAP_14  37
    x_4_14      CONF_4_11_14  1.0
    x_4_14      CONF_4_12_14  1.0
    x_4_14      CONF_4_13_14  1.0
    x_4_14      CONF_4_17_14  1.0
    x_4_15      ASSIGN_4  1.0
    x_4_15      CAP_15  37
    x_4_15      CONF_4_11_15  1.0
    x_4_15      CONF_4_12_15  1.0
    x_4_15      CONF_4_13_15  1.0
    x_4_15      CONF_4_17_15  1.0
    x_4_16      ASSIGN_4  1.0
    x_4_16      CAP_16  37
    x_4_16      CONF_4_11_16  1.0
    x_4_16      CONF_4_12_16  1.0
    x_4_16      CONF_4_13_16  1.0
    x_4_16      CONF_4_17_16  1.0
    x_4_17      ASSIGN_4  1.0
    x_4_17      CAP_17  37
    x_4_17      CONF_4_11_17  1.0
    x_4_17      CONF_4_12_17  1.0
    x_4_17      CONF_4_13_17  1.0
    x_4_17      CONF_4_17_17  1.0
    x_4_18      ASSIGN_4  1.0
    x_4_18      CAP_18  37
    x_4_18      CONF_4_11_18  1.0
    x_4_18      CONF_4_12_18  1.0
    x_4_18      CONF_4_13_18  1.0
    x_4_18      CONF_4_17_18  1.0
    x_4_19      ASSIGN_4  1.0
    x_4_19      CAP_19  37
    x_4_19      CONF_4_11_19  1.0
    x_4_19      CONF_4_12_19  1.0
    x_4_19      CONF_4_13_19  1.0
    x_4_19      CONF_4_17_19  1.0
    x_5_0       ASSIGN_5  1.0
    x_5_0       CAP_0  82
    x_5_0       CONF_3_5_0  1.0
    x_5_0       CONF_5_9_0  1.0
    x_5_0       CONF_5_15_0  1.0
    x_5_1       ASSIGN_5  1.0
    x_5_1       CAP_1  82
    x_5_1       CONF_3_5_1  1.0
    x_5_1       CONF_5_9_1  1.0
    x_5_1       CONF_5_15_1  1.0
    x_5_2       ASSIGN_5  1.0
    x_5_2       CAP_2  82
    x_5_2       CONF_3_5_2  1.0
    x_5_2       CONF_5_9_2  1.0
    x_5_2       CONF_5_15_2  1.0
    x_5_3       ASSIGN_5  1.0
    x_5_3       CAP_3  82
    x_5_3       CONF_3_5_3  1.0
    x_5_3       CONF_5_9_3  1.0
    x_5_3       CONF_5_15_3  1.0
    x_5_4       ASSIGN_5  1.0
    x_5_4       CAP_4  82
    x_5_4       CONF_3_5_4  1.0
    x_5_4       CONF_5_9_4  1.0
    x_5_4       CONF_5_15_4  1.0
    x_5_5       ASSIGN_5  1.0
    x_5_5       CAP_5  82
    x_5_5       CONF_3_5_5  1.0
    x_5_5       CONF_5_9_5  1.0
    x_5_5       CONF_5_15_5  1.0
    x_5_6       ASSIGN_5  1.0
    x_5_6       CAP_6  82
    x_5_6       CONF_3_5_6  1.0
    x_5_6       CONF_5_9_6  1.0
    x_5_6       CONF_5_15_6  1.0
    x_5_7       ASSIGN_5  1.0
    x_5_7       CAP_7  82
    x_5_7       CONF_3_5_7  1.0
    x_5_7       CONF_5_9_7  1.0
    x_5_7       CONF_5_15_7  1.0
    x_5_8       ASSIGN_5  1.0
    x_5_8       CAP_8  82
    x_5_8       CONF_3_5_8  1.0
    x_5_8       CONF_5_9_8  1.0
    x_5_8       CONF_5_15_8  1.0
    x_5_9       ASSIGN_5  1.0
    x_5_9       CAP_9  82
    x_5_9       CONF_3_5_9  1.0
    x_5_9       CONF_5_9_9  1.0
    x_5_9       CONF_5_15_9  1.0
    x_5_10      ASSIGN_5  1.0
    x_5_10      CAP_10  82
    x_5_10      CONF_3_5_10  1.0
    x_5_10      CONF_5_9_10  1.0
    x_5_10      CONF_5_15_10  1.0
    x_5_11      ASSIGN_5  1.0
    x_5_11      CAP_11  82
    x_5_11      CONF_3_5_11  1.0
    x_5_11      CONF_5_9_11  1.0
    x_5_11      CONF_5_15_11  1.0
    x_5_12      ASSIGN_5  1.0
    x_5_12      CAP_12  82
    x_5_12      CONF_3_5_12  1.0
    x_5_12      CONF_5_9_12  1.0
    x_5_12      CONF_5_15_12  1.0
    x_5_13      ASSIGN_5  1.0
    x_5_13      CAP_13  82
    x_5_13      CONF_3_5_13  1.0
    x_5_13      CONF_5_9_13  1.0
    x_5_13      CONF_5_15_13  1.0
    x_5_14      ASSIGN_5  1.0
    x_5_14      CAP_14  82
    x_5_14      CONF_3_5_14  1.0
    x_5_14      CONF_5_9_14  1.0
    x_5_14      CONF_5_15_14  1.0
    x_5_15      ASSIGN_5  1.0
    x_5_15      CAP_15  82
    x_5_15      CONF_3_5_15  1.0
    x_5_15      CONF_5_9_15  1.0
    x_5_15      CONF_5_15_15  1.0
    x_5_16      ASSIGN_5  1.0
    x_5_16      CAP_16  82
    x_5_16      CONF_3_5_16  1.0
    x_5_16      CONF_5_9_16  1.0
    x_5_16      CONF_5_15_16  1.0
    x_5_17      ASSIGN_5  1.0
    x_5_17      CAP_17  82
    x_5_17      CONF_3_5_17  1.0
    x_5_17      CONF_5_9_17  1.0
    x_5_17      CONF_5_15_17  1.0
    x_5_18      ASSIGN_5  1.0
    x_5_18      CAP_18  82
    x_5_18      CONF_3_5_18  1.0
    x_5_18      CONF_5_9_18  1.0
    x_5_18      CONF_5_15_18  1.0
    x_5_19      ASSIGN_5  1.0
    x_5_19      CAP_19  82
    x_5_19      CONF_3_5_19  1.0
    x_5_19      CONF_5_9_19  1.0
    x_5_19      CONF_5_15_19  1.0
    x_6_0       ASSIGN_6  1.0
    x_6_0       CAP_0  9
    x_6_0       CONF_6_9_0  1.0
    x_6_0       CONF_6_15_0  1.0
    x_6_1       ASSIGN_6  1.0
    x_6_1       CAP_1  9
    x_6_1       CONF_6_9_1  1.0
    x_6_1       CONF_6_15_1  1.0
    x_6_2       ASSIGN_6  1.0
    x_6_2       CAP_2  9
    x_6_2       CONF_6_9_2  1.0
    x_6_2       CONF_6_15_2  1.0
    x_6_3       ASSIGN_6  1.0
    x_6_3       CAP_3  9
    x_6_3       CONF_6_9_3  1.0
    x_6_3       CONF_6_15_3  1.0
    x_6_4       ASSIGN_6  1.0
    x_6_4       CAP_4  9
    x_6_4       CONF_6_9_4  1.0
    x_6_4       CONF_6_15_4  1.0
    x_6_5       ASSIGN_6  1.0
    x_6_5       CAP_5  9
    x_6_5       CONF_6_9_5  1.0
    x_6_5       CONF_6_15_5  1.0
    x_6_6       ASSIGN_6  1.0
    x_6_6       CAP_6  9
    x_6_6       CONF_6_9_6  1.0
    x_6_6       CONF_6_15_6  1.0
    x_6_7       ASSIGN_6  1.0
    x_6_7       CAP_7  9
    x_6_7       CONF_6_9_7  1.0
    x_6_7       CONF_6_15_7  1.0
    x_6_8       ASSIGN_6  1.0
    x_6_8       CAP_8  9
    x_6_8       CONF_6_9_8  1.0
    x_6_8       CONF_6_15_8  1.0
    x_6_9       ASSIGN_6  1.0
    x_6_9       CAP_9  9
    x_6_9       CONF_6_9_9  1.0
    x_6_9       CONF_6_15_9  1.0
    x_6_10      ASSIGN_6  1.0
    x_6_10      CAP_10  9
    x_6_10      CONF_6_9_10  1.0
    x_6_10      CONF_6_15_10  1.0
    x_6_11      ASSIGN_6  1.0
    x_6_11      CAP_11  9
    x_6_11      CONF_6_9_11  1.0
    x_6_11      CONF_6_15_11  1.0
    x_6_12      ASSIGN_6  1.0
    x_6_12      CAP_12  9
    x_6_12      CONF_6_9_12  1.0
    x_6_12      CONF_6_15_12  1.0
    x_6_13      ASSIGN_6  1.0
    x_6_13      CAP_13  9
    x_6_13      CONF_6_9_13  1.0
    x_6_13      CONF_6_15_13  1.0
    x_6_14      ASSIGN_6  1.0
    x_6_14      CAP_14  9
    x_6_14      CONF_6_9_14  1.0
    x_6_14      CONF_6_15_14  1.0
    x_6_15      ASSIGN_6  1.0
    x_6_15      CAP_15  9
    x_6_15      CONF_6_9_15  1.0
    x_6_15      CONF_6_15_15  1.0
    x_6_16      ASSIGN_6  1.0
    x_6_16      CAP_16  9
    x_6_16      CONF_6_9_16  1.0
    x_6_16      CONF_6_15_16  1.0
    x_6_17      ASSIGN_6  1.0
    x_6_17      CAP_17  9
    x_6_17      CONF_6_9_17  1.0
    x_6_17      CONF_6_15_17  1.0
    x_6_18      ASSIGN_6  1.0
    x_6_18      CAP_18  9
    x_6_18      CONF_6_9_18  1.0
    x_6_18      CONF_6_15_18  1.0
    x_6_19      ASSIGN_6  1.0
    x_6_19      CAP_19  9
    x_6_19      CONF_6_9_19  1.0
    x_6_19      CONF_6_15_19  1.0
    x_7_0       ASSIGN_7  1.0
    x_7_0       CAP_0  33
    x_7_0       CONF_7_8_0  1.0
    x_7_0       CONF_7_10_0  1.0
    x_7_0       CONF_7_15_0  1.0
    x_7_0       CONF_7_18_0  1.0
    x_7_1       ASSIGN_7  1.0
    x_7_1       CAP_1  33
    x_7_1       CONF_7_8_1  1.0
    x_7_1       CONF_7_10_1  1.0
    x_7_1       CONF_7_15_1  1.0
    x_7_1       CONF_7_18_1  1.0
    x_7_2       ASSIGN_7  1.0
    x_7_2       CAP_2  33
    x_7_2       CONF_7_8_2  1.0
    x_7_2       CONF_7_10_2  1.0
    x_7_2       CONF_7_15_2  1.0
    x_7_2       CONF_7_18_2  1.0
    x_7_3       ASSIGN_7  1.0
    x_7_3       CAP_3  33
    x_7_3       CONF_7_8_3  1.0
    x_7_3       CONF_7_10_3  1.0
    x_7_3       CONF_7_15_3  1.0
    x_7_3       CONF_7_18_3  1.0
    x_7_4       ASSIGN_7  1.0
    x_7_4       CAP_4  33
    x_7_4       CONF_7_8_4  1.0
    x_7_4       CONF_7_10_4  1.0
    x_7_4       CONF_7_15_4  1.0
    x_7_4       CONF_7_18_4  1.0
    x_7_5       ASSIGN_7  1.0
    x_7_5       CAP_5  33
    x_7_5       CONF_7_8_5  1.0
    x_7_5       CONF_7_10_5  1.0
    x_7_5       CONF_7_15_5  1.0
    x_7_5       CONF_7_18_5  1.0
    x_7_6       ASSIGN_7  1.0
    x_7_6       CAP_6  33
    x_7_6       CONF_7_8_6  1.0
    x_7_6       CONF_7_10_6  1.0
    x_7_6       CONF_7_15_6  1.0
    x_7_6       CONF_7_18_6  1.0
    x_7_7       ASSIGN_7  1.0
    x_7_7       CAP_7  33
    x_7_7       CONF_7_8_7  1.0
    x_7_7       CONF_7_10_7  1.0
    x_7_7       CONF_7_15_7  1.0
    x_7_7       CONF_7_18_7  1.0
    x_7_8       ASSIGN_7  1.0
    x_7_8       CAP_8  33
    x_7_8       CONF_7_8_8  1.0
    x_7_8       CONF_7_10_8  1.0
    x_7_8       CONF_7_15_8  1.0
    x_7_8       CONF_7_18_8  1.0
    x_7_9       ASSIGN_7  1.0
    x_7_9       CAP_9  33
    x_7_9       CONF_7_8_9  1.0
    x_7_9       CONF_7_10_9  1.0
    x_7_9       CONF_7_15_9  1.0
    x_7_9       CONF_7_18_9  1.0
    x_7_10      ASSIGN_7  1.0
    x_7_10      CAP_10  33
    x_7_10      CONF_7_8_10  1.0
    x_7_10      CONF_7_10_10  1.0
    x_7_10      CONF_7_15_10  1.0
    x_7_10      CONF_7_18_10  1.0
    x_7_11      ASSIGN_7  1.0
    x_7_11      CAP_11  33
    x_7_11      CONF_7_8_11  1.0
    x_7_11      CONF_7_10_11  1.0
    x_7_11      CONF_7_15_11  1.0
    x_7_11      CONF_7_18_11  1.0
    x_7_12      ASSIGN_7  1.0
    x_7_12      CAP_12  33
    x_7_12      CONF_7_8_12  1.0
    x_7_12      CONF_7_10_12  1.0
    x_7_12      CONF_7_15_12  1.0
    x_7_12      CONF_7_18_12  1.0
    x_7_13      ASSIGN_7  1.0
    x_7_13      CAP_13  33
    x_7_13      CONF_7_8_13  1.0
    x_7_13      CONF_7_10_13  1.0
    x_7_13      CONF_7_15_13  1.0
    x_7_13      CONF_7_18_13  1.0
    x_7_14      ASSIGN_7  1.0
    x_7_14      CAP_14  33
    x_7_14      CONF_7_8_14  1.0
    x_7_14      CONF_7_10_14  1.0
    x_7_14      CONF_7_15_14  1.0
    x_7_14      CONF_7_18_14  1.0
    x_7_15      ASSIGN_7  1.0
    x_7_15      CAP_15  33
    x_7_15      CONF_7_8_15  1.0
    x_7_15      CONF_7_10_15  1.0
    x_7_15      CONF_7_15_15  1.0
    x_7_15      CONF_7_18_15  1.0
    x_7_16      ASSIGN_7  1.0
    x_7_16      CAP_16  33
    x_7_16      CONF_7_8_16  1.0
    x_7_16      CONF_7_10_16  1.0
    x_7_16      CONF_7_15_16  1.0
    x_7_16      CONF_7_18_16  1.0
    x_7_17      ASSIGN_7  1.0
    x_7_17      CAP_17  33
    x_7_17      CONF_7_8_17  1.0
    x_7_17      CONF_7_10_17  1.0
    x_7_17      CONF_7_15_17  1.0
    x_7_17      CONF_7_18_17  1.0
    x_7_18      ASSIGN_7  1.0
    x_7_18      CAP_18  33
    x_7_18      CONF_7_8_18  1.0
    x_7_18      CONF_7_10_18  1.0
    x_7_18      CONF_7_15_18  1.0
    x_7_18      CONF_7_18_18  1.0
    x_7_19      ASSIGN_7  1.0
    x_7_19      CAP_19  33
    x_7_19      CONF_7_8_19  1.0
    x_7_19      CONF_7_10_19  1.0
    x_7_19      CONF_7_15_19  1.0
    x_7_19      CONF_7_18_19  1.0
    x_8_0       ASSIGN_8  1.0
    x_8_0       CAP_0  96
    x_8_0       CONF_0_8_0  1.0
    x_8_0       CONF_7_8_0  1.0
    x_8_0       CONF_8_9_0  1.0
    x_8_0       CONF_8_12_0  1.0
    x_8_1       ASSIGN_8  1.0
    x_8_1       CAP_1  96
    x_8_1       CONF_0_8_1  1.0
    x_8_1       CONF_7_8_1  1.0
    x_8_1       CONF_8_9_1  1.0
    x_8_1       CONF_8_12_1  1.0
    x_8_2       ASSIGN_8  1.0
    x_8_2       CAP_2  96
    x_8_2       CONF_0_8_2  1.0
    x_8_2       CONF_7_8_2  1.0
    x_8_2       CONF_8_9_2  1.0
    x_8_2       CONF_8_12_2  1.0
    x_8_3       ASSIGN_8  1.0
    x_8_3       CAP_3  96
    x_8_3       CONF_0_8_3  1.0
    x_8_3       CONF_7_8_3  1.0
    x_8_3       CONF_8_9_3  1.0
    x_8_3       CONF_8_12_3  1.0
    x_8_4       ASSIGN_8  1.0
    x_8_4       CAP_4  96
    x_8_4       CONF_0_8_4  1.0
    x_8_4       CONF_7_8_4  1.0
    x_8_4       CONF_8_9_4  1.0
    x_8_4       CONF_8_12_4  1.0
    x_8_5       ASSIGN_8  1.0
    x_8_5       CAP_5  96
    x_8_5       CONF_0_8_5  1.0
    x_8_5       CONF_7_8_5  1.0
    x_8_5       CONF_8_9_5  1.0
    x_8_5       CONF_8_12_5  1.0
    x_8_6       ASSIGN_8  1.0
    x_8_6       CAP_6  96
    x_8_6       CONF_0_8_6  1.0
    x_8_6       CONF_7_8_6  1.0
    x_8_6       CONF_8_9_6  1.0
    x_8_6       CONF_8_12_6  1.0
    x_8_7       ASSIGN_8  1.0
    x_8_7       CAP_7  96
    x_8_7       CONF_0_8_7  1.0
    x_8_7       CONF_7_8_7  1.0
    x_8_7       CONF_8_9_7  1.0
    x_8_7       CONF_8_12_7  1.0
    x_8_8       ASSIGN_8  1.0
    x_8_8       CAP_8  96
    x_8_8       CONF_0_8_8  1.0
    x_8_8       CONF_7_8_8  1.0
    x_8_8       CONF_8_9_8  1.0
    x_8_8       CONF_8_12_8  1.0
    x_8_9       ASSIGN_8  1.0
    x_8_9       CAP_9  96
    x_8_9       CONF_0_8_9  1.0
    x_8_9       CONF_7_8_9  1.0
    x_8_9       CONF_8_9_9  1.0
    x_8_9       CONF_8_12_9  1.0
    x_8_10      ASSIGN_8  1.0
    x_8_10      CAP_10  96
    x_8_10      CONF_0_8_10  1.0
    x_8_10      CONF_7_8_10  1.0
    x_8_10      CONF_8_9_10  1.0
    x_8_10      CONF_8_12_10  1.0
    x_8_11      ASSIGN_8  1.0
    x_8_11      CAP_11  96
    x_8_11      CONF_0_8_11  1.0
    x_8_11      CONF_7_8_11  1.0
    x_8_11      CONF_8_9_11  1.0
    x_8_11      CONF_8_12_11  1.0
    x_8_12      ASSIGN_8  1.0
    x_8_12      CAP_12  96
    x_8_12      CONF_0_8_12  1.0
    x_8_12      CONF_7_8_12  1.0
    x_8_12      CONF_8_9_12  1.0
    x_8_12      CONF_8_12_12  1.0
    x_8_13      ASSIGN_8  1.0
    x_8_13      CAP_13  96
    x_8_13      CONF_0_8_13  1.0
    x_8_13      CONF_7_8_13  1.0
    x_8_13      CONF_8_9_13  1.0
    x_8_13      CONF_8_12_13  1.0
    x_8_14      ASSIGN_8  1.0
    x_8_14      CAP_14  96
    x_8_14      CONF_0_8_14  1.0
    x_8_14      CONF_7_8_14  1.0
    x_8_14      CONF_8_9_14  1.0
    x_8_14      CONF_8_12_14  1.0
    x_8_15      ASSIGN_8  1.0
    x_8_15      CAP_15  96
    x_8_15      CONF_0_8_15  1.0
    x_8_15      CONF_7_8_15  1.0
    x_8_15      CONF_8_9_15  1.0
    x_8_15      CONF_8_12_15  1.0
    x_8_16      ASSIGN_8  1.0
    x_8_16      CAP_16  96
    x_8_16      CONF_0_8_16  1.0
    x_8_16      CONF_7_8_16  1.0
    x_8_16      CONF_8_9_16  1.0
    x_8_16      CONF_8_12_16  1.0
    x_8_17      ASSIGN_8  1.0
    x_8_17      CAP_17  96
    x_8_17      CONF_0_8_17  1.0
    x_8_17      CONF_7_8_17  1.0
    x_8_17      CONF_8_9_17  1.0
    x_8_17      CONF_8_12_17  1.0
    x_8_18      ASSIGN_8  1.0
    x_8_18      CAP_18  96
    x_8_18      CONF_0_8_18  1.0
    x_8_18      CONF_7_8_18  1.0
    x_8_18      CONF_8_9_18  1.0
    x_8_18      CONF_8_12_18  1.0
    x_8_19      ASSIGN_8  1.0
    x_8_19      CAP_19  96
    x_8_19      CONF_0_8_19  1.0
    x_8_19      CONF_7_8_19  1.0
    x_8_19      CONF_8_9_19  1.0
    x_8_19      CONF_8_12_19  1.0
    x_9_0       ASSIGN_9  1.0
    x_9_0       CAP_0  15
    x_9_0       CONF_5_9_0  1.0
    x_9_0       CONF_6_9_0  1.0
    x_9_0       CONF_8_9_0  1.0
    x_9_0       CONF_9_17_0  1.0
    x_9_1       ASSIGN_9  1.0
    x_9_1       CAP_1  15
    x_9_1       CONF_5_9_1  1.0
    x_9_1       CONF_6_9_1  1.0
    x_9_1       CONF_8_9_1  1.0
    x_9_1       CONF_9_17_1  1.0
    x_9_2       ASSIGN_9  1.0
    x_9_2       CAP_2  15
    x_9_2       CONF_5_9_2  1.0
    x_9_2       CONF_6_9_2  1.0
    x_9_2       CONF_8_9_2  1.0
    x_9_2       CONF_9_17_2  1.0
    x_9_3       ASSIGN_9  1.0
    x_9_3       CAP_3  15
    x_9_3       CONF_5_9_3  1.0
    x_9_3       CONF_6_9_3  1.0
    x_9_3       CONF_8_9_3  1.0
    x_9_3       CONF_9_17_3  1.0
    x_9_4       ASSIGN_9  1.0
    x_9_4       CAP_4  15
    x_9_4       CONF_5_9_4  1.0
    x_9_4       CONF_6_9_4  1.0
    x_9_4       CONF_8_9_4  1.0
    x_9_4       CONF_9_17_4  1.0
    x_9_5       ASSIGN_9  1.0
    x_9_5       CAP_5  15
    x_9_5       CONF_5_9_5  1.0
    x_9_5       CONF_6_9_5  1.0
    x_9_5       CONF_8_9_5  1.0
    x_9_5       CONF_9_17_5  1.0
    x_9_6       ASSIGN_9  1.0
    x_9_6       CAP_6  15
    x_9_6       CONF_5_9_6  1.0
    x_9_6       CONF_6_9_6  1.0
    x_9_6       CONF_8_9_6  1.0
    x_9_6       CONF_9_17_6  1.0
    x_9_7       ASSIGN_9  1.0
    x_9_7       CAP_7  15
    x_9_7       CONF_5_9_7  1.0
    x_9_7       CONF_6_9_7  1.0
    x_9_7       CONF_8_9_7  1.0
    x_9_7       CONF_9_17_7  1.0
    x_9_8       ASSIGN_9  1.0
    x_9_8       CAP_8  15
    x_9_8       CONF_5_9_8  1.0
    x_9_8       CONF_6_9_8  1.0
    x_9_8       CONF_8_9_8  1.0
    x_9_8       CONF_9_17_8  1.0
    x_9_9       ASSIGN_9  1.0
    x_9_9       CAP_9  15
    x_9_9       CONF_5_9_9  1.0
    x_9_9       CONF_6_9_9  1.0
    x_9_9       CONF_8_9_9  1.0
    x_9_9       CONF_9_17_9  1.0
    x_9_10      ASSIGN_9  1.0
    x_9_10      CAP_10  15
    x_9_10      CONF_5_9_10  1.0
    x_9_10      CONF_6_9_10  1.0
    x_9_10      CONF_8_9_10  1.0
    x_9_10      CONF_9_17_10  1.0
    x_9_11      ASSIGN_9  1.0
    x_9_11      CAP_11  15
    x_9_11      CONF_5_9_11  1.0
    x_9_11      CONF_6_9_11  1.0
    x_9_11      CONF_8_9_11  1.0
    x_9_11      CONF_9_17_11  1.0
    x_9_12      ASSIGN_9  1.0
    x_9_12      CAP_12  15
    x_9_12      CONF_5_9_12  1.0
    x_9_12      CONF_6_9_12  1.0
    x_9_12      CONF_8_9_12  1.0
    x_9_12      CONF_9_17_12  1.0
    x_9_13      ASSIGN_9  1.0
    x_9_13      CAP_13  15
    x_9_13      CONF_5_9_13  1.0
    x_9_13      CONF_6_9_13  1.0
    x_9_13      CONF_8_9_13  1.0
    x_9_13      CONF_9_17_13  1.0
    x_9_14      ASSIGN_9  1.0
    x_9_14      CAP_14  15
    x_9_14      CONF_5_9_14  1.0
    x_9_14      CONF_6_9_14  1.0
    x_9_14      CONF_8_9_14  1.0
    x_9_14      CONF_9_17_14  1.0
    x_9_15      ASSIGN_9  1.0
    x_9_15      CAP_15  15
    x_9_15      CONF_5_9_15  1.0
    x_9_15      CONF_6_9_15  1.0
    x_9_15      CONF_8_9_15  1.0
    x_9_15      CONF_9_17_15  1.0
    x_9_16      ASSIGN_9  1.0
    x_9_16      CAP_16  15
    x_9_16      CONF_5_9_16  1.0
    x_9_16      CONF_6_9_16  1.0
    x_9_16      CONF_8_9_16  1.0
    x_9_16      CONF_9_17_16  1.0
    x_9_17      ASSIGN_9  1.0
    x_9_17      CAP_17  15
    x_9_17      CONF_5_9_17  1.0
    x_9_17      CONF_6_9_17  1.0
    x_9_17      CONF_8_9_17  1.0
    x_9_17      CONF_9_17_17  1.0
    x_9_18      ASSIGN_9  1.0
    x_9_18      CAP_18  15
    x_9_18      CONF_5_9_18  1.0
    x_9_18      CONF_6_9_18  1.0
    x_9_18      CONF_8_9_18  1.0
    x_9_18      CONF_9_17_18  1.0
    x_9_19      ASSIGN_9  1.0
    x_9_19      CAP_19  15
    x_9_19      CONF_5_9_19  1.0
    x_9_19      CONF_6_9_19  1.0
    x_9_19      CONF_8_9_19  1.0
    x_9_19      CONF_9_17_19  1.0
    x_10_0      ASSIGN_10  1.0
    x_10_0      CAP_0  32
    x_10_0      CONF_2_10_0  1.0
    x_10_0      CONF_7_10_0  1.0
    x_10_0      CONF_10_14_0  1.0
    x_10_0      CONF_10_19_0  1.0
    x_10_1      ASSIGN_10  1.0
    x_10_1      CAP_1  32
    x_10_1      CONF_2_10_1  1.0
    x_10_1      CONF_7_10_1  1.0
    x_10_1      CONF_10_14_1  1.0
    x_10_1      CONF_10_19_1  1.0
    x_10_2      ASSIGN_10  1.0
    x_10_2      CAP_2  32
    x_10_2      CONF_2_10_2  1.0
    x_10_2      CONF_7_10_2  1.0
    x_10_2      CONF_10_14_2  1.0
    x_10_2      CONF_10_19_2  1.0
    x_10_3      ASSIGN_10  1.0
    x_10_3      CAP_3  32
    x_10_3      CONF_2_10_3  1.0
    x_10_3      CONF_7_10_3  1.0
    x_10_3      CONF_10_14_3  1.0
    x_10_3      CONF_10_19_3  1.0
    x_10_4      ASSIGN_10  1.0
    x_10_4      CAP_4  32
    x_10_4      CONF_2_10_4  1.0
    x_10_4      CONF_7_10_4  1.0
    x_10_4      CONF_10_14_4  1.0
    x_10_4      CONF_10_19_4  1.0
    x_10_5      ASSIGN_10  1.0
    x_10_5      CAP_5  32
    x_10_5      CONF_2_10_5  1.0
    x_10_5      CONF_7_10_5  1.0
    x_10_5      CONF_10_14_5  1.0
    x_10_5      CONF_10_19_5  1.0
    x_10_6      ASSIGN_10  1.0
    x_10_6      CAP_6  32
    x_10_6      CONF_2_10_6  1.0
    x_10_6      CONF_7_10_6  1.0
    x_10_6      CONF_10_14_6  1.0
    x_10_6      CONF_10_19_6  1.0
    x_10_7      ASSIGN_10  1.0
    x_10_7      CAP_7  32
    x_10_7      CONF_2_10_7  1.0
    x_10_7      CONF_7_10_7  1.0
    x_10_7      CONF_10_14_7  1.0
    x_10_7      CONF_10_19_7  1.0
    x_10_8      ASSIGN_10  1.0
    x_10_8      CAP_8  32
    x_10_8      CONF_2_10_8  1.0
    x_10_8      CONF_7_10_8  1.0
    x_10_8      CONF_10_14_8  1.0
    x_10_8      CONF_10_19_8  1.0
    x_10_9      ASSIGN_10  1.0
    x_10_9      CAP_9  32
    x_10_9      CONF_2_10_9  1.0
    x_10_9      CONF_7_10_9  1.0
    x_10_9      CONF_10_14_9  1.0
    x_10_9      CONF_10_19_9  1.0
    x_10_10     ASSIGN_10  1.0
    x_10_10     CAP_10  32
    x_10_10     CONF_2_10_10  1.0
    x_10_10     CONF_7_10_10  1.0
    x_10_10     CONF_10_14_10  1.0
    x_10_10     CONF_10_19_10  1.0
    x_10_11     ASSIGN_10  1.0
    x_10_11     CAP_11  32
    x_10_11     CONF_2_10_11  1.0
    x_10_11     CONF_7_10_11  1.0
    x_10_11     CONF_10_14_11  1.0
    x_10_11     CONF_10_19_11  1.0
    x_10_12     ASSIGN_10  1.0
    x_10_12     CAP_12  32
    x_10_12     CONF_2_10_12  1.0
    x_10_12     CONF_7_10_12  1.0
    x_10_12     CONF_10_14_12  1.0
    x_10_12     CONF_10_19_12  1.0
    x_10_13     ASSIGN_10  1.0
    x_10_13     CAP_13  32
    x_10_13     CONF_2_10_13  1.0
    x_10_13     CONF_7_10_13  1.0
    x_10_13     CONF_10_14_13  1.0
    x_10_13     CONF_10_19_13  1.0
    x_10_14     ASSIGN_10  1.0
    x_10_14     CAP_14  32
    x_10_14     CONF_2_10_14  1.0
    x_10_14     CONF_7_10_14  1.0
    x_10_14     CONF_10_14_14  1.0
    x_10_14     CONF_10_19_14  1.0
    x_10_15     ASSIGN_10  1.0
    x_10_15     CAP_15  32
    x_10_15     CONF_2_10_15  1.0
    x_10_15     CONF_7_10_15  1.0
    x_10_15     CONF_10_14_15  1.0
    x_10_15     CONF_10_19_15  1.0
    x_10_16     ASSIGN_10  1.0
    x_10_16     CAP_16  32
    x_10_16     CONF_2_10_16  1.0
    x_10_16     CONF_7_10_16  1.0
    x_10_16     CONF_10_14_16  1.0
    x_10_16     CONF_10_19_16  1.0
    x_10_17     ASSIGN_10  1.0
    x_10_17     CAP_17  32
    x_10_17     CONF_2_10_17  1.0
    x_10_17     CONF_7_10_17  1.0
    x_10_17     CONF_10_14_17  1.0
    x_10_17     CONF_10_19_17  1.0
    x_10_18     ASSIGN_10  1.0
    x_10_18     CAP_18  32
    x_10_18     CONF_2_10_18  1.0
    x_10_18     CONF_7_10_18  1.0
    x_10_18     CONF_10_14_18  1.0
    x_10_18     CONF_10_19_18  1.0
    x_10_19     ASSIGN_10  1.0
    x_10_19     CAP_19  32
    x_10_19     CONF_2_10_19  1.0
    x_10_19     CONF_7_10_19  1.0
    x_10_19     CONF_10_14_19  1.0
    x_10_19     CONF_10_19_19  1.0
    x_11_0      ASSIGN_11  1.0
    x_11_0      CAP_0  93
    x_11_0      CONF_4_11_0  1.0
    x_11_0      CONF_11_15_0  1.0
    x_11_1      ASSIGN_11  1.0
    x_11_1      CAP_1  93
    x_11_1      CONF_4_11_1  1.0
    x_11_1      CONF_11_15_1  1.0
    x_11_2      ASSIGN_11  1.0
    x_11_2      CAP_2  93
    x_11_2      CONF_4_11_2  1.0
    x_11_2      CONF_11_15_2  1.0
    x_11_3      ASSIGN_11  1.0
    x_11_3      CAP_3  93
    x_11_3      CONF_4_11_3  1.0
    x_11_3      CONF_11_15_3  1.0
    x_11_4      ASSIGN_11  1.0
    x_11_4      CAP_4  93
    x_11_4      CONF_4_11_4  1.0
    x_11_4      CONF_11_15_4  1.0
    x_11_5      ASSIGN_11  1.0
    x_11_5      CAP_5  93
    x_11_5      CONF_4_11_5  1.0
    x_11_5      CONF_11_15_5  1.0
    x_11_6      ASSIGN_11  1.0
    x_11_6      CAP_6  93
    x_11_6      CONF_4_11_6  1.0
    x_11_6      CONF_11_15_6  1.0
    x_11_7      ASSIGN_11  1.0
    x_11_7      CAP_7  93
    x_11_7      CONF_4_11_7  1.0
    x_11_7      CONF_11_15_7  1.0
    x_11_8      ASSIGN_11  1.0
    x_11_8      CAP_8  93
    x_11_8      CONF_4_11_8  1.0
    x_11_8      CONF_11_15_8  1.0
    x_11_9      ASSIGN_11  1.0
    x_11_9      CAP_9  93
    x_11_9      CONF_4_11_9  1.0
    x_11_9      CONF_11_15_9  1.0
    x_11_10     ASSIGN_11  1.0
    x_11_10     CAP_10  93
    x_11_10     CONF_4_11_10  1.0
    x_11_10     CONF_11_15_10  1.0
    x_11_11     ASSIGN_11  1.0
    x_11_11     CAP_11  93
    x_11_11     CONF_4_11_11  1.0
    x_11_11     CONF_11_15_11  1.0
    x_11_12     ASSIGN_11  1.0
    x_11_12     CAP_12  93
    x_11_12     CONF_4_11_12  1.0
    x_11_12     CONF_11_15_12  1.0
    x_11_13     ASSIGN_11  1.0
    x_11_13     CAP_13  93
    x_11_13     CONF_4_11_13  1.0
    x_11_13     CONF_11_15_13  1.0
    x_11_14     ASSIGN_11  1.0
    x_11_14     CAP_14  93
    x_11_14     CONF_4_11_14  1.0
    x_11_14     CONF_11_15_14  1.0
    x_11_15     ASSIGN_11  1.0
    x_11_15     CAP_15  93
    x_11_15     CONF_4_11_15  1.0
    x_11_15     CONF_11_15_15  1.0
    x_11_16     ASSIGN_11  1.0
    x_11_16     CAP_16  93
    x_11_16     CONF_4_11_16  1.0
    x_11_16     CONF_11_15_16  1.0
    x_11_17     ASSIGN_11  1.0
    x_11_17     CAP_17  93
    x_11_17     CONF_4_11_17  1.0
    x_11_17     CONF_11_15_17  1.0
    x_11_18     ASSIGN_11  1.0
    x_11_18     CAP_18  93
    x_11_18     CONF_4_11_18  1.0
    x_11_18     CONF_11_15_18  1.0
    x_11_19     ASSIGN_11  1.0
    x_11_19     CAP_19  93
    x_11_19     CONF_4_11_19  1.0
    x_11_19     CONF_11_15_19  1.0
    x_12_0      ASSIGN_12  1.0
    x_12_0      CAP_0  13
    x_12_0      CONF_0_12_0  1.0
    x_12_0      CONF_1_12_0  1.0
    x_12_0      CONF_2_12_0  1.0
    x_12_0      CONF_4_12_0  1.0
    x_12_0      CONF_8_12_0  1.0
    x_12_0      CONF_12_14_0  1.0
    x_12_0      CONF_12_15_0  1.0
    x_12_1      ASSIGN_12  1.0
    x_12_1      CAP_1  13
    x_12_1      CONF_0_12_1  1.0
    x_12_1      CONF_1_12_1  1.0
    x_12_1      CONF_2_12_1  1.0
    x_12_1      CONF_4_12_1  1.0
    x_12_1      CONF_8_12_1  1.0
    x_12_1      CONF_12_14_1  1.0
    x_12_1      CONF_12_15_1  1.0
    x_12_2      ASSIGN_12  1.0
    x_12_2      CAP_2  13
    x_12_2      CONF_0_12_2  1.0
    x_12_2      CONF_1_12_2  1.0
    x_12_2      CONF_2_12_2  1.0
    x_12_2      CONF_4_12_2  1.0
    x_12_2      CONF_8_12_2  1.0
    x_12_2      CONF_12_14_2  1.0
    x_12_2      CONF_12_15_2  1.0
    x_12_3      ASSIGN_12  1.0
    x_12_3      CAP_3  13
    x_12_3      CONF_0_12_3  1.0
    x_12_3      CONF_1_12_3  1.0
    x_12_3      CONF_2_12_3  1.0
    x_12_3      CONF_4_12_3  1.0
    x_12_3      CONF_8_12_3  1.0
    x_12_3      CONF_12_14_3  1.0
    x_12_3      CONF_12_15_3  1.0
    x_12_4      ASSIGN_12  1.0
    x_12_4      CAP_4  13
    x_12_4      CONF_0_12_4  1.0
    x_12_4      CONF_1_12_4  1.0
    x_12_4      CONF_2_12_4  1.0
    x_12_4      CONF_4_12_4  1.0
    x_12_4      CONF_8_12_4  1.0
    x_12_4      CONF_12_14_4  1.0
    x_12_4      CONF_12_15_4  1.0
    x_12_5      ASSIGN_12  1.0
    x_12_5      CAP_5  13
    x_12_5      CONF_0_12_5  1.0
    x_12_5      CONF_1_12_5  1.0
    x_12_5      CONF_2_12_5  1.0
    x_12_5      CONF_4_12_5  1.0
    x_12_5      CONF_8_12_5  1.0
    x_12_5      CONF_12_14_5  1.0
    x_12_5      CONF_12_15_5  1.0
    x_12_6      ASSIGN_12  1.0
    x_12_6      CAP_6  13
    x_12_6      CONF_0_12_6  1.0
    x_12_6      CONF_1_12_6  1.0
    x_12_6      CONF_2_12_6  1.0
    x_12_6      CONF_4_12_6  1.0
    x_12_6      CONF_8_12_6  1.0
    x_12_6      CONF_12_14_6  1.0
    x_12_6      CONF_12_15_6  1.0
    x_12_7      ASSIGN_12  1.0
    x_12_7      CAP_7  13
    x_12_7      CONF_0_12_7  1.0
    x_12_7      CONF_1_12_7  1.0
    x_12_7      CONF_2_12_7  1.0
    x_12_7      CONF_4_12_7  1.0
    x_12_7      CONF_8_12_7  1.0
    x_12_7      CONF_12_14_7  1.0
    x_12_7      CONF_12_15_7  1.0
    x_12_8      ASSIGN_12  1.0
    x_12_8      CAP_8  13
    x_12_8      CONF_0_12_8  1.0
    x_12_8      CONF_1_12_8  1.0
    x_12_8      CONF_2_12_8  1.0
    x_12_8      CONF_4_12_8  1.0
    x_12_8      CONF_8_12_8  1.0
    x_12_8      CONF_12_14_8  1.0
    x_12_8      CONF_12_15_8  1.0
    x_12_9      ASSIGN_12  1.0
    x_12_9      CAP_9  13
    x_12_9      CONF_0_12_9  1.0
    x_12_9      CONF_1_12_9  1.0
    x_12_9      CONF_2_12_9  1.0
    x_12_9      CONF_4_12_9  1.0
    x_12_9      CONF_8_12_9  1.0
    x_12_9      CONF_12_14_9  1.0
    x_12_9      CONF_12_15_9  1.0
    x_12_10     ASSIGN_12  1.0
    x_12_10     CAP_10  13
    x_12_10     CONF_0_12_10  1.0
    x_12_10     CONF_1_12_10  1.0
    x_12_10     CONF_2_12_10  1.0
    x_12_10     CONF_4_12_10  1.0
    x_12_10     CONF_8_12_10  1.0
    x_12_10     CONF_12_14_10  1.0
    x_12_10     CONF_12_15_10  1.0
    x_12_11     ASSIGN_12  1.0
    x_12_11     CAP_11  13
    x_12_11     CONF_0_12_11  1.0
    x_12_11     CONF_1_12_11  1.0
    x_12_11     CONF_2_12_11  1.0
    x_12_11     CONF_4_12_11  1.0
    x_12_11     CONF_8_12_11  1.0
    x_12_11     CONF_12_14_11  1.0
    x_12_11     CONF_12_15_11  1.0
    x_12_12     ASSIGN_12  1.0
    x_12_12     CAP_12  13
    x_12_12     CONF_0_12_12  1.0
    x_12_12     CONF_1_12_12  1.0
    x_12_12     CONF_2_12_12  1.0
    x_12_12     CONF_4_12_12  1.0
    x_12_12     CONF_8_12_12  1.0
    x_12_12     CONF_12_14_12  1.0
    x_12_12     CONF_12_15_12  1.0
    x_12_13     ASSIGN_12  1.0
    x_12_13     CAP_13  13
    x_12_13     CONF_0_12_13  1.0
    x_12_13     CONF_1_12_13  1.0
    x_12_13     CONF_2_12_13  1.0
    x_12_13     CONF_4_12_13  1.0
    x_12_13     CONF_8_12_13  1.0
    x_12_13     CONF_12_14_13  1.0
    x_12_13     CONF_12_15_13  1.0
    x_12_14     ASSIGN_12  1.0
    x_12_14     CAP_14  13
    x_12_14     CONF_0_12_14  1.0
    x_12_14     CONF_1_12_14  1.0
    x_12_14     CONF_2_12_14  1.0
    x_12_14     CONF_4_12_14  1.0
    x_12_14     CONF_8_12_14  1.0
    x_12_14     CONF_12_14_14  1.0
    x_12_14     CONF_12_15_14  1.0
    x_12_15     ASSIGN_12  1.0
    x_12_15     CAP_15  13
    x_12_15     CONF_0_12_15  1.0
    x_12_15     CONF_1_12_15  1.0
    x_12_15     CONF_2_12_15  1.0
    x_12_15     CONF_4_12_15  1.0
    x_12_15     CONF_8_12_15  1.0
    x_12_15     CONF_12_14_15  1.0
    x_12_15     CONF_12_15_15  1.0
    x_12_16     ASSIGN_12  1.0
    x_12_16     CAP_16  13
    x_12_16     CONF_0_12_16  1.0
    x_12_16     CONF_1_12_16  1.0
    x_12_16     CONF_2_12_16  1.0
    x_12_16     CONF_4_12_16  1.0
    x_12_16     CONF_8_12_16  1.0
    x_12_16     CONF_12_14_16  1.0
    x_12_16     CONF_12_15_16  1.0
    x_12_17     ASSIGN_12  1.0
    x_12_17     CAP_17  13
    x_12_17     CONF_0_12_17  1.0
    x_12_17     CONF_1_12_17  1.0
    x_12_17     CONF_2_12_17  1.0
    x_12_17     CONF_4_12_17  1.0
    x_12_17     CONF_8_12_17  1.0
    x_12_17     CONF_12_14_17  1.0
    x_12_17     CONF_12_15_17  1.0
    x_12_18     ASSIGN_12  1.0
    x_12_18     CAP_18  13
    x_12_18     CONF_0_12_18  1.0
    x_12_18     CONF_1_12_18  1.0
    x_12_18     CONF_2_12_18  1.0
    x_12_18     CONF_4_12_18  1.0
    x_12_18     CONF_8_12_18  1.0
    x_12_18     CONF_12_14_18  1.0
    x_12_18     CONF_12_15_18  1.0
    x_12_19     ASSIGN_12  1.0
    x_12_19     CAP_19  13
    x_12_19     CONF_0_12_19  1.0
    x_12_19     CONF_1_12_19  1.0
    x_12_19     CONF_2_12_19  1.0
    x_12_19     CONF_4_12_19  1.0
    x_12_19     CONF_8_12_19  1.0
    x_12_19     CONF_12_14_19  1.0
    x_12_19     CONF_12_15_19  1.0
    x_13_0      ASSIGN_13  1.0
    x_13_0      CAP_0  31
    x_13_0      CONF_4_13_0  1.0
    x_13_0      CONF_13_16_0  1.0
    x_13_1      ASSIGN_13  1.0
    x_13_1      CAP_1  31
    x_13_1      CONF_4_13_1  1.0
    x_13_1      CONF_13_16_1  1.0
    x_13_2      ASSIGN_13  1.0
    x_13_2      CAP_2  31
    x_13_2      CONF_4_13_2  1.0
    x_13_2      CONF_13_16_2  1.0
    x_13_3      ASSIGN_13  1.0
    x_13_3      CAP_3  31
    x_13_3      CONF_4_13_3  1.0
    x_13_3      CONF_13_16_3  1.0
    x_13_4      ASSIGN_13  1.0
    x_13_4      CAP_4  31
    x_13_4      CONF_4_13_4  1.0
    x_13_4      CONF_13_16_4  1.0
    x_13_5      ASSIGN_13  1.0
    x_13_5      CAP_5  31
    x_13_5      CONF_4_13_5  1.0
    x_13_5      CONF_13_16_5  1.0
    x_13_6      ASSIGN_13  1.0
    x_13_6      CAP_6  31
    x_13_6      CONF_4_13_6  1.0
    x_13_6      CONF_13_16_6  1.0
    x_13_7      ASSIGN_13  1.0
    x_13_7      CAP_7  31
    x_13_7      CONF_4_13_7  1.0
    x_13_7      CONF_13_16_7  1.0
    x_13_8      ASSIGN_13  1.0
    x_13_8      CAP_8  31
    x_13_8      CONF_4_13_8  1.0
    x_13_8      CONF_13_16_8  1.0
    x_13_9      ASSIGN_13  1.0
    x_13_9      CAP_9  31
    x_13_9      CONF_4_13_9  1.0
    x_13_9      CONF_13_16_9  1.0
    x_13_10     ASSIGN_13  1.0
    x_13_10     CAP_10  31
    x_13_10     CONF_4_13_10  1.0
    x_13_10     CONF_13_16_10  1.0
    x_13_11     ASSIGN_13  1.0
    x_13_11     CAP_11  31
    x_13_11     CONF_4_13_11  1.0
    x_13_11     CONF_13_16_11  1.0
    x_13_12     ASSIGN_13  1.0
    x_13_12     CAP_12  31
    x_13_12     CONF_4_13_12  1.0
    x_13_12     CONF_13_16_12  1.0
    x_13_13     ASSIGN_13  1.0
    x_13_13     CAP_13  31
    x_13_13     CONF_4_13_13  1.0
    x_13_13     CONF_13_16_13  1.0
    x_13_14     ASSIGN_13  1.0
    x_13_14     CAP_14  31
    x_13_14     CONF_4_13_14  1.0
    x_13_14     CONF_13_16_14  1.0
    x_13_15     ASSIGN_13  1.0
    x_13_15     CAP_15  31
    x_13_15     CONF_4_13_15  1.0
    x_13_15     CONF_13_16_15  1.0
    x_13_16     ASSIGN_13  1.0
    x_13_16     CAP_16  31
    x_13_16     CONF_4_13_16  1.0
    x_13_16     CONF_13_16_16  1.0
    x_13_17     ASSIGN_13  1.0
    x_13_17     CAP_17  31
    x_13_17     CONF_4_13_17  1.0
    x_13_17     CONF_13_16_17  1.0
    x_13_18     ASSIGN_13  1.0
    x_13_18     CAP_18  31
    x_13_18     CONF_4_13_18  1.0
    x_13_18     CONF_13_16_18  1.0
    x_13_19     ASSIGN_13  1.0
    x_13_19     CAP_19  31
    x_13_19     CONF_4_13_19  1.0
    x_13_19     CONF_13_16_19  1.0
    x_14_0      ASSIGN_14  1.0
    x_14_0      CAP_0  75
    x_14_0      CONF_10_14_0  1.0
    x_14_0      CONF_12_14_0  1.0
    x_14_0      CONF_14_16_0  1.0
    x_14_1      ASSIGN_14  1.0
    x_14_1      CAP_1  75
    x_14_1      CONF_10_14_1  1.0
    x_14_1      CONF_12_14_1  1.0
    x_14_1      CONF_14_16_1  1.0
    x_14_2      ASSIGN_14  1.0
    x_14_2      CAP_2  75
    x_14_2      CONF_10_14_2  1.0
    x_14_2      CONF_12_14_2  1.0
    x_14_2      CONF_14_16_2  1.0
    x_14_3      ASSIGN_14  1.0
    x_14_3      CAP_3  75
    x_14_3      CONF_10_14_3  1.0
    x_14_3      CONF_12_14_3  1.0
    x_14_3      CONF_14_16_3  1.0
    x_14_4      ASSIGN_14  1.0
    x_14_4      CAP_4  75
    x_14_4      CONF_10_14_4  1.0
    x_14_4      CONF_12_14_4  1.0
    x_14_4      CONF_14_16_4  1.0
    x_14_5      ASSIGN_14  1.0
    x_14_5      CAP_5  75
    x_14_5      CONF_10_14_5  1.0
    x_14_5      CONF_12_14_5  1.0
    x_14_5      CONF_14_16_5  1.0
    x_14_6      ASSIGN_14  1.0
    x_14_6      CAP_6  75
    x_14_6      CONF_10_14_6  1.0
    x_14_6      CONF_12_14_6  1.0
    x_14_6      CONF_14_16_6  1.0
    x_14_7      ASSIGN_14  1.0
    x_14_7      CAP_7  75
    x_14_7      CONF_10_14_7  1.0
    x_14_7      CONF_12_14_7  1.0
    x_14_7      CONF_14_16_7  1.0
    x_14_8      ASSIGN_14  1.0
    x_14_8      CAP_8  75
    x_14_8      CONF_10_14_8  1.0
    x_14_8      CONF_12_14_8  1.0
    x_14_8      CONF_14_16_8  1.0
    x_14_9      ASSIGN_14  1.0
    x_14_9      CAP_9  75
    x_14_9      CONF_10_14_9  1.0
    x_14_9      CONF_12_14_9  1.0
    x_14_9      CONF_14_16_9  1.0
    x_14_10     ASSIGN_14  1.0
    x_14_10     CAP_10  75
    x_14_10     CONF_10_14_10  1.0
    x_14_10     CONF_12_14_10  1.0
    x_14_10     CONF_14_16_10  1.0
    x_14_11     ASSIGN_14  1.0
    x_14_11     CAP_11  75
    x_14_11     CONF_10_14_11  1.0
    x_14_11     CONF_12_14_11  1.0
    x_14_11     CONF_14_16_11  1.0
    x_14_12     ASSIGN_14  1.0
    x_14_12     CAP_12  75
    x_14_12     CONF_10_14_12  1.0
    x_14_12     CONF_12_14_12  1.0
    x_14_12     CONF_14_16_12  1.0
    x_14_13     ASSIGN_14  1.0
    x_14_13     CAP_13  75
    x_14_13     CONF_10_14_13  1.0
    x_14_13     CONF_12_14_13  1.0
    x_14_13     CONF_14_16_13  1.0
    x_14_14     ASSIGN_14  1.0
    x_14_14     CAP_14  75
    x_14_14     CONF_10_14_14  1.0
    x_14_14     CONF_12_14_14  1.0
    x_14_14     CONF_14_16_14  1.0
    x_14_15     ASSIGN_14  1.0
    x_14_15     CAP_15  75
    x_14_15     CONF_10_14_15  1.0
    x_14_15     CONF_12_14_15  1.0
    x_14_15     CONF_14_16_15  1.0
    x_14_16     ASSIGN_14  1.0
    x_14_16     CAP_16  75
    x_14_16     CONF_10_14_16  1.0
    x_14_16     CONF_12_14_16  1.0
    x_14_16     CONF_14_16_16  1.0
    x_14_17     ASSIGN_14  1.0
    x_14_17     CAP_17  75
    x_14_17     CONF_10_14_17  1.0
    x_14_17     CONF_12_14_17  1.0
    x_14_17     CONF_14_16_17  1.0
    x_14_18     ASSIGN_14  1.0
    x_14_18     CAP_18  75
    x_14_18     CONF_10_14_18  1.0
    x_14_18     CONF_12_14_18  1.0
    x_14_18     CONF_14_16_18  1.0
    x_14_19     ASSIGN_14  1.0
    x_14_19     CAP_19  75
    x_14_19     CONF_10_14_19  1.0
    x_14_19     CONF_12_14_19  1.0
    x_14_19     CONF_14_16_19  1.0
    x_15_0      ASSIGN_15  1.0
    x_15_0      CAP_0  8
    x_15_0      CONF_0_15_0  1.0
    x_15_0      CONF_1_15_0  1.0
    x_15_0      CONF_5_15_0  1.0
    x_15_0      CONF_6_15_0  1.0
    x_15_0      CONF_7_15_0  1.0
    x_15_0      CONF_11_15_0  1.0
    x_15_0      CONF_12_15_0  1.0
    x_15_1      ASSIGN_15  1.0
    x_15_1      CAP_1  8
    x_15_1      CONF_0_15_1  1.0
    x_15_1      CONF_1_15_1  1.0
    x_15_1      CONF_5_15_1  1.0
    x_15_1      CONF_6_15_1  1.0
    x_15_1      CONF_7_15_1  1.0
    x_15_1      CONF_11_15_1  1.0
    x_15_1      CONF_12_15_1  1.0
    x_15_2      ASSIGN_15  1.0
    x_15_2      CAP_2  8
    x_15_2      CONF_0_15_2  1.0
    x_15_2      CONF_1_15_2  1.0
    x_15_2      CONF_5_15_2  1.0
    x_15_2      CONF_6_15_2  1.0
    x_15_2      CONF_7_15_2  1.0
    x_15_2      CONF_11_15_2  1.0
    x_15_2      CONF_12_15_2  1.0
    x_15_3      ASSIGN_15  1.0
    x_15_3      CAP_3  8
    x_15_3      CONF_0_15_3  1.0
    x_15_3      CONF_1_15_3  1.0
    x_15_3      CONF_5_15_3  1.0
    x_15_3      CONF_6_15_3  1.0
    x_15_3      CONF_7_15_3  1.0
    x_15_3      CONF_11_15_3  1.0
    x_15_3      CONF_12_15_3  1.0
    x_15_4      ASSIGN_15  1.0
    x_15_4      CAP_4  8
    x_15_4      CONF_0_15_4  1.0
    x_15_4      CONF_1_15_4  1.0
    x_15_4      CONF_5_15_4  1.0
    x_15_4      CONF_6_15_4  1.0
    x_15_4      CONF_7_15_4  1.0
    x_15_4      CONF_11_15_4  1.0
    x_15_4      CONF_12_15_4  1.0
    x_15_5      ASSIGN_15  1.0
    x_15_5      CAP_5  8
    x_15_5      CONF_0_15_5  1.0
    x_15_5      CONF_1_15_5  1.0
    x_15_5      CONF_5_15_5  1.0
    x_15_5      CONF_6_15_5  1.0
    x_15_5      CONF_7_15_5  1.0
    x_15_5      CONF_11_15_5  1.0
    x_15_5      CONF_12_15_5  1.0
    x_15_6      ASSIGN_15  1.0
    x_15_6      CAP_6  8
    x_15_6      CONF_0_15_6  1.0
    x_15_6      CONF_1_15_6  1.0
    x_15_6      CONF_5_15_6  1.0
    x_15_6      CONF_6_15_6  1.0
    x_15_6      CONF_7_15_6  1.0
    x_15_6      CONF_11_15_6  1.0
    x_15_6      CONF_12_15_6  1.0
    x_15_7      ASSIGN_15  1.0
    x_15_7      CAP_7  8
    x_15_7      CONF_0_15_7  1.0
    x_15_7      CONF_1_15_7  1.0
    x_15_7      CONF_5_15_7  1.0
    x_15_7      CONF_6_15_7  1.0
    x_15_7      CONF_7_15_7  1.0
    x_15_7      CONF_11_15_7  1.0
    x_15_7      CONF_12_15_7  1.0
    x_15_8      ASSIGN_15  1.0
    x_15_8      CAP_8  8
    x_15_8      CONF_0_15_8  1.0
    x_15_8      CONF_1_15_8  1.0
    x_15_8      CONF_5_15_8  1.0
    x_15_8      CONF_6_15_8  1.0
    x_15_8      CONF_7_15_8  1.0
    x_15_8      CONF_11_15_8  1.0
    x_15_8      CONF_12_15_8  1.0
    x_15_9      ASSIGN_15  1.0
    x_15_9      CAP_9  8
    x_15_9      CONF_0_15_9  1.0
    x_15_9      CONF_1_15_9  1.0
    x_15_9      CONF_5_15_9  1.0
    x_15_9      CONF_6_15_9  1.0
    x_15_9      CONF_7_15_9  1.0
    x_15_9      CONF_11_15_9  1.0
    x_15_9      CONF_12_15_9  1.0
    x_15_10     ASSIGN_15  1.0
    x_15_10     CAP_10  8
    x_15_10     CONF_0_15_10  1.0
    x_15_10     CONF_1_15_10  1.0
    x_15_10     CONF_5_15_10  1.0
    x_15_10     CONF_6_15_10  1.0
    x_15_10     CONF_7_15_10  1.0
    x_15_10     CONF_11_15_10  1.0
    x_15_10     CONF_12_15_10  1.0
    x_15_11     ASSIGN_15  1.0
    x_15_11     CAP_11  8
    x_15_11     CONF_0_15_11  1.0
    x_15_11     CONF_1_15_11  1.0
    x_15_11     CONF_5_15_11  1.0
    x_15_11     CONF_6_15_11  1.0
    x_15_11     CONF_7_15_11  1.0
    x_15_11     CONF_11_15_11  1.0
    x_15_11     CONF_12_15_11  1.0
    x_15_12     ASSIGN_15  1.0
    x_15_12     CAP_12  8
    x_15_12     CONF_0_15_12  1.0
    x_15_12     CONF_1_15_12  1.0
    x_15_12     CONF_5_15_12  1.0
    x_15_12     CONF_6_15_12  1.0
    x_15_12     CONF_7_15_12  1.0
    x_15_12     CONF_11_15_12  1.0
    x_15_12     CONF_12_15_12  1.0
    x_15_13     ASSIGN_15  1.0
    x_15_13     CAP_13  8
    x_15_13     CONF_0_15_13  1.0
    x_15_13     CONF_1_15_13  1.0
    x_15_13     CONF_5_15_13  1.0
    x_15_13     CONF_6_15_13  1.0
    x_15_13     CONF_7_15_13  1.0
    x_15_13     CONF_11_15_13  1.0
    x_15_13     CONF_12_15_13  1.0
    x_15_14     ASSIGN_15  1.0
    x_15_14     CAP_14  8
    x_15_14     CONF_0_15_14  1.0
    x_15_14     CONF_1_15_14  1.0
    x_15_14     CONF_5_15_14  1.0
    x_15_14     CONF_6_15_14  1.0
    x_15_14     CONF_7_15_14  1.0
    x_15_14     CONF_11_15_14  1.0
    x_15_14     CONF_12_15_14  1.0
    x_15_15     ASSIGN_15  1.0
    x_15_15     CAP_15  8
    x_15_15     CONF_0_15_15  1.0
    x_15_15     CONF_1_15_15  1.0
    x_15_15     CONF_5_15_15  1.0
    x_15_15     CONF_6_15_15  1.0
    x_15_15     CONF_7_15_15  1.0
    x_15_15     CONF_11_15_15  1.0
    x_15_15     CONF_12_15_15  1.0
    x_15_16     ASSIGN_15  1.0
    x_15_16     CAP_16  8
    x_15_16     CONF_0_15_16  1.0
    x_15_16     CONF_1_15_16  1.0
    x_15_16     CONF_5_15_16  1.0
    x_15_16     CONF_6_15_16  1.0
    x_15_16     CONF_7_15_16  1.0
    x_15_16     CONF_11_15_16  1.0
    x_15_16     CONF_12_15_16  1.0
    x_15_17     ASSIGN_15  1.0
    x_15_17     CAP_17  8
    x_15_17     CONF_0_15_17  1.0
    x_15_17     CONF_1_15_17  1.0
    x_15_17     CONF_5_15_17  1.0
    x_15_17     CONF_6_15_17  1.0
    x_15_17     CONF_7_15_17  1.0
    x_15_17     CONF_11_15_17  1.0
    x_15_17     CONF_12_15_17  1.0
    x_15_18     ASSIGN_15  1.0
    x_15_18     CAP_18  8
    x_15_18     CONF_0_15_18  1.0
    x_15_18     CONF_1_15_18  1.0
    x_15_18     CONF_5_15_18  1.0
    x_15_18     CONF_6_15_18  1.0
    x_15_18     CONF_7_15_18  1.0
    x_15_18     CONF_11_15_18  1.0
    x_15_18     CONF_12_15_18  1.0
    x_15_19     ASSIGN_15  1.0
    x_15_19     CAP_19  8
    x_15_19     CONF_0_15_19  1.0
    x_15_19     CONF_1_15_19  1.0
    x_15_19     CONF_5_15_19  1.0
    x_15_19     CONF_6_15_19  1.0
    x_15_19     CONF_7_15_19  1.0
    x_15_19     CONF_11_15_19  1.0
    x_15_19     CONF_12_15_19  1.0
    x_16_0      ASSIGN_16  1.0
    x_16_0      CAP_0  36
    x_16_0      CONF_0_16_0  1.0
    x_16_0      CONF_13_16_0  1.0
    x_16_0      CONF_14_16_0  1.0
    x_16_0      CONF_16_18_0  1.0
    x_16_1      ASSIGN_16  1.0
    x_16_1      CAP_1  36
    x_16_1      CONF_0_16_1  1.0
    x_16_1      CONF_13_16_1  1.0
    x_16_1      CONF_14_16_1  1.0
    x_16_1      CONF_16_18_1  1.0
    x_16_2      ASSIGN_16  1.0
    x_16_2      CAP_2  36
    x_16_2      CONF_0_16_2  1.0
    x_16_2      CONF_13_16_2  1.0
    x_16_2      CONF_14_16_2  1.0
    x_16_2      CONF_16_18_2  1.0
    x_16_3      ASSIGN_16  1.0
    x_16_3      CAP_3  36
    x_16_3      CONF_0_16_3  1.0
    x_16_3      CONF_13_16_3  1.0
    x_16_3      CONF_14_16_3  1.0
    x_16_3      CONF_16_18_3  1.0
    x_16_4      ASSIGN_16  1.0
    x_16_4      CAP_4  36
    x_16_4      CONF_0_16_4  1.0
    x_16_4      CONF_13_16_4  1.0
    x_16_4      CONF_14_16_4  1.0
    x_16_4      CONF_16_18_4  1.0
    x_16_5      ASSIGN_16  1.0
    x_16_5      CAP_5  36
    x_16_5      CONF_0_16_5  1.0
    x_16_5      CONF_13_16_5  1.0
    x_16_5      CONF_14_16_5  1.0
    x_16_5      CONF_16_18_5  1.0
    x_16_6      ASSIGN_16  1.0
    x_16_6      CAP_6  36
    x_16_6      CONF_0_16_6  1.0
    x_16_6      CONF_13_16_6  1.0
    x_16_6      CONF_14_16_6  1.0
    x_16_6      CONF_16_18_6  1.0
    x_16_7      ASSIGN_16  1.0
    x_16_7      CAP_7  36
    x_16_7      CONF_0_16_7  1.0
    x_16_7      CONF_13_16_7  1.0
    x_16_7      CONF_14_16_7  1.0
    x_16_7      CONF_16_18_7  1.0
    x_16_8      ASSIGN_16  1.0
    x_16_8      CAP_8  36
    x_16_8      CONF_0_16_8  1.0
    x_16_8      CONF_13_16_8  1.0
    x_16_8      CONF_14_16_8  1.0
    x_16_8      CONF_16_18_8  1.0
    x_16_9      ASSIGN_16  1.0
    x_16_9      CAP_9  36
    x_16_9      CONF_0_16_9  1.0
    x_16_9      CONF_13_16_9  1.0
    x_16_9      CONF_14_16_9  1.0
    x_16_9      CONF_16_18_9  1.0
    x_16_10     ASSIGN_16  1.0
    x_16_10     CAP_10  36
    x_16_10     CONF_0_16_10  1.0
    x_16_10     CONF_13_16_10  1.0
    x_16_10     CONF_14_16_10  1.0
    x_16_10     CONF_16_18_10  1.0
    x_16_11     ASSIGN_16  1.0
    x_16_11     CAP_11  36
    x_16_11     CONF_0_16_11  1.0
    x_16_11     CONF_13_16_11  1.0
    x_16_11     CONF_14_16_11  1.0
    x_16_11     CONF_16_18_11  1.0
    x_16_12     ASSIGN_16  1.0
    x_16_12     CAP_12  36
    x_16_12     CONF_0_16_12  1.0
    x_16_12     CONF_13_16_12  1.0
    x_16_12     CONF_14_16_12  1.0
    x_16_12     CONF_16_18_12  1.0
    x_16_13     ASSIGN_16  1.0
    x_16_13     CAP_13  36
    x_16_13     CONF_0_16_13  1.0
    x_16_13     CONF_13_16_13  1.0
    x_16_13     CONF_14_16_13  1.0
    x_16_13     CONF_16_18_13  1.0
    x_16_14     ASSIGN_16  1.0
    x_16_14     CAP_14  36
    x_16_14     CONF_0_16_14  1.0
    x_16_14     CONF_13_16_14  1.0
    x_16_14     CONF_14_16_14  1.0
    x_16_14     CONF_16_18_14  1.0
    x_16_15     ASSIGN_16  1.0
    x_16_15     CAP_15  36
    x_16_15     CONF_0_16_15  1.0
    x_16_15     CONF_13_16_15  1.0
    x_16_15     CONF_14_16_15  1.0
    x_16_15     CONF_16_18_15  1.0
    x_16_16     ASSIGN_16  1.0
    x_16_16     CAP_16  36
    x_16_16     CONF_0_16_16  1.0
    x_16_16     CONF_13_16_16  1.0
    x_16_16     CONF_14_16_16  1.0
    x_16_16     CONF_16_18_16  1.0
    x_16_17     ASSIGN_16  1.0
    x_16_17     CAP_17  36
    x_16_17     CONF_0_16_17  1.0
    x_16_17     CONF_13_16_17  1.0
    x_16_17     CONF_14_16_17  1.0
    x_16_17     CONF_16_18_17  1.0
    x_16_18     ASSIGN_16  1.0
    x_16_18     CAP_18  36
    x_16_18     CONF_0_16_18  1.0
    x_16_18     CONF_13_16_18  1.0
    x_16_18     CONF_14_16_18  1.0
    x_16_18     CONF_16_18_18  1.0
    x_16_19     ASSIGN_16  1.0
    x_16_19     CAP_19  36
    x_16_19     CONF_0_16_19  1.0
    x_16_19     CONF_13_16_19  1.0
    x_16_19     CONF_14_16_19  1.0
    x_16_19     CONF_16_18_19  1.0
    x_17_0      ASSIGN_17  1.0
    x_17_0      CAP_0  82
    x_17_0      CONF_1_17_0  1.0
    x_17_0      CONF_4_17_0  1.0
    x_17_0      CONF_9_17_0  1.0
    x_17_1      ASSIGN_17  1.0
    x_17_1      CAP_1  82
    x_17_1      CONF_1_17_1  1.0
    x_17_1      CONF_4_17_1  1.0
    x_17_1      CONF_9_17_1  1.0
    x_17_2      ASSIGN_17  1.0
    x_17_2      CAP_2  82
    x_17_2      CONF_1_17_2  1.0
    x_17_2      CONF_4_17_2  1.0
    x_17_2      CONF_9_17_2  1.0
    x_17_3      ASSIGN_17  1.0
    x_17_3      CAP_3  82
    x_17_3      CONF_1_17_3  1.0
    x_17_3      CONF_4_17_3  1.0
    x_17_3      CONF_9_17_3  1.0
    x_17_4      ASSIGN_17  1.0
    x_17_4      CAP_4  82
    x_17_4      CONF_1_17_4  1.0
    x_17_4      CONF_4_17_4  1.0
    x_17_4      CONF_9_17_4  1.0
    x_17_5      ASSIGN_17  1.0
    x_17_5      CAP_5  82
    x_17_5      CONF_1_17_5  1.0
    x_17_5      CONF_4_17_5  1.0
    x_17_5      CONF_9_17_5  1.0
    x_17_6      ASSIGN_17  1.0
    x_17_6      CAP_6  82
    x_17_6      CONF_1_17_6  1.0
    x_17_6      CONF_4_17_6  1.0
    x_17_6      CONF_9_17_6  1.0
    x_17_7      ASSIGN_17  1.0
    x_17_7      CAP_7  82
    x_17_7      CONF_1_17_7  1.0
    x_17_7      CONF_4_17_7  1.0
    x_17_7      CONF_9_17_7  1.0
    x_17_8      ASSIGN_17  1.0
    x_17_8      CAP_8  82
    x_17_8      CONF_1_17_8  1.0
    x_17_8      CONF_4_17_8  1.0
    x_17_8      CONF_9_17_8  1.0
    x_17_9      ASSIGN_17  1.0
    x_17_9      CAP_9  82
    x_17_9      CONF_1_17_9  1.0
    x_17_9      CONF_4_17_9  1.0
    x_17_9      CONF_9_17_9  1.0
    x_17_10     ASSIGN_17  1.0
    x_17_10     CAP_10  82
    x_17_10     CONF_1_17_10  1.0
    x_17_10     CONF_4_17_10  1.0
    x_17_10     CONF_9_17_10  1.0
    x_17_11     ASSIGN_17  1.0
    x_17_11     CAP_11  82
    x_17_11     CONF_1_17_11  1.0
    x_17_11     CONF_4_17_11  1.0
    x_17_11     CONF_9_17_11  1.0
    x_17_12     ASSIGN_17  1.0
    x_17_12     CAP_12  82
    x_17_12     CONF_1_17_12  1.0
    x_17_12     CONF_4_17_12  1.0
    x_17_12     CONF_9_17_12  1.0
    x_17_13     ASSIGN_17  1.0
    x_17_13     CAP_13  82
    x_17_13     CONF_1_17_13  1.0
    x_17_13     CONF_4_17_13  1.0
    x_17_13     CONF_9_17_13  1.0
    x_17_14     ASSIGN_17  1.0
    x_17_14     CAP_14  82
    x_17_14     CONF_1_17_14  1.0
    x_17_14     CONF_4_17_14  1.0
    x_17_14     CONF_9_17_14  1.0
    x_17_15     ASSIGN_17  1.0
    x_17_15     CAP_15  82
    x_17_15     CONF_1_17_15  1.0
    x_17_15     CONF_4_17_15  1.0
    x_17_15     CONF_9_17_15  1.0
    x_17_16     ASSIGN_17  1.0
    x_17_16     CAP_16  82
    x_17_16     CONF_1_17_16  1.0
    x_17_16     CONF_4_17_16  1.0
    x_17_16     CONF_9_17_16  1.0
    x_17_17     ASSIGN_17  1.0
    x_17_17     CAP_17  82
    x_17_17     CONF_1_17_17  1.0
    x_17_17     CONF_4_17_17  1.0
    x_17_17     CONF_9_17_17  1.0
    x_17_18     ASSIGN_17  1.0
    x_17_18     CAP_18  82
    x_17_18     CONF_1_17_18  1.0
    x_17_18     CONF_4_17_18  1.0
    x_17_18     CONF_9_17_18  1.0
    x_17_19     ASSIGN_17  1.0
    x_17_19     CAP_19  82
    x_17_19     CONF_1_17_19  1.0
    x_17_19     CONF_4_17_19  1.0
    x_17_19     CONF_9_17_19  1.0
    x_18_0      ASSIGN_18  1.0
    x_18_0      CAP_0  15
    x_18_0      CONF_7_18_0  1.0
    x_18_0      CONF_16_18_0  1.0
    x_18_1      ASSIGN_18  1.0
    x_18_1      CAP_1  15
    x_18_1      CONF_7_18_1  1.0
    x_18_1      CONF_16_18_1  1.0
    x_18_2      ASSIGN_18  1.0
    x_18_2      CAP_2  15
    x_18_2      CONF_7_18_2  1.0
    x_18_2      CONF_16_18_2  1.0
    x_18_3      ASSIGN_18  1.0
    x_18_3      CAP_3  15
    x_18_3      CONF_7_18_3  1.0
    x_18_3      CONF_16_18_3  1.0
    x_18_4      ASSIGN_18  1.0
    x_18_4      CAP_4  15
    x_18_4      CONF_7_18_4  1.0
    x_18_4      CONF_16_18_4  1.0
    x_18_5      ASSIGN_18  1.0
    x_18_5      CAP_5  15
    x_18_5      CONF_7_18_5  1.0
    x_18_5      CONF_16_18_5  1.0
    x_18_6      ASSIGN_18  1.0
    x_18_6      CAP_6  15
    x_18_6      CONF_7_18_6  1.0
    x_18_6      CONF_16_18_6  1.0
    x_18_7      ASSIGN_18  1.0
    x_18_7      CAP_7  15
    x_18_7      CONF_7_18_7  1.0
    x_18_7      CONF_16_18_7  1.0
    x_18_8      ASSIGN_18  1.0
    x_18_8      CAP_8  15
    x_18_8      CONF_7_18_8  1.0
    x_18_8      CONF_16_18_8  1.0
    x_18_9      ASSIGN_18  1.0
    x_18_9      CAP_9  15
    x_18_9      CONF_7_18_9  1.0
    x_18_9      CONF_16_18_9  1.0
    x_18_10     ASSIGN_18  1.0
    x_18_10     CAP_10  15
    x_18_10     CONF_7_18_10  1.0
    x_18_10     CONF_16_18_10  1.0
    x_18_11     ASSIGN_18  1.0
    x_18_11     CAP_11  15
    x_18_11     CONF_7_18_11  1.0
    x_18_11     CONF_16_18_11  1.0
    x_18_12     ASSIGN_18  1.0
    x_18_12     CAP_12  15
    x_18_12     CONF_7_18_12  1.0
    x_18_12     CONF_16_18_12  1.0
    x_18_13     ASSIGN_18  1.0
    x_18_13     CAP_13  15
    x_18_13     CONF_7_18_13  1.0
    x_18_13     CONF_16_18_13  1.0
    x_18_14     ASSIGN_18  1.0
    x_18_14     CAP_14  15
    x_18_14     CONF_7_18_14  1.0
    x_18_14     CONF_16_18_14  1.0
    x_18_15     ASSIGN_18  1.0
    x_18_15     CAP_15  15
    x_18_15     CONF_7_18_15  1.0
    x_18_15     CONF_16_18_15  1.0
    x_18_16     ASSIGN_18  1.0
    x_18_16     CAP_16  15
    x_18_16     CONF_7_18_16  1.0
    x_18_16     CONF_16_18_16  1.0
    x_18_17     ASSIGN_18  1.0
    x_18_17     CAP_17  15
    x_18_17     CONF_7_18_17  1.0
    x_18_17     CONF_16_18_17  1.0
    x_18_18     ASSIGN_18  1.0
    x_18_18     CAP_18  15
    x_18_18     CONF_7_18_18  1.0
    x_18_18     CONF_16_18_18  1.0
    x_18_19     ASSIGN_18  1.0
    x_18_19     CAP_19  15
    x_18_19     CONF_7_18_19  1.0
    x_18_19     CONF_16_18_19  1.0
    x_19_0      ASSIGN_19  1.0
    x_19_0      CAP_0  49
    x_19_0      CONF_10_19_0  1.0
    x_19_1      ASSIGN_19  1.0
    x_19_1      CAP_1  49
    x_19_1      CONF_10_19_1  1.0
    x_19_2      ASSIGN_19  1.0
    x_19_2      CAP_2  49
    x_19_2      CONF_10_19_2  1.0
    x_19_3      ASSIGN_19  1.0
    x_19_3      CAP_3  49
    x_19_3      CONF_10_19_3  1.0
    x_19_4      ASSIGN_19  1.0
    x_19_4      CAP_4  49
    x_19_4      CONF_10_19_4  1.0
    x_19_5      ASSIGN_19  1.0
    x_19_5      CAP_5  49
    x_19_5      CONF_10_19_5  1.0
    x_19_6      ASSIGN_19  1.0
    x_19_6      CAP_6  49
    x_19_6      CONF_10_19_6  1.0
    x_19_7      ASSIGN_19  1.0
    x_19_7      CAP_7  49
    x_19_7      CONF_10_19_7  1.0
    x_19_8      ASSIGN_19  1.0
    x_19_8      CAP_8  49
    x_19_8      CONF_10_19_8  1.0
    x_19_9      ASSIGN_19  1.0
    x_19_9      CAP_9  49
    x_19_9      CONF_10_19_9  1.0
    x_19_10     ASSIGN_19  1.0
    x_19_10     CAP_10  49
    x_19_10     CONF_10_19_10  1.0
    x_19_11     ASSIGN_19  1.0
    x_19_11     CAP_11  49
    x_19_11     CONF_10_19_11  1.0
    x_19_12     ASSIGN_19  1.0
    x_19_12     CAP_12  49
    x_19_12     CONF_10_19_12  1.0
    x_19_13     ASSIGN_19  1.0
    x_19_13     CAP_13  49
    x_19_13     CONF_10_19_13  1.0
    x_19_14     ASSIGN_19  1.0
    x_19_14     CAP_14  49
    x_19_14     CONF_10_19_14  1.0
    x_19_15     ASSIGN_19  1.0
    x_19_15     CAP_15  49
    x_19_15     CONF_10_19_15  1.0
    x_19_16     ASSIGN_19  1.0
    x_19_16     CAP_16  49
    x_19_16     CONF_10_19_16  1.0
    x_19_17     ASSIGN_19  1.0
    x_19_17     CAP_17  49
    x_19_17     CONF_10_19_17  1.0
    x_19_18     ASSIGN_19  1.0
    x_19_18     CAP_18  49
    x_19_18     CONF_10_19_18  1.0
    x_19_19     ASSIGN_19  1.0
    x_19_19     CAP_19  49
    x_19_19     CONF_10_19_19  1.0
    y_0         CAP_0  -150
    y_0         CONF_6_15_0  -1.0
    y_0         CONF_4_12_0  -1.0
    y_0         CONF_14_16_0  -1.0
    y_0         CONF_0_2_0  -1.0
    y_0         CONF_8_9_0  -1.0
    y_0         CONF_8_12_0  -1.0
    y_0         CONF_0_8_0  -1.0
    y_0         CONF_9_17_0  -1.0
    y_0         CONF_1_12_0  -1.0
    y_0         CONF_1_15_0  -1.0
    y_0         CONF_7_10_0  -1.0
    y_0         CONF_12_15_0  -1.0
    y_0         CONF_5_9_0  -1.0
    y_0         CONF_4_11_0  -1.0
    y_0         CONF_4_17_0  -1.0
    y_0         CONF_0_1_0  -1.0
    y_0         CONF_5_15_0  -1.0
    y_0         CONF_0_16_0  -1.0
    y_0         CONF_10_14_0  -1.0
    y_0         CONF_2_10_0  -1.0
    y_0         CONF_13_16_0  -1.0
    y_0         CONF_1_17_0  -1.0
    y_0         CONF_16_18_0  -1.0
    y_0         CONF_7_15_0  -1.0
    y_0         CONF_7_18_0  -1.0
    y_0         CONF_3_5_0  -1.0
    y_0         CONF_12_14_0  -1.0
    y_0         CONF_4_13_0  -1.0
    y_0         CONF_0_12_0  -1.0
    y_0         CONF_0_15_0  -1.0
    y_0         CONF_2_12_0  -1.0
    y_0         CONF_10_19_0  -1.0
    y_0         CONF_11_15_0  -1.0
    y_0         CONF_6_9_0  -1.0
    y_0         CONF_7_8_0  -1.0
    y_1         CAP_1  -150
    y_1         CONF_6_15_1  -1.0
    y_1         CONF_4_12_1  -1.0
    y_1         CONF_14_16_1  -1.0
    y_1         CONF_0_2_1  -1.0
    y_1         CONF_8_9_1  -1.0
    y_1         CONF_8_12_1  -1.0
    y_1         CONF_0_8_1  -1.0
    y_1         CONF_9_17_1  -1.0
    y_1         CONF_1_12_1  -1.0
    y_1         CONF_1_15_1  -1.0
    y_1         CONF_7_10_1  -1.0
    y_1         CONF_12_15_1  -1.0
    y_1         CONF_5_9_1  -1.0
    y_1         CONF_4_11_1  -1.0
    y_1         CONF_4_17_1  -1.0
    y_1         CONF_0_1_1  -1.0
    y_1         CONF_5_15_1  -1.0
    y_1         CONF_0_16_1  -1.0
    y_1         CONF_10_14_1  -1.0
    y_1         CONF_2_10_1  -1.0
    y_1         CONF_13_16_1  -1.0
    y_1         CONF_1_17_1  -1.0
    y_1         CONF_16_18_1  -1.0
    y_1         CONF_7_15_1  -1.0
    y_1         CONF_7_18_1  -1.0
    y_1         CONF_3_5_1  -1.0
    y_1         CONF_12_14_1  -1.0
    y_1         CONF_4_13_1  -1.0
    y_1         CONF_0_12_1  -1.0
    y_1         CONF_0_15_1  -1.0
    y_1         CONF_2_12_1  -1.0
    y_1         CONF_10_19_1  -1.0
    y_1         CONF_11_15_1  -1.0
    y_1         CONF_6_9_1  -1.0
    y_1         CONF_7_8_1  -1.0
    y_2         CAP_2  -150
    y_2         CONF_6_15_2  -1.0
    y_2         CONF_4_12_2  -1.0
    y_2         CONF_14_16_2  -1.0
    y_2         CONF_0_2_2  -1.0
    y_2         CONF_8_9_2  -1.0
    y_2         CONF_8_12_2  -1.0
    y_2         CONF_0_8_2  -1.0
    y_2         CONF_9_17_2  -1.0
    y_2         CONF_1_12_2  -1.0
    y_2         CONF_1_15_2  -1.0
    y_2         CONF_7_10_2  -1.0
    y_2         CONF_12_15_2  -1.0
    y_2         CONF_5_9_2  -1.0
    y_2         CONF_4_11_2  -1.0
    y_2         CONF_4_17_2  -1.0
    y_2         CONF_0_1_2  -1.0
    y_2         CONF_5_15_2  -1.0
    y_2         CONF_0_16_2  -1.0
    y_2         CONF_10_14_2  -1.0
    y_2         CONF_2_10_2  -1.0
    y_2         CONF_13_16_2  -1.0
    y_2         CONF_1_17_2  -1.0
    y_2         CONF_16_18_2  -1.0
    y_2         CONF_7_15_2  -1.0
    y_2         CONF_7_18_2  -1.0
    y_2         CONF_3_5_2  -1.0
    y_2         CONF_12_14_2  -1.0
    y_2         CONF_4_13_2  -1.0
    y_2         CONF_0_12_2  -1.0
    y_2         CONF_0_15_2  -1.0
    y_2         CONF_2_12_2  -1.0
    y_2         CONF_10_19_2  -1.0
    y_2         CONF_11_15_2  -1.0
    y_2         CONF_6_9_2  -1.0
    y_2         CONF_7_8_2  -1.0
    y_3         CAP_3  -150
    y_3         CONF_6_15_3  -1.0
    y_3         CONF_4_12_3  -1.0
    y_3         CONF_14_16_3  -1.0
    y_3         CONF_0_2_3  -1.0
    y_3         CONF_8_9_3  -1.0
    y_3         CONF_8_12_3  -1.0
    y_3         CONF_0_8_3  -1.0
    y_3         CONF_9_17_3  -1.0
    y_3         CONF_1_12_3  -1.0
    y_3         CONF_1_15_3  -1.0
    y_3         CONF_7_10_3  -1.0
    y_3         CONF_12_15_3  -1.0
    y_3         CONF_5_9_3  -1.0
    y_3         CONF_4_11_3  -1.0
    y_3         CONF_4_17_3  -1.0
    y_3         CONF_0_1_3  -1.0
    y_3         CONF_5_15_3  -1.0
    y_3         CONF_0_16_3  -1.0
    y_3         CONF_10_14_3  -1.0
    y_3         CONF_2_10_3  -1.0
    y_3         CONF_13_16_3  -1.0
    y_3         CONF_1_17_3  -1.0
    y_3         CONF_16_18_3  -1.0
    y_3         CONF_7_15_3  -1.0
    y_3         CONF_7_18_3  -1.0
    y_3         CONF_3_5_3  -1.0
    y_3         CONF_12_14_3  -1.0
    y_3         CONF_4_13_3  -1.0
    y_3         CONF_0_12_3  -1.0
    y_3         CONF_0_15_3  -1.0
    y_3         CONF_2_12_3  -1.0
    y_3         CONF_10_19_3  -1.0
    y_3         CONF_11_15_3  -1.0
    y_3         CONF_6_9_3  -1.0
    y_3         CONF_7_8_3  -1.0
    y_4         CAP_4  -150
    y_4         CONF_6_15_4  -1.0
    y_4         CONF_4_12_4  -1.0
    y_4         CONF_14_16_4  -1.0
    y_4         CONF_0_2_4  -1.0
    y_4         CONF_8_9_4  -1.0
    y_4         CONF_8_12_4  -1.0
    y_4         CONF_0_8_4  -1.0
    y_4         CONF_9_17_4  -1.0
    y_4         CONF_1_12_4  -1.0
    y_4         CONF_1_15_4  -1.0
    y_4         CONF_7_10_4  -1.0
    y_4         CONF_12_15_4  -1.0
    y_4         CONF_5_9_4  -1.0
    y_4         CONF_4_11_4  -1.0
    y_4         CONF_4_17_4  -1.0
    y_4         CONF_0_1_4  -1.0
    y_4         CONF_5_15_4  -1.0
    y_4         CONF_0_16_4  -1.0
    y_4         CONF_10_14_4  -1.0
    y_4         CONF_2_10_4  -1.0
    y_4         CONF_13_16_4  -1.0
    y_4         CONF_1_17_4  -1.0
    y_4         CONF_16_18_4  -1.0
    y_4         CONF_7_15_4  -1.0
    y_4         CONF_7_18_4  -1.0
    y_4         CONF_3_5_4  -1.0
    y_4         CONF_12_14_4  -1.0
    y_4         CONF_4_13_4  -1.0
    y_4         CONF_0_12_4  -1.0
    y_4         CONF_0_15_4  -1.0
    y_4         CONF_2_12_4  -1.0
    y_4         CONF_10_19_4  -1.0
    y_4         CONF_11_15_4  -1.0
    y_4         CONF_6_9_4  -1.0
    y_4         CONF_7_8_4  -1.0
    y_5         CAP_5  -150
    y_5         CONF_6_15_5  -1.0
    y_5         CONF_4_12_5  -1.0
    y_5         CONF_14_16_5  -1.0
    y_5         CONF_0_2_5  -1.0
    y_5         CONF_8_9_5  -1.0
    y_5         CONF_8_12_5  -1.0
    y_5         CONF_0_8_5  -1.0
    y_5         CONF_9_17_5  -1.0
    y_5         CONF_1_12_5  -1.0
    y_5         CONF_1_15_5  -1.0
    y_5         CONF_7_10_5  -1.0
    y_5         CONF_12_15_5  -1.0
    y_5         CONF_5_9_5  -1.0
    y_5         CONF_4_11_5  -1.0
    y_5         CONF_4_17_5  -1.0
    y_5         CONF_0_1_5  -1.0
    y_5         CONF_5_15_5  -1.0
    y_5         CONF_0_16_5  -1.0
    y_5         CONF_10_14_5  -1.0
    y_5         CONF_2_10_5  -1.0
    y_5         CONF_13_16_5  -1.0
    y_5         CONF_1_17_5  -1.0
    y_5         CONF_16_18_5  -1.0
    y_5         CONF_7_15_5  -1.0
    y_5         CONF_7_18_5  -1.0
    y_5         CONF_3_5_5  -1.0
    y_5         CONF_12_14_5  -1.0
    y_5         CONF_4_13_5  -1.0
    y_5         CONF_0_12_5  -1.0
    y_5         CONF_0_15_5  -1.0
    y_5         CONF_2_12_5  -1.0
    y_5         CONF_10_19_5  -1.0
    y_5         CONF_11_15_5  -1.0
    y_5         CONF_6_9_5  -1.0
    y_5         CONF_7_8_5  -1.0
    y_6         CAP_6  -150
    y_6         CONF_6_15_6  -1.0
    y_6         CONF_4_12_6  -1.0
    y_6         CONF_14_16_6  -1.0
    y_6         CONF_0_2_6  -1.0
    y_6         CONF_8_9_6  -1.0
    y_6         CONF_8_12_6  -1.0
    y_6         CONF_0_8_6  -1.0
    y_6         CONF_9_17_6  -1.0
    y_6         CONF_1_12_6  -1.0
    y_6         CONF_1_15_6  -1.0
    y_6         CONF_7_10_6  -1.0
    y_6         CONF_12_15_6  -1.0
    y_6         CONF_5_9_6  -1.0
    y_6         CONF_4_11_6  -1.0
    y_6         CONF_4_17_6  -1.0
    y_6         CONF_0_1_6  -1.0
    y_6         CONF_5_15_6  -1.0
    y_6         CONF_0_16_6  -1.0
    y_6         CONF_10_14_6  -1.0
    y_6         CONF_2_10_6  -1.0
    y_6         CONF_13_16_6  -1.0
    y_6         CONF_1_17_6  -1.0
    y_6         CONF_16_18_6  -1.0
    y_6         CONF_7_15_6  -1.0
    y_6         CONF_7_18_6  -1.0
    y_6         CONF_3_5_6  -1.0
    y_6         CONF_12_14_6  -1.0
    y_6         CONF_4_13_6  -1.0
    y_6         CONF_0_12_6  -1.0
    y_6         CONF_0_15_6  -1.0
    y_6         CONF_2_12_6  -1.0
    y_6         CONF_10_19_6  -1.0
    y_6         CONF_11_15_6  -1.0
    y_6         CONF_6_9_6  -1.0
    y_6         CONF_7_8_6  -1.0
    y_7         CAP_7  -150
    y_7         CONF_6_15_7  -1.0
    y_7         CONF_4_12_7  -1.0
    y_7         CONF_14_16_7  -1.0
    y_7         CONF_0_2_7  -1.0
    y_7         CONF_8_9_7  -1.0
    y_7         CONF_8_12_7  -1.0
    y_7         CONF_0_8_7  -1.0
    y_7         CONF_9_17_7  -1.0
    y_7         CONF_1_12_7  -1.0
    y_7         CONF_1_15_7  -1.0
    y_7         CONF_7_10_7  -1.0
    y_7         CONF_12_15_7  -1.0
    y_7         CONF_5_9_7  -1.0
    y_7         CONF_4_11_7  -1.0
    y_7         CONF_4_17_7  -1.0
    y_7         CONF_0_1_7  -1.0
    y_7         CONF_5_15_7  -1.0
    y_7         CONF_0_16_7  -1.0
    y_7         CONF_10_14_7  -1.0
    y_7         CONF_2_10_7  -1.0
    y_7         CONF_13_16_7  -1.0
    y_7         CONF_1_17_7  -1.0
    y_7         CONF_16_18_7  -1.0
    y_7         CONF_7_15_7  -1.0
    y_7         CONF_7_18_7  -1.0
    y_7         CONF_3_5_7  -1.0
    y_7         CONF_12_14_7  -1.0
    y_7         CONF_4_13_7  -1.0
    y_7         CONF_0_12_7  -1.0
    y_7         CONF_0_15_7  -1.0
    y_7         CONF_2_12_7  -1.0
    y_7         CONF_10_19_7  -1.0
    y_7         CONF_11_15_7  -1.0
    y_7         CONF_6_9_7  -1.0
    y_7         CONF_7_8_7  -1.0
    y_8         CAP_8  -150
    y_8         CONF_6_15_8  -1.0
    y_8         CONF_4_12_8  -1.0
    y_8         CONF_14_16_8  -1.0
    y_8         CONF_0_2_8  -1.0
    y_8         CONF_8_9_8  -1.0
    y_8         CONF_8_12_8  -1.0
    y_8         CONF_0_8_8  -1.0
    y_8         CONF_9_17_8  -1.0
    y_8         CONF_1_12_8  -1.0
    y_8         CONF_1_15_8  -1.0
    y_8         CONF_7_10_8  -1.0
    y_8         CONF_12_15_8  -1.0
    y_8         CONF_5_9_8  -1.0
    y_8         CONF_4_11_8  -1.0
    y_8         CONF_4_17_8  -1.0
    y_8         CONF_0_1_8  -1.0
    y_8         CONF_5_15_8  -1.0
    y_8         CONF_0_16_8  -1.0
    y_8         CONF_10_14_8  -1.0
    y_8         CONF_2_10_8  -1.0
    y_8         CONF_13_16_8  -1.0
    y_8         CONF_1_17_8  -1.0
    y_8         CONF_16_18_8  -1.0
    y_8         CONF_7_15_8  -1.0
    y_8         CONF_7_18_8  -1.0
    y_8         CONF_3_5_8  -1.0
    y_8         CONF_12_14_8  -1.0
    y_8         CONF_4_13_8  -1.0
    y_8         CONF_0_12_8  -1.0
    y_8         CONF_0_15_8  -1.0
    y_8         CONF_2_12_8  -1.0
    y_8         CONF_10_19_8  -1.0
    y_8         CONF_11_15_8  -1.0
    y_8         CONF_6_9_8  -1.0
    y_8         CONF_7_8_8  -1.0
    y_9         CAP_9  -150
    y_9         CONF_6_15_9  -1.0
    y_9         CONF_4_12_9  -1.0
    y_9         CONF_14_16_9  -1.0
    y_9         CONF_0_2_9  -1.0
    y_9         CONF_8_9_9  -1.0
    y_9         CONF_8_12_9  -1.0
    y_9         CONF_0_8_9  -1.0
    y_9         CONF_9_17_9  -1.0
    y_9         CONF_1_12_9  -1.0
    y_9         CONF_1_15_9  -1.0
    y_9         CONF_7_10_9  -1.0
    y_9         CONF_12_15_9  -1.0
    y_9         CONF_5_9_9  -1.0
    y_9         CONF_4_11_9  -1.0
    y_9         CONF_4_17_9  -1.0
    y_9         CONF_0_1_9  -1.0
    y_9         CONF_5_15_9  -1.0
    y_9         CONF_0_16_9  -1.0
    y_9         CONF_10_14_9  -1.0
    y_9         CONF_2_10_9  -1.0
    y_9         CONF_13_16_9  -1.0
    y_9         CONF_1_17_9  -1.0
    y_9         CONF_16_18_9  -1.0
    y_9         CONF_7_15_9  -1.0
    y_9         CONF_7_18_9  -1.0
    y_9         CONF_3_5_9  -1.0
    y_9         CONF_12_14_9  -1.0
    y_9         CONF_4_13_9  -1.0
    y_9         CONF_0_12_9  -1.0
    y_9         CONF_0_15_9  -1.0
    y_9         CONF_2_12_9  -1.0
    y_9         CONF_10_19_9  -1.0
    y_9         CONF_11_15_9  -1.0
    y_9         CONF_6_9_9  -1.0
    y_9         CONF_7_8_9  -1.0
    y_10        CAP_10  -150
    y_10        CONF_6_15_10  -1.0
    y_10        CONF_4_12_10  -1.0
    y_10        CONF_14_16_10  -1.0
    y_10        CONF_0_2_10  -1.0
    y_10        CONF_8_9_10  -1.0
    y_10        CONF_8_12_10  -1.0
    y_10        CONF_0_8_10  -1.0
    y_10        CONF_9_17_10  -1.0
    y_10        CONF_1_12_10  -1.0
    y_10        CONF_1_15_10  -1.0
    y_10        CONF_7_10_10  -1.0
    y_10        CONF_12_15_10  -1.0
    y_10        CONF_5_9_10  -1.0
    y_10        CONF_4_11_10  -1.0
    y_10        CONF_4_17_10  -1.0
    y_10        CONF_0_1_10  -1.0
    y_10        CONF_5_15_10  -1.0
    y_10        CONF_0_16_10  -1.0
    y_10        CONF_10_14_10  -1.0
    y_10        CONF_2_10_10  -1.0
    y_10        CONF_13_16_10  -1.0
    y_10        CONF_1_17_10  -1.0
    y_10        CONF_16_18_10  -1.0
    y_10        CONF_7_15_10  -1.0
    y_10        CONF_7_18_10  -1.0
    y_10        CONF_3_5_10  -1.0
    y_10        CONF_12_14_10  -1.0
    y_10        CONF_4_13_10  -1.0
    y_10        CONF_0_12_10  -1.0
    y_10        CONF_0_15_10  -1.0
    y_10        CONF_2_12_10  -1.0
    y_10        CONF_10_19_10  -1.0
    y_10        CONF_11_15_10  -1.0
    y_10        CONF_6_9_10  -1.0
    y_10        CONF_7_8_10  -1.0
    y_11        CAP_11  -150
    y_11        CONF_6_15_11  -1.0
    y_11        CONF_4_12_11  -1.0
    y_11        CONF_14_16_11  -1.0
    y_11        CONF_0_2_11  -1.0
    y_11        CONF_8_9_11  -1.0
    y_11        CONF_8_12_11  -1.0
    y_11        CONF_0_8_11  -1.0
    y_11        CONF_9_17_11  -1.0
    y_11        CONF_1_12_11  -1.0
    y_11        CONF_1_15_11  -1.0
    y_11        CONF_7_10_11  -1.0
    y_11        CONF_12_15_11  -1.0
    y_11        CONF_5_9_11  -1.0
    y_11        CONF_4_11_11  -1.0
    y_11        CONF_4_17_11  -1.0
    y_11        CONF_0_1_11  -1.0
    y_11        CONF_5_15_11  -1.0
    y_11        CONF_0_16_11  -1.0
    y_11        CONF_10_14_11  -1.0
    y_11        CONF_2_10_11  -1.0
    y_11        CONF_13_16_11  -1.0
    y_11        CONF_1_17_11  -1.0
    y_11        CONF_16_18_11  -1.0
    y_11        CONF_7_15_11  -1.0
    y_11        CONF_7_18_11  -1.0
    y_11        CONF_3_5_11  -1.0
    y_11        CONF_12_14_11  -1.0
    y_11        CONF_4_13_11  -1.0
    y_11        CONF_0_12_11  -1.0
    y_11        CONF_0_15_11  -1.0
    y_11        CONF_2_12_11  -1.0
    y_11        CONF_10_19_11  -1.0
    y_11        CONF_11_15_11  -1.0
    y_11        CONF_6_9_11  -1.0
    y_11        CONF_7_8_11  -1.0
    y_12        CAP_12  -150
    y_12        CONF_6_15_12  -1.0
    y_12        CONF_4_12_12  -1.0
    y_12        CONF_14_16_12  -1.0
    y_12        CONF_0_2_12  -1.0
    y_12        CONF_8_9_12  -1.0
    y_12        CONF_8_12_12  -1.0
    y_12        CONF_0_8_12  -1.0
    y_12        CONF_9_17_12  -1.0
    y_12        CONF_1_12_12  -1.0
    y_12        CONF_1_15_12  -1.0
    y_12        CONF_7_10_12  -1.0
    y_12        CONF_12_15_12  -1.0
    y_12        CONF_5_9_12  -1.0
    y_12        CONF_4_11_12  -1.0
    y_12        CONF_4_17_12  -1.0
    y_12        CONF_0_1_12  -1.0
    y_12        CONF_5_15_12  -1.0
    y_12        CONF_0_16_12  -1.0
    y_12        CONF_10_14_12  -1.0
    y_12        CONF_2_10_12  -1.0
    y_12        CONF_13_16_12  -1.0
    y_12        CONF_1_17_12  -1.0
    y_12        CONF_16_18_12  -1.0
    y_12        CONF_7_15_12  -1.0
    y_12        CONF_7_18_12  -1.0
    y_12        CONF_3_5_12  -1.0
    y_12        CONF_12_14_12  -1.0
    y_12        CONF_4_13_12  -1.0
    y_12        CONF_0_12_12  -1.0
    y_12        CONF_0_15_12  -1.0
    y_12        CONF_2_12_12  -1.0
    y_12        CONF_10_19_12  -1.0
    y_12        CONF_11_15_12  -1.0
    y_12        CONF_6_9_12  -1.0
    y_12        CONF_7_8_12  -1.0
    y_13        CAP_13  -150
    y_13        CONF_6_15_13  -1.0
    y_13        CONF_4_12_13  -1.0
    y_13        CONF_14_16_13  -1.0
    y_13        CONF_0_2_13  -1.0
    y_13        CONF_8_9_13  -1.0
    y_13        CONF_8_12_13  -1.0
    y_13        CONF_0_8_13  -1.0
    y_13        CONF_9_17_13  -1.0
    y_13        CONF_1_12_13  -1.0
    y_13        CONF_1_15_13  -1.0
    y_13        CONF_7_10_13  -1.0
    y_13        CONF_12_15_13  -1.0
    y_13        CONF_5_9_13  -1.0
    y_13        CONF_4_11_13  -1.0
    y_13        CONF_4_17_13  -1.0
    y_13        CONF_0_1_13  -1.0
    y_13        CONF_5_15_13  -1.0
    y_13        CONF_0_16_13  -1.0
    y_13        CONF_10_14_13  -1.0
    y_13        CONF_2_10_13  -1.0
    y_13        CONF_13_16_13  -1.0
    y_13        CONF_1_17_13  -1.0
    y_13        CONF_16_18_13  -1.0
    y_13        CONF_7_15_13  -1.0
    y_13        CONF_7_18_13  -1.0
    y_13        CONF_3_5_13  -1.0
    y_13        CONF_12_14_13  -1.0
    y_13        CONF_4_13_13  -1.0
    y_13        CONF_0_12_13  -1.0
    y_13        CONF_0_15_13  -1.0
    y_13        CONF_2_12_13  -1.0
    y_13        CONF_10_19_13  -1.0
    y_13        CONF_11_15_13  -1.0
    y_13        CONF_6_9_13  -1.0
    y_13        CONF_7_8_13  -1.0
    y_14        CAP_14  -150
    y_14        CONF_6_15_14  -1.0
    y_14        CONF_4_12_14  -1.0
    y_14        CONF_14_16_14  -1.0
    y_14        CONF_0_2_14  -1.0
    y_14        CONF_8_9_14  -1.0
    y_14        CONF_8_12_14  -1.0
    y_14        CONF_0_8_14  -1.0
    y_14        CONF_9_17_14  -1.0
    y_14        CONF_1_12_14  -1.0
    y_14        CONF_1_15_14  -1.0
    y_14        CONF_7_10_14  -1.0
    y_14        CONF_12_15_14  -1.0
    y_14        CONF_5_9_14  -1.0
    y_14        CONF_4_11_14  -1.0
    y_14        CONF_4_17_14  -1.0
    y_14        CONF_0_1_14  -1.0
    y_14        CONF_5_15_14  -1.0
    y_14        CONF_0_16_14  -1.0
    y_14        CONF_10_14_14  -1.0
    y_14        CONF_2_10_14  -1.0
    y_14        CONF_13_16_14  -1.0
    y_14        CONF_1_17_14  -1.0
    y_14        CONF_16_18_14  -1.0
    y_14        CONF_7_15_14  -1.0
    y_14        CONF_7_18_14  -1.0
    y_14        CONF_3_5_14  -1.0
    y_14        CONF_12_14_14  -1.0
    y_14        CONF_4_13_14  -1.0
    y_14        CONF_0_12_14  -1.0
    y_14        CONF_0_15_14  -1.0
    y_14        CONF_2_12_14  -1.0
    y_14        CONF_10_19_14  -1.0
    y_14        CONF_11_15_14  -1.0
    y_14        CONF_6_9_14  -1.0
    y_14        CONF_7_8_14  -1.0
    y_15        CAP_15  -150
    y_15        CONF_6_15_15  -1.0
    y_15        CONF_4_12_15  -1.0
    y_15        CONF_14_16_15  -1.0
    y_15        CONF_0_2_15  -1.0
    y_15        CONF_8_9_15  -1.0
    y_15        CONF_8_12_15  -1.0
    y_15        CONF_0_8_15  -1.0
    y_15        CONF_9_17_15  -1.0
    y_15        CONF_1_12_15  -1.0
    y_15        CONF_1_15_15  -1.0
    y_15        CONF_7_10_15  -1.0
    y_15        CONF_12_15_15  -1.0
    y_15        CONF_5_9_15  -1.0
    y_15        CONF_4_11_15  -1.0
    y_15        CONF_4_17_15  -1.0
    y_15        CONF_0_1_15  -1.0
    y_15        CONF_5_15_15  -1.0
    y_15        CONF_0_16_15  -1.0
    y_15        CONF_10_14_15  -1.0
    y_15        CONF_2_10_15  -1.0
    y_15        CONF_13_16_15  -1.0
    y_15        CONF_1_17_15  -1.0
    y_15        CONF_16_18_15  -1.0
    y_15        CONF_7_15_15  -1.0
    y_15        CONF_7_18_15  -1.0
    y_15        CONF_3_5_15  -1.0
    y_15        CONF_12_14_15  -1.0
    y_15        CONF_4_13_15  -1.0
    y_15        CONF_0_12_15  -1.0
    y_15        CONF_0_15_15  -1.0
    y_15        CONF_2_12_15  -1.0
    y_15        CONF_10_19_15  -1.0
    y_15        CONF_11_15_15  -1.0
    y_15        CONF_6_9_15  -1.0
    y_15        CONF_7_8_15  -1.0
    y_16        CAP_16  -150
    y_16        CONF_6_15_16  -1.0
    y_16        CONF_4_12_16  -1.0
    y_16        CONF_14_16_16  -1.0
    y_16        CONF_0_2_16  -1.0
    y_16        CONF_8_9_16  -1.0
    y_16        CONF_8_12_16  -1.0
    y_16        CONF_0_8_16  -1.0
    y_16        CONF_9_17_16  -1.0
    y_16        CONF_1_12_16  -1.0
    y_16        CONF_1_15_16  -1.0
    y_16        CONF_7_10_16  -1.0
    y_16        CONF_12_15_16  -1.0
    y_16        CONF_5_9_16  -1.0
    y_16        CONF_4_11_16  -1.0
    y_16        CONF_4_17_16  -1.0
    y_16        CONF_0_1_16  -1.0
    y_16        CONF_5_15_16  -1.0
    y_16        CONF_0_16_16  -1.0
    y_16        CONF_10_14_16  -1.0
    y_16        CONF_2_10_16  -1.0
    y_16        CONF_13_16_16  -1.0
    y_16        CONF_1_17_16  -1.0
    y_16        CONF_16_18_16  -1.0
    y_16        CONF_7_15_16  -1.0
    y_16        CONF_7_18_16  -1.0
    y_16        CONF_3_5_16  -1.0
    y_16        CONF_12_14_16  -1.0
    y_16        CONF_4_13_16  -1.0
    y_16        CONF_0_12_16  -1.0
    y_16        CONF_0_15_16  -1.0
    y_16        CONF_2_12_16  -1.0
    y_16        CONF_10_19_16  -1.0
    y_16        CONF_11_15_16  -1.0
    y_16        CONF_6_9_16  -1.0
    y_16        CONF_7_8_16  -1.0
    y_17        CAP_17  -150
    y_17        CONF_6_15_17  -1.0
    y_17        CONF_4_12_17  -1.0
    y_17        CONF_14_16_17  -1.0
    y_17        CONF_0_2_17  -1.0
    y_17        CONF_8_9_17  -1.0
    y_17        CONF_8_12_17  -1.0
    y_17        CONF_0_8_17  -1.0
    y_17        CONF_9_17_17  -1.0
    y_17        CONF_1_12_17  -1.0
    y_17        CONF_1_15_17  -1.0
    y_17        CONF_7_10_17  -1.0
    y_17        CONF_12_15_17  -1.0
    y_17        CONF_5_9_17  -1.0
    y_17        CONF_4_11_17  -1.0
    y_17        CONF_4_17_17  -1.0
    y_17        CONF_0_1_17  -1.0
    y_17        CONF_5_15_17  -1.0
    y_17        CONF_0_16_17  -1.0
    y_17        CONF_10_14_17  -1.0
    y_17        CONF_2_10_17  -1.0
    y_17        CONF_13_16_17  -1.0
    y_17        CONF_1_17_17  -1.0
    y_17        CONF_16_18_17  -1.0
    y_17        CONF_7_15_17  -1.0
    y_17        CONF_7_18_17  -1.0
    y_17        CONF_3_5_17  -1.0
    y_17        CONF_12_14_17  -1.0
    y_17        CONF_4_13_17  -1.0
    y_17        CONF_0_12_17  -1.0
    y_17        CONF_0_15_17  -1.0
    y_17        CONF_2_12_17  -1.0
    y_17        CONF_10_19_17  -1.0
    y_17        CONF_11_15_17  -1.0
    y_17        CONF_6_9_17  -1.0
    y_17        CONF_7_8_17  -1.0
    y_18        CAP_18  -150
    y_18        CONF_6_15_18  -1.0
    y_18        CONF_4_12_18  -1.0
    y_18        CONF_14_16_18  -1.0
    y_18        CONF_0_2_18  -1.0
    y_18        CONF_8_9_18  -1.0
    y_18        CONF_8_12_18  -1.0
    y_18        CONF_0_8_18  -1.0
    y_18        CONF_9_17_18  -1.0
    y_18        CONF_1_12_18  -1.0
    y_18        CONF_1_15_18  -1.0
    y_18        CONF_7_10_18  -1.0
    y_18        CONF_12_15_18  -1.0
    y_18        CONF_5_9_18  -1.0
    y_18        CONF_4_11_18  -1.0
    y_18        CONF_4_17_18  -1.0
    y_18        CONF_0_1_18  -1.0
    y_18        CONF_5_15_18  -1.0
    y_18        CONF_0_16_18  -1.0
    y_18        CONF_10_14_18  -1.0
    y_18        CONF_2_10_18  -1.0
    y_18        CONF_13_16_18  -1.0
    y_18        CONF_1_17_18  -1.0
    y_18        CONF_16_18_18  -1.0
    y_18        CONF_7_15_18  -1.0
    y_18        CONF_7_18_18  -1.0
    y_18        CONF_3_5_18  -1.0
    y_18        CONF_12_14_18  -1.0
    y_18        CONF_4_13_18  -1.0
    y_18        CONF_0_12_18  -1.0
    y_18        CONF_0_15_18  -1.0
    y_18        CONF_2_12_18  -1.0
    y_18        CONF_10_19_18  -1.0
    y_18        CONF_11_15_18  -1.0
    y_18        CONF_6_9_18  -1.0
    y_18        CONF_7_8_18  -1.0
    y_19        CAP_19  -150
    y_19        CONF_6_15_19  -1.0
    y_19        CONF_4_12_19  -1.0
    y_19        CONF_14_16_19  -1.0
    y_19        CONF_0_2_19  -1.0
    y_19        CONF_8_9_19  -1.0
    y_19        CONF_8_12_19  -1.0
    y_19        CONF_0_8_19  -1.0
    y_19        CONF_9_17_19  -1.0
    y_19        CONF_1_12_19  -1.0
    y_19        CONF_1_15_19  -1.0
    y_19        CONF_7_10_19  -1.0
    y_19        CONF_12_15_19  -1.0
    y_19        CONF_5_9_19  -1.0
    y_19        CONF_4_11_19  -1.0
    y_19        CONF_4_17_19  -1.0
    y_19        CONF_0_1_19  -1.0
    y_19        CONF_5_15_19  -1.0
    y_19        CONF_0_16_19  -1.0
    y_19        CONF_10_14_19  -1.0
    y_19        CONF_2_10_19  -1.0
    y_19        CONF_13_16_19  -1.0
    y_19        CONF_1_17_19  -1.0
    y_19        CONF_16_18_19  -1.0
    y_19        CONF_7_15_19  -1.0
    y_19        CONF_7_18_19  -1.0
    y_19        CONF_3_5_19  -1.0
    y_19        CONF_12_14_19  -1.0
    y_19        CONF_4_13_19  -1.0
    y_19        CONF_0_12_19  -1.0
    y_19        CONF_0_15_19  -1.0
    y_19        CONF_2_12_19  -1.0
    y_19        CONF_10_19_19  -1.0
    y_19        CONF_11_15_19  -1.0
    y_19        CONF_6_9_19  -1.0
    y_19        CONF_7_8_19  -1.0
RHS
    RHS1      ASSIGN_0  1.0
    RHS1      ASSIGN_1  1.0
    RHS1      ASSIGN_2  1.0
    RHS1      ASSIGN_3  1.0
    RHS1      ASSIGN_4  1.0
    RHS1      ASSIGN_5  1.0
    RHS1      ASSIGN_6  1.0
    RHS1      ASSIGN_7  1.0
    RHS1      ASSIGN_8  1.0
    RHS1      ASSIGN_9  1.0
    RHS1      ASSIGN_10  1.0
    RHS1      ASSIGN_11  1.0
    RHS1      ASSIGN_12  1.0
    RHS1      ASSIGN_13  1.0
    RHS1      ASSIGN_14  1.0
    RHS1      ASSIGN_15  1.0
    RHS1      ASSIGN_16  1.0
    RHS1      ASSIGN_17  1.0
    RHS1      ASSIGN_18  1.0
    RHS1      ASSIGN_19  1.0
BOUNDS
 BV BND1      y_0
 BV BND1      y_1
 BV BND1      y_2
 BV BND1      y_3
 BV BND1      y_4
 BV BND1      y_5
 BV BND1      y_6
 BV BND1      y_7
 BV BND1      y_8
 BV BND1      y_9
 BV BND1      y_10
 BV BND1      y_11
 BV BND1      y_12
 BV BND1      y_13
 BV BND1      y_14
 BV BND1      y_15
 BV BND1      y_16
 BV BND1      y_17
 BV BND1      y_18
 BV BND1      y_19
 BV BND1      x_0_0
 BV BND1      x_0_1
 BV BND1      x_0_2
 BV BND1      x_0_3
 BV BND1      x_0_4
 BV BND1      x_0_5
 BV BND1      x_0_6
 BV BND1      x_0_7
 BV BND1      x_0_8
 BV BND1      x_0_9
 BV BND1      x_0_10
 BV BND1      x_0_11
 BV BND1      x_0_12
 BV BND1      x_0_13
 BV BND1      x_0_14
 BV BND1      x_0_15
 BV BND1      x_0_16
 BV BND1      x_0_17
 BV BND1      x_0_18
 BV BND1      x_0_19
 BV BND1      x_1_0
 BV BND1      x_1_1
 BV BND1      x_1_2
 BV BND1      x_1_3
 BV BND1      x_1_4
 BV BND1      x_1_5
 BV BND1      x_1_6
 BV BND1      x_1_7
 BV BND1      x_1_8
 BV BND1      x_1_9
 BV BND1      x_1_10
 BV BND1      x_1_11
 BV BND1      x_1_12
 BV BND1      x_1_13
 BV BND1      x_1_14
 BV BND1      x_1_15
 BV BND1      x_1_16
 BV BND1      x_1_17
 BV BND1      x_1_18
 BV BND1      x_1_19
 BV BND1      x_2_0
 BV BND1      x_2_1
 BV BND1      x_2_2
 BV BND1      x_2_3
 BV BND1      x_2_4
 BV BND1      x_2_5
 BV BND1      x_2_6
 BV BND1      x_2_7
 BV BND1      x_2_8
 BV BND1      x_2_9
 BV BND1      x_2_10
 BV BND1      x_2_11
 BV BND1      x_2_12
 BV BND1      x_2_13
 BV BND1      x_2_14
 BV BND1      x_2_15
 BV BND1      x_2_16
 BV BND1      x_2_17
 BV BND1      x_2_18
 BV BND1      x_2_19
 BV BND1      x_3_0
 BV BND1      x_3_1
 BV BND1      x_3_2
 BV BND1      x_3_3
 BV BND1      x_3_4
 BV BND1      x_3_5
 BV BND1      x_3_6
 BV BND1      x_3_7
 BV BND1      x_3_8
 BV BND1      x_3_9
 BV BND1      x_3_10
 BV BND1      x_3_11
 BV BND1      x_3_12
 BV BND1      x_3_13
 BV BND1      x_3_14
 BV BND1      x_3_15
 BV BND1      x_3_16
 BV BND1      x_3_17
 BV BND1      x_3_18
 BV BND1      x_3_19
 BV BND1      x_4_0
 BV BND1      x_4_1
 BV BND1      x_4_2
 BV BND1      x_4_3
 BV BND1      x_4_4
 BV BND1      x_4_5
 BV BND1      x_4_6
 BV BND1      x_4_7
 BV BND1      x_4_8
 BV BND1      x_4_9
 BV BND1      x_4_10
 BV BND1      x_4_11
 BV BND1      x_4_12
 BV BND1      x_4_13
 BV BND1      x_4_14
 BV BND1      x_4_15
 BV BND1      x_4_16
 BV BND1      x_4_17
 BV BND1      x_4_18
 BV BND1      x_4_19
 BV BND1      x_5_0
 BV BND1      x_5_1
 BV BND1      x_5_2
 BV BND1      x_5_3
 BV BND1      x_5_4
 BV BND1      x_5_5
 BV BND1      x_5_6
 BV BND1      x_5_7
 BV BND1      x_5_8
 BV BND1      x_5_9
 BV BND1      x_5_10
 BV BND1      x_5_11
 BV BND1      x_5_12
 BV BND1      x_5_13
 BV BND1      x_5_14
 BV BND1      x_5_15
 BV BND1      x_5_16
 BV BND1      x_5_17
 BV BND1      x_5_18
 BV BND1      x_5_19
 BV BND1      x_6_0
 BV BND1      x_6_1
 BV BND1      x_6_2
 BV BND1      x_6_3
 BV BND1      x_6_4
 BV BND1      x_6_5
 BV BND1      x_6_6
 BV BND1      x_6_7
 BV BND1      x_6_8
 BV BND1      x_6_9
 BV BND1      x_6_10
 BV BND1      x_6_11
 BV BND1      x_6_12
 BV BND1      x_6_13
 BV BND1      x_6_14
 BV BND1      x_6_15
 BV BND1      x_6_16
 BV BND1      x_6_17
 BV BND1      x_6_18
 BV BND1      x_6_19
 BV BND1      x_7_0
 BV BND1      x_7_1
 BV BND1      x_7_2
 BV BND1      x_7_3
 BV BND1      x_7_4
 BV BND1      x_7_5
 BV BND1      x_7_6
 BV BND1      x_7_7
 BV BND1      x_7_8
 BV BND1      x_7_9
 BV BND1      x_7_10
 BV BND1      x_7_11
 BV BND1      x_7_12
 BV BND1      x_7_13
 BV BND1      x_7_14
 BV BND1      x_7_15
 BV BND1      x_7_16
 BV BND1      x_7_17
 BV BND1      x_7_18
 BV BND1      x_7_19
 BV BND1      x_8_0
 BV BND1      x_8_1
 BV BND1      x_8_2
 BV BND1      x_8_3
 BV BND1      x_8_4
 BV BND1      x_8_5
 BV BND1      x_8_6
 BV BND1      x_8_7
 BV BND1      x_8_8
 BV BND1      x_8_9
 BV BND1      x_8_10
 BV BND1      x_8_11
 BV BND1      x_8_12
 BV BND1      x_8_13
 BV BND1      x_8_14
 BV BND1      x_8_15
 BV BND1      x_8_16
 BV BND1      x_8_17
 BV BND1      x_8_18
 BV BND1      x_8_19
 BV BND1      x_9_0
 BV BND1      x_9_1
 BV BND1      x_9_2
 BV BND1      x_9_3
 BV BND1      x_9_4
 BV BND1      x_9_5
 BV BND1      x_9_6
 BV BND1      x_9_7
 BV BND1      x_9_8
 BV BND1      x_9_9
 BV BND1      x_9_10
 BV BND1      x_9_11
 BV BND1      x_9_12
 BV BND1      x_9_13
 BV BND1      x_9_14
 BV BND1      x_9_15
 BV BND1      x_9_16
 BV BND1      x_9_17
 BV BND1      x_9_18
 BV BND1      x_9_19
 BV BND1      x_10_0
 BV BND1      x_10_1
 BV BND1      x_10_2
 BV BND1      x_10_3
 BV BND1      x_10_4
 BV BND1      x_10_5
 BV BND1      x_10_6
 BV BND1      x_10_7
 BV BND1      x_10_8
 BV BND1      x_10_9
 BV BND1      x_10_10
 BV BND1      x_10_11
 BV BND1      x_10_12
 BV BND1      x_10_13
 BV BND1      x_10_14
 BV BND1      x_10_15
 BV BND1      x_10_16
 BV BND1      x_10_17
 BV BND1      x_10_18
 BV BND1      x_10_19
 BV BND1      x_11_0
 BV BND1      x_11_1
 BV BND1      x_11_2
 BV BND1      x_11_3
 BV BND1      x_11_4
 BV BND1      x_11_5
 BV BND1      x_11_6
 BV BND1      x_11_7
 BV BND1      x_11_8
 BV BND1      x_11_9
 BV BND1      x_11_10
 BV BND1      x_11_11
 BV BND1      x_11_12
 BV BND1      x_11_13
 BV BND1      x_11_14
 BV BND1      x_11_15
 BV BND1      x_11_16
 BV BND1      x_11_17
 BV BND1      x_11_18
 BV BND1      x_11_19
 BV BND1      x_12_0
 BV BND1      x_12_1
 BV BND1      x_12_2
 BV BND1      x_12_3
 BV BND1      x_12_4
 BV BND1      x_12_5
 BV BND1      x_12_6
 BV BND1      x_12_7
 BV BND1      x_12_8
 BV BND1      x_12_9
 BV BND1      x_12_10
 BV BND1      x_12_11
 BV BND1      x_12_12
 BV BND1      x_12_13
 BV BND1      x_12_14
 BV BND1      x_12_15
 BV BND1      x_12_16
 BV BND1      x_12_17
 BV BND1      x_12_18
 BV BND1      x_12_19
 BV BND1      x_13_0
 BV BND1      x_13_1
 BV BND1      x_13_2
 BV BND1      x_13_3
 BV BND1      x_13_4
 BV BND1      x_13_5
 BV BND1      x_13_6
 BV BND1      x_13_7
 BV BND1      x_13_8
 BV BND1      x_13_9
 BV BND1      x_13_10
 BV BND1      x_13_11
 BV BND1      x_13_12
 BV BND1      x_13_13
 BV BND1      x_13_14
 BV BND1      x_13_15
 BV BND1      x_13_16
 BV BND1      x_13_17
 BV BND1      x_13_18
 BV BND1      x_13_19
 BV BND1      x_14_0
 BV BND1      x_14_1
 BV BND1      x_14_2
 BV BND1      x_14_3
 BV BND1      x_14_4
 BV BND1      x_14_5
 BV BND1      x_14_6
 BV BND1      x_14_7
 BV BND1      x_14_8
 BV BND1      x_14_9
 BV BND1      x_14_10
 BV BND1      x_14_11
 BV BND1      x_14_12
 BV BND1      x_14_13
 BV BND1      x_14_14
 BV BND1      x_14_15
 BV BND1      x_14_16
 BV BND1      x_14_17
 BV BND1      x_14_18
 BV BND1      x_14_19
 BV BND1      x_15_0
 BV BND1      x_15_1
 BV BND1      x_15_2
 BV BND1      x_15_3
 BV BND1      x_15_4
 BV BND1      x_15_5
 BV BND1      x_15_6
 BV BND1      x_15_7
 BV BND1      x_15_8
 BV BND1      x_15_9
 BV BND1      x_15_10
 BV BND1      x_15_11
 BV BND1      x_15_12
 BV BND1      x_15_13
 BV BND1      x_15_14
 BV BND1      x_15_15
 BV BND1      x_15_16
 BV BND1      x_15_17
 BV BND1      x_15_18
 BV BND1      x_15_19
 BV BND1      x_16_0
 BV BND1      x_16_1
 BV BND1      x_16_2
 BV BND1      x_16_3
 BV BND1      x_16_4
 BV BND1      x_16_5
 BV BND1      x_16_6
 BV BND1      x_16_7
 BV BND1      x_16_8
 BV BND1      x_16_9
 BV BND1      x_16_10
 BV BND1      x_16_11
 BV BND1      x_16_12
 BV BND1      x_16_13
 BV BND1      x_16_14
 BV BND1      x_16_15
 BV BND1      x_16_16
 BV BND1      x_16_17
 BV BND1      x_16_18
 BV BND1      x_16_19
 BV BND1      x_17_0
 BV BND1      x_17_1
 BV BND1      x_17_2
 BV BND1      x_17_3
 BV BND1      x_17_4
 BV BND1      x_17_5
 BV BND1      x_17_6
 BV BND1      x_17_7
 BV BND1      x_17_8
 BV BND1      x_17_9
 BV BND1      x_17_10
 BV BND1      x_17_11
 BV BND1      x_17_12
 BV BND1      x_17_13
 BV BND1      x_17_14
 BV BND1      x_17_15
 BV BND1      x_17_16
 BV BND1      x_17_17
 BV BND1      x_17_18
 BV BND1      x_17_19
 BV BND1      x_18_0
 BV BND1      x_18_1
 BV BND1      x_18_2
 BV BND1      x_18_3
 BV BND1      x_18_4
 BV BND1      x_18_5
 BV BND1      x_18_6
 BV BND1      x_18_7
 BV BND1      x_18_8
 BV BND1      x_18_9
 BV BND1      x_18_10
 BV BND1      x_18_11
 BV BND1      x_18_12
 BV BND1      x_18_13
 BV BND1      x_18_14
 BV BND1      x_18_15
 BV BND1      x_18_16
 BV BND1      x_18_17
 BV BND1      x_18_18
 BV BND1      x_18_19
 BV BND1      x_19_0
 BV BND1      x_19_1
 BV BND1      x_19_2
 BV BND1      x_19_3
 BV BND1      x_19_4
 BV BND1      x_19_5
 BV BND1      x_19_6
 BV BND1      x_19_7
 BV BND1      x_19_8
 BV BND1      x_19_9
 BV BND1      x_19_10
 BV BND1      x_19_11
 BV BND1      x_19_12
 BV BND1      x_19_13
 BV BND1      x_19_14
 BV BND1      x_19_15
 BV BND1      x_19_16
 BV BND1      x_19_17
 BV BND1      x_19_18
 BV BND1      x_19_19
ENDATA
