NAME          MIS
ROWS
 N  OBJ
 L  EDGE_6_12
 L  EDGE_15_21
 L  EDGE_24_30
 L  EDGE_3_4
 L  EDGE_26_27
 L  EDGE_16_17
 L  EDGE_12_13
 L  EDGE_21_22
 L  EDGE_20_26
 L  EDGE_22_23
 L  EDGE_29_35
 L  EDGE_31_32
 L  EDGE_3_10
 L  EDGE_8_9
 L  EDGE_22_29
 L  EDGE_27_28
 L  EDGE_25_26
 L  EDGE_2_8
 L  EDGE_11_17
 L  EDGE_13_14
 L  EDGE_36_37
 L  EDGE_13_20
 L  EDGE_32_33
 L  EDGE_7_13
 L  EDGE_16_22
 L  EDGE_18_19
 L  EDGE_25_31
 L  EDGE_26_32
 L  EDGE_4_5
 L  EDGE_3_9
 L  EDGE_18_25
 L  EDGE_12_18
 L  EDGE_14_15
 L  EDGE_21_27
 L  EDGE_22_28
 L  EDGE_0_1
 L  EDGE_9_10
 L  EDGE_8_14
 L  EDGE_1_2
 L  EDGE_10_11
 L  EDGE_17_23
 L  EDGE_0_7
 L  EDGE_19_20
 L  EDGE_28_29
 L  EDGE_27_33
 L  EDGE_37_38
 L  EDGE_13_19
 L  EDGE_6_7
 L  EDGE_15_16
 L  EDGE_24_25
 L  EDGE_33_34
 L  EDGE_18_24
 L  EDGE_20_21
 L  EDGE_4_10
 L  EDGE_5_11
 L  EDGE_38_39
 L  EDGE_20_27
 L  EDGE_14_20
 L  EDGE_23_29
 L  EDGE_34_35
 L  EDGE_0_6
 L  EDGE_2_3
 L  EDGE_9_15
 L  EDGE_1_7
 L  EDGE_10_16
 L  EDGE_19_25
 L  EDGE_28_34
 L  EDGE_30_31
 L  EDGE_7_8
 L  EDGE_16_23
COLUMNS
    x_0         OBJ       -10
    x_0         EDGE_0_1  1.0
    x_0         EDGE_0_7  1.0
    x_0         EDGE_0_6  1.0
    x_1         OBJ       -24
    x_1         EDGE_0_1  1.0
    x_1         EDGE_1_2  1.0
    x_1         EDGE_1_7  1.0
    x_2         OBJ       -53
    x_2         EDGE_2_8  1.0
    x_2         EDGE_1_2  1.0
    x_2         EDGE_2_3  1.0
    x_3         OBJ       -42
    x_3         EDGE_3_4  1.0
    x_3         EDGE_3_10  1.0
    x_3         EDGE_3_9  1.0
    x_3         EDGE_2_3  1.0
    x_4         OBJ       -25
    x_4         EDGE_3_4  1.0
    x_4         EDGE_4_5  1.0
    x_4         EDGE_4_10  1.0
    x_5         OBJ       -30
    x_5         EDGE_4_5  1.0
    x_5         EDGE_5_11  1.0
    x_6         OBJ       -63
    x_6         EDGE_6_12  1.0
    x_6         EDGE_6_7  1.0
    x_6         EDGE_0_6  1.0
    x_7         OBJ       -45
    x_7         EDGE_7_13  1.0
    x_7         EDGE_0_7  1.0
    x_7         EDGE_6_7  1.0
    x_7         EDGE_1_7  1.0
    x_7         EDGE_7_8  1.0
    x_8         OBJ       -2
    x_8         EDGE_8_9  1.0
    x_8         EDGE_2_8  1.0
    x_8         EDGE_8_14  1.0
    x_8         EDGE_7_8  1.0
    x_9         OBJ       -52
    x_9         EDGE_8_9  1.0
    x_9         EDGE_3_9  1.0
    x_9         EDGE_9_10  1.0
    x_9         EDGE_9_15  1.0
    x_10        OBJ       -66
    x_10        EDGE_3_10  1.0
    x_10        EDGE_9_10  1.0
    x_10        EDGE_10_11  1.0
    x_10        EDGE_4_10  1.0
    x_10        EDGE_10_16  1.0
    x_11        OBJ       -42
    x_11        EDGE_11_17  1.0
    x_11        EDGE_10_11  1.0
    x_11        EDGE_5_11  1.0
    x_12        OBJ       -51
    x_12        EDGE_6_12  1.0
    x_12        EDGE_12_13  1.0
    x_12        EDGE_12_18  1.0
    x_13        OBJ       -68
    x_13        EDGE_12_13  1.0
    x_13        EDGE_13_14  1.0
    x_13        EDGE_13_20  1.0
    x_13        EDGE_7_13  1.0
    x_13        EDGE_13_19  1.0
    x_14        OBJ       -61
    x_14        EDGE_13_14  1.0
    x_14        EDGE_14_15  1.0
    x_14        EDGE_8_14  1.0
    x_14        EDGE_14_20  1.0
    x_15        OBJ       -18
    x_15        EDGE_15_21  1.0
    x_15        EDGE_14_15  1.0
    x_15        EDGE_15_16  1.0
    x_15        EDGE_9_15  1.0
    x_16        OBJ       -55
    x_16        EDGE_16_17  1.0
    x_16        EDGE_16_22  1.0
    x_16        EDGE_15_16  1.0
    x_16        EDGE_10_16  1.0
    x_16        EDGE_16_23  1.0
    x_17        OBJ       -67
    x_17        EDGE_16_17  1.0
    x_17        EDGE_11_17  1.0
    x_17        EDGE_17_23  1.0
    x_18        OBJ       -67
    x_18        EDGE_18_19  1.0
    x_18        EDGE_18_25  1.0
    x_18        EDGE_12_18  1.0
    x_18        EDGE_18_24  1.0
    x_19        OBJ       -43
    x_19        EDGE_18_19  1.0
    x_19        EDGE_19_20  1.0
    x_19        EDGE_13_19  1.0
    x_19        EDGE_19_25  1.0
    x_20        OBJ       -1
    x_20        EDGE_20_26  1.0
    x_20        EDGE_13_20  1.0
    x_20        EDGE_19_20  1.0
    x_20        EDGE_20_21  1.0
    x_20        EDGE_20_27  1.0
    x_20        EDGE_14_20  1.0
    x_21        OBJ       -79
    x_21        EDGE_15_21  1.0
    x_21        EDGE_21_22  1.0
    x_21        EDGE_21_27  1.0
    x_21        EDGE_20_21  1.0
    x_22        OBJ       -4
    x_22        EDGE_21_22  1.0
    x_22        EDGE_22_23  1.0
    x_22        EDGE_22_29  1.0
    x_22        EDGE_16_22  1.0
    x_22        EDGE_22_28  1.0
    x_23        OBJ       -86
    x_23        EDGE_22_23  1.0
    x_23        EDGE_17_23  1.0
    x_23        EDGE_23_29  1.0
    x_23        EDGE_16_23  1.0
    x_24        OBJ       -89
    x_24        EDGE_24_30  1.0
    x_24        EDGE_24_25  1.0
    x_24        EDGE_18_24  1.0
    x_25        OBJ       -19
    x_25        EDGE_25_26  1.0
    x_25        EDGE_25_31  1.0
    x_25        EDGE_18_25  1.0
    x_25        EDGE_24_25  1.0
    x_25        EDGE_19_25  1.0
    x_26        OBJ       -62
    x_26        EDGE_26_27  1.0
    x_26        EDGE_20_26  1.0
    x_26        EDGE_25_26  1.0
    x_26        EDGE_26_32  1.0
    x_27        OBJ       -47
    x_27        EDGE_26_27  1.0
    x_27        EDGE_27_28  1.0
    x_27        EDGE_21_27  1.0
    x_27        EDGE_27_33  1.0
    x_27        EDGE_20_27  1.0
    x_28        OBJ       -23
    x_28        EDGE_27_28  1.0
    x_28        EDGE_22_28  1.0
    x_28        EDGE_28_29  1.0
    x_28        EDGE_28_34  1.0
    x_29        OBJ       -45
    x_29        EDGE_29_35  1.0
    x_29        EDGE_22_29  1.0
    x_29        EDGE_28_29  1.0
    x_29        EDGE_23_29  1.0
    x_30        OBJ       -32
    x_30        EDGE_24_30  1.0
    x_30        EDGE_30_31  1.0
    x_31        OBJ       -63
    x_31        EDGE_31_32  1.0
    x_31        EDGE_25_31  1.0
    x_31        EDGE_30_31  1.0
    x_32        OBJ       -50
    x_32        EDGE_31_32  1.0
    x_32        EDGE_32_33  1.0
    x_32        EDGE_26_32  1.0
    x_33        OBJ       -42
    x_33        EDGE_32_33  1.0
    x_33        EDGE_27_33  1.0
    x_33        EDGE_33_34  1.0
    x_34        OBJ       -41
    x_34        EDGE_33_34  1.0
    x_34        EDGE_34_35  1.0
    x_34        EDGE_28_34  1.0
    x_35        OBJ       -92
    x_35        EDGE_29_35  1.0
    x_35        EDGE_34_35  1.0
    x_36        OBJ       -2
    x_36        EDGE_36_37  1.0
    x_37        OBJ       -90
    x_37        EDGE_36_37  1.0
    x_37        EDGE_37_38  1.0
    x_38        OBJ       -52
    x_38        EDGE_37_38  1.0
    x_38        EDGE_38_39  1.0
    x_39        OBJ       -44
    x_39        EDGE_38_39  1.0
RHS
    RHS1      EDGE_6_12  1.0
    RHS1      EDGE_15_21  1.0
    RHS1      EDGE_24_30  1.0
    RHS1      EDGE_3_4  1.0
    RHS1      EDGE_26_27  1.0
    RHS1      EDGE_16_17  1.0
    RHS1      EDGE_12_13  1.0
    RHS1      EDGE_21_22  1.0
    RHS1      EDGE_20_26  1.0
    RHS1      EDGE_22_23  1.0
    RHS1      EDGE_29_35  1.0
    RHS1      EDGE_31_32  1.0
    RHS1      EDGE_3_10  1.0
    RHS1      EDGE_8_9  1.0
    RHS1      EDGE_22_29  1.0
    RHS1      EDGE_27_28  1.0
    RHS1      EDGE_25_26  1.0
    RHS1      EDGE_2_8  1.0
    RHS1      EDGE_11_17  1.0
    RHS1      EDGE_13_14  1.0
    RHS1      EDGE_36_37  1.0
    RHS1      EDGE_13_20  1.0
    RHS1      EDGE_32_33  1.0
    RHS1      EDGE_7_13  1.0
    RHS1      EDGE_16_22  1.0
    RHS1      EDGE_18_19  1.0
    RHS1      EDGE_25_31  1.0
    RHS1      EDGE_26_32  1.0
    RHS1      EDGE_4_5  1.0
    RHS1      EDGE_3_9  1.0
    RHS1      EDGE_18_25  1.0
    RHS1      EDGE_12_18  1.0
    RHS1      EDGE_14_15  1.0
    RHS1      EDGE_21_27  1.0
    RHS1      EDGE_22_28  1.0
    RHS1      EDGE_0_1  1.0
    RHS1      EDGE_9_10  1.0
    RHS1      EDGE_8_14  1.0
    RHS1      EDGE_1_2  1.0
    RHS1      EDGE_10_11  1.0
    RHS1      EDGE_17_23  1.0
    RHS1      EDGE_0_7  1.0
    RHS1      EDGE_19_20  1.0
    RHS1      EDGE_28_29  1.0
    RHS1      EDGE_27_33  1.0
    RHS1      EDGE_37_38  1.0
    RHS1      EDGE_13_19  1.0
    RHS1      EDGE_6_7  1.0
    RHS1      EDGE_15_16  1.0
    RHS1      EDGE_24_25  1.0
    RHS1      EDGE_33_34  1.0
    RHS1      EDGE_18_24  1.0
    RHS1      EDGE_20_21  1.0
    RHS1      EDGE_4_10  1.0
    RHS1      EDGE_5_11  1.0
    RHS1      EDGE_38_39  1.0
    RHS1      EDGE_20_27  1.0
    RHS1      EDGE_14_20  1.0
    RHS1      EDGE_23_29  1.0
    RHS1      EDGE_34_35  1.0
    RHS1      EDGE_0_6  1.0
    RHS1      EDGE_2_3  1.0
    RHS1      EDGE_9_15  1.0
    RHS1      EDGE_1_7  1.0
    RHS1      EDGE_10_16  1.0
    RHS1      EDGE_19_25  1.0
    RHS1      EDGE_28_34  1.0
    RHS1      EDGE_30_31  1.0
    RHS1      EDGE_7_8  1.0
    RHS1      EDGE_16_23  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
 BV BND1      x_30
 BV BND1      x_31
 BV BND1      x_32
 BV BND1      x_33
 BV BND1      x_34
 BV BND1      x_35
 BV BND1      x_36
 BV BND1      x_37
 BV BND1      x_38
 BV BND1      x_39
ENDATA
