NAME          SETPART
ROWS
 N  OBJ
 E  PART_0
 E  PART_1
 E  PART_2
 E  PART_3
 E  PART_4
 E  PART_5
 E  PART_6
 E  PART_7
 E  PART_8
 E  PART_9
COLUMNS
    x_0         OBJ       82
    x_0         PART_0  1.0
    x_0         PART_2  1.0
    x_1         OBJ       15
    x_1         PART_7  1.0
    x_2         OBJ       4
    x_2         PART_5  1.0
    x_2         PART_8  1.0
    x_2         PART_9  1.0
    x_3         OBJ       95
    x_3         PART_7  1.0
    x_4         OBJ       36
    x_4         PART_4  1.0
    x_5         OBJ       32
    x_6         OBJ       29
    x_6         PART_1  1.0
    x_6         PART_4  1.0
    x_6         PART_9  1.0
    x_7         OBJ       18
    x_7         PART_1  1.0
    x_8         OBJ       95
    x_8         PART_2  1.0
    x_8         PART_7  1.0
    x_9         OBJ       14
    x_9         PART_8  1.0
    x_10        OBJ       87
    x_10        PART_3  1.0
    x_10        PART_4  1.0
    x_11        OBJ       95
    x_11        PART_6  1.0
    x_11        PART_9  1.0
    x_12        OBJ       70
    x_12        PART_5  1.0
    x_13        OBJ       12
    x_13        PART_1  1.0
    x_13        PART_3  1.0
    x_14        OBJ       76
    x_14        PART_7  1.0
    x_15        OBJ       55
    x_16        OBJ       5
    x_16        PART_0  1.0
    x_17        OBJ       4
    x_17        PART_1  1.0
    x_17        PART_8  1.0
    x_18        OBJ       12
    x_18        PART_2  1.0
    x_19        OBJ       28
    x_19        PART_6  1.0
    x_19        PART_9  1.0
RHS
    RHS1      PART_0  1.0
    RHS1      PART_1  1.0
    RHS1      PART_2  1.0
    RHS1      PART_3  1.0
    RHS1      PART_4  1.0
    RHS1      PART_5  1.0
    RHS1      PART_6  1.0
    RHS1      PART_7  1.0
    RHS1      PART_8  1.0
    RHS1      PART_9  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
ENDATA
