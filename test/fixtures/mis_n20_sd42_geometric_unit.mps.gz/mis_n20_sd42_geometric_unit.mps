NAME          MIS
ROWS
 N  OBJ
 L  EDGE_7_17
 L  EDGE_12_19
 L  EDGE_14_19
 L  EDGE_1_6
 L  EDGE_10_18
 L  EDGE_0_11
 L  EDGE_2_14
 L  EDGE_10_15
 L  EDGE_6_11
 L  EDGE_7_10
 L  EDGE_7_19
 L  EDGE_18_19
 L  EDGE_3_9
 L  EDGE_5_6
 L  EDGE_3_12
 L  EDGE_14_18
 L  EDGE_4_11
 L  EDGE_12_18
 L  EDGE_14_15
 L  EDGE_0_4
 L  EDGE_2_7
 L  EDGE_1_5
 L  EDGE_1_11
 L  EDGE_8_17
 L  EDGE_2_10
 L  EDGE_2_16
 L  EDGE_10_14
 L  EDGE_11_13
 L  EDGE_2_19
 L  EDGE_1_17
 L  EDGE_15_16
 L  EDGE_6_13
 L  EDGE_15_19
 L  EDGE_7_15
 L  EDGE_7_18
 L  EDGE_12_14
 L  EDGE_4_13
 L  EDGE_5_8
 L  EDGE_0_3
 L  EDGE_0_9
 L  EDGE_5_17
 L  EDGE_1_4
 L  EDGE_9_12
 L  EDGE_1_13
 L  EDGE_2_18
 L  EDGE_10_19
 L  EDGE_2_15
 L  EDGE_15_18
 L  EDGE_7_14
COLUMNS
    x_0         OBJ       -1
    x_0         EDGE_0_11  1.0
    x_0         EDGE_0_4  1.0
    x_0         EDGE_0_3  1.0
    x_0         EDGE_0_9  1.0
    x_1         OBJ       -1
    x_1         EDGE_1_6  1.0
    x_1         EDGE_1_5  1.0
    x_1         EDGE_1_11  1.0
    x_1         EDGE_1_17  1.0
    x_1         EDGE_1_4  1.0
    x_1         EDGE_1_13  1.0
    x_2         OBJ       -1
    x_2         EDGE_2_14  1.0
    x_2         EDGE_2_7  1.0
    x_2         EDGE_2_10  1.0
    x_2         EDGE_2_16  1.0
    x_2         EDGE_2_19  1.0
    x_2         EDGE_2_18  1.0
    x_2         EDGE_2_15  1.0
    x_3         OBJ       -1
    x_3         EDGE_3_9  1.0
    x_3         EDGE_3_12  1.0
    x_3         EDGE_0_3  1.0
    x_4         OBJ       -1
    x_4         EDGE_4_11  1.0
    x_4         EDGE_0_4  1.0
    x_4         EDGE_4_13  1.0
    x_4         EDGE_1_4  1.0
    x_5         OBJ       -1
    x_5         EDGE_5_6  1.0
    x_5         EDGE_1_5  1.0
    x_5         EDGE_5_8  1.0
    x_5         EDGE_5_17  1.0
    x_6         OBJ       -1
    x_6         EDGE_1_6  1.0
    x_6         EDGE_6_11  1.0
    x_6         EDGE_5_6  1.0
    x_6         EDGE_6_13  1.0
    x_7         OBJ       -1
    x_7         EDGE_7_17  1.0
    x_7         EDGE_7_10  1.0
    x_7         EDGE_7_19  1.0
    x_7         EDGE_2_7  1.0
    x_7         EDGE_7_15  1.0
    x_7         EDGE_7_18  1.0
    x_7         EDGE_7_14  1.0
    x_8         OBJ       -1
    x_8         EDGE_8_17  1.0
    x_8         EDGE_5_8  1.0
    x_9         OBJ       -1
    x_9         EDGE_3_9  1.0
    x_9         EDGE_0_9  1.0
    x_9         EDGE_9_12  1.0
    x_10        OBJ       -1
    x_10        EDGE_10_18  1.0
    x_10        EDGE_10_15  1.0
    x_10        EDGE_7_10  1.0
    x_10        EDGE_2_10  1.0
    x_10        EDGE_10_14  1.0
    x_10        EDGE_10_19  1.0
    x_11        OBJ       -1
    x_11        EDGE_0_11  1.0
    x_11        EDGE_6_11  1.0
    x_11        EDGE_4_11  1.0
    x_11        EDGE_1_11  1.0
    x_11        EDGE_11_13  1.0
    x_12        OBJ       -1
    x_12        EDGE_12_19  1.0
    x_12        EDGE_3_12  1.0
    x_12        EDGE_12_18  1.0
    x_12        EDGE_12_14  1.0
    x_12        EDGE_9_12  1.0
    x_13        OBJ       -1
    x_13        EDGE_11_13  1.0
    x_13        EDGE_6_13  1.0
    x_13        EDGE_4_13  1.0
    x_13        EDGE_1_13  1.0
    x_14        OBJ       -1
    x_14        EDGE_14_19  1.0
    x_14        EDGE_2_14  1.0
    x_14        EDGE_14_18  1.0
    x_14        EDGE_14_15  1.0
    x_14        EDGE_10_14  1.0
    x_14        EDGE_12_14  1.0
    x_14        EDGE_7_14  1.0
    x_15        OBJ       -1
    x_15        EDGE_10_15  1.0
    x_15        EDGE_14_15  1.0
    x_15        EDGE_15_16  1.0
    x_15        EDGE_15_19  1.0
    x_15        EDGE_7_15  1.0
    x_15        EDGE_2_15  1.0
    x_15        EDGE_15_18  1.0
    x_16        OBJ       -1
    x_16        EDGE_2_16  1.0
    x_16        EDGE_15_16  1.0
    x_17        OBJ       -1
    x_17        EDGE_7_17  1.0
    x_17        EDGE_8_17  1.0
    x_17        EDGE_1_17  1.0
    x_17        EDGE_5_17  1.0
    x_18        OBJ       -1
    x_18        EDGE_10_18  1.0
    x_18        EDGE_18_19  1.0
    x_18        EDGE_14_18  1.0
    x_18        EDGE_12_18  1.0
    x_18        EDGE_7_18  1.0
    x_18        EDGE_2_18  1.0
    x_18        EDGE_15_18  1.0
    x_19        OBJ       -1
    x_19        EDGE_12_19  1.0
    x_19        EDGE_14_19  1.0
    x_19        EDGE_7_19  1.0
    x_19        EDGE_18_19  1.0
    x_19        EDGE_2_19  1.0
    x_19        EDGE_15_19  1.0
    x_19        EDGE_10_19  1.0
RHS
    RHS1      EDGE_7_17  1.0
    RHS1      EDGE_12_19  1.0
    RHS1      EDGE_14_19  1.0
    RHS1      EDGE_1_6  1.0
    RHS1      EDGE_10_18  1.0
    RHS1      EDGE_0_11  1.0
    RHS1      EDGE_2_14  1.0
    RHS1      EDGE_10_15  1.0
    RHS1      EDGE_6_11  1.0
    RHS1      EDGE_7_10  1.0
    RHS1      EDGE_7_19  1.0
    RHS1      EDGE_18_19  1.0
    RHS1      EDGE_3_9  1.0
    RHS1      EDGE_5_6  1.0
    RHS1      EDGE_3_12  1.0
    RHS1      EDGE_14_18  1.0
    RHS1      EDGE_4_11  1.0
    RHS1      EDGE_12_18  1.0
    RHS1      EDGE_14_15  1.0
    RHS1      EDGE_0_4  1.0
    RHS1      EDGE_2_7  1.0
    RHS1      EDGE_1_5  1.0
    RHS1      EDGE_1_11  1.0
    RHS1      EDGE_8_17  1.0
    RHS1      EDGE_2_10  1.0
    RHS1      EDGE_2_16  1.0
    RHS1      EDGE_10_14  1.0
    RHS1      EDGE_11_13  1.0
    RHS1      EDGE_2_19  1.0
    RHS1      EDGE_1_17  1.0
    RHS1      EDGE_15_16  1.0
    RHS1      EDGE_6_13  1.0
    RHS1      EDGE_15_19  1.0
    RHS1      EDGE_7_15  1.0
    RHS1      EDGE_7_18  1.0
    RHS1      EDGE_12_14  1.0
    RHS1      EDGE_4_13  1.0
    RHS1      EDGE_5_8  1.0
    RHS1      EDGE_0_3  1.0
    RHS1      EDGE_0_9  1.0
    RHS1      EDGE_5_17  1.0
    RHS1      EDGE_1_4  1.0
    RHS1      EDGE_9_12  1.0
    RHS1      EDGE_1_13  1.0
    RHS1      EDGE_2_18  1.0
    RHS1      EDGE_10_19  1.0
    RHS1      EDGE_2_15  1.0
    RHS1      EDGE_15_18  1.0
    RHS1      EDGE_7_14  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
ENDATA
