NAME          MIS
ROWS
 N  OBJ
 L  EDGE_10_34
 L  EDGE_13_33
 L  EDGE_15_30
 L  EDGE_26_30
 L  EDGE_18_26
 L  EDGE_8_9
 L  EDGE_22_26
 L  EDGE_17_21
 L  EDGE_0_14
 L  EDGE_17_30
 L  EDGE_18_19
 L  EDGE_1_33
 L  EDGE_14_15
 L  EDGE_5_12
 L  EDGE_29_34
 L  EDGE_12_27
 L  EDGE_3_24
 L  EDGE_11_16
 L  EDGE_1_8
 L  EDGE_7_12
 L  EDGE_10_29
 L  EDGE_15_25
 L  EDGE_2_25
 L  EDGE_16_24
 L  EDGE_24_28
 L  EDGE_18_30
 L  EDGE_6_34
 L  EDGE_14_17
 L  EDGE_20_33
 L  EDGE_22_30
 L  EDGE_14_26
 L  EDGE_4_34
 L  EDGE_15_18
 L  EDGE_10_31
 L  EDGE_24_30
 L  EDGE_12_13
 L  EDGE_3_10
 L  EDGE_14_19
 L  EDGE_21_34
 L  EDGE_3_28
 L  EDGE_1_3
 L  EDGE_10_24
 L  EDGE_0_32
 L  EDGE_25_31
 L  EDGE_16_28
 L  EDGE_29_31
 L  EDGE_4_11
 L  EDGE_22_25
 L  EDGE_12_33
 L  EDGE_23_33
 L  EDGE_4_29
 L  EDGE_8_20
 L  EDGE_10_17
 L  EDGE_27_33
 L  EDGE_1_23
 L  EDGE_2_22
 L  EDGE_11_34
 L  EDGE_2_31
 L  EDGE_21_29
 L  EDGE_2_6
 L  EDGE_17_25
 L  EDGE_1_16
 L  EDGE_2_15
 L  EDGE_17_34
 L  EDGE_10_28
 L  EDGE_28_34
 L  EDGE_30_31
 L  EDGE_25_26
 L  EDGE_6_15
 L  EDGE_20_23
 L  EDGE_3_16
 L  EDGE_5_13
 L  EDGE_7_32
 L  EDGE_21_31
 L  EDGE_14_25
 L  EDGE_4_24
 L  EDGE_1_9
 L  EDGE_10_21
 L  EDGE_9_23
 L  EDGE_2_17
 L  EDGE_8_33
 L  EDGE_11_29
 L  EDGE_2_26
 L  EDGE_6_17
 L  EDGE_13_32
 L  EDGE_3_9
 L  EDGE_6_26
 L  EDGE_18_25
 L  EDGE_21_24
 L  EDGE_5_27
 L  EDGE_17_29
 L  EDGE_19_26
 L  EDGE_1_20
 L  EDGE_28_29
 L  EDGE_15_22
 L  EDGE_6_19
 L  EDGE_24_34
 L  EDGE_26_31
 L  EDGE_3_11
 L  EDGE_29_30
 L  EDGE_4_10
 L  EDGE_4_28
 L  EDGE_5_20
 L  EDGE_17_22
 L  EDGE_10_16
 L  EDGE_27_32
 L  EDGE_0_15
 L  EDGE_17_31
 L  EDGE_11_24
 L  EDGE_2_30
 L  EDGE_13_27
 L  EDGE_3_4
 L  EDGE_21_28
 L  EDGE_4_21
 L  EDGE_17_24
 L  EDGE_9_20
 L  EDGE_3_34
 L  EDGE_2_14
 L  EDGE_0_26
 L  EDGE_15_17
 L  EDGE_6_14
 L  EDGE_24_29
 L  EDGE_15_26
 L  EDGE_18_22
 L  EDGE_16_34
 L  EDGE_21_30
 L  EDGE_22_31
 L  EDGE_10_11
 L  EDGE_17_26
 L  EDGE_8_23
 L  EDGE_0_19
 L  EDGE_5_33
 L  EDGE_11_28
 L  EDGE_15_19
 L  EDGE_24_31
 L  EDGE_6_25
 L  EDGE_25_30
 L  EDGE_4_16
 L  EDGE_20_27
 L  EDGE_12_32
 L  EDGE_17_28
 L  EDGE_19_25
 L  EDGE_11_21
 L  EDGE_2_18
 L  EDGE_9_33
COLUMNS
    x_0         OBJ       -3
    x_0         EDGE_0_14  1.0
    x_0         EDGE_0_32  1.0
    x_0         EDGE_0_15  1.0
    x_0         EDGE_0_26  1.0
    x_0         EDGE_0_19  1.0
    x_1         OBJ       -41
    x_1         EDGE_1_33  1.0
    x_1         EDGE_1_8  1.0
    x_1         EDGE_1_3  1.0
    x_1         EDGE_1_23  1.0
    x_1         EDGE_1_16  1.0
    x_1         EDGE_1_9  1.0
    x_1         EDGE_1_20  1.0
    x_2         OBJ       -132
    x_2         EDGE_2_25  1.0
    x_2         EDGE_2_22  1.0
    x_2         EDGE_2_31  1.0
    x_2         EDGE_2_6  1.0
    x_2         EDGE_2_15  1.0
    x_2         EDGE_2_17  1.0
    x_2         EDGE_2_26  1.0
    x_2         EDGE_2_30  1.0
    x_2         EDGE_2_14  1.0
    x_2         EDGE_2_18  1.0
    x_3         OBJ       -11
    x_3         EDGE_3_24  1.0
    x_3         EDGE_3_10  1.0
    x_3         EDGE_3_28  1.0
    x_3         EDGE_1_3  1.0
    x_3         EDGE_3_16  1.0
    x_3         EDGE_3_9  1.0
    x_3         EDGE_3_11  1.0
    x_3         EDGE_3_4  1.0
    x_3         EDGE_3_34  1.0
    x_4         OBJ       -42
    x_4         EDGE_4_34  1.0
    x_4         EDGE_4_11  1.0
    x_4         EDGE_4_29  1.0
    x_4         EDGE_4_24  1.0
    x_4         EDGE_4_10  1.0
    x_4         EDGE_4_28  1.0
    x_4         EDGE_3_4  1.0
    x_4         EDGE_4_21  1.0
    x_4         EDGE_4_16  1.0
    x_5         OBJ       -109
    x_5         EDGE_5_12  1.0
    x_5         EDGE_5_13  1.0
    x_5         EDGE_5_27  1.0
    x_5         EDGE_5_20  1.0
    x_5         EDGE_5_33  1.0
    x_6         OBJ       -16
    x_6         EDGE_6_34  1.0
    x_6         EDGE_2_6  1.0
    x_6         EDGE_6_15  1.0
    x_6         EDGE_6_17  1.0
    x_6         EDGE_6_26  1.0
    x_6         EDGE_6_19  1.0
    x_6         EDGE_6_14  1.0
    x_6         EDGE_6_25  1.0
    x_7         OBJ       -52
    x_7         EDGE_7_12  1.0
    x_7         EDGE_7_32  1.0
    x_8         OBJ       -81
    x_8         EDGE_8_9  1.0
    x_8         EDGE_1_8  1.0
    x_8         EDGE_8_20  1.0
    x_8         EDGE_8_33  1.0
    x_8         EDGE_8_23  1.0
    x_9         OBJ       -13
    x_9         EDGE_8_9  1.0
    x_9         EDGE_1_9  1.0
    x_9         EDGE_9_23  1.0
    x_9         EDGE_3_9  1.0
    x_9         EDGE_9_20  1.0
    x_9         EDGE_9_33  1.0
    x_10        OBJ       -62
    x_10        EDGE_10_34  1.0
    x_10        EDGE_10_29  1.0
    x_10        EDGE_10_31  1.0
    x_10        EDGE_3_10  1.0
    x_10        EDGE_10_24  1.0
    x_10        EDGE_10_17  1.0
    x_10        EDGE_10_28  1.0
    x_10        EDGE_10_21  1.0
    x_10        EDGE_4_10  1.0
    x_10        EDGE_10_16  1.0
    x_10        EDGE_10_11  1.0
    x_11        OBJ       -121
    x_11        EDGE_11_16  1.0
    x_11        EDGE_4_11  1.0
    x_11        EDGE_11_34  1.0
    x_11        EDGE_11_29  1.0
    x_11        EDGE_3_11  1.0
    x_11        EDGE_11_24  1.0
    x_11        EDGE_10_11  1.0
    x_11        EDGE_11_28  1.0
    x_11        EDGE_11_21  1.0
    x_12        OBJ       -13
    x_12        EDGE_5_12  1.0
    x_12        EDGE_12_27  1.0
    x_12        EDGE_7_12  1.0
    x_12        EDGE_12_13  1.0
    x_12        EDGE_12_33  1.0
    x_12        EDGE_12_32  1.0
    x_13        OBJ       -63
    x_13        EDGE_13_33  1.0
    x_13        EDGE_12_13  1.0
    x_13        EDGE_5_13  1.0
    x_13        EDGE_13_32  1.0
    x_13        EDGE_13_27  1.0
    x_14        OBJ       -140
    x_14        EDGE_0_14  1.0
    x_14        EDGE_14_15  1.0
    x_14        EDGE_14_17  1.0
    x_14        EDGE_14_26  1.0
    x_14        EDGE_14_19  1.0
    x_14        EDGE_14_25  1.0
    x_14        EDGE_2_14  1.0
    x_14        EDGE_6_14  1.0
    x_15        OBJ       -5
    x_15        EDGE_15_30  1.0
    x_15        EDGE_14_15  1.0
    x_15        EDGE_15_25  1.0
    x_15        EDGE_15_18  1.0
    x_15        EDGE_2_15  1.0
    x_15        EDGE_6_15  1.0
    x_15        EDGE_15_22  1.0
    x_15        EDGE_0_15  1.0
    x_15        EDGE_15_17  1.0
    x_15        EDGE_15_26  1.0
    x_15        EDGE_15_19  1.0
    x_16        OBJ       -57
    x_16        EDGE_11_16  1.0
    x_16        EDGE_16_24  1.0
    x_16        EDGE_16_28  1.0
    x_16        EDGE_1_16  1.0
    x_16        EDGE_3_16  1.0
    x_16        EDGE_10_16  1.0
    x_16        EDGE_16_34  1.0
    x_16        EDGE_4_16  1.0
    x_17        OBJ       -146
    x_17        EDGE_17_21  1.0
    x_17        EDGE_17_30  1.0
    x_17        EDGE_14_17  1.0
    x_17        EDGE_10_17  1.0
    x_17        EDGE_17_25  1.0
    x_17        EDGE_17_34  1.0
    x_17        EDGE_2_17  1.0
    x_17        EDGE_6_17  1.0
    x_17        EDGE_17_29  1.0
    x_17        EDGE_17_22  1.0
    x_17        EDGE_17_31  1.0
    x_17        EDGE_17_24  1.0
    x_17        EDGE_15_17  1.0
    x_17        EDGE_17_26  1.0
    x_17        EDGE_17_28  1.0
    x_18        OBJ       -17
    x_18        EDGE_18_26  1.0
    x_18        EDGE_18_19  1.0
    x_18        EDGE_18_30  1.0
    x_18        EDGE_15_18  1.0
    x_18        EDGE_18_25  1.0
    x_18        EDGE_18_22  1.0
    x_18        EDGE_2_18  1.0
    x_19        OBJ       -51
    x_19        EDGE_18_19  1.0
    x_19        EDGE_14_19  1.0
    x_19        EDGE_19_26  1.0
    x_19        EDGE_6_19  1.0
    x_19        EDGE_0_19  1.0
    x_19        EDGE_15_19  1.0
    x_19        EDGE_19_25  1.0
    x_20        OBJ       -80
    x_20        EDGE_20_33  1.0
    x_20        EDGE_8_20  1.0
    x_20        EDGE_20_23  1.0
    x_20        EDGE_1_20  1.0
    x_20        EDGE_5_20  1.0
    x_20        EDGE_9_20  1.0
    x_20        EDGE_20_27  1.0
    x_21        OBJ       -20
    x_21        EDGE_17_21  1.0
    x_21        EDGE_21_34  1.0
    x_21        EDGE_21_29  1.0
    x_21        EDGE_21_31  1.0
    x_21        EDGE_10_21  1.0
    x_21        EDGE_21_24  1.0
    x_21        EDGE_21_28  1.0
    x_21        EDGE_4_21  1.0
    x_21        EDGE_21_30  1.0
    x_21        EDGE_11_21  1.0
    x_22        OBJ       -31
    x_22        EDGE_22_26  1.0
    x_22        EDGE_22_30  1.0
    x_22        EDGE_22_25  1.0
    x_22        EDGE_2_22  1.0
    x_22        EDGE_15_22  1.0
    x_22        EDGE_17_22  1.0
    x_22        EDGE_18_22  1.0
    x_22        EDGE_22_31  1.0
    x_23        OBJ       -98
    x_23        EDGE_23_33  1.0
    x_23        EDGE_1_23  1.0
    x_23        EDGE_20_23  1.0
    x_23        EDGE_9_23  1.0
    x_23        EDGE_8_23  1.0
    x_24        OBJ       -16
    x_24        EDGE_3_24  1.0
    x_24        EDGE_16_24  1.0
    x_24        EDGE_24_28  1.0
    x_24        EDGE_24_30  1.0
    x_24        EDGE_10_24  1.0
    x_24        EDGE_4_24  1.0
    x_24        EDGE_21_24  1.0
    x_24        EDGE_24_34  1.0
    x_24        EDGE_11_24  1.0
    x_24        EDGE_17_24  1.0
    x_24        EDGE_24_29  1.0
    x_24        EDGE_24_31  1.0
    x_25        OBJ       -53
    x_25        EDGE_15_25  1.0
    x_25        EDGE_2_25  1.0
    x_25        EDGE_25_31  1.0
    x_25        EDGE_22_25  1.0
    x_25        EDGE_17_25  1.0
    x_25        EDGE_25_26  1.0
    x_25        EDGE_14_25  1.0
    x_25        EDGE_18_25  1.0
    x_25        EDGE_6_25  1.0
    x_25        EDGE_25_30  1.0
    x_25        EDGE_19_25  1.0
    x_26        OBJ       -102
    x_26        EDGE_26_30  1.0
    x_26        EDGE_18_26  1.0
    x_26        EDGE_22_26  1.0
    x_26        EDGE_14_26  1.0
    x_26        EDGE_25_26  1.0
    x_26        EDGE_2_26  1.0
    x_26        EDGE_6_26  1.0
    x_26        EDGE_19_26  1.0
    x_26        EDGE_26_31  1.0
    x_26        EDGE_0_26  1.0
    x_26        EDGE_15_26  1.0
    x_26        EDGE_17_26  1.0
    x_27        OBJ       -12
    x_27        EDGE_12_27  1.0
    x_27        EDGE_27_33  1.0
    x_27        EDGE_5_27  1.0
    x_27        EDGE_27_32  1.0
    x_27        EDGE_13_27  1.0
    x_27        EDGE_20_27  1.0
    x_28        OBJ       -45
    x_28        EDGE_24_28  1.0
    x_28        EDGE_3_28  1.0
    x_28        EDGE_16_28  1.0
    x_28        EDGE_10_28  1.0
    x_28        EDGE_28_34  1.0
    x_28        EDGE_28_29  1.0
    x_28        EDGE_4_28  1.0
    x_28        EDGE_21_28  1.0
    x_28        EDGE_11_28  1.0
    x_28        EDGE_17_28  1.0
    x_29        OBJ       -142
    x_29        EDGE_29_34  1.0
    x_29        EDGE_10_29  1.0
    x_29        EDGE_29_31  1.0
    x_29        EDGE_4_29  1.0
    x_29        EDGE_21_29  1.0
    x_29        EDGE_11_29  1.0
    x_29        EDGE_17_29  1.0
    x_29        EDGE_28_29  1.0
    x_29        EDGE_29_30  1.0
    x_29        EDGE_24_29  1.0
    x_30        OBJ       -13
    x_30        EDGE_15_30  1.0
    x_30        EDGE_26_30  1.0
    x_30        EDGE_17_30  1.0
    x_30        EDGE_18_30  1.0
    x_30        EDGE_22_30  1.0
    x_30        EDGE_24_30  1.0
    x_30        EDGE_30_31  1.0
    x_30        EDGE_29_30  1.0
    x_30        EDGE_2_30  1.0
    x_30        EDGE_21_30  1.0
    x_30        EDGE_25_30  1.0
    x_31        OBJ       -50
    x_31        EDGE_10_31  1.0
    x_31        EDGE_25_31  1.0
    x_31        EDGE_29_31  1.0
    x_31        EDGE_2_31  1.0
    x_31        EDGE_30_31  1.0
    x_31        EDGE_21_31  1.0
    x_31        EDGE_26_31  1.0
    x_31        EDGE_17_31  1.0
    x_31        EDGE_22_31  1.0
    x_31        EDGE_24_31  1.0
    x_32        OBJ       -120
    x_32        EDGE_0_32  1.0
    x_32        EDGE_7_32  1.0
    x_32        EDGE_13_32  1.0
    x_32        EDGE_27_32  1.0
    x_32        EDGE_12_32  1.0
    x_33        OBJ       -1
    x_33        EDGE_13_33  1.0
    x_33        EDGE_1_33  1.0
    x_33        EDGE_20_33  1.0
    x_33        EDGE_12_33  1.0
    x_33        EDGE_23_33  1.0
    x_33        EDGE_27_33  1.0
    x_33        EDGE_8_33  1.0
    x_33        EDGE_5_33  1.0
    x_33        EDGE_9_33  1.0
    x_34        OBJ       -55
    x_34        EDGE_10_34  1.0
    x_34        EDGE_29_34  1.0
    x_34        EDGE_6_34  1.0
    x_34        EDGE_4_34  1.0
    x_34        EDGE_21_34  1.0
    x_34        EDGE_11_34  1.0
    x_34        EDGE_17_34  1.0
    x_34        EDGE_28_34  1.0
    x_34        EDGE_24_34  1.0
    x_34        EDGE_3_34  1.0
    x_34        EDGE_16_34  1.0
RHS
    RHS1      EDGE_10_34  1.0
    RHS1      EDGE_13_33  1.0
    RHS1      EDGE_15_30  1.0
    RHS1      EDGE_26_30  1.0
    RHS1      EDGE_18_26  1.0
    RHS1      EDGE_8_9  1.0
    RHS1      EDGE_22_26  1.0
    RHS1      EDGE_17_21  1.0
    RHS1      EDGE_0_14  1.0
    RHS1      EDGE_17_30  1.0
    RHS1      EDGE_18_19  1.0
    RHS1      EDGE_1_33  1.0
    RHS1      EDGE_14_15  1.0
    RHS1      EDGE_5_12  1.0
    RHS1      EDGE_29_34  1.0
    RHS1      EDGE_12_27  1.0
    RHS1      EDGE_3_24  1.0
    RHS1      EDGE_11_16  1.0
    RHS1      EDGE_1_8  1.0
    RHS1      EDGE_7_12  1.0
    RHS1      EDGE_10_29  1.0
    RHS1      EDGE_15_25  1.0
    RHS1      EDGE_2_25  1.0
    RHS1      EDGE_16_24  1.0
    RHS1      EDGE_24_28  1.0
    RHS1      EDGE_18_30  1.0
    RHS1      EDGE_6_34  1.0
    RHS1      EDGE_14_17  1.0
    RHS1      EDGE_20_33  1.0
    RHS1      EDGE_22_30  1.0
    RHS1      EDGE_14_26  1.0
    RHS1      EDGE_4_34  1.0
    RHS1      EDGE_15_18  1.0
    RHS1      EDGE_10_31  1.0
    RHS1      EDGE_24_30  1.0
    RHS1      EDGE_12_13  1.0
    RHS1      EDGE_3_10  1.0
    RHS1      EDGE_14_19  1.0
    RHS1      EDGE_21_34  1.0
    RHS1      EDGE_3_28  1.0
    RHS1      EDGE_1_3  1.0
    RHS1      EDGE_10_24  1.0
    RHS1      EDGE_0_32  1.0
    RHS1      EDGE_25_31  1.0
    RHS1      EDGE_16_28  1.0
    RHS1      EDGE_29_31  1.0
    RHS1      EDGE_4_11  1.0
    RHS1      EDGE_22_25  1.0
    RHS1      EDGE_12_33  1.0
    RHS1      EDGE_23_33  1.0
    RHS1      EDGE_4_29  1.0
    RHS1      EDGE_8_20  1.0
    RHS1      EDGE_10_17  1.0
    RHS1      EDGE_27_33  1.0
    RHS1      EDGE_1_23  1.0
    RHS1      EDGE_2_22  1.0
    RHS1      EDGE_11_34  1.0
    RHS1      EDGE_2_31  1.0
    RHS1      EDGE_21_29  1.0
    RHS1      EDGE_2_6  1.0
    RHS1      EDGE_17_25  1.0
    RHS1      EDGE_1_16  1.0
    RHS1      EDGE_2_15  1.0
    RHS1      EDGE_17_34  1.0
    RHS1      EDGE_10_28  1.0
    RHS1      EDGE_28_34  1.0
    RHS1      EDGE_30_31  1.0
    RHS1      EDGE_25_26  1.0
    RHS1      EDGE_6_15  1.0
    RHS1      EDGE_20_23  1.0
    RHS1      EDGE_3_16  1.0
    RHS1      EDGE_5_13  1.0
    RHS1      EDGE_7_32  1.0
    RHS1      EDGE_21_31  1.0
    RHS1      EDGE_14_25  1.0
    RHS1      EDGE_4_24  1.0
    RHS1      EDGE_1_9  1.0
    RHS1      EDGE_10_21  1.0
    RHS1      EDGE_9_23  1.0
    RHS1      EDGE_2_17  1.0
    RHS1      EDGE_8_33  1.0
    RHS1      EDGE_11_29  1.0
    RHS1      EDGE_2_26  1.0
    RHS1      EDGE_6_17  1.0
    RHS1      EDGE_13_32  1.0
    RHS1      EDGE_3_9  1.0
    RHS1      EDGE_6_26  1.0
    RHS1      EDGE_18_25  1.0
    RHS1      EDGE_21_24  1.0
    RHS1      EDGE_5_27  1.0
    RHS1      EDGE_17_29  1.0
    RHS1      EDGE_19_26  1.0
    RHS1      EDGE_1_20  1.0
    RHS1      EDGE_28_29  1.0
    RHS1      EDGE_15_22  1.0
    RHS1      EDGE_6_19  1.0
    RHS1      EDGE_24_34  1.0
    RHS1      EDGE_26_31  1.0
    RHS1      EDGE_3_11  1.0
    RHS1      EDGE_29_30  1.0
    RHS1      EDGE_4_10  1.0
    RHS1      EDGE_4_28  1.0
    RHS1      EDGE_5_20  1.0
    RHS1      EDGE_17_22  1.0
    RHS1      EDGE_10_16  1.0
    RHS1      EDGE_27_32  1.0
    RHS1      EDGE_0_15  1.0
    RHS1      EDGE_17_31  1.0
    RHS1      EDGE_11_24  1.0
    RHS1      EDGE_2_30  1.0
    RHS1      EDGE_13_27  1.0
    RHS1      EDGE_3_4  1.0
    RHS1      EDGE_21_28  1.0
    RHS1      EDGE_4_21  1.0
    RHS1      EDGE_17_24  1.0
    RHS1      EDGE_9_20  1.0
    RHS1      EDGE_3_34  1.0
    RHS1      EDGE_2_14  1.0
    RHS1      EDGE_0_26  1.0
    RHS1      EDGE_15_17  1.0
    RHS1      EDGE_6_14  1.0
    RHS1      EDGE_24_29  1.0
    RHS1      EDGE_15_26  1.0
    RHS1      EDGE_18_22  1.0
    RHS1      EDGE_16_34  1.0
    RHS1      EDGE_21_30  1.0
    RHS1      EDGE_22_31  1.0
    RHS1      EDGE_10_11  1.0
    RHS1      EDGE_17_26  1.0
    RHS1      EDGE_8_23  1.0
    RHS1      EDGE_0_19  1.0
    RHS1      EDGE_5_33  1.0
    RHS1      EDGE_11_28  1.0
    RHS1      EDGE_15_19  1.0
    RHS1      EDGE_24_31  1.0
    RHS1      EDGE_6_25  1.0
    RHS1      EDGE_25_30  1.0
    RHS1      EDGE_4_16  1.0
    RHS1      EDGE_20_27  1.0
    RHS1      EDGE_12_32  1.0
    RHS1      EDGE_17_28  1.0
    RHS1      EDGE_19_25  1.0
    RHS1      EDGE_11_21  1.0
    RHS1      EDGE_2_18  1.0
    RHS1      EDGE_9_33  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
 BV BND1      x_30
 BV BND1      x_31
 BV BND1      x_32
 BV BND1      x_33
 BV BND1      x_34
ENDATA
