NAME          MIS
ROWS
 N  OBJ
 L  EDGE_4_9
 L  EDGE_3_13
 L  EDGE_9_17
 L  EDGE_0_14
 L  EDGE_2_11
 L  EDGE_11_14
 L  EDGE_1_15
 L  EDGE_3_15
 L  EDGE_5_12
 L  EDGE_0_7
 L  EDGE_0_16
 L  EDGE_11_16
 L  EDGE_1_8
 L  EDGE_1_17
 L  EDGE_6_13
 L  EDGE_7_12
 L  EDGE_3_17
 L  EDGE_5_14
 L  EDGE_9_12
 L  EDGE_0_9
 L  EDGE_1_10
 L  EDGE_7_14
 L  EDGE_3_10
 L  EDGE_5_7
 L  EDGE_5_16
 L  EDGE_9_14
 L  EDGE_7_16
 L  EDGE_3_12
 L  EDGE_5_9
 L  EDGE_9_16
 L  EDGE_10_17
 L  EDGE_2_13
 L  EDGE_3_14
 L  EDGE_5_11
 L  EDGE_4_13
 L  EDGE_8_13
 L  EDGE_1_7
 L  EDGE_1_16
 L  EDGE_6_15
 L  EDGE_3_7
 L  EDGE_4_6
 L  EDGE_3_16
 L  EDGE_5_13
 L  EDGE_4_15
 L  EDGE_8_15
 L  EDGE_1_9
 L  EDGE_0_11
 L  EDGE_2_8
 L  EDGE_2_17
 L  EDGE_6_17
 L  EDGE_3_9
 L  EDGE_4_8
 L  EDGE_4_17
 L  EDGE_8_17
 L  EDGE_1_11
 L  EDGE_0_13
 L  EDGE_11_13
 L  EDGE_3_11
 L  EDGE_4_10
 L  EDGE_0_6
 L  EDGE_10_16
 L  EDGE_1_13
 L  EDGE_0_15
 L  EDGE_11_15
 L  EDGE_4_12
 L  EDGE_8_12
 L  EDGE_1_6
 L  EDGE_0_8
 L  EDGE_0_17
 L  EDGE_2_14
 L  EDGE_11_17
 L  EDGE_6_14
 L  EDGE_7_13
 L  EDGE_4_14
 L  EDGE_5_15
 L  EDGE_9_13
 L  EDGE_0_10
 L  EDGE_2_7
 L  EDGE_2_16
 L  EDGE_7_15
 L  EDGE_4_7
 L  EDGE_4_16
 L  EDGE_5_8
 L  EDGE_8_16
 L  EDGE_10_13
 L  EDGE_9_15
 L  EDGE_11_12
 L  EDGE_2_9
COLUMNS
    x_0         OBJ       -82
    x_0         EDGE_0_14  1.0
    x_0         EDGE_0_7  1.0
    x_0         EDGE_0_16  1.0
    x_0         EDGE_0_9  1.0
    x_0         EDGE_0_11  1.0
    x_0         EDGE_0_13  1.0
    x_0         EDGE_0_6  1.0
    x_0         EDGE_0_15  1.0
    x_0         EDGE_0_8  1.0
    x_0         EDGE_0_17  1.0
    x_0         EDGE_0_10  1.0
    x_1         OBJ       -15
    x_1         EDGE_1_15  1.0
    x_1         EDGE_1_8  1.0
    x_1         EDGE_1_17  1.0
    x_1         EDGE_1_10  1.0
    x_1         EDGE_1_7  1.0
    x_1         EDGE_1_16  1.0
    x_1         EDGE_1_9  1.0
    x_1         EDGE_1_11  1.0
    x_1         EDGE_1_13  1.0
    x_1         EDGE_1_6  1.0
    x_2         OBJ       -4
    x_2         EDGE_2_11  1.0
    x_2         EDGE_2_13  1.0
    x_2         EDGE_2_8  1.0
    x_2         EDGE_2_17  1.0
    x_2         EDGE_2_14  1.0
    x_2         EDGE_2_7  1.0
    x_2         EDGE_2_16  1.0
    x_2         EDGE_2_9  1.0
    x_3         OBJ       -95
    x_3         EDGE_3_13  1.0
    x_3         EDGE_3_15  1.0
    x_3         EDGE_3_17  1.0
    x_3         EDGE_3_10  1.0
    x_3         EDGE_3_12  1.0
    x_3         EDGE_3_14  1.0
    x_3         EDGE_3_7  1.0
    x_3         EDGE_3_16  1.0
    x_3         EDGE_3_9  1.0
    x_3         EDGE_3_11  1.0
    x_4         OBJ       -36
    x_4         EDGE_4_9  1.0
    x_4         EDGE_4_13  1.0
    x_4         EDGE_4_6  1.0
    x_4         EDGE_4_15  1.0
    x_4         EDGE_4_8  1.0
    x_4         EDGE_4_17  1.0
    x_4         EDGE_4_10  1.0
    x_4         EDGE_4_12  1.0
    x_4         EDGE_4_14  1.0
    x_4         EDGE_4_7  1.0
    x_4         EDGE_4_16  1.0
    x_5         OBJ       -32
    x_5         EDGE_5_12  1.0
    x_5         EDGE_5_14  1.0
    x_5         EDGE_5_7  1.0
    x_5         EDGE_5_16  1.0
    x_5         EDGE_5_9  1.0
    x_5         EDGE_5_11  1.0
    x_5         EDGE_5_13  1.0
    x_5         EDGE_5_15  1.0
    x_5         EDGE_5_8  1.0
    x_6         OBJ       -29
    x_6         EDGE_6_13  1.0
    x_6         EDGE_6_15  1.0
    x_6         EDGE_4_6  1.0
    x_6         EDGE_6_17  1.0
    x_6         EDGE_0_6  1.0
    x_6         EDGE_1_6  1.0
    x_6         EDGE_6_14  1.0
    x_7         OBJ       -18
    x_7         EDGE_0_7  1.0
    x_7         EDGE_7_12  1.0
    x_7         EDGE_7_14  1.0
    x_7         EDGE_5_7  1.0
    x_7         EDGE_7_16  1.0
    x_7         EDGE_1_7  1.0
    x_7         EDGE_3_7  1.0
    x_7         EDGE_7_13  1.0
    x_7         EDGE_2_7  1.0
    x_7         EDGE_7_15  1.0
    x_7         EDGE_4_7  1.0
    x_8         OBJ       -95
    x_8         EDGE_1_8  1.0
    x_8         EDGE_8_13  1.0
    x_8         EDGE_8_15  1.0
    x_8         EDGE_2_8  1.0
    x_8         EDGE_4_8  1.0
    x_8         EDGE_8_17  1.0
    x_8         EDGE_8_12  1.0
    x_8         EDGE_0_8  1.0
    x_8         EDGE_5_8  1.0
    x_8         EDGE_8_16  1.0
    x_9         OBJ       -14
    x_9         EDGE_4_9  1.0
    x_9         EDGE_9_17  1.0
    x_9         EDGE_9_12  1.0
    x_9         EDGE_0_9  1.0
    x_9         EDGE_9_14  1.0
    x_9         EDGE_5_9  1.0
    x_9         EDGE_9_16  1.0
    x_9         EDGE_1_9  1.0
    x_9         EDGE_3_9  1.0
    x_9         EDGE_9_13  1.0
    x_9         EDGE_9_15  1.0
    x_9         EDGE_2_9  1.0
    x_10        OBJ       -87
    x_10        EDGE_1_10  1.0
    x_10        EDGE_3_10  1.0
    x_10        EDGE_10_17  1.0
    x_10        EDGE_4_10  1.0
    x_10        EDGE_10_16  1.0
    x_10        EDGE_0_10  1.0
    x_10        EDGE_10_13  1.0
    x_11        OBJ       -95
    x_11        EDGE_2_11  1.0
    x_11        EDGE_11_14  1.0
    x_11        EDGE_11_16  1.0
    x_11        EDGE_5_11  1.0
    x_11        EDGE_0_11  1.0
    x_11        EDGE_1_11  1.0
    x_11        EDGE_11_13  1.0
    x_11        EDGE_3_11  1.0
    x_11        EDGE_11_15  1.0
    x_11        EDGE_11_17  1.0
    x_11        EDGE_11_12  1.0
    x_12        OBJ       -70
    x_12        EDGE_5_12  1.0
    x_12        EDGE_7_12  1.0
    x_12        EDGE_9_12  1.0
    x_12        EDGE_3_12  1.0
    x_12        EDGE_4_12  1.0
    x_12        EDGE_8_12  1.0
    x_12        EDGE_11_12  1.0
    x_13        OBJ       -12
    x_13        EDGE_3_13  1.0
    x_13        EDGE_6_13  1.0
    x_13        EDGE_2_13  1.0
    x_13        EDGE_4_13  1.0
    x_13        EDGE_8_13  1.0
    x_13        EDGE_5_13  1.0
    x_13        EDGE_0_13  1.0
    x_13        EDGE_11_13  1.0
    x_13        EDGE_1_13  1.0
    x_13        EDGE_7_13  1.0
    x_13        EDGE_9_13  1.0
    x_13        EDGE_10_13  1.0
    x_14        OBJ       -76
    x_14        EDGE_0_14  1.0
    x_14        EDGE_11_14  1.0
    x_14        EDGE_5_14  1.0
    x_14        EDGE_7_14  1.0
    x_14        EDGE_9_14  1.0
    x_14        EDGE_3_14  1.0
    x_14        EDGE_2_14  1.0
    x_14        EDGE_6_14  1.0
    x_14        EDGE_4_14  1.0
    x_15        OBJ       -55
    x_15        EDGE_1_15  1.0
    x_15        EDGE_3_15  1.0
    x_15        EDGE_6_15  1.0
    x_15        EDGE_4_15  1.0
    x_15        EDGE_8_15  1.0
    x_15        EDGE_0_15  1.0
    x_15        EDGE_11_15  1.0
    x_15        EDGE_5_15  1.0
    x_15        EDGE_7_15  1.0
    x_15        EDGE_9_15  1.0
    x_16        OBJ       -5
    x_16        EDGE_0_16  1.0
    x_16        EDGE_11_16  1.0
    x_16        EDGE_5_16  1.0
    x_16        EDGE_7_16  1.0
    x_16        EDGE_9_16  1.0
    x_16        EDGE_1_16  1.0
    x_16        EDGE_3_16  1.0
    x_16        EDGE_10_16  1.0
    x_16        EDGE_2_16  1.0
    x_16        EDGE_4_16  1.0
    x_16        EDGE_8_16  1.0
    x_17        OBJ       -4
    x_17        EDGE_9_17  1.0
    x_17        EDGE_1_17  1.0
    x_17        EDGE_3_17  1.0
    x_17        EDGE_10_17  1.0
    x_17        EDGE_2_17  1.0
    x_17        EDGE_6_17  1.0
    x_17        EDGE_4_17  1.0
    x_17        EDGE_8_17  1.0
    x_17        EDGE_0_17  1.0
    x_17        EDGE_11_17  1.0
RHS
    RHS1      EDGE_4_9  1.0
    RHS1      EDGE_3_13  1.0
    RHS1      EDGE_9_17  1.0
    RHS1      EDGE_0_14  1.0
    RHS1      EDGE_2_11  1.0
    RHS1      EDGE_11_14  1.0
    RHS1      EDGE_1_15  1.0
    RHS1      EDGE_3_15  1.0
    RHS1      EDGE_5_12  1.0
    RHS1      EDGE_0_7  1.0
    RHS1      EDGE_0_16  1.0
    RHS1      EDGE_11_16  1.0
    RHS1      EDGE_1_8  1.0
    RHS1      EDGE_1_17  1.0
    RHS1      EDGE_6_13  1.0
    RHS1      EDGE_7_12  1.0
    RHS1      EDGE_3_17  1.0
    RHS1      EDGE_5_14  1.0
    RHS1      EDGE_9_12  1.0
    RHS1      EDGE_0_9  1.0
    RHS1      EDGE_1_10  1.0
    RHS1      EDGE_7_14  1.0
    RHS1      EDGE_3_10  1.0
    RHS1      EDGE_5_7  1.0
    RHS1      EDGE_5_16  1.0
    RHS1      EDGE_9_14  1.0
    RHS1      EDGE_7_16  1.0
    RHS1      EDGE_3_12  1.0
    RHS1      EDGE_5_9  1.0
    RHS1      EDGE_9_16  1.0
    RHS1      EDGE_10_17  1.0
    RHS1      EDGE_2_13  1.0
    RHS1      EDGE_3_14  1.0
    RHS1      EDGE_5_11  1.0
    RHS1      EDGE_4_13  1.0
    RHS1      EDGE_8_13  1.0
    RHS1      EDGE_1_7  1.0
    RHS1      EDGE_1_16  1.0
    RHS1      EDGE_6_15  1.0
    RHS1      EDGE_3_7  1.0
    RHS1      EDGE_4_6  1.0
    RHS1      EDGE_3_16  1.0
    RHS1      EDGE_5_13  1.0
    RHS1      EDGE_4_15  1.0
    RHS1      EDGE_8_15  1.0
    RHS1      EDGE_1_9  1.0
    RHS1      EDGE_0_11  1.0
    RHS1      EDGE_2_8  1.0
    RHS1      EDGE_2_17  1.0
    RHS1      EDGE_6_17  1.0
    RHS1      EDGE_3_9  1.0
    RHS1      EDGE_4_8  1.0
    RHS1      EDGE_4_17  1.0
    RHS1      EDGE_8_17  1.0
    RHS1      EDGE_1_11  1.0
    RHS1      EDGE_0_13  1.0
    RHS1      EDGE_11_13  1.0
    RHS1      EDGE_3_11  1.0
    RHS1      EDGE_4_10  1.0
    RHS1      EDGE_0_6  1.0
    RHS1      EDGE_10_16  1.0
    RHS1      EDGE_1_13  1.0
    RHS1      EDGE_0_15  1.0
    RHS1      EDGE_11_15  1.0
    RHS1      EDGE_4_12  1.0
    RHS1      EDGE_8_12  1.0
    RHS1      EDGE_1_6  1.0
    RHS1      EDGE_0_8  1.0
    RHS1      EDGE_0_17  1.0
    RHS1      EDGE_2_14  1.0
    RHS1      EDGE_11_17  1.0
    RHS1      EDGE_6_14  1.0
    RHS1      EDGE_7_13  1.0
    RHS1      EDGE_4_14  1.0
    RHS1      EDGE_5_15  1.0
    RHS1      EDGE_9_13  1.0
    RHS1      EDGE_0_10  1.0
    RHS1      EDGE_2_7  1.0
    RHS1      EDGE_2_16  1.0
    RHS1      EDGE_7_15  1.0
    RHS1      EDGE_4_7  1.0
    RHS1      EDGE_4_16  1.0
    RHS1      EDGE_5_8  1.0
    RHS1      EDGE_8_16  1.0
    RHS1      EDGE_10_13  1.0
    RHS1      EDGE_9_15  1.0
    RHS1      EDGE_11_12  1.0
    RHS1      EDGE_2_9  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
ENDATA
