NAME          SETPACK
ROWS
 N  OBJ
 L  PACK_0
 L  PACK_1
 L  PACK_2
 L  PACK_3
 L  PACK_4
 L  PACK_5
 L  PACK_6
 L  PACK_7
 L  PACK_8
 L  PACK_9
COLUMNS
    x_0         OBJ       -82
    x_0         PACK_0  1.0
    x_0         PACK_9  1.0
    x_0         PACK_1  1.0
    x_1         OBJ       -15
    x_1         PACK_3  1.0
    x_1         PACK_8  1.0
    x_2         OBJ       -4
    x_2         PACK_8  1.0
    x_2         PACK_3  1.0
    x_3         OBJ       -95
    x_3         PACK_3  1.0
    x_3         PACK_7  1.0
    x_3         PACK_4  1.0
    x_4         OBJ       -36
    x_4         PACK_2  1.0
    x_4         PACK_6  1.0
    x_5         OBJ       -32
    x_5         PACK_4  1.0
    x_5         PACK_2  1.0
    x_5         PACK_3  1.0
    x_6         OBJ       -29
    x_6         PACK_1  1.0
    x_6         PACK_9  1.0
    x_6         PACK_6  1.0
    x_7         OBJ       -18
    x_7         PACK_5  1.0
    x_7         PACK_9  1.0
    x_8         OBJ       -95
    x_8         PACK_0  1.0
    x_8         PACK_7  1.0
    x_8         PACK_1  1.0
    x_9         OBJ       -14
    x_9         PACK_1  1.0
    x_9         PACK_8  1.0
    x_9         PACK_4  1.0
    x_10        OBJ       -87
    x_10        PACK_9  1.0
    x_10        PACK_3  1.0
    x_10        PACK_1  1.0
    x_11        OBJ       -95
    x_11        PACK_3  1.0
    x_11        PACK_4  1.0
    x_12        OBJ       -70
    x_12        PACK_3  1.0
    x_12        PACK_1  1.0
    x_13        OBJ       -12
    x_13        PACK_4  1.0
    x_13        PACK_7  1.0
    x_13        PACK_5  1.0
    x_14        OBJ       -76
    x_14        PACK_5  1.0
    x_14        PACK_9  1.0
RHS
    RHS1      PACK_0  1.0
    RHS1      PACK_1  1.0
    RHS1      PACK_2  1.0
    RHS1      PACK_3  1.0
    RHS1      PACK_4  1.0
    RHS1      PACK_5  1.0
    RHS1      PACK_6  1.0
    RHS1      PACK_7  1.0
    RHS1      PACK_8  1.0
    RHS1      PACK_9  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
ENDATA
