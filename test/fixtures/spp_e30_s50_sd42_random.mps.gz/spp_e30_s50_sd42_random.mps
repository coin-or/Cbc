NAME          SETPACK
ROWS
 N  OBJ
 L  PACK_0
 L  PACK_1
 L  PACK_2
 L  PACK_3
 L  PACK_4
 L  PACK_5
 L  PACK_6
 L  PACK_7
 L  PACK_8
 L  PACK_9
 L  PACK_10
 L  PACK_11
 L  PACK_12
 L  PACK_13
 L  PACK_14
 L  PACK_15
 L  PACK_16
 L  PACK_17
 L  PACK_18
 L  PACK_19
 L  PACK_20
 L  PACK_21
 L  PACK_22
 L  PACK_23
 L  PACK_24
 L  PACK_25
 L  PACK_26
 L  PACK_27
 L  PACK_28
 L  PACK_29
COLUMNS
    x_0         OBJ       -82
    x_0         PACK_27  1.0
    x_0         PACK_11  1.0
    x_0         PACK_19  1.0
    x_1         OBJ       -15
    x_1         PACK_25  1.0
    x_1         PACK_1  1.0
    x_1         PACK_23  1.0
    x_2         OBJ       -4
    x_2         PACK_17  1.0
    x_2         PACK_3  1.0
    x_2         PACK_29  1.0
    x_3         OBJ       -95
    x_3         PACK_2  1.0
    x_3         PACK_17  1.0
    x_3         PACK_9  1.0
    x_4         OBJ       -36
    x_4         PACK_19  1.0
    x_4         PACK_28  1.0
    x_4         PACK_27  1.0
    x_4         PACK_11  1.0
    x_5         OBJ       -32
    x_5         PACK_6  1.0
    x_5         PACK_22  1.0
    x_5         PACK_2  1.0
    x_5         PACK_1  1.0
    x_6         OBJ       -29
    x_6         PACK_7  1.0
    x_6         PACK_24  1.0
    x_6         PACK_9  1.0
    x_6         PACK_2  1.0
    x_7         OBJ       -18
    x_7         PACK_27  1.0
    x_7         PACK_3  1.0
    x_8         OBJ       -95
    x_8         PACK_8  1.0
    x_8         PACK_14  1.0
    x_8         PACK_20  1.0
    x_9         OBJ       -14
    x_9         PACK_5  1.0
    x_9         PACK_11  1.0
    x_9         PACK_6  1.0
    x_10        OBJ       -87
    x_10        PACK_8  1.0
    x_10        PACK_22  1.0
    x_10        PACK_29  1.0
    x_10        PACK_21  1.0
    x_11        OBJ       -95
    x_11        PACK_2  1.0
    x_11        PACK_19  1.0
    x_11        PACK_20  1.0
    x_11        PACK_5  1.0
    x_12        OBJ       -70
    x_12        PACK_23  1.0
    x_12        PACK_7  1.0
    x_12        PACK_5  1.0
    x_12        PACK_14  1.0
    x_13        OBJ       -12
    x_13        PACK_8  1.0
    x_13        PACK_29  1.0
    x_13        PACK_20  1.0
    x_14        OBJ       -76
    x_14        PACK_17  1.0
    x_14        PACK_7  1.0
    x_14        PACK_21  1.0
    x_14        PACK_10  1.0
    x_15        OBJ       -55
    x_15        PACK_7  1.0
    x_15        PACK_26  1.0
    x_16        OBJ       -5
    x_16        PACK_25  1.0
    x_16        PACK_10  1.0
    x_17        OBJ       -4
    x_17        PACK_8  1.0
    x_17        PACK_2  1.0
    x_17        PACK_6  1.0
    x_18        OBJ       -12
    x_18        PACK_28  1.0
    x_18        PACK_22  1.0
    x_18        PACK_10  1.0
    x_18        PACK_6  1.0
    x_19        OBJ       -28
    x_19        PACK_15  1.0
    x_19        PACK_12  1.0
    x_19        PACK_28  1.0
    x_19        PACK_29  1.0
    x_20        OBJ       -30
    x_20        PACK_14  1.0
    x_20        PACK_4  1.0
    x_20        PACK_8  1.0
    x_20        PACK_7  1.0
    x_21        OBJ       -65
    x_21        PACK_17  1.0
    x_21        PACK_8  1.0
    x_21        PACK_23  1.0
    x_21        PACK_18  1.0
    x_22        OBJ       -78
    x_22        PACK_28  1.0
    x_22        PACK_18  1.0
    x_22        PACK_12  1.0
    x_23        OBJ       -4
    x_23        PACK_7  1.0
    x_23        PACK_4  1.0
    x_23        PACK_16  1.0
    x_24        OBJ       -72
    x_24        PACK_2  1.0
    x_24        PACK_24  1.0
    x_24        PACK_1  1.0
    x_25        OBJ       -26
    x_25        PACK_4  1.0
    x_25        PACK_20  1.0
    x_26        OBJ       -92
    x_26        PACK_25  1.0
    x_26        PACK_21  1.0
    x_27        OBJ       -84
    x_27        PACK_19  1.0
    x_27        PACK_2  1.0
    x_27        PACK_12  1.0
    x_28        OBJ       -90
    x_28        PACK_19  1.0
    x_28        PACK_14  1.0
    x_28        PACK_16  1.0
    x_29        OBJ       -70
    x_29        PACK_17  1.0
    x_29        PACK_27  1.0
    x_29        PACK_0  1.0
    x_30        OBJ       -54
    x_30        PACK_23  1.0
    x_30        PACK_3  1.0
    x_30        PACK_21  1.0
    x_30        PACK_28  1.0
    x_31        OBJ       -29
    x_31        PACK_24  1.0
    x_31        PACK_8  1.0
    x_31        PACK_20  1.0
    x_31        PACK_10  1.0
    x_32        OBJ       -58
    x_32        PACK_9  1.0
    x_32        PACK_13  1.0
    x_33        OBJ       -76
    x_33        PACK_14  1.0
    x_33        PACK_0  1.0
    x_34        OBJ       -36
    x_34        PACK_28  1.0
    x_34        PACK_23  1.0
    x_34        PACK_8  1.0
    x_34        PACK_16  1.0
    x_35        OBJ       -1
    x_35        PACK_16  1.0
    x_35        PACK_29  1.0
    x_36        OBJ       -98
    x_36        PACK_27  1.0
    x_36        PACK_20  1.0
    x_37        OBJ       -21
    x_37        PACK_26  1.0
    x_37        PACK_20  1.0
    x_37        PACK_16  1.0
    x_38        OBJ       -90
    x_38        PACK_6  1.0
    x_38        PACK_4  1.0
    x_38        PACK_11  1.0
    x_38        PACK_24  1.0
    x_39        OBJ       -55
    x_39        PACK_17  1.0
    x_39        PACK_24  1.0
    x_40        OBJ       -44
    x_40        PACK_29  1.0
    x_40        PACK_0  1.0
    x_40        PACK_19  1.0
    x_40        PACK_10  1.0
    x_41        OBJ       -36
    x_41        PACK_0  1.0
    x_41        PACK_3  1.0
    x_41        PACK_29  1.0
    x_42        OBJ       -20
    x_42        PACK_28  1.0
    x_42        PACK_26  1.0
    x_42        PACK_25  1.0
    x_43        OBJ       -28
    x_43        PACK_7  1.0
    x_43        PACK_1  1.0
    x_43        PACK_28  1.0
    x_44        OBJ       -98
    x_44        PACK_2  1.0
    x_44        PACK_23  1.0
    x_44        PACK_15  1.0
    x_44        PACK_26  1.0
    x_45        OBJ       -44
    x_45        PACK_24  1.0
    x_45        PACK_17  1.0
    x_46        OBJ       -14
    x_46        PACK_4  1.0
    x_46        PACK_21  1.0
    x_47        OBJ       -12
    x_47        PACK_17  1.0
    x_47        PACK_5  1.0
    x_47        PACK_8  1.0
    x_48        OBJ       -49
    x_48        PACK_27  1.0
    x_48        PACK_19  1.0
    x_48        PACK_13  1.0
    x_48        PACK_6  1.0
    x_49        OBJ       -13
    x_49        PACK_24  1.0
    x_49        PACK_23  1.0
    x_49        PACK_22  1.0
    x_49        PACK_6  1.0
RHS
    RHS1      PACK_0  1.0
    RHS1      PACK_1  1.0
    RHS1      PACK_2  1.0
    RHS1      PACK_3  1.0
    RHS1      PACK_4  1.0
    RHS1      PACK_5  1.0
    RHS1      PACK_6  1.0
    RHS1      PACK_7  1.0
    RHS1      PACK_8  1.0
    RHS1      PACK_9  1.0
    RHS1      PACK_10  1.0
    RHS1      PACK_11  1.0
    RHS1      PACK_12  1.0
    RHS1      PACK_13  1.0
    RHS1      PACK_14  1.0
    RHS1      PACK_15  1.0
    RHS1      PACK_16  1.0
    RHS1      PACK_17  1.0
    RHS1      PACK_18  1.0
    RHS1      PACK_19  1.0
    RHS1      PACK_20  1.0
    RHS1      PACK_21  1.0
    RHS1      PACK_22  1.0
    RHS1      PACK_23  1.0
    RHS1      PACK_24  1.0
    RHS1      PACK_25  1.0
    RHS1      PACK_26  1.0
    RHS1      PACK_27  1.0
    RHS1      PACK_28  1.0
    RHS1      PACK_29  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
 BV BND1      x_30
 BV BND1      x_31
 BV BND1      x_32
 BV BND1      x_33
 BV BND1      x_34
 BV BND1      x_35
 BV BND1      x_36
 BV BND1      x_37
 BV BND1      x_38
 BV BND1      x_39
 BV BND1      x_40
 BV BND1      x_41
 BV BND1      x_42
 BV BND1      x_43
 BV BND1      x_44
 BV BND1      x_45
 BV BND1      x_46
 BV BND1      x_47
 BV BND1      x_48
 BV BND1      x_49
ENDATA
