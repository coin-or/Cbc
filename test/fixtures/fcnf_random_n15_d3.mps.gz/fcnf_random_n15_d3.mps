NAME          fcnf_random_n15_d3
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
 L  link_42
 L  link_43
 L  link_44
COLUMNS
    x_0         OBJ       1.66
    x_0         flow_8      1.0
    x_0         flow_5      -1.0
    x_0         link_0      1.0
    x_1         OBJ       4.57
    x_1         flow_8      1.0
    x_1         flow_3      -1.0
    x_1         link_1      1.0
    x_2         OBJ       4.29
    x_2         flow_12     1.0
    x_2         flow_13     -1.0
    x_2         link_2      1.0
    x_3         OBJ       3.78
    x_3         flow_12     1.0
    x_3         flow_8      -1.0
    x_3         link_3      1.0
    x_4         OBJ       3.12
    x_4         flow_0      1.0
    x_4         flow_1      -1.0
    x_4         link_4      1.0
    x_5         OBJ       4.49
    x_5         flow_2      1.0
    x_5         flow_0      -1.0
    x_5         link_5      1.0
    x_6         OBJ       5.21
    x_6         flow_5      1.0
    x_6         flow_1      -1.0
    x_6         link_6      1.0
    x_7         OBJ       2.41
    x_7         flow_9      1.0
    x_7         flow_14     -1.0
    x_7         link_7      1.0
    x_8         OBJ       3.01
    x_8         flow_2      1.0
    x_8         flow_3      -1.0
    x_8         link_8      1.0
    x_9         OBJ       2.83
    x_9         flow_4      1.0
    x_9         flow_0      -1.0
    x_9         link_9      1.0
    x_10        OBJ       1.58
    x_10        flow_7      1.0
    x_10        flow_11     -1.0
    x_10        link_10     1.0
    x_11        OBJ       3.67
    x_11        flow_5      1.0
    x_11        flow_7      -1.0
    x_11        link_11     1.0
    x_12        OBJ       4.91
    x_12        flow_12     1.0
    x_12        flow_0      -1.0
    x_12        link_12     1.0
    x_13        OBJ       3.91
    x_13        flow_0      1.0
    x_13        flow_12     -1.0
    x_13        link_13     1.0
    x_14        OBJ       2.29
    x_14        flow_6      1.0
    x_14        flow_9      -1.0
    x_14        link_14     1.0
    x_15        OBJ       5.14
    x_15        flow_11     1.0
    x_15        flow_3      -1.0
    x_15        link_15     1.0
    x_16        OBJ       5.13
    x_16        flow_4      1.0
    x_16        flow_14     -1.0
    x_16        link_16     1.0
    x_17        OBJ       3.88
    x_17        flow_14     1.0
    x_17        flow_6      -1.0
    x_17        link_17     1.0
    x_18        OBJ       3.27
    x_18        flow_0      1.0
    x_18        flow_14     -1.0
    x_18        link_18     1.0
    x_19        OBJ       4.41
    x_19        flow_11     1.0
    x_19        flow_0      -1.0
    x_19        link_19     1.0
    x_20        OBJ       5.3
    x_20        flow_10     1.0
    x_20        flow_12     -1.0
    x_20        link_20     1.0
    x_21        OBJ       5.64
    x_21        flow_7      1.0
    x_21        flow_1      -1.0
    x_21        link_21     1.0
    x_22        OBJ       5.29
    x_22        flow_12     1.0
    x_22        flow_1      -1.0
    x_22        link_22     1.0
    x_23        OBJ       2.21
    x_23        flow_3      1.0
    x_23        flow_13     -1.0
    x_23        link_23     1.0
    x_24        OBJ       2.36
    x_24        flow_6      1.0
    x_24        flow_0      -1.0
    x_24        link_24     1.0
    x_25        OBJ       3.11
    x_25        flow_6      1.0
    x_25        flow_10     -1.0
    x_25        link_25     1.0
    x_26        OBJ       5.32
    x_26        flow_7      1.0
    x_26        flow_5      -1.0
    x_26        link_26     1.0
    x_27        OBJ       2.05
    x_27        flow_2      1.0
    x_27        flow_13     -1.0
    x_27        link_27     1.0
    x_28        OBJ       1.97
    x_28        flow_4      1.0
    x_28        flow_5      -1.0
    x_28        link_28     1.0
    x_29        OBJ       1.22
    x_29        flow_6      1.0
    x_29        flow_12     -1.0
    x_29        link_29     1.0
    x_30        OBJ       3.54
    x_30        flow_6      1.0
    x_30        flow_13     -1.0
    x_30        link_30     1.0
    x_31        OBJ       1.63
    x_31        flow_14     1.0
    x_31        flow_1      -1.0
    x_31        link_31     1.0
    x_32        OBJ       3.51
    x_32        flow_8      1.0
    x_32        flow_12     -1.0
    x_32        link_32     1.0
    x_33        OBJ       2.46
    x_33        flow_4      1.0
    x_33        flow_12     -1.0
    x_33        link_33     1.0
    x_34        OBJ       3.07
    x_34        flow_10     1.0
    x_34        flow_7      -1.0
    x_34        link_34     1.0
    x_35        OBJ       3.01
    x_35        flow_0      1.0
    x_35        flow_2      -1.0
    x_35        link_35     1.0
    x_36        OBJ       4.62
    x_36        flow_5      1.0
    x_36        flow_8      -1.0
    x_36        link_36     1.0
    x_37        OBJ       2.71
    x_37        flow_13     1.0
    x_37        flow_10     -1.0
    x_37        link_37     1.0
    x_38        OBJ       5.63
    x_38        flow_3      1.0
    x_38        flow_10     -1.0
    x_38        link_38     1.0
    x_39        OBJ       3.5
    x_39        flow_2      1.0
    x_39        flow_9      -1.0
    x_39        link_39     1.0
    x_40        OBJ       1.2
    x_40        flow_6      1.0
    x_40        flow_1      -1.0
    x_40        link_40     1.0
    x_41        OBJ       1.57
    x_41        flow_14     1.0
    x_41        flow_13     -1.0
    x_41        link_41     1.0
    x_42        OBJ       2.1
    x_42        flow_8      1.0
    x_42        flow_13     -1.0
    x_42        link_42     1.0
    x_43        OBJ       3.87
    x_43        flow_10     1.0
    x_43        flow_1      -1.0
    x_43        link_43     1.0
    x_44        OBJ       2.64
    x_44        flow_3      1.0
    x_44        flow_11     -1.0
    x_44        link_44     1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       7.98
    y_0         link_0      -6.63
    y_1         OBJ       6.05
    y_1         link_1      -4.86
    y_2         OBJ       6.45
    y_2         link_2      -5.64
    y_3         OBJ       6.56
    y_3         link_3      -8.66
    y_4         OBJ       3.93
    y_4         link_4      -11.07
    y_5         OBJ       5.04
    y_5         link_5      -7.07
    y_6         OBJ       4.9
    y_6         link_6      -10.78
    y_7         OBJ       3.97
    y_7         link_7      -10.83
    y_8         OBJ       8.71
    y_8         link_8      -12.39
    y_9         OBJ       5.02
    y_9         link_9      -6.5
    y_10        OBJ       3.81
    y_10        link_10     -4.76
    y_11        OBJ       5.23
    y_11        link_11     -8.16
    y_12        OBJ       5.96
    y_12        link_12     -13.64
    y_13        OBJ       7.79
    y_13        link_13     -7.87
    y_14        OBJ       8.36
    y_14        link_14     -5.31
    y_15        OBJ       9.5
    y_15        link_15     -4.97
    y_16        OBJ       7.07
    y_16        link_16     -11.8
    y_17        OBJ       8.37
    y_17        link_17     -11.6
    y_18        OBJ       5.05
    y_18        link_18     -10.63
    y_19        OBJ       5.35
    y_19        link_19     -13.77
    y_20        OBJ       6.14
    y_20        link_20     -13.36
    y_21        OBJ       9.39
    y_21        link_21     -4.03
    y_22        OBJ       9.96
    y_22        link_22     -10.24
    y_23        OBJ       3.22
    y_23        link_23     -14.82
    y_24        OBJ       3.14
    y_24        link_24     -6.77
    y_25        OBJ       7.85
    y_25        link_25     -14.44
    y_26        OBJ       3.87
    y_26        link_26     -3.58
    y_27        OBJ       7.08
    y_27        link_27     -4.63
    y_28        OBJ       3.92
    y_28        link_28     -10.65
    y_29        OBJ       6.95
    y_29        link_29     -14.26
    y_30        OBJ       8.15
    y_30        link_30     -10.55
    y_31        OBJ       3.64
    y_31        link_31     -12.12
    y_32        OBJ       7.02
    y_32        link_32     -6.96
    y_33        OBJ       9.8
    y_33        link_33     -4.53
    y_34        OBJ       7.06
    y_34        link_34     -4.44
    y_35        OBJ       3.66
    y_35        link_35     -13.13
    y_36        OBJ       9.63
    y_36        link_36     -4.97
    y_37        OBJ       4.02
    y_37        link_37     -12.13
    y_38        OBJ       3.29
    y_38        link_38     -8.27
    y_39        OBJ       9.7
    y_39        link_39     -3.63
    y_40        OBJ       6.48
    y_40        link_40     -11.85
    y_41        OBJ       3.75
    y_41        link_41     -6.65
    y_42        OBJ       4.78
    y_42        link_42     -13.98
    y_43        OBJ       6.92
    y_43        link_43     -5.13
    y_44        OBJ       5.83
    y_44        link_44     -9.51
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_1      -3
    RHS       flow_6      -3
    RHS       flow_8      -3
    RHS       flow_10     5
    RHS       flow_14     4
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
 BV BOUND     y_42
 BV BOUND     y_43
 BV BOUND     y_44
ENDATA
