NAME          fcnf_random_n20_d4_tight
ROWS
 N  OBJ
 E  flow_0
 E  flow_1
 E  flow_2
 E  flow_3
 E  flow_4
 E  flow_5
 E  flow_6
 E  flow_7
 E  flow_8
 E  flow_9
 E  flow_10
 E  flow_11
 E  flow_12
 E  flow_13
 E  flow_14
 E  flow_15
 E  flow_16
 E  flow_17
 E  flow_18
 E  flow_19
 L  link_0
 L  link_1
 L  link_2
 L  link_3
 L  link_4
 L  link_5
 L  link_6
 L  link_7
 L  link_8
 L  link_9
 L  link_10
 L  link_11
 L  link_12
 L  link_13
 L  link_14
 L  link_15
 L  link_16
 L  link_17
 L  link_18
 L  link_19
 L  link_20
 L  link_21
 L  link_22
 L  link_23
 L  link_24
 L  link_25
 L  link_26
 L  link_27
 L  link_28
 L  link_29
 L  link_30
 L  link_31
 L  link_32
 L  link_33
 L  link_34
 L  link_35
 L  link_36
 L  link_37
 L  link_38
 L  link_39
 L  link_40
 L  link_41
 L  link_42
 L  link_43
 L  link_44
 L  link_45
 L  link_46
 L  link_47
 L  link_48
 L  link_49
 L  link_50
 L  link_51
 L  link_52
 L  link_53
 L  link_54
 L  link_55
 L  link_56
 L  link_57
 L  link_58
 L  link_59
 L  link_60
 L  link_61
 L  link_62
 L  link_63
 L  link_64
 L  link_65
 L  link_66
 L  link_67
 L  link_68
 L  link_69
 L  link_70
 L  link_71
 L  link_72
 L  link_73
 L  link_74
 L  link_75
 L  link_76
 L  link_77
 L  link_78
 L  link_79
COLUMNS
    x_0         OBJ       0.78
    x_0         flow_2      1.0
    x_0         flow_11     -1.0
    x_0         link_0      1.0
    x_1         OBJ       0.61
    x_1         flow_8      1.0
    x_1         flow_4      -1.0
    x_1         link_1      1.0
    x_2         OBJ       44.0
    x_2         flow_19     1.0
    x_2         flow_9      -1.0
    x_2         link_2      1.0
    x_3         OBJ       39.59
    x_3         flow_3      1.0
    x_3         flow_13     -1.0
    x_3         link_3      1.0
    x_4         OBJ       59.68
    x_4         flow_12     1.0
    x_4         flow_19     -1.0
    x_4         link_4      1.0
    x_5         OBJ       52.44
    x_5         flow_6      1.0
    x_5         flow_2      -1.0
    x_5         link_5      1.0
    x_6         OBJ       1.96
    x_6         flow_15     1.0
    x_6         flow_7      -1.0
    x_6         link_6      1.0
    x_7         OBJ       2.8
    x_7         flow_15     1.0
    x_7         flow_12     -1.0
    x_7         link_7      1.0
    x_8         OBJ       2.81
    x_8         flow_17     1.0
    x_8         flow_4      -1.0
    x_8         link_8      1.0
    x_9         OBJ       2.26
    x_9         flow_9      1.0
    x_9         flow_2      -1.0
    x_9         link_9      1.0
    x_10        OBJ       48.53
    x_10        flow_13     1.0
    x_10        flow_10     -1.0
    x_10        link_10     1.0
    x_11        OBJ       1.35
    x_11        flow_15     1.0
    x_11        flow_5      -1.0
    x_11        link_11     1.0
    x_12        OBJ       59.06
    x_12        flow_13     1.0
    x_12        flow_15     -1.0
    x_12        link_12     1.0
    x_13        OBJ       1.35
    x_13        flow_2      1.0
    x_13        flow_7      -1.0
    x_13        link_13     1.0
    x_14        OBJ       0.76
    x_14        flow_5      1.0
    x_14        flow_11     -1.0
    x_14        link_14     1.0
    x_15        OBJ       1.99
    x_15        flow_5      1.0
    x_15        flow_18     -1.0
    x_15        link_15     1.0
    x_16        OBJ       47.35
    x_16        flow_11     1.0
    x_16        flow_16     -1.0
    x_16        link_16     1.0
    x_17        OBJ       2.15
    x_17        flow_14     1.0
    x_17        flow_18     -1.0
    x_17        link_17     1.0
    x_18        OBJ       1.91
    x_18        flow_16     1.0
    x_18        flow_3      -1.0
    x_18        link_18     1.0
    x_19        OBJ       0.58
    x_19        flow_17     1.0
    x_19        flow_7      -1.0
    x_19        link_19     1.0
    x_20        OBJ       1.53
    x_20        flow_8      1.0
    x_20        flow_17     -1.0
    x_20        link_20     1.0
    x_21        OBJ       2.62
    x_21        flow_8      1.0
    x_21        flow_3      -1.0
    x_21        link_21     1.0
    x_22        OBJ       0.93
    x_22        flow_18     1.0
    x_22        flow_4      -1.0
    x_22        link_22     1.0
    x_23        OBJ       38.72
    x_23        flow_5      1.0
    x_23        flow_7      -1.0
    x_23        link_23     1.0
    x_24        OBJ       2.25
    x_24        flow_1      1.0
    x_24        flow_3      -1.0
    x_24        link_24     1.0
    x_25        OBJ       50.59
    x_25        flow_16     1.0
    x_25        flow_13     -1.0
    x_25        link_25     1.0
    x_26        OBJ       2.76
    x_26        flow_6      1.0
    x_26        flow_15     -1.0
    x_26        link_26     1.0
    x_27        OBJ       32.02
    x_27        flow_0      1.0
    x_27        flow_9      -1.0
    x_27        link_27     1.0
    x_28        OBJ       0.74
    x_28        flow_10     1.0
    x_28        flow_7      -1.0
    x_28        link_28     1.0
    x_29        OBJ       66.24
    x_29        flow_3      1.0
    x_29        flow_19     -1.0
    x_29        link_29     1.0
    x_30        OBJ       24.93
    x_30        flow_7      1.0
    x_30        flow_11     -1.0
    x_30        link_30     1.0
    x_31        OBJ       1.05
    x_31        flow_10     1.0
    x_31        flow_17     -1.0
    x_31        link_31     1.0
    x_32        OBJ       1.29
    x_32        flow_7      1.0
    x_32        flow_10     -1.0
    x_32        link_32     1.0
    x_33        OBJ       1.23
    x_33        flow_17     1.0
    x_33        flow_1      -1.0
    x_33        link_33     1.0
    x_34        OBJ       2.11
    x_34        flow_14     1.0
    x_34        flow_7      -1.0
    x_34        link_34     1.0
    x_35        OBJ       57.57
    x_35        flow_4      1.0
    x_35        flow_0      -1.0
    x_35        link_35     1.0
    x_36        OBJ       27.44
    x_36        flow_9      1.0
    x_36        flow_5      -1.0
    x_36        link_36     1.0
    x_37        OBJ       42.48
    x_37        flow_10     1.0
    x_37        flow_6      -1.0
    x_37        link_37     1.0
    x_38        OBJ       43.7
    x_38        flow_8      1.0
    x_38        flow_7      -1.0
    x_38        link_38     1.0
    x_39        OBJ       49.06
    x_39        flow_15     1.0
    x_39        flow_19     -1.0
    x_39        link_39     1.0
    x_40        OBJ       1.89
    x_40        flow_14     1.0
    x_40        flow_3      -1.0
    x_40        link_40     1.0
    x_41        OBJ       78.96
    x_41        flow_13     1.0
    x_41        flow_3      -1.0
    x_41        link_41     1.0
    x_42        OBJ       0.68
    x_42        flow_0      1.0
    x_42        flow_17     -1.0
    x_42        link_42     1.0
    x_43        OBJ       55.91
    x_43        flow_1      1.0
    x_43        flow_6      -1.0
    x_43        link_43     1.0
    x_44        OBJ       2.78
    x_44        flow_15     1.0
    x_44        flow_2      -1.0
    x_44        link_44     1.0
    x_45        OBJ       48.15
    x_45        flow_1      1.0
    x_45        flow_15     -1.0
    x_45        link_45     1.0
    x_46        OBJ       2.38
    x_46        flow_11     1.0
    x_46        flow_8      -1.0
    x_46        link_46     1.0
    x_47        OBJ       1.07
    x_47        flow_9      1.0
    x_47        flow_19     -1.0
    x_47        link_47     1.0
    x_48        OBJ       60.67
    x_48        flow_17     1.0
    x_48        flow_0      -1.0
    x_48        link_48     1.0
    x_49        OBJ       1.44
    x_49        flow_0      1.0
    x_49        flow_6      -1.0
    x_49        link_49     1.0
    x_50        OBJ       49.31
    x_50        flow_11     1.0
    x_50        flow_12     -1.0
    x_50        link_50     1.0
    x_51        OBJ       33.62
    x_51        flow_6      1.0
    x_51        flow_16     -1.0
    x_51        link_51     1.0
    x_52        OBJ       53.24
    x_52        flow_6      1.0
    x_52        flow_17     -1.0
    x_52        link_52     1.0
    x_53        OBJ       38.76
    x_53        flow_9      1.0
    x_53        flow_18     -1.0
    x_53        link_53     1.0
    x_54        OBJ       2.37
    x_54        flow_16     1.0
    x_54        flow_11     -1.0
    x_54        link_54     1.0
    x_55        OBJ       71.78
    x_55        flow_12     1.0
    x_55        flow_13     -1.0
    x_55        link_55     1.0
    x_56        OBJ       1.06
    x_56        flow_7      1.0
    x_56        flow_19     -1.0
    x_56        link_56     1.0
    x_57        OBJ       2.04
    x_57        flow_14     1.0
    x_57        flow_17     -1.0
    x_57        link_57     1.0
    x_58        OBJ       1.5
    x_58        flow_18     1.0
    x_58        flow_9      -1.0
    x_58        link_58     1.0
    x_59        OBJ       0.58
    x_59        flow_16     1.0
    x_59        flow_4      -1.0
    x_59        link_59     1.0
    x_60        OBJ       42.24
    x_60        flow_11     1.0
    x_60        flow_2      -1.0
    x_60        link_60     1.0
    x_61        OBJ       1.17
    x_61        flow_19     1.0
    x_61        flow_17     -1.0
    x_61        link_61     1.0
    x_62        OBJ       65.64
    x_62        flow_19     1.0
    x_62        flow_10     -1.0
    x_62        link_62     1.0
    x_63        OBJ       1.39
    x_63        flow_6      1.0
    x_63        flow_13     -1.0
    x_63        link_63     1.0
    x_64        OBJ       27.89
    x_64        flow_0      1.0
    x_64        flow_3      -1.0
    x_64        link_64     1.0
    x_65        OBJ       0.62
    x_65        flow_12     1.0
    x_65        flow_1      -1.0
    x_65        link_65     1.0
    x_66        OBJ       0.86
    x_66        flow_5      1.0
    x_66        flow_10     -1.0
    x_66        link_66     1.0
    x_67        OBJ       75.42
    x_67        flow_2      1.0
    x_67        flow_17     -1.0
    x_67        link_67     1.0
    x_68        OBJ       30.68
    x_68        flow_16     1.0
    x_68        flow_1      -1.0
    x_68        link_68     1.0
    x_69        OBJ       2.57
    x_69        flow_4      1.0
    x_69        flow_5      -1.0
    x_69        link_69     1.0
    x_70        OBJ       1.17
    x_70        flow_4      1.0
    x_70        flow_18     -1.0
    x_70        link_70     1.0
    x_71        OBJ       1.19
    x_71        flow_1      1.0
    x_71        flow_16     -1.0
    x_71        link_71     1.0
    x_72        OBJ       27.53
    x_72        flow_7      1.0
    x_72        flow_6      -1.0
    x_72        link_72     1.0
    x_73        OBJ       76.4
    x_73        flow_10     1.0
    x_73        flow_18     -1.0
    x_73        link_73     1.0
    x_74        OBJ       1.51
    x_74        flow_1      1.0
    x_74        flow_18     -1.0
    x_74        link_74     1.0
    x_75        OBJ       0.66
    x_75        flow_19     1.0
    x_75        flow_5      -1.0
    x_75        link_75     1.0
    x_76        OBJ       79.61
    x_76        flow_18     1.0
    x_76        flow_2      -1.0
    x_76        link_76     1.0
    x_77        OBJ       38.28
    x_77        flow_4      1.0
    x_77        flow_1      -1.0
    x_77        link_77     1.0
    x_78        OBJ       0.59
    x_78        flow_2      1.0
    x_78        flow_9      -1.0
    x_78        link_78     1.0
    x_79        OBJ       2.86
    x_79        flow_1      1.0
    x_79        flow_2      -1.0
    x_79        link_79     1.0
    MARKBIN   'MARKER'                 'INTORG'
    y_0         OBJ       162.82
    y_0         link_0      -6.0
    y_1         OBJ       131.91
    y_1         link_1      -3.0
    y_2         OBJ       1.99
    y_2         link_2      -3.0
    y_3         OBJ       2.43
    y_3         link_3      -7.0
    y_4         OBJ       3.75
    y_4         link_4      -6.0
    y_5         OBJ       3.13
    y_5         link_5      -3.0
    y_6         OBJ       194.02
    y_6         link_6      -5.0
    y_7         OBJ       153.56
    y_7         link_7      -2.0
    y_8         OBJ       178.06
    y_8         link_8      -8.0
    y_9         OBJ       154.18
    y_9         link_9      -2.0
    y_10        OBJ       4.05
    y_10        link_10     -4.0
    y_11        OBJ       65.61
    y_11        link_11     -7.0
    y_12        OBJ       4.8
    y_12        link_12     -6.0
    y_13        OBJ       134.61
    y_13        link_13     -2.0
    y_14        OBJ       177.6
    y_14        link_14     -2.0
    y_15        OBJ       114.3
    y_15        link_15     -4.0
    y_16        OBJ       1.49
    y_16        link_16     -6.0
    y_17        OBJ       141.77
    y_17        link_17     -4.0
    y_18        OBJ       195.96
    y_18        link_18     -7.0
    y_19        OBJ       61.68
    y_19        link_19     -5.0
    y_20        OBJ       153.35
    y_20        link_20     -6.0
    y_21        OBJ       54.5
    y_21        link_21     -5.0
    y_22        OBJ       190.51
    y_22        link_22     -3.0
    y_23        OBJ       2.43
    y_23        link_23     -3.0
    y_24        OBJ       63.46
    y_24        link_24     -2.0
    y_25        OBJ       2.11
    y_25        link_25     -4.0
    y_26        OBJ       96.88
    y_26        link_26     -8.0
    y_27        OBJ       1.5
    y_27        link_27     -8.0
    y_28        OBJ       195.11
    y_28        link_28     -4.0
    y_29        OBJ       1.94
    y_29        link_29     -2.0
    y_30        OBJ       4.11
    y_30        link_30     -7.0
    y_31        OBJ       64.48
    y_31        link_31     -5.0
    y_32        OBJ       155.8
    y_32        link_32     -4.0
    y_33        OBJ       63.13
    y_33        link_33     -2.0
    y_34        OBJ       187.32
    y_34        link_34     -7.0
    y_35        OBJ       4.09
    y_35        link_35     -2.0
    y_36        OBJ       1.74
    y_36        link_36     -3.0
    y_37        OBJ       2.94
    y_37        link_37     -8.0
    y_38        OBJ       1.17
    y_38        link_38     -6.0
    y_39        OBJ       4.57
    y_39        link_39     -5.0
    y_40        OBJ       79.12
    y_40        link_40     -5.0
    y_41        OBJ       1.72
    y_41        link_41     -7.0
    y_42        OBJ       99.81
    y_42        link_42     -6.0
    y_43        OBJ       3.55
    y_43        link_43     -2.0
    y_44        OBJ       130.89
    y_44        link_44     -3.0
    y_45        OBJ       4.93
    y_45        link_45     -4.0
    y_46        OBJ       84.5
    y_46        link_46     -2.0
    y_47        OBJ       162.41
    y_47        link_47     -7.0
    y_48        OBJ       3.11
    y_48        link_48     -3.0
    y_49        OBJ       96.35
    y_49        link_49     -2.0
    y_50        OBJ       2.81
    y_50        link_50     -6.0
    y_51        OBJ       2.18
    y_51        link_51     -3.0
    y_52        OBJ       3.63
    y_52        link_52     -4.0
    y_53        OBJ       2.31
    y_53        link_53     -4.0
    y_54        OBJ       130.37
    y_54        link_54     -3.0
    y_55        OBJ       4.56
    y_55        link_55     -5.0
    y_56        OBJ       165.6
    y_56        link_56     -4.0
    y_57        OBJ       139.51
    y_57        link_57     -4.0
    y_58        OBJ       63.16
    y_58        link_58     -2.0
    y_59        OBJ       106.48
    y_59        link_59     -5.0
    y_60        OBJ       2.86
    y_60        link_60     -6.0
    y_61        OBJ       164.71
    y_61        link_61     -8.0
    y_62        OBJ       4.35
    y_62        link_62     -3.0
    y_63        OBJ       169.52
    y_63        link_63     -4.0
    y_64        OBJ       1.56
    y_64        link_64     -5.0
    y_65        OBJ       142.04
    y_65        link_65     -7.0
    y_66        OBJ       172.51
    y_66        link_66     -5.0
    y_67        OBJ       1.52
    y_67        link_67     -6.0
    y_68        OBJ       3.48
    y_68        link_68     -4.0
    y_69        OBJ       151.22
    y_69        link_69     -6.0
    y_70        OBJ       143.61
    y_70        link_70     -8.0
    y_71        OBJ       190.72
    y_71        link_71     -8.0
    y_72        OBJ       4.47
    y_72        link_72     -5.0
    y_73        OBJ       2.45
    y_73        link_73     -7.0
    y_74        OBJ       134.37
    y_74        link_74     -5.0
    y_75        OBJ       131.42
    y_75        link_75     -4.0
    y_76        OBJ       3.59
    y_76        link_76     -2.0
    y_77        OBJ       3.7
    y_77        link_77     -8.0
    y_78        OBJ       83.33
    y_78        link_78     -3.0
    y_79        OBJ       164.06
    y_79        link_79     -5.0
    MARKBIN   'MARKER'                 'INTEND'
RHS
    RHS       flow_0      3
    RHS       flow_1      -2
    RHS       flow_6      3
    RHS       flow_8      -2
    RHS       flow_10     -2
BOUNDS
 BV BOUND     y_0
 BV BOUND     y_1
 BV BOUND     y_2
 BV BOUND     y_3
 BV BOUND     y_4
 BV BOUND     y_5
 BV BOUND     y_6
 BV BOUND     y_7
 BV BOUND     y_8
 BV BOUND     y_9
 BV BOUND     y_10
 BV BOUND     y_11
 BV BOUND     y_12
 BV BOUND     y_13
 BV BOUND     y_14
 BV BOUND     y_15
 BV BOUND     y_16
 BV BOUND     y_17
 BV BOUND     y_18
 BV BOUND     y_19
 BV BOUND     y_20
 BV BOUND     y_21
 BV BOUND     y_22
 BV BOUND     y_23
 BV BOUND     y_24
 BV BOUND     y_25
 BV BOUND     y_26
 BV BOUND     y_27
 BV BOUND     y_28
 BV BOUND     y_29
 BV BOUND     y_30
 BV BOUND     y_31
 BV BOUND     y_32
 BV BOUND     y_33
 BV BOUND     y_34
 BV BOUND     y_35
 BV BOUND     y_36
 BV BOUND     y_37
 BV BOUND     y_38
 BV BOUND     y_39
 BV BOUND     y_40
 BV BOUND     y_41
 BV BOUND     y_42
 BV BOUND     y_43
 BV BOUND     y_44
 BV BOUND     y_45
 BV BOUND     y_46
 BV BOUND     y_47
 BV BOUND     y_48
 BV BOUND     y_49
 BV BOUND     y_50
 BV BOUND     y_51
 BV BOUND     y_52
 BV BOUND     y_53
 BV BOUND     y_54
 BV BOUND     y_55
 BV BOUND     y_56
 BV BOUND     y_57
 BV BOUND     y_58
 BV BOUND     y_59
 BV BOUND     y_60
 BV BOUND     y_61
 BV BOUND     y_62
 BV BOUND     y_63
 BV BOUND     y_64
 BV BOUND     y_65
 BV BOUND     y_66
 BV BOUND     y_67
 BV BOUND     y_68
 BV BOUND     y_69
 BV BOUND     y_70
 BV BOUND     y_71
 BV BOUND     y_72
 BV BOUND     y_73
 BV BOUND     y_74
 BV BOUND     y_75
 BV BOUND     y_76
 BV BOUND     y_77
 BV BOUND     y_78
 BV BOUND     y_79
ENDATA
