NAME          la06
ROWS
 N  OBJ
 G  prec_0_0
 G  prec_0_1
 G  prec_0_2
 G  prec_0_3
 G  prec_1_0
 G  prec_1_1
 G  prec_1_2
 G  prec_1_3
 G  prec_2_0
 G  prec_2_1
 G  prec_2_2
 G  prec_2_3
 G  prec_3_0
 G  prec_3_1
 G  prec_3_2
 G  prec_3_3
 G  prec_4_0
 G  prec_4_1
 G  prec_4_2
 G  prec_4_3
 G  prec_5_0
 G  prec_5_1
 G  prec_5_2
 G  prec_5_3
 G  prec_6_0
 G  prec_6_1
 G  prec_6_2
 G  prec_6_3
 G  prec_7_0
 G  prec_7_1
 G  prec_7_2
 G  prec_7_3
 G  prec_8_0
 G  prec_8_1
 G  prec_8_2
 G  prec_8_3
 G  prec_9_0
 G  prec_9_1
 G  prec_9_2
 G  prec_9_3
 G  prec_10_0
 G  prec_10_1
 G  prec_10_2
 G  prec_10_3
 G  prec_11_0
 G  prec_11_1
 G  prec_11_2
 G  prec_11_3
 G  prec_12_0
 G  prec_12_1
 G  prec_12_2
 G  prec_12_3
 G  prec_13_0
 G  prec_13_1
 G  prec_13_2
 G  prec_13_3
 G  prec_14_0
 G  prec_14_1
 G  prec_14_2
 G  prec_14_3
 G  mksp_0
 G  mksp_1
 G  mksp_2
 G  mksp_3
 G  mksp_4
 G  mksp_5
 G  mksp_6
 G  mksp_7
 G  mksp_8
 G  mksp_9
 G  mksp_10
 G  mksp_11
 G  mksp_12
 G  mksp_13
 G  mksp_14
 G  disj1_0_1_0
 G  disj2_0_1_0
 G  disj1_0_2_0
 G  disj2_0_2_0
 G  disj1_0_3_0
 G  disj2_0_3_0
 G  disj1_0_4_0
 G  disj2_0_4_0
 G  disj1_0_5_0
 G  disj2_0_5_0
 G  disj1_0_6_0
 G  disj2_0_6_0
 G  disj1_0_7_0
 G  disj2_0_7_0
 G  disj1_0_8_0
 G  disj2_0_8_0
 G  disj1_0_9_0
 G  disj2_0_9_0
 G  disj1_0_10_0
 G  disj2_0_10_0
 G  disj1_0_11_0
 G  disj2_0_11_0
 G  disj1_0_12_0
 G  disj2_0_12_0
 G  disj1_0_13_0
 G  disj2_0_13_0
 G  disj1_0_14_0
 G  disj2_0_14_0
 G  disj1_1_2_0
 G  disj2_1_2_0
 G  disj1_1_3_0
 G  disj2_1_3_0
 G  disj1_1_4_0
 G  disj2_1_4_0
 G  disj1_1_5_0
 G  disj2_1_5_0
 G  disj1_1_6_0
 G  disj2_1_6_0
 G  disj1_1_7_0
 G  disj2_1_7_0
 G  disj1_1_8_0
 G  disj2_1_8_0
 G  disj1_1_9_0
 G  disj2_1_9_0
 G  disj1_1_10_0
 G  disj2_1_10_0
 G  disj1_1_11_0
 G  disj2_1_11_0
 G  disj1_1_12_0
 G  disj2_1_12_0
 G  disj1_1_13_0
 G  disj2_1_13_0
 G  disj1_1_14_0
 G  disj2_1_14_0
 G  disj1_2_3_0
 G  disj2_2_3_0
 G  disj1_2_4_0
 G  disj2_2_4_0
 G  disj1_2_5_0
 G  disj2_2_5_0
 G  disj1_2_6_0
 G  disj2_2_6_0
 G  disj1_2_7_0
 G  disj2_2_7_0
 G  disj1_2_8_0
 G  disj2_2_8_0
 G  disj1_2_9_0
 G  disj2_2_9_0
 G  disj1_2_10_0
 G  disj2_2_10_0
 G  disj1_2_11_0
 G  disj2_2_11_0
 G  disj1_2_12_0
 G  disj2_2_12_0
 G  disj1_2_13_0
 G  disj2_2_13_0
 G  disj1_2_14_0
 G  disj2_2_14_0
 G  disj1_3_4_0
 G  disj2_3_4_0
 G  disj1_3_5_0
 G  disj2_3_5_0
 G  disj1_3_6_0
 G  disj2_3_6_0
 G  disj1_3_7_0
 G  disj2_3_7_0
 G  disj1_3_8_0
 G  disj2_3_8_0
 G  disj1_3_9_0
 G  disj2_3_9_0
 G  disj1_3_10_0
 G  disj2_3_10_0
 G  disj1_3_11_0
 G  disj2_3_11_0
 G  disj1_3_12_0
 G  disj2_3_12_0
 G  disj1_3_13_0
 G  disj2_3_13_0
 G  disj1_3_14_0
 G  disj2_3_14_0
 G  disj1_4_5_0
 G  disj2_4_5_0
 G  disj1_4_6_0
 G  disj2_4_6_0
 G  disj1_4_7_0
 G  disj2_4_7_0
 G  disj1_4_8_0
 G  disj2_4_8_0
 G  disj1_4_9_0
 G  disj2_4_9_0
 G  disj1_4_10_0
 G  disj2_4_10_0
 G  disj1_4_11_0
 G  disj2_4_11_0
 G  disj1_4_12_0
 G  disj2_4_12_0
 G  disj1_4_13_0
 G  disj2_4_13_0
 G  disj1_4_14_0
 G  disj2_4_14_0
 G  disj1_5_6_0
 G  disj2_5_6_0
 G  disj1_5_7_0
 G  disj2_5_7_0
 G  disj1_5_8_0
 G  disj2_5_8_0
 G  disj1_5_9_0
 G  disj2_5_9_0
 G  disj1_5_10_0
 G  disj2_5_10_0
 G  disj1_5_11_0
 G  disj2_5_11_0
 G  disj1_5_12_0
 G  disj2_5_12_0
 G  disj1_5_13_0
 G  disj2_5_13_0
 G  disj1_5_14_0
 G  disj2_5_14_0
 G  disj1_6_7_0
 G  disj2_6_7_0
 G  disj1_6_8_0
 G  disj2_6_8_0
 G  disj1_6_9_0
 G  disj2_6_9_0
 G  disj1_6_10_0
 G  disj2_6_10_0
 G  disj1_6_11_0
 G  disj2_6_11_0
 G  disj1_6_12_0
 G  disj2_6_12_0
 G  disj1_6_13_0
 G  disj2_6_13_0
 G  disj1_6_14_0
 G  disj2_6_14_0
 G  disj1_7_8_0
 G  disj2_7_8_0
 G  disj1_7_9_0
 G  disj2_7_9_0
 G  disj1_7_10_0
 G  disj2_7_10_0
 G  disj1_7_11_0
 G  disj2_7_11_0
 G  disj1_7_12_0
 G  disj2_7_12_0
 G  disj1_7_13_0
 G  disj2_7_13_0
 G  disj1_7_14_0
 G  disj2_7_14_0
 G  disj1_8_9_0
 G  disj2_8_9_0
 G  disj1_8_10_0
 G  disj2_8_10_0
 G  disj1_8_11_0
 G  disj2_8_11_0
 G  disj1_8_12_0
 G  disj2_8_12_0
 G  disj1_8_13_0
 G  disj2_8_13_0
 G  disj1_8_14_0
 G  disj2_8_14_0
 G  disj1_9_10_0
 G  disj2_9_10_0
 G  disj1_9_11_0
 G  disj2_9_11_0
 G  disj1_9_12_0
 G  disj2_9_12_0
 G  disj1_9_13_0
 G  disj2_9_13_0
 G  disj1_9_14_0
 G  disj2_9_14_0
 G  disj1_10_11_0
 G  disj2_10_11_0
 G  disj1_10_12_0
 G  disj2_10_12_0
 G  disj1_10_13_0
 G  disj2_10_13_0
 G  disj1_10_14_0
 G  disj2_10_14_0
 G  disj1_11_12_0
 G  disj2_11_12_0
 G  disj1_11_13_0
 G  disj2_11_13_0
 G  disj1_11_14_0
 G  disj2_11_14_0
 G  disj1_12_13_0
 G  disj2_12_13_0
 G  disj1_12_14_0
 G  disj2_12_14_0
 G  disj1_13_14_0
 G  disj2_13_14_0
 G  disj1_0_1_1
 G  disj2_0_1_1
 G  disj1_0_2_1
 G  disj2_0_2_1
 G  disj1_0_3_1
 G  disj2_0_3_1
 G  disj1_0_4_1
 G  disj2_0_4_1
 G  disj1_0_5_1
 G  disj2_0_5_1
 G  disj1_0_6_1
 G  disj2_0_6_1
 G  disj1_0_7_1
 G  disj2_0_7_1
 G  disj1_0_8_1
 G  disj2_0_8_1
 G  disj1_0_9_1
 G  disj2_0_9_1
 G  disj1_0_10_1
 G  disj2_0_10_1
 G  disj1_0_11_1
 G  disj2_0_11_1
 G  disj1_0_12_1
 G  disj2_0_12_1
 G  disj1_0_13_1
 G  disj2_0_13_1
 G  disj1_0_14_1
 G  disj2_0_14_1
 G  disj1_1_2_1
 G  disj2_1_2_1
 G  disj1_1_3_1
 G  disj2_1_3_1
 G  disj1_1_4_1
 G  disj2_1_4_1
 G  disj1_1_5_1
 G  disj2_1_5_1
 G  disj1_1_6_1
 G  disj2_1_6_1
 G  disj1_1_7_1
 G  disj2_1_7_1
 G  disj1_1_8_1
 G  disj2_1_8_1
 G  disj1_1_9_1
 G  disj2_1_9_1
 G  disj1_1_10_1
 G  disj2_1_10_1
 G  disj1_1_11_1
 G  disj2_1_11_1
 G  disj1_1_12_1
 G  disj2_1_12_1
 G  disj1_1_13_1
 G  disj2_1_13_1
 G  disj1_1_14_1
 G  disj2_1_14_1
 G  disj1_2_3_1
 G  disj2_2_3_1
 G  disj1_2_4_1
 G  disj2_2_4_1
 G  disj1_2_5_1
 G  disj2_2_5_1
 G  disj1_2_6_1
 G  disj2_2_6_1
 G  disj1_2_7_1
 G  disj2_2_7_1
 G  disj1_2_8_1
 G  disj2_2_8_1
 G  disj1_2_9_1
 G  disj2_2_9_1
 G  disj1_2_10_1
 G  disj2_2_10_1
 G  disj1_2_11_1
 G  disj2_2_11_1
 G  disj1_2_12_1
 G  disj2_2_12_1
 G  disj1_2_13_1
 G  disj2_2_13_1
 G  disj1_2_14_1
 G  disj2_2_14_1
 G  disj1_3_4_1
 G  disj2_3_4_1
 G  disj1_3_5_1
 G  disj2_3_5_1
 G  disj1_3_6_1
 G  disj2_3_6_1
 G  disj1_3_7_1
 G  disj2_3_7_1
 G  disj1_3_8_1
 G  disj2_3_8_1
 G  disj1_3_9_1
 G  disj2_3_9_1
 G  disj1_3_10_1
 G  disj2_3_10_1
 G  disj1_3_11_1
 G  disj2_3_11_1
 G  disj1_3_12_1
 G  disj2_3_12_1
 G  disj1_3_13_1
 G  disj2_3_13_1
 G  disj1_3_14_1
 G  disj2_3_14_1
 G  disj1_4_5_1
 G  disj2_4_5_1
 G  disj1_4_6_1
 G  disj2_4_6_1
 G  disj1_4_7_1
 G  disj2_4_7_1
 G  disj1_4_8_1
 G  disj2_4_8_1
 G  disj1_4_9_1
 G  disj2_4_9_1
 G  disj1_4_10_1
 G  disj2_4_10_1
 G  disj1_4_11_1
 G  disj2_4_11_1
 G  disj1_4_12_1
 G  disj2_4_12_1
 G  disj1_4_13_1
 G  disj2_4_13_1
 G  disj1_4_14_1
 G  disj2_4_14_1
 G  disj1_5_6_1
 G  disj2_5_6_1
 G  disj1_5_7_1
 G  disj2_5_7_1
 G  disj1_5_8_1
 G  disj2_5_8_1
 G  disj1_5_9_1
 G  disj2_5_9_1
 G  disj1_5_10_1
 G  disj2_5_10_1
 G  disj1_5_11_1
 G  disj2_5_11_1
 G  disj1_5_12_1
 G  disj2_5_12_1
 G  disj1_5_13_1
 G  disj2_5_13_1
 G  disj1_5_14_1
 G  disj2_5_14_1
 G  disj1_6_7_1
 G  disj2_6_7_1
 G  disj1_6_8_1
 G  disj2_6_8_1
 G  disj1_6_9_1
 G  disj2_6_9_1
 G  disj1_6_10_1
 G  disj2_6_10_1
 G  disj1_6_11_1
 G  disj2_6_11_1
 G  disj1_6_12_1
 G  disj2_6_12_1
 G  disj1_6_13_1
 G  disj2_6_13_1
 G  disj1_6_14_1
 G  disj2_6_14_1
 G  disj1_7_8_1
 G  disj2_7_8_1
 G  disj1_7_9_1
 G  disj2_7_9_1
 G  disj1_7_10_1
 G  disj2_7_10_1
 G  disj1_7_11_1
 G  disj2_7_11_1
 G  disj1_7_12_1
 G  disj2_7_12_1
 G  disj1_7_13_1
 G  disj2_7_13_1
 G  disj1_7_14_1
 G  disj2_7_14_1
 G  disj1_8_9_1
 G  disj2_8_9_1
 G  disj1_8_10_1
 G  disj2_8_10_1
 G  disj1_8_11_1
 G  disj2_8_11_1
 G  disj1_8_12_1
 G  disj2_8_12_1
 G  disj1_8_13_1
 G  disj2_8_13_1
 G  disj1_8_14_1
 G  disj2_8_14_1
 G  disj1_9_10_1
 G  disj2_9_10_1
 G  disj1_9_11_1
 G  disj2_9_11_1
 G  disj1_9_12_1
 G  disj2_9_12_1
 G  disj1_9_13_1
 G  disj2_9_13_1
 G  disj1_9_14_1
 G  disj2_9_14_1
 G  disj1_10_11_1
 G  disj2_10_11_1
 G  disj1_10_12_1
 G  disj2_10_12_1
 G  disj1_10_13_1
 G  disj2_10_13_1
 G  disj1_10_14_1
 G  disj2_10_14_1
 G  disj1_11_12_1
 G  disj2_11_12_1
 G  disj1_11_13_1
 G  disj2_11_13_1
 G  disj1_11_14_1
 G  disj2_11_14_1
 G  disj1_12_13_1
 G  disj2_12_13_1
 G  disj1_12_14_1
 G  disj2_12_14_1
 G  disj1_13_14_1
 G  disj2_13_14_1
 G  disj1_0_1_2
 G  disj2_0_1_2
 G  disj1_0_2_2
 G  disj2_0_2_2
 G  disj1_0_3_2
 G  disj2_0_3_2
 G  disj1_0_4_2
 G  disj2_0_4_2
 G  disj1_0_5_2
 G  disj2_0_5_2
 G  disj1_0_6_2
 G  disj2_0_6_2
 G  disj1_0_7_2
 G  disj2_0_7_2
 G  disj1_0_8_2
 G  disj2_0_8_2
 G  disj1_0_9_2
 G  disj2_0_9_2
 G  disj1_0_10_2
 G  disj2_0_10_2
 G  disj1_0_11_2
 G  disj2_0_11_2
 G  disj1_0_12_2
 G  disj2_0_12_2
 G  disj1_0_13_2
 G  disj2_0_13_2
 G  disj1_0_14_2
 G  disj2_0_14_2
 G  disj1_1_2_2
 G  disj2_1_2_2
 G  disj1_1_3_2
 G  disj2_1_3_2
 G  disj1_1_4_2
 G  disj2_1_4_2
 G  disj1_1_5_2
 G  disj2_1_5_2
 G  disj1_1_6_2
 G  disj2_1_6_2
 G  disj1_1_7_2
 G  disj2_1_7_2
 G  disj1_1_8_2
 G  disj2_1_8_2
 G  disj1_1_9_2
 G  disj2_1_9_2
 G  disj1_1_10_2
 G  disj2_1_10_2
 G  disj1_1_11_2
 G  disj2_1_11_2
 G  disj1_1_12_2
 G  disj2_1_12_2
 G  disj1_1_13_2
 G  disj2_1_13_2
 G  disj1_1_14_2
 G  disj2_1_14_2
 G  disj1_2_3_2
 G  disj2_2_3_2
 G  disj1_2_4_2
 G  disj2_2_4_2
 G  disj1_2_5_2
 G  disj2_2_5_2
 G  disj1_2_6_2
 G  disj2_2_6_2
 G  disj1_2_7_2
 G  disj2_2_7_2
 G  disj1_2_8_2
 G  disj2_2_8_2
 G  disj1_2_9_2
 G  disj2_2_9_2
 G  disj1_2_10_2
 G  disj2_2_10_2
 G  disj1_2_11_2
 G  disj2_2_11_2
 G  disj1_2_12_2
 G  disj2_2_12_2
 G  disj1_2_13_2
 G  disj2_2_13_2
 G  disj1_2_14_2
 G  disj2_2_14_2
 G  disj1_3_4_2
 G  disj2_3_4_2
 G  disj1_3_5_2
 G  disj2_3_5_2
 G  disj1_3_6_2
 G  disj2_3_6_2
 G  disj1_3_7_2
 G  disj2_3_7_2
 G  disj1_3_8_2
 G  disj2_3_8_2
 G  disj1_3_9_2
 G  disj2_3_9_2
 G  disj1_3_10_2
 G  disj2_3_10_2
 G  disj1_3_11_2
 G  disj2_3_11_2
 G  disj1_3_12_2
 G  disj2_3_12_2
 G  disj1_3_13_2
 G  disj2_3_13_2
 G  disj1_3_14_2
 G  disj2_3_14_2
 G  disj1_4_5_2
 G  disj2_4_5_2
 G  disj1_4_6_2
 G  disj2_4_6_2
 G  disj1_4_7_2
 G  disj2_4_7_2
 G  disj1_4_8_2
 G  disj2_4_8_2
 G  disj1_4_9_2
 G  disj2_4_9_2
 G  disj1_4_10_2
 G  disj2_4_10_2
 G  disj1_4_11_2
 G  disj2_4_11_2
 G  disj1_4_12_2
 G  disj2_4_12_2
 G  disj1_4_13_2
 G  disj2_4_13_2
 G  disj1_4_14_2
 G  disj2_4_14_2
 G  disj1_5_6_2
 G  disj2_5_6_2
 G  disj1_5_7_2
 G  disj2_5_7_2
 G  disj1_5_8_2
 G  disj2_5_8_2
 G  disj1_5_9_2
 G  disj2_5_9_2
 G  disj1_5_10_2
 G  disj2_5_10_2
 G  disj1_5_11_2
 G  disj2_5_11_2
 G  disj1_5_12_2
 G  disj2_5_12_2
 G  disj1_5_13_2
 G  disj2_5_13_2
 G  disj1_5_14_2
 G  disj2_5_14_2
 G  disj1_6_7_2
 G  disj2_6_7_2
 G  disj1_6_8_2
 G  disj2_6_8_2
 G  disj1_6_9_2
 G  disj2_6_9_2
 G  disj1_6_10_2
 G  disj2_6_10_2
 G  disj1_6_11_2
 G  disj2_6_11_2
 G  disj1_6_12_2
 G  disj2_6_12_2
 G  disj1_6_13_2
 G  disj2_6_13_2
 G  disj1_6_14_2
 G  disj2_6_14_2
 G  disj1_7_8_2
 G  disj2_7_8_2
 G  disj1_7_9_2
 G  disj2_7_9_2
 G  disj1_7_10_2
 G  disj2_7_10_2
 G  disj1_7_11_2
 G  disj2_7_11_2
 G  disj1_7_12_2
 G  disj2_7_12_2
 G  disj1_7_13_2
 G  disj2_7_13_2
 G  disj1_7_14_2
 G  disj2_7_14_2
 G  disj1_8_9_2
 G  disj2_8_9_2
 G  disj1_8_10_2
 G  disj2_8_10_2
 G  disj1_8_11_2
 G  disj2_8_11_2
 G  disj1_8_12_2
 G  disj2_8_12_2
 G  disj1_8_13_2
 G  disj2_8_13_2
 G  disj1_8_14_2
 G  disj2_8_14_2
 G  disj1_9_10_2
 G  disj2_9_10_2
 G  disj1_9_11_2
 G  disj2_9_11_2
 G  disj1_9_12_2
 G  disj2_9_12_2
 G  disj1_9_13_2
 G  disj2_9_13_2
 G  disj1_9_14_2
 G  disj2_9_14_2
 G  disj1_10_11_2
 G  disj2_10_11_2
 G  disj1_10_12_2
 G  disj2_10_12_2
 G  disj1_10_13_2
 G  disj2_10_13_2
 G  disj1_10_14_2
 G  disj2_10_14_2
 G  disj1_11_12_2
 G  disj2_11_12_2
 G  disj1_11_13_2
 G  disj2_11_13_2
 G  disj1_11_14_2
 G  disj2_11_14_2
 G  disj1_12_13_2
 G  disj2_12_13_2
 G  disj1_12_14_2
 G  disj2_12_14_2
 G  disj1_13_14_2
 G  disj2_13_14_2
 G  disj1_0_1_3
 G  disj2_0_1_3
 G  disj1_0_2_3
 G  disj2_0_2_3
 G  disj1_0_3_3
 G  disj2_0_3_3
 G  disj1_0_4_3
 G  disj2_0_4_3
 G  disj1_0_5_3
 G  disj2_0_5_3
 G  disj1_0_6_3
 G  disj2_0_6_3
 G  disj1_0_7_3
 G  disj2_0_7_3
 G  disj1_0_8_3
 G  disj2_0_8_3
 G  disj1_0_9_3
 G  disj2_0_9_3
 G  disj1_0_10_3
 G  disj2_0_10_3
 G  disj1_0_11_3
 G  disj2_0_11_3
 G  disj1_0_12_3
 G  disj2_0_12_3
 G  disj1_0_13_3
 G  disj2_0_13_3
 G  disj1_0_14_3
 G  disj2_0_14_3
 G  disj1_1_2_3
 G  disj2_1_2_3
 G  disj1_1_3_3
 G  disj2_1_3_3
 G  disj1_1_4_3
 G  disj2_1_4_3
 G  disj1_1_5_3
 G  disj2_1_5_3
 G  disj1_1_6_3
 G  disj2_1_6_3
 G  disj1_1_7_3
 G  disj2_1_7_3
 G  disj1_1_8_3
 G  disj2_1_8_3
 G  disj1_1_9_3
 G  disj2_1_9_3
 G  disj1_1_10_3
 G  disj2_1_10_3
 G  disj1_1_11_3
 G  disj2_1_11_3
 G  disj1_1_12_3
 G  disj2_1_12_3
 G  disj1_1_13_3
 G  disj2_1_13_3
 G  disj1_1_14_3
 G  disj2_1_14_3
 G  disj1_2_3_3
 G  disj2_2_3_3
 G  disj1_2_4_3
 G  disj2_2_4_3
 G  disj1_2_5_3
 G  disj2_2_5_3
 G  disj1_2_6_3
 G  disj2_2_6_3
 G  disj1_2_7_3
 G  disj2_2_7_3
 G  disj1_2_8_3
 G  disj2_2_8_3
 G  disj1_2_9_3
 G  disj2_2_9_3
 G  disj1_2_10_3
 G  disj2_2_10_3
 G  disj1_2_11_3
 G  disj2_2_11_3
 G  disj1_2_12_3
 G  disj2_2_12_3
 G  disj1_2_13_3
 G  disj2_2_13_3
 G  disj1_2_14_3
 G  disj2_2_14_3
 G  disj1_3_4_3
 G  disj2_3_4_3
 G  disj1_3_5_3
 G  disj2_3_5_3
 G  disj1_3_6_3
 G  disj2_3_6_3
 G  disj1_3_7_3
 G  disj2_3_7_3
 G  disj1_3_8_3
 G  disj2_3_8_3
 G  disj1_3_9_3
 G  disj2_3_9_3
 G  disj1_3_10_3
 G  disj2_3_10_3
 G  disj1_3_11_3
 G  disj2_3_11_3
 G  disj1_3_12_3
 G  disj2_3_12_3
 G  disj1_3_13_3
 G  disj2_3_13_3
 G  disj1_3_14_3
 G  disj2_3_14_3
 G  disj1_4_5_3
 G  disj2_4_5_3
 G  disj1_4_6_3
 G  disj2_4_6_3
 G  disj1_4_7_3
 G  disj2_4_7_3
 G  disj1_4_8_3
 G  disj2_4_8_3
 G  disj1_4_9_3
 G  disj2_4_9_3
 G  disj1_4_10_3
 G  disj2_4_10_3
 G  disj1_4_11_3
 G  disj2_4_11_3
 G  disj1_4_12_3
 G  disj2_4_12_3
 G  disj1_4_13_3
 G  disj2_4_13_3
 G  disj1_4_14_3
 G  disj2_4_14_3
 G  disj1_5_6_3
 G  disj2_5_6_3
 G  disj1_5_7_3
 G  disj2_5_7_3
 G  disj1_5_8_3
 G  disj2_5_8_3
 G  disj1_5_9_3
 G  disj2_5_9_3
 G  disj1_5_10_3
 G  disj2_5_10_3
 G  disj1_5_11_3
 G  disj2_5_11_3
 G  disj1_5_12_3
 G  disj2_5_12_3
 G  disj1_5_13_3
 G  disj2_5_13_3
 G  disj1_5_14_3
 G  disj2_5_14_3
 G  disj1_6_7_3
 G  disj2_6_7_3
 G  disj1_6_8_3
 G  disj2_6_8_3
 G  disj1_6_9_3
 G  disj2_6_9_3
 G  disj1_6_10_3
 G  disj2_6_10_3
 G  disj1_6_11_3
 G  disj2_6_11_3
 G  disj1_6_12_3
 G  disj2_6_12_3
 G  disj1_6_13_3
 G  disj2_6_13_3
 G  disj1_6_14_3
 G  disj2_6_14_3
 G  disj1_7_8_3
 G  disj2_7_8_3
 G  disj1_7_9_3
 G  disj2_7_9_3
 G  disj1_7_10_3
 G  disj2_7_10_3
 G  disj1_7_11_3
 G  disj2_7_11_3
 G  disj1_7_12_3
 G  disj2_7_12_3
 G  disj1_7_13_3
 G  disj2_7_13_3
 G  disj1_7_14_3
 G  disj2_7_14_3
 G  disj1_8_9_3
 G  disj2_8_9_3
 G  disj1_8_10_3
 G  disj2_8_10_3
 G  disj1_8_11_3
 G  disj2_8_11_3
 G  disj1_8_12_3
 G  disj2_8_12_3
 G  disj1_8_13_3
 G  disj2_8_13_3
 G  disj1_8_14_3
 G  disj2_8_14_3
 G  disj1_9_10_3
 G  disj2_9_10_3
 G  disj1_9_11_3
 G  disj2_9_11_3
 G  disj1_9_12_3
 G  disj2_9_12_3
 G  disj1_9_13_3
 G  disj2_9_13_3
 G  disj1_9_14_3
 G  disj2_9_14_3
 G  disj1_10_11_3
 G  disj2_10_11_3
 G  disj1_10_12_3
 G  disj2_10_12_3
 G  disj1_10_13_3
 G  disj2_10_13_3
 G  disj1_10_14_3
 G  disj2_10_14_3
 G  disj1_11_12_3
 G  disj2_11_12_3
 G  disj1_11_13_3
 G  disj2_11_13_3
 G  disj1_11_14_3
 G  disj2_11_14_3
 G  disj1_12_13_3
 G  disj2_12_13_3
 G  disj1_12_14_3
 G  disj2_12_14_3
 G  disj1_13_14_3
 G  disj2_13_14_3
 G  disj1_0_1_4
 G  disj2_0_1_4
 G  disj1_0_2_4
 G  disj2_0_2_4
 G  disj1_0_3_4
 G  disj2_0_3_4
 G  disj1_0_4_4
 G  disj2_0_4_4
 G  disj1_0_5_4
 G  disj2_0_5_4
 G  disj1_0_6_4
 G  disj2_0_6_4
 G  disj1_0_7_4
 G  disj2_0_7_4
 G  disj1_0_8_4
 G  disj2_0_8_4
 G  disj1_0_9_4
 G  disj2_0_9_4
 G  disj1_0_10_4
 G  disj2_0_10_4
 G  disj1_0_11_4
 G  disj2_0_11_4
 G  disj1_0_12_4
 G  disj2_0_12_4
 G  disj1_0_13_4
 G  disj2_0_13_4
 G  disj1_0_14_4
 G  disj2_0_14_4
 G  disj1_1_2_4
 G  disj2_1_2_4
 G  disj1_1_3_4
 G  disj2_1_3_4
 G  disj1_1_4_4
 G  disj2_1_4_4
 G  disj1_1_5_4
 G  disj2_1_5_4
 G  disj1_1_6_4
 G  disj2_1_6_4
 G  disj1_1_7_4
 G  disj2_1_7_4
 G  disj1_1_8_4
 G  disj2_1_8_4
 G  disj1_1_9_4
 G  disj2_1_9_4
 G  disj1_1_10_4
 G  disj2_1_10_4
 G  disj1_1_11_4
 G  disj2_1_11_4
 G  disj1_1_12_4
 G  disj2_1_12_4
 G  disj1_1_13_4
 G  disj2_1_13_4
 G  disj1_1_14_4
 G  disj2_1_14_4
 G  disj1_2_3_4
 G  disj2_2_3_4
 G  disj1_2_4_4
 G  disj2_2_4_4
 G  disj1_2_5_4
 G  disj2_2_5_4
 G  disj1_2_6_4
 G  disj2_2_6_4
 G  disj1_2_7_4
 G  disj2_2_7_4
 G  disj1_2_8_4
 G  disj2_2_8_4
 G  disj1_2_9_4
 G  disj2_2_9_4
 G  disj1_2_10_4
 G  disj2_2_10_4
 G  disj1_2_11_4
 G  disj2_2_11_4
 G  disj1_2_12_4
 G  disj2_2_12_4
 G  disj1_2_13_4
 G  disj2_2_13_4
 G  disj1_2_14_4
 G  disj2_2_14_4
 G  disj1_3_4_4
 G  disj2_3_4_4
 G  disj1_3_5_4
 G  disj2_3_5_4
 G  disj1_3_6_4
 G  disj2_3_6_4
 G  disj1_3_7_4
 G  disj2_3_7_4
 G  disj1_3_8_4
 G  disj2_3_8_4
 G  disj1_3_9_4
 G  disj2_3_9_4
 G  disj1_3_10_4
 G  disj2_3_10_4
 G  disj1_3_11_4
 G  disj2_3_11_4
 G  disj1_3_12_4
 G  disj2_3_12_4
 G  disj1_3_13_4
 G  disj2_3_13_4
 G  disj1_3_14_4
 G  disj2_3_14_4
 G  disj1_4_5_4
 G  disj2_4_5_4
 G  disj1_4_6_4
 G  disj2_4_6_4
 G  disj1_4_7_4
 G  disj2_4_7_4
 G  disj1_4_8_4
 G  disj2_4_8_4
 G  disj1_4_9_4
 G  disj2_4_9_4
 G  disj1_4_10_4
 G  disj2_4_10_4
 G  disj1_4_11_4
 G  disj2_4_11_4
 G  disj1_4_12_4
 G  disj2_4_12_4
 G  disj1_4_13_4
 G  disj2_4_13_4
 G  disj1_4_14_4
 G  disj2_4_14_4
 G  disj1_5_6_4
 G  disj2_5_6_4
 G  disj1_5_7_4
 G  disj2_5_7_4
 G  disj1_5_8_4
 G  disj2_5_8_4
 G  disj1_5_9_4
 G  disj2_5_9_4
 G  disj1_5_10_4
 G  disj2_5_10_4
 G  disj1_5_11_4
 G  disj2_5_11_4
 G  disj1_5_12_4
 G  disj2_5_12_4
 G  disj1_5_13_4
 G  disj2_5_13_4
 G  disj1_5_14_4
 G  disj2_5_14_4
 G  disj1_6_7_4
 G  disj2_6_7_4
 G  disj1_6_8_4
 G  disj2_6_8_4
 G  disj1_6_9_4
 G  disj2_6_9_4
 G  disj1_6_10_4
 G  disj2_6_10_4
 G  disj1_6_11_4
 G  disj2_6_11_4
 G  disj1_6_12_4
 G  disj2_6_12_4
 G  disj1_6_13_4
 G  disj2_6_13_4
 G  disj1_6_14_4
 G  disj2_6_14_4
 G  disj1_7_8_4
 G  disj2_7_8_4
 G  disj1_7_9_4
 G  disj2_7_9_4
 G  disj1_7_10_4
 G  disj2_7_10_4
 G  disj1_7_11_4
 G  disj2_7_11_4
 G  disj1_7_12_4
 G  disj2_7_12_4
 G  disj1_7_13_4
 G  disj2_7_13_4
 G  disj1_7_14_4
 G  disj2_7_14_4
 G  disj1_8_9_4
 G  disj2_8_9_4
 G  disj1_8_10_4
 G  disj2_8_10_4
 G  disj1_8_11_4
 G  disj2_8_11_4
 G  disj1_8_12_4
 G  disj2_8_12_4
 G  disj1_8_13_4
 G  disj2_8_13_4
 G  disj1_8_14_4
 G  disj2_8_14_4
 G  disj1_9_10_4
 G  disj2_9_10_4
 G  disj1_9_11_4
 G  disj2_9_11_4
 G  disj1_9_12_4
 G  disj2_9_12_4
 G  disj1_9_13_4
 G  disj2_9_13_4
 G  disj1_9_14_4
 G  disj2_9_14_4
 G  disj1_10_11_4
 G  disj2_10_11_4
 G  disj1_10_12_4
 G  disj2_10_12_4
 G  disj1_10_13_4
 G  disj2_10_13_4
 G  disj1_10_14_4
 G  disj2_10_14_4
 G  disj1_11_12_4
 G  disj2_11_12_4
 G  disj1_11_13_4
 G  disj2_11_13_4
 G  disj1_11_14_4
 G  disj2_11_14_4
 G  disj1_12_13_4
 G  disj2_12_13_4
 G  disj1_12_14_4
 G  disj2_12_14_4
 G  disj1_13_14_4
 G  disj2_13_14_4
COLUMNS
    C         OBJ       1.0
    C         mksp_0    1.0
    C         mksp_1    1.0
    C         mksp_2    1.0
    C         mksp_3    1.0
    C         mksp_4    1.0
    C         mksp_5    1.0
    C         mksp_6    1.0
    C         mksp_7    1.0
    C         mksp_8    1.0
    C         mksp_9    1.0
    C         mksp_10   1.0
    C         mksp_11   1.0
    C         mksp_12   1.0
    C         mksp_13   1.0
    C         mksp_14   1.0
    x_0_0     prec_0_0  -1.0
    x_0_0     disj1_0_1_1  -1.0
    x_0_0     disj2_0_1_1  1.0
    x_0_0     disj1_0_2_1  -1.0
    x_0_0     disj2_0_2_1  1.0
    x_0_0     disj1_0_3_1  -1.0
    x_0_0     disj2_0_3_1  1.0
    x_0_0     disj1_0_4_1  -1.0
    x_0_0     disj2_0_4_1  1.0
    x_0_0     disj1_0_5_1  -1.0
    x_0_0     disj2_0_5_1  1.0
    x_0_0     disj1_0_6_1  -1.0
    x_0_0     disj2_0_6_1  1.0
    x_0_0     disj1_0_7_1  -1.0
    x_0_0     disj2_0_7_1  1.0
    x_0_0     disj1_0_8_1  -1.0
    x_0_0     disj2_0_8_1  1.0
    x_0_0     disj1_0_9_1  -1.0
    x_0_0     disj2_0_9_1  1.0
    x_0_0     disj1_0_10_1  -1.0
    x_0_0     disj2_0_10_1  1.0
    x_0_0     disj1_0_11_1  -1.0
    x_0_0     disj2_0_11_1  1.0
    x_0_0     disj1_0_12_1  -1.0
    x_0_0     disj2_0_12_1  1.0
    x_0_0     disj1_0_13_1  -1.0
    x_0_0     disj2_0_13_1  1.0
    x_0_0     disj1_0_14_1  -1.0
    x_0_0     disj2_0_14_1  1.0
    x_0_1     prec_0_0  1.0
    x_0_1     prec_0_1  -1.0
    x_0_1     disj1_0_1_0  -1.0
    x_0_1     disj2_0_1_0  1.0
    x_0_1     disj1_0_2_0  -1.0
    x_0_1     disj2_0_2_0  1.0
    x_0_1     disj1_0_3_0  -1.0
    x_0_1     disj2_0_3_0  1.0
    x_0_1     disj1_0_4_0  -1.0
    x_0_1     disj2_0_4_0  1.0
    x_0_1     disj1_0_5_0  -1.0
    x_0_1     disj2_0_5_0  1.0
    x_0_1     disj1_0_6_0  -1.0
    x_0_1     disj2_0_6_0  1.0
    x_0_1     disj1_0_7_0  -1.0
    x_0_1     disj2_0_7_0  1.0
    x_0_1     disj1_0_8_0  -1.0
    x_0_1     disj2_0_8_0  1.0
    x_0_1     disj1_0_9_0  -1.0
    x_0_1     disj2_0_9_0  1.0
    x_0_1     disj1_0_10_0  -1.0
    x_0_1     disj2_0_10_0  1.0
    x_0_1     disj1_0_11_0  -1.0
    x_0_1     disj2_0_11_0  1.0
    x_0_1     disj1_0_12_0  -1.0
    x_0_1     disj2_0_12_0  1.0
    x_0_1     disj1_0_13_0  -1.0
    x_0_1     disj2_0_13_0  1.0
    x_0_1     disj1_0_14_0  -1.0
    x_0_1     disj2_0_14_0  1.0
    x_0_2     prec_0_1  1.0
    x_0_2     prec_0_2  -1.0
    x_0_2     disj1_0_1_3  -1.0
    x_0_2     disj2_0_1_3  1.0
    x_0_2     disj1_0_2_3  -1.0
    x_0_2     disj2_0_2_3  1.0
    x_0_2     disj1_0_3_3  -1.0
    x_0_2     disj2_0_3_3  1.0
    x_0_2     disj1_0_4_3  -1.0
    x_0_2     disj2_0_4_3  1.0
    x_0_2     disj1_0_5_3  -1.0
    x_0_2     disj2_0_5_3  1.0
    x_0_2     disj1_0_6_3  -1.0
    x_0_2     disj2_0_6_3  1.0
    x_0_2     disj1_0_7_3  -1.0
    x_0_2     disj2_0_7_3  1.0
    x_0_2     disj1_0_8_3  -1.0
    x_0_2     disj2_0_8_3  1.0
    x_0_2     disj1_0_9_3  -1.0
    x_0_2     disj2_0_9_3  1.0
    x_0_2     disj1_0_10_3  -1.0
    x_0_2     disj2_0_10_3  1.0
    x_0_2     disj1_0_11_3  -1.0
    x_0_2     disj2_0_11_3  1.0
    x_0_2     disj1_0_12_3  -1.0
    x_0_2     disj2_0_12_3  1.0
    x_0_2     disj1_0_13_3  -1.0
    x_0_2     disj2_0_13_3  1.0
    x_0_2     disj1_0_14_3  -1.0
    x_0_2     disj2_0_14_3  1.0
    x_0_3     prec_0_2  1.0
    x_0_3     prec_0_3  -1.0
    x_0_3     disj1_0_1_2  -1.0
    x_0_3     disj2_0_1_2  1.0
    x_0_3     disj1_0_2_2  -1.0
    x_0_3     disj2_0_2_2  1.0
    x_0_3     disj1_0_3_2  -1.0
    x_0_3     disj2_0_3_2  1.0
    x_0_3     disj1_0_4_2  -1.0
    x_0_3     disj2_0_4_2  1.0
    x_0_3     disj1_0_5_2  -1.0
    x_0_3     disj2_0_5_2  1.0
    x_0_3     disj1_0_6_2  -1.0
    x_0_3     disj2_0_6_2  1.0
    x_0_3     disj1_0_7_2  -1.0
    x_0_3     disj2_0_7_2  1.0
    x_0_3     disj1_0_8_2  -1.0
    x_0_3     disj2_0_8_2  1.0
    x_0_3     disj1_0_9_2  -1.0
    x_0_3     disj2_0_9_2  1.0
    x_0_3     disj1_0_10_2  -1.0
    x_0_3     disj2_0_10_2  1.0
    x_0_3     disj1_0_11_2  -1.0
    x_0_3     disj2_0_11_2  1.0
    x_0_3     disj1_0_12_2  -1.0
    x_0_3     disj2_0_12_2  1.0
    x_0_3     disj1_0_13_2  -1.0
    x_0_3     disj2_0_13_2  1.0
    x_0_3     disj1_0_14_2  -1.0
    x_0_3     disj2_0_14_2  1.0
    x_0_4     prec_0_3  1.0
    x_0_4     mksp_0    -1.0
    x_0_4     disj1_0_1_4  -1.0
    x_0_4     disj2_0_1_4  1.0
    x_0_4     disj1_0_2_4  -1.0
    x_0_4     disj2_0_2_4  1.0
    x_0_4     disj1_0_3_4  -1.0
    x_0_4     disj2_0_3_4  1.0
    x_0_4     disj1_0_4_4  -1.0
    x_0_4     disj2_0_4_4  1.0
    x_0_4     disj1_0_5_4  -1.0
    x_0_4     disj2_0_5_4  1.0
    x_0_4     disj1_0_6_4  -1.0
    x_0_4     disj2_0_6_4  1.0
    x_0_4     disj1_0_7_4  -1.0
    x_0_4     disj2_0_7_4  1.0
    x_0_4     disj1_0_8_4  -1.0
    x_0_4     disj2_0_8_4  1.0
    x_0_4     disj1_0_9_4  -1.0
    x_0_4     disj2_0_9_4  1.0
    x_0_4     disj1_0_10_4  -1.0
    x_0_4     disj2_0_10_4  1.0
    x_0_4     disj1_0_11_4  -1.0
    x_0_4     disj2_0_11_4  1.0
    x_0_4     disj1_0_12_4  -1.0
    x_0_4     disj2_0_12_4  1.0
    x_0_4     disj1_0_13_4  -1.0
    x_0_4     disj2_0_13_4  1.0
    x_0_4     disj1_0_14_4  -1.0
    x_0_4     disj2_0_14_4  1.0
    x_1_0     prec_1_0  -1.0
    x_1_0     disj1_0_1_0  1.0
    x_1_0     disj2_0_1_0  -1.0
    x_1_0     disj1_1_2_0  -1.0
    x_1_0     disj2_1_2_0  1.0
    x_1_0     disj1_1_3_0  -1.0
    x_1_0     disj2_1_3_0  1.0
    x_1_0     disj1_1_4_0  -1.0
    x_1_0     disj2_1_4_0  1.0
    x_1_0     disj1_1_5_0  -1.0
    x_1_0     disj2_1_5_0  1.0
    x_1_0     disj1_1_6_0  -1.0
    x_1_0     disj2_1_6_0  1.0
    x_1_0     disj1_1_7_0  -1.0
    x_1_0     disj2_1_7_0  1.0
    x_1_0     disj1_1_8_0  -1.0
    x_1_0     disj2_1_8_0  1.0
    x_1_0     disj1_1_9_0  -1.0
    x_1_0     disj2_1_9_0  1.0
    x_1_0     disj1_1_10_0  -1.0
    x_1_0     disj2_1_10_0  1.0
    x_1_0     disj1_1_11_0  -1.0
    x_1_0     disj2_1_11_0  1.0
    x_1_0     disj1_1_12_0  -1.0
    x_1_0     disj2_1_12_0  1.0
    x_1_0     disj1_1_13_0  -1.0
    x_1_0     disj2_1_13_0  1.0
    x_1_0     disj1_1_14_0  -1.0
    x_1_0     disj2_1_14_0  1.0
    x_1_1     prec_1_0  1.0
    x_1_1     prec_1_1  -1.0
    x_1_1     disj1_0_1_1  1.0
    x_1_1     disj2_0_1_1  -1.0
    x_1_1     disj1_1_2_1  -1.0
    x_1_1     disj2_1_2_1  1.0
    x_1_1     disj1_1_3_1  -1.0
    x_1_1     disj2_1_3_1  1.0
    x_1_1     disj1_1_4_1  -1.0
    x_1_1     disj2_1_4_1  1.0
    x_1_1     disj1_1_5_1  -1.0
    x_1_1     disj2_1_5_1  1.0
    x_1_1     disj1_1_6_1  -1.0
    x_1_1     disj2_1_6_1  1.0
    x_1_1     disj1_1_7_1  -1.0
    x_1_1     disj2_1_7_1  1.0
    x_1_1     disj1_1_8_1  -1.0
    x_1_1     disj2_1_8_1  1.0
    x_1_1     disj1_1_9_1  -1.0
    x_1_1     disj2_1_9_1  1.0
    x_1_1     disj1_1_10_1  -1.0
    x_1_1     disj2_1_10_1  1.0
    x_1_1     disj1_1_11_1  -1.0
    x_1_1     disj2_1_11_1  1.0
    x_1_1     disj1_1_12_1  -1.0
    x_1_1     disj2_1_12_1  1.0
    x_1_1     disj1_1_13_1  -1.0
    x_1_1     disj2_1_13_1  1.0
    x_1_1     disj1_1_14_1  -1.0
    x_1_1     disj2_1_14_1  1.0
    x_1_2     prec_1_1  1.0
    x_1_2     prec_1_2  -1.0
    x_1_2     disj1_0_1_4  1.0
    x_1_2     disj2_0_1_4  -1.0
    x_1_2     disj1_1_2_4  -1.0
    x_1_2     disj2_1_2_4  1.0
    x_1_2     disj1_1_3_4  -1.0
    x_1_2     disj2_1_3_4  1.0
    x_1_2     disj1_1_4_4  -1.0
    x_1_2     disj2_1_4_4  1.0
    x_1_2     disj1_1_5_4  -1.0
    x_1_2     disj2_1_5_4  1.0
    x_1_2     disj1_1_6_4  -1.0
    x_1_2     disj2_1_6_4  1.0
    x_1_2     disj1_1_7_4  -1.0
    x_1_2     disj2_1_7_4  1.0
    x_1_2     disj1_1_8_4  -1.0
    x_1_2     disj2_1_8_4  1.0
    x_1_2     disj1_1_9_4  -1.0
    x_1_2     disj2_1_9_4  1.0
    x_1_2     disj1_1_10_4  -1.0
    x_1_2     disj2_1_10_4  1.0
    x_1_2     disj1_1_11_4  -1.0
    x_1_2     disj2_1_11_4  1.0
    x_1_2     disj1_1_12_4  -1.0
    x_1_2     disj2_1_12_4  1.0
    x_1_2     disj1_1_13_4  -1.0
    x_1_2     disj2_1_13_4  1.0
    x_1_2     disj1_1_14_4  -1.0
    x_1_2     disj2_1_14_4  1.0
    x_1_3     prec_1_2  1.0
    x_1_3     prec_1_3  -1.0
    x_1_3     disj1_0_1_3  1.0
    x_1_3     disj2_0_1_3  -1.0
    x_1_3     disj1_1_2_3  -1.0
    x_1_3     disj2_1_2_3  1.0
    x_1_3     disj1_1_3_3  -1.0
    x_1_3     disj2_1_3_3  1.0
    x_1_3     disj1_1_4_3  -1.0
    x_1_3     disj2_1_4_3  1.0
    x_1_3     disj1_1_5_3  -1.0
    x_1_3     disj2_1_5_3  1.0
    x_1_3     disj1_1_6_3  -1.0
    x_1_3     disj2_1_6_3  1.0
    x_1_3     disj1_1_7_3  -1.0
    x_1_3     disj2_1_7_3  1.0
    x_1_3     disj1_1_8_3  -1.0
    x_1_3     disj2_1_8_3  1.0
    x_1_3     disj1_1_9_3  -1.0
    x_1_3     disj2_1_9_3  1.0
    x_1_3     disj1_1_10_3  -1.0
    x_1_3     disj2_1_10_3  1.0
    x_1_3     disj1_1_11_3  -1.0
    x_1_3     disj2_1_11_3  1.0
    x_1_3     disj1_1_12_3  -1.0
    x_1_3     disj2_1_12_3  1.0
    x_1_3     disj1_1_13_3  -1.0
    x_1_3     disj2_1_13_3  1.0
    x_1_3     disj1_1_14_3  -1.0
    x_1_3     disj2_1_14_3  1.0
    x_1_4     prec_1_3  1.0
    x_1_4     mksp_1    -1.0
    x_1_4     disj1_0_1_2  1.0
    x_1_4     disj2_0_1_2  -1.0
    x_1_4     disj1_1_2_2  -1.0
    x_1_4     disj2_1_2_2  1.0
    x_1_4     disj1_1_3_2  -1.0
    x_1_4     disj2_1_3_2  1.0
    x_1_4     disj1_1_4_2  -1.0
    x_1_4     disj2_1_4_2  1.0
    x_1_4     disj1_1_5_2  -1.0
    x_1_4     disj2_1_5_2  1.0
    x_1_4     disj1_1_6_2  -1.0
    x_1_4     disj2_1_6_2  1.0
    x_1_4     disj1_1_7_2  -1.0
    x_1_4     disj2_1_7_2  1.0
    x_1_4     disj1_1_8_2  -1.0
    x_1_4     disj2_1_8_2  1.0
    x_1_4     disj1_1_9_2  -1.0
    x_1_4     disj2_1_9_2  1.0
    x_1_4     disj1_1_10_2  -1.0
    x_1_4     disj2_1_10_2  1.0
    x_1_4     disj1_1_11_2  -1.0
    x_1_4     disj2_1_11_2  1.0
    x_1_4     disj1_1_12_2  -1.0
    x_1_4     disj2_1_12_2  1.0
    x_1_4     disj1_1_13_2  -1.0
    x_1_4     disj2_1_13_2  1.0
    x_1_4     disj1_1_14_2  -1.0
    x_1_4     disj2_1_14_2  1.0
    x_2_0     prec_2_0  -1.0
    x_2_0     disj1_0_2_3  1.0
    x_2_0     disj2_0_2_3  -1.0
    x_2_0     disj1_1_2_3  1.0
    x_2_0     disj2_1_2_3  -1.0
    x_2_0     disj1_2_3_3  -1.0
    x_2_0     disj2_2_3_3  1.0
    x_2_0     disj1_2_4_3  -1.0
    x_2_0     disj2_2_4_3  1.0
    x_2_0     disj1_2_5_3  -1.0
    x_2_0     disj2_2_5_3  1.0
    x_2_0     disj1_2_6_3  -1.0
    x_2_0     disj2_2_6_3  1.0
    x_2_0     disj1_2_7_3  -1.0
    x_2_0     disj2_2_7_3  1.0
    x_2_0     disj1_2_8_3  -1.0
    x_2_0     disj2_2_8_3  1.0
    x_2_0     disj1_2_9_3  -1.0
    x_2_0     disj2_2_9_3  1.0
    x_2_0     disj1_2_10_3  -1.0
    x_2_0     disj2_2_10_3  1.0
    x_2_0     disj1_2_11_3  -1.0
    x_2_0     disj2_2_11_3  1.0
    x_2_0     disj1_2_12_3  -1.0
    x_2_0     disj2_2_12_3  1.0
    x_2_0     disj1_2_13_3  -1.0
    x_2_0     disj2_2_13_3  1.0
    x_2_0     disj1_2_14_3  -1.0
    x_2_0     disj2_2_14_3  1.0
    x_2_1     prec_2_0  1.0
    x_2_1     prec_2_1  -1.0
    x_2_1     disj1_0_2_2  1.0
    x_2_1     disj2_0_2_2  -1.0
    x_2_1     disj1_1_2_2  1.0
    x_2_1     disj2_1_2_2  -1.0
    x_2_1     disj1_2_3_2  -1.0
    x_2_1     disj2_2_3_2  1.0
    x_2_1     disj1_2_4_2  -1.0
    x_2_1     disj2_2_4_2  1.0
    x_2_1     disj1_2_5_2  -1.0
    x_2_1     disj2_2_5_2  1.0
    x_2_1     disj1_2_6_2  -1.0
    x_2_1     disj2_2_6_2  1.0
    x_2_1     disj1_2_7_2  -1.0
    x_2_1     disj2_2_7_2  1.0
    x_2_1     disj1_2_8_2  -1.0
    x_2_1     disj2_2_8_2  1.0
    x_2_1     disj1_2_9_2  -1.0
    x_2_1     disj2_2_9_2  1.0
    x_2_1     disj1_2_10_2  -1.0
    x_2_1     disj2_2_10_2  1.0
    x_2_1     disj1_2_11_2  -1.0
    x_2_1     disj2_2_11_2  1.0
    x_2_1     disj1_2_12_2  -1.0
    x_2_1     disj2_2_12_2  1.0
    x_2_1     disj1_2_13_2  -1.0
    x_2_1     disj2_2_13_2  1.0
    x_2_1     disj1_2_14_2  -1.0
    x_2_1     disj2_2_14_2  1.0
    x_2_2     prec_2_1  1.0
    x_2_2     prec_2_2  -1.0
    x_2_2     disj1_0_2_0  1.0
    x_2_2     disj2_0_2_0  -1.0
    x_2_2     disj1_1_2_0  1.0
    x_2_2     disj2_1_2_0  -1.0
    x_2_2     disj1_2_3_0  -1.0
    x_2_2     disj2_2_3_0  1.0
    x_2_2     disj1_2_4_0  -1.0
    x_2_2     disj2_2_4_0  1.0
    x_2_2     disj1_2_5_0  -1.0
    x_2_2     disj2_2_5_0  1.0
    x_2_2     disj1_2_6_0  -1.0
    x_2_2     disj2_2_6_0  1.0
    x_2_2     disj1_2_7_0  -1.0
    x_2_2     disj2_2_7_0  1.0
    x_2_2     disj1_2_8_0  -1.0
    x_2_2     disj2_2_8_0  1.0
    x_2_2     disj1_2_9_0  -1.0
    x_2_2     disj2_2_9_0  1.0
    x_2_2     disj1_2_10_0  -1.0
    x_2_2     disj2_2_10_0  1.0
    x_2_2     disj1_2_11_0  -1.0
    x_2_2     disj2_2_11_0  1.0
    x_2_2     disj1_2_12_0  -1.0
    x_2_2     disj2_2_12_0  1.0
    x_2_2     disj1_2_13_0  -1.0
    x_2_2     disj2_2_13_0  1.0
    x_2_2     disj1_2_14_0  -1.0
    x_2_2     disj2_2_14_0  1.0
    x_2_3     prec_2_2  1.0
    x_2_3     prec_2_3  -1.0
    x_2_3     disj1_0_2_1  1.0
    x_2_3     disj2_0_2_1  -1.0
    x_2_3     disj1_1_2_1  1.0
    x_2_3     disj2_1_2_1  -1.0
    x_2_3     disj1_2_3_1  -1.0
    x_2_3     disj2_2_3_1  1.0
    x_2_3     disj1_2_4_1  -1.0
    x_2_3     disj2_2_4_1  1.0
    x_2_3     disj1_2_5_1  -1.0
    x_2_3     disj2_2_5_1  1.0
    x_2_3     disj1_2_6_1  -1.0
    x_2_3     disj2_2_6_1  1.0
    x_2_3     disj1_2_7_1  -1.0
    x_2_3     disj2_2_7_1  1.0
    x_2_3     disj1_2_8_1  -1.0
    x_2_3     disj2_2_8_1  1.0
    x_2_3     disj1_2_9_1  -1.0
    x_2_3     disj2_2_9_1  1.0
    x_2_3     disj1_2_10_1  -1.0
    x_2_3     disj2_2_10_1  1.0
    x_2_3     disj1_2_11_1  -1.0
    x_2_3     disj2_2_11_1  1.0
    x_2_3     disj1_2_12_1  -1.0
    x_2_3     disj2_2_12_1  1.0
    x_2_3     disj1_2_13_1  -1.0
    x_2_3     disj2_2_13_1  1.0
    x_2_3     disj1_2_14_1  -1.0
    x_2_3     disj2_2_14_1  1.0
    x_2_4     prec_2_3  1.0
    x_2_4     mksp_2    -1.0
    x_2_4     disj1_0_2_4  1.0
    x_2_4     disj2_0_2_4  -1.0
    x_2_4     disj1_1_2_4  1.0
    x_2_4     disj2_1_2_4  -1.0
    x_2_4     disj1_2_3_4  -1.0
    x_2_4     disj2_2_3_4  1.0
    x_2_4     disj1_2_4_4  -1.0
    x_2_4     disj2_2_4_4  1.0
    x_2_4     disj1_2_5_4  -1.0
    x_2_4     disj2_2_5_4  1.0
    x_2_4     disj1_2_6_4  -1.0
    x_2_4     disj2_2_6_4  1.0
    x_2_4     disj1_2_7_4  -1.0
    x_2_4     disj2_2_7_4  1.0
    x_2_4     disj1_2_8_4  -1.0
    x_2_4     disj2_2_8_4  1.0
    x_2_4     disj1_2_9_4  -1.0
    x_2_4     disj2_2_9_4  1.0
    x_2_4     disj1_2_10_4  -1.0
    x_2_4     disj2_2_10_4  1.0
    x_2_4     disj1_2_11_4  -1.0
    x_2_4     disj2_2_11_4  1.0
    x_2_4     disj1_2_12_4  -1.0
    x_2_4     disj2_2_12_4  1.0
    x_2_4     disj1_2_13_4  -1.0
    x_2_4     disj2_2_13_4  1.0
    x_2_4     disj1_2_14_4  -1.0
    x_2_4     disj2_2_14_4  1.0
    x_3_0     prec_3_0  -1.0
    x_3_0     disj1_0_3_1  1.0
    x_3_0     disj2_0_3_1  -1.0
    x_3_0     disj1_1_3_1  1.0
    x_3_0     disj2_1_3_1  -1.0
    x_3_0     disj1_2_3_1  1.0
    x_3_0     disj2_2_3_1  -1.0
    x_3_0     disj1_3_4_1  -1.0
    x_3_0     disj2_3_4_1  1.0
    x_3_0     disj1_3_5_1  -1.0
    x_3_0     disj2_3_5_1  1.0
    x_3_0     disj1_3_6_1  -1.0
    x_3_0     disj2_3_6_1  1.0
    x_3_0     disj1_3_7_1  -1.0
    x_3_0     disj2_3_7_1  1.0
    x_3_0     disj1_3_8_1  -1.0
    x_3_0     disj2_3_8_1  1.0
    x_3_0     disj1_3_9_1  -1.0
    x_3_0     disj2_3_9_1  1.0
    x_3_0     disj1_3_10_1  -1.0
    x_3_0     disj2_3_10_1  1.0
    x_3_0     disj1_3_11_1  -1.0
    x_3_0     disj2_3_11_1  1.0
    x_3_0     disj1_3_12_1  -1.0
    x_3_0     disj2_3_12_1  1.0
    x_3_0     disj1_3_13_1  -1.0
    x_3_0     disj2_3_13_1  1.0
    x_3_0     disj1_3_14_1  -1.0
    x_3_0     disj2_3_14_1  1.0
    x_3_1     prec_3_0  1.0
    x_3_1     prec_3_1  -1.0
    x_3_1     disj1_0_3_3  1.0
    x_3_1     disj2_0_3_3  -1.0
    x_3_1     disj1_1_3_3  1.0
    x_3_1     disj2_1_3_3  -1.0
    x_3_1     disj1_2_3_3  1.0
    x_3_1     disj2_2_3_3  -1.0
    x_3_1     disj1_3_4_3  -1.0
    x_3_1     disj2_3_4_3  1.0
    x_3_1     disj1_3_5_3  -1.0
    x_3_1     disj2_3_5_3  1.0
    x_3_1     disj1_3_6_3  -1.0
    x_3_1     disj2_3_6_3  1.0
    x_3_1     disj1_3_7_3  -1.0
    x_3_1     disj2_3_7_3  1.0
    x_3_1     disj1_3_8_3  -1.0
    x_3_1     disj2_3_8_3  1.0
    x_3_1     disj1_3_9_3  -1.0
    x_3_1     disj2_3_9_3  1.0
    x_3_1     disj1_3_10_3  -1.0
    x_3_1     disj2_3_10_3  1.0
    x_3_1     disj1_3_11_3  -1.0
    x_3_1     disj2_3_11_3  1.0
    x_3_1     disj1_3_12_3  -1.0
    x_3_1     disj2_3_12_3  1.0
    x_3_1     disj1_3_13_3  -1.0
    x_3_1     disj2_3_13_3  1.0
    x_3_1     disj1_3_14_3  -1.0
    x_3_1     disj2_3_14_3  1.0
    x_3_2     prec_3_1  1.0
    x_3_2     prec_3_2  -1.0
    x_3_2     disj1_0_3_0  1.0
    x_3_2     disj2_0_3_0  -1.0
    x_3_2     disj1_1_3_0  1.0
    x_3_2     disj2_1_3_0  -1.0
    x_3_2     disj1_2_3_0  1.0
    x_3_2     disj2_2_3_0  -1.0
    x_3_2     disj1_3_4_0  -1.0
    x_3_2     disj2_3_4_0  1.0
    x_3_2     disj1_3_5_0  -1.0
    x_3_2     disj2_3_5_0  1.0
    x_3_2     disj1_3_6_0  -1.0
    x_3_2     disj2_3_6_0  1.0
    x_3_2     disj1_3_7_0  -1.0
    x_3_2     disj2_3_7_0  1.0
    x_3_2     disj1_3_8_0  -1.0
    x_3_2     disj2_3_8_0  1.0
    x_3_2     disj1_3_9_0  -1.0
    x_3_2     disj2_3_9_0  1.0
    x_3_2     disj1_3_10_0  -1.0
    x_3_2     disj2_3_10_0  1.0
    x_3_2     disj1_3_11_0  -1.0
    x_3_2     disj2_3_11_0  1.0
    x_3_2     disj1_3_12_0  -1.0
    x_3_2     disj2_3_12_0  1.0
    x_3_2     disj1_3_13_0  -1.0
    x_3_2     disj2_3_13_0  1.0
    x_3_2     disj1_3_14_0  -1.0
    x_3_2     disj2_3_14_0  1.0
    x_3_3     prec_3_2  1.0
    x_3_3     prec_3_3  -1.0
    x_3_3     disj1_0_3_4  1.0
    x_3_3     disj2_0_3_4  -1.0
    x_3_3     disj1_1_3_4  1.0
    x_3_3     disj2_1_3_4  -1.0
    x_3_3     disj1_2_3_4  1.0
    x_3_3     disj2_2_3_4  -1.0
    x_3_3     disj1_3_4_4  -1.0
    x_3_3     disj2_3_4_4  1.0
    x_3_3     disj1_3_5_4  -1.0
    x_3_3     disj2_3_5_4  1.0
    x_3_3     disj1_3_6_4  -1.0
    x_3_3     disj2_3_6_4  1.0
    x_3_3     disj1_3_7_4  -1.0
    x_3_3     disj2_3_7_4  1.0
    x_3_3     disj1_3_8_4  -1.0
    x_3_3     disj2_3_8_4  1.0
    x_3_3     disj1_3_9_4  -1.0
    x_3_3     disj2_3_9_4  1.0
    x_3_3     disj1_3_10_4  -1.0
    x_3_3     disj2_3_10_4  1.0
    x_3_3     disj1_3_11_4  -1.0
    x_3_3     disj2_3_11_4  1.0
    x_3_3     disj1_3_12_4  -1.0
    x_3_3     disj2_3_12_4  1.0
    x_3_3     disj1_3_13_4  -1.0
    x_3_3     disj2_3_13_4  1.0
    x_3_3     disj1_3_14_4  -1.0
    x_3_3     disj2_3_14_4  1.0
    x_3_4     prec_3_3  1.0
    x_3_4     mksp_3    -1.0
    x_3_4     disj1_0_3_2  1.0
    x_3_4     disj2_0_3_2  -1.0
    x_3_4     disj1_1_3_2  1.0
    x_3_4     disj2_1_3_2  -1.0
    x_3_4     disj1_2_3_2  1.0
    x_3_4     disj2_2_3_2  -1.0
    x_3_4     disj1_3_4_2  -1.0
    x_3_4     disj2_3_4_2  1.0
    x_3_4     disj1_3_5_2  -1.0
    x_3_4     disj2_3_5_2  1.0
    x_3_4     disj1_3_6_2  -1.0
    x_3_4     disj2_3_6_2  1.0
    x_3_4     disj1_3_7_2  -1.0
    x_3_4     disj2_3_7_2  1.0
    x_3_4     disj1_3_8_2  -1.0
    x_3_4     disj2_3_8_2  1.0
    x_3_4     disj1_3_9_2  -1.0
    x_3_4     disj2_3_9_2  1.0
    x_3_4     disj1_3_10_2  -1.0
    x_3_4     disj2_3_10_2  1.0
    x_3_4     disj1_3_11_2  -1.0
    x_3_4     disj2_3_11_2  1.0
    x_3_4     disj1_3_12_2  -1.0
    x_3_4     disj2_3_12_2  1.0
    x_3_4     disj1_3_13_2  -1.0
    x_3_4     disj2_3_13_2  1.0
    x_3_4     disj1_3_14_2  -1.0
    x_3_4     disj2_3_14_2  1.0
    x_4_0     prec_4_0  -1.0
    x_4_0     disj1_0_4_3  1.0
    x_4_0     disj2_0_4_3  -1.0
    x_4_0     disj1_1_4_3  1.0
    x_4_0     disj2_1_4_3  -1.0
    x_4_0     disj1_2_4_3  1.0
    x_4_0     disj2_2_4_3  -1.0
    x_4_0     disj1_3_4_3  1.0
    x_4_0     disj2_3_4_3  -1.0
    x_4_0     disj1_4_5_3  -1.0
    x_4_0     disj2_4_5_3  1.0
    x_4_0     disj1_4_6_3  -1.0
    x_4_0     disj2_4_6_3  1.0
    x_4_0     disj1_4_7_3  -1.0
    x_4_0     disj2_4_7_3  1.0
    x_4_0     disj1_4_8_3  -1.0
    x_4_0     disj2_4_8_3  1.0
    x_4_0     disj1_4_9_3  -1.0
    x_4_0     disj2_4_9_3  1.0
    x_4_0     disj1_4_10_3  -1.0
    x_4_0     disj2_4_10_3  1.0
    x_4_0     disj1_4_11_3  -1.0
    x_4_0     disj2_4_11_3  1.0
    x_4_0     disj1_4_12_3  -1.0
    x_4_0     disj2_4_12_3  1.0
    x_4_0     disj1_4_13_3  -1.0
    x_4_0     disj2_4_13_3  1.0
    x_4_0     disj1_4_14_3  -1.0
    x_4_0     disj2_4_14_3  1.0
    x_4_1     prec_4_0  1.0
    x_4_1     prec_4_1  -1.0
    x_4_1     disj1_0_4_1  1.0
    x_4_1     disj2_0_4_1  -1.0
    x_4_1     disj1_1_4_1  1.0
    x_4_1     disj2_1_4_1  -1.0
    x_4_1     disj1_2_4_1  1.0
    x_4_1     disj2_2_4_1  -1.0
    x_4_1     disj1_3_4_1  1.0
    x_4_1     disj2_3_4_1  -1.0
    x_4_1     disj1_4_5_1  -1.0
    x_4_1     disj2_4_5_1  1.0
    x_4_1     disj1_4_6_1  -1.0
    x_4_1     disj2_4_6_1  1.0
    x_4_1     disj1_4_7_1  -1.0
    x_4_1     disj2_4_7_1  1.0
    x_4_1     disj1_4_8_1  -1.0
    x_4_1     disj2_4_8_1  1.0
    x_4_1     disj1_4_9_1  -1.0
    x_4_1     disj2_4_9_1  1.0
    x_4_1     disj1_4_10_1  -1.0
    x_4_1     disj2_4_10_1  1.0
    x_4_1     disj1_4_11_1  -1.0
    x_4_1     disj2_4_11_1  1.0
    x_4_1     disj1_4_12_1  -1.0
    x_4_1     disj2_4_12_1  1.0
    x_4_1     disj1_4_13_1  -1.0
    x_4_1     disj2_4_13_1  1.0
    x_4_1     disj1_4_14_1  -1.0
    x_4_1     disj2_4_14_1  1.0
    x_4_2     prec_4_1  1.0
    x_4_2     prec_4_2  -1.0
    x_4_2     disj1_0_4_4  1.0
    x_4_2     disj2_0_4_4  -1.0
    x_4_2     disj1_1_4_4  1.0
    x_4_2     disj2_1_4_4  -1.0
    x_4_2     disj1_2_4_4  1.0
    x_4_2     disj2_2_4_4  -1.0
    x_4_2     disj1_3_4_4  1.0
    x_4_2     disj2_3_4_4  -1.0
    x_4_2     disj1_4_5_4  -1.0
    x_4_2     disj2_4_5_4  1.0
    x_4_2     disj1_4_6_4  -1.0
    x_4_2     disj2_4_6_4  1.0
    x_4_2     disj1_4_7_4  -1.0
    x_4_2     disj2_4_7_4  1.0
    x_4_2     disj1_4_8_4  -1.0
    x_4_2     disj2_4_8_4  1.0
    x_4_2     disj1_4_9_4  -1.0
    x_4_2     disj2_4_9_4  1.0
    x_4_2     disj1_4_10_4  -1.0
    x_4_2     disj2_4_10_4  1.0
    x_4_2     disj1_4_11_4  -1.0
    x_4_2     disj2_4_11_4  1.0
    x_4_2     disj1_4_12_4  -1.0
    x_4_2     disj2_4_12_4  1.0
    x_4_2     disj1_4_13_4  -1.0
    x_4_2     disj2_4_13_4  1.0
    x_4_2     disj1_4_14_4  -1.0
    x_4_2     disj2_4_14_4  1.0
    x_4_3     prec_4_2  1.0
    x_4_3     prec_4_3  -1.0
    x_4_3     disj1_0_4_0  1.0
    x_4_3     disj2_0_4_0  -1.0
    x_4_3     disj1_1_4_0  1.0
    x_4_3     disj2_1_4_0  -1.0
    x_4_3     disj1_2_4_0  1.0
    x_4_3     disj2_2_4_0  -1.0
    x_4_3     disj1_3_4_0  1.0
    x_4_3     disj2_3_4_0  -1.0
    x_4_3     disj1_4_5_0  -1.0
    x_4_3     disj2_4_5_0  1.0
    x_4_3     disj1_4_6_0  -1.0
    x_4_3     disj2_4_6_0  1.0
    x_4_3     disj1_4_7_0  -1.0
    x_4_3     disj2_4_7_0  1.0
    x_4_3     disj1_4_8_0  -1.0
    x_4_3     disj2_4_8_0  1.0
    x_4_3     disj1_4_9_0  -1.0
    x_4_3     disj2_4_9_0  1.0
    x_4_3     disj1_4_10_0  -1.0
    x_4_3     disj2_4_10_0  1.0
    x_4_3     disj1_4_11_0  -1.0
    x_4_3     disj2_4_11_0  1.0
    x_4_3     disj1_4_12_0  -1.0
    x_4_3     disj2_4_12_0  1.0
    x_4_3     disj1_4_13_0  -1.0
    x_4_3     disj2_4_13_0  1.0
    x_4_3     disj1_4_14_0  -1.0
    x_4_3     disj2_4_14_0  1.0
    x_4_4     prec_4_3  1.0
    x_4_4     mksp_4    -1.0
    x_4_4     disj1_0_4_2  1.0
    x_4_4     disj2_0_4_2  -1.0
    x_4_4     disj1_1_4_2  1.0
    x_4_4     disj2_1_4_2  -1.0
    x_4_4     disj1_2_4_2  1.0
    x_4_4     disj2_2_4_2  -1.0
    x_4_4     disj1_3_4_2  1.0
    x_4_4     disj2_3_4_2  -1.0
    x_4_4     disj1_4_5_2  -1.0
    x_4_4     disj2_4_5_2  1.0
    x_4_4     disj1_4_6_2  -1.0
    x_4_4     disj2_4_6_2  1.0
    x_4_4     disj1_4_7_2  -1.0
    x_4_4     disj2_4_7_2  1.0
    x_4_4     disj1_4_8_2  -1.0
    x_4_4     disj2_4_8_2  1.0
    x_4_4     disj1_4_9_2  -1.0
    x_4_4     disj2_4_9_2  1.0
    x_4_4     disj1_4_10_2  -1.0
    x_4_4     disj2_4_10_2  1.0
    x_4_4     disj1_4_11_2  -1.0
    x_4_4     disj2_4_11_2  1.0
    x_4_4     disj1_4_12_2  -1.0
    x_4_4     disj2_4_12_2  1.0
    x_4_4     disj1_4_13_2  -1.0
    x_4_4     disj2_4_13_2  1.0
    x_4_4     disj1_4_14_2  -1.0
    x_4_4     disj2_4_14_2  1.0
    x_5_0     prec_5_0  -1.0
    x_5_0     disj1_0_5_0  1.0
    x_5_0     disj2_0_5_0  -1.0
    x_5_0     disj1_1_5_0  1.0
    x_5_0     disj2_1_5_0  -1.0
    x_5_0     disj1_2_5_0  1.0
    x_5_0     disj2_2_5_0  -1.0
    x_5_0     disj1_3_5_0  1.0
    x_5_0     disj2_3_5_0  -1.0
    x_5_0     disj1_4_5_0  1.0
    x_5_0     disj2_4_5_0  -1.0
    x_5_0     disj1_5_6_0  -1.0
    x_5_0     disj2_5_6_0  1.0
    x_5_0     disj1_5_7_0  -1.0
    x_5_0     disj2_5_7_0  1.0
    x_5_0     disj1_5_8_0  -1.0
    x_5_0     disj2_5_8_0  1.0
    x_5_0     disj1_5_9_0  -1.0
    x_5_0     disj2_5_9_0  1.0
    x_5_0     disj1_5_10_0  -1.0
    x_5_0     disj2_5_10_0  1.0
    x_5_0     disj1_5_11_0  -1.0
    x_5_0     disj2_5_11_0  1.0
    x_5_0     disj1_5_12_0  -1.0
    x_5_0     disj2_5_12_0  1.0
    x_5_0     disj1_5_13_0  -1.0
    x_5_0     disj2_5_13_0  1.0
    x_5_0     disj1_5_14_0  -1.0
    x_5_0     disj2_5_14_0  1.0
    x_5_1     prec_5_0  1.0
    x_5_1     prec_5_1  -1.0
    x_5_1     disj1_0_5_1  1.0
    x_5_1     disj2_0_5_1  -1.0
    x_5_1     disj1_1_5_1  1.0
    x_5_1     disj2_1_5_1  -1.0
    x_5_1     disj1_2_5_1  1.0
    x_5_1     disj2_2_5_1  -1.0
    x_5_1     disj1_3_5_1  1.0
    x_5_1     disj2_3_5_1  -1.0
    x_5_1     disj1_4_5_1  1.0
    x_5_1     disj2_4_5_1  -1.0
    x_5_1     disj1_5_6_1  -1.0
    x_5_1     disj2_5_6_1  1.0
    x_5_1     disj1_5_7_1  -1.0
    x_5_1     disj2_5_7_1  1.0
    x_5_1     disj1_5_8_1  -1.0
    x_5_1     disj2_5_8_1  1.0
    x_5_1     disj1_5_9_1  -1.0
    x_5_1     disj2_5_9_1  1.0
    x_5_1     disj1_5_10_1  -1.0
    x_5_1     disj2_5_10_1  1.0
    x_5_1     disj1_5_11_1  -1.0
    x_5_1     disj2_5_11_1  1.0
    x_5_1     disj1_5_12_1  -1.0
    x_5_1     disj2_5_12_1  1.0
    x_5_1     disj1_5_13_1  -1.0
    x_5_1     disj2_5_13_1  1.0
    x_5_1     disj1_5_14_1  -1.0
    x_5_1     disj2_5_14_1  1.0
    x_5_2     prec_5_1  1.0
    x_5_2     prec_5_2  -1.0
    x_5_2     disj1_0_5_3  1.0
    x_5_2     disj2_0_5_3  -1.0
    x_5_2     disj1_1_5_3  1.0
    x_5_2     disj2_1_5_3  -1.0
    x_5_2     disj1_2_5_3  1.0
    x_5_2     disj2_2_5_3  -1.0
    x_5_2     disj1_3_5_3  1.0
    x_5_2     disj2_3_5_3  -1.0
    x_5_2     disj1_4_5_3  1.0
    x_5_2     disj2_4_5_3  -1.0
    x_5_2     disj1_5_6_3  -1.0
    x_5_2     disj2_5_6_3  1.0
    x_5_2     disj1_5_7_3  -1.0
    x_5_2     disj2_5_7_3  1.0
    x_5_2     disj1_5_8_3  -1.0
    x_5_2     disj2_5_8_3  1.0
    x_5_2     disj1_5_9_3  -1.0
    x_5_2     disj2_5_9_3  1.0
    x_5_2     disj1_5_10_3  -1.0
    x_5_2     disj2_5_10_3  1.0
    x_5_2     disj1_5_11_3  -1.0
    x_5_2     disj2_5_11_3  1.0
    x_5_2     disj1_5_12_3  -1.0
    x_5_2     disj2_5_12_3  1.0
    x_5_2     disj1_5_13_3  -1.0
    x_5_2     disj2_5_13_3  1.0
    x_5_2     disj1_5_14_3  -1.0
    x_5_2     disj2_5_14_3  1.0
    x_5_3     prec_5_2  1.0
    x_5_3     prec_5_3  -1.0
    x_5_3     disj1_0_5_2  1.0
    x_5_3     disj2_0_5_2  -1.0
    x_5_3     disj1_1_5_2  1.0
    x_5_3     disj2_1_5_2  -1.0
    x_5_3     disj1_2_5_2  1.0
    x_5_3     disj2_2_5_2  -1.0
    x_5_3     disj1_3_5_2  1.0
    x_5_3     disj2_3_5_2  -1.0
    x_5_3     disj1_4_5_2  1.0
    x_5_3     disj2_4_5_2  -1.0
    x_5_3     disj1_5_6_2  -1.0
    x_5_3     disj2_5_6_2  1.0
    x_5_3     disj1_5_7_2  -1.0
    x_5_3     disj2_5_7_2  1.0
    x_5_3     disj1_5_8_2  -1.0
    x_5_3     disj2_5_8_2  1.0
    x_5_3     disj1_5_9_2  -1.0
    x_5_3     disj2_5_9_2  1.0
    x_5_3     disj1_5_10_2  -1.0
    x_5_3     disj2_5_10_2  1.0
    x_5_3     disj1_5_11_2  -1.0
    x_5_3     disj2_5_11_2  1.0
    x_5_3     disj1_5_12_2  -1.0
    x_5_3     disj2_5_12_2  1.0
    x_5_3     disj1_5_13_2  -1.0
    x_5_3     disj2_5_13_2  1.0
    x_5_3     disj1_5_14_2  -1.0
    x_5_3     disj2_5_14_2  1.0
    x_5_4     prec_5_3  1.0
    x_5_4     mksp_5    -1.0
    x_5_4     disj1_0_5_4  1.0
    x_5_4     disj2_0_5_4  -1.0
    x_5_4     disj1_1_5_4  1.0
    x_5_4     disj2_1_5_4  -1.0
    x_5_4     disj1_2_5_4  1.0
    x_5_4     disj2_2_5_4  -1.0
    x_5_4     disj1_3_5_4  1.0
    x_5_4     disj2_3_5_4  -1.0
    x_5_4     disj1_4_5_4  1.0
    x_5_4     disj2_4_5_4  -1.0
    x_5_4     disj1_5_6_4  -1.0
    x_5_4     disj2_5_6_4  1.0
    x_5_4     disj1_5_7_4  -1.0
    x_5_4     disj2_5_7_4  1.0
    x_5_4     disj1_5_8_4  -1.0
    x_5_4     disj2_5_8_4  1.0
    x_5_4     disj1_5_9_4  -1.0
    x_5_4     disj2_5_9_4  1.0
    x_5_4     disj1_5_10_4  -1.0
    x_5_4     disj2_5_10_4  1.0
    x_5_4     disj1_5_11_4  -1.0
    x_5_4     disj2_5_11_4  1.0
    x_5_4     disj1_5_12_4  -1.0
    x_5_4     disj2_5_12_4  1.0
    x_5_4     disj1_5_13_4  -1.0
    x_5_4     disj2_5_13_4  1.0
    x_5_4     disj1_5_14_4  -1.0
    x_5_4     disj2_5_14_4  1.0
    x_6_0     prec_6_0  -1.0
    x_6_0     disj1_0_6_2  1.0
    x_6_0     disj2_0_6_2  -1.0
    x_6_0     disj1_1_6_2  1.0
    x_6_0     disj2_1_6_2  -1.0
    x_6_0     disj1_2_6_2  1.0
    x_6_0     disj2_2_6_2  -1.0
    x_6_0     disj1_3_6_2  1.0
    x_6_0     disj2_3_6_2  -1.0
    x_6_0     disj1_4_6_2  1.0
    x_6_0     disj2_4_6_2  -1.0
    x_6_0     disj1_5_6_2  1.0
    x_6_0     disj2_5_6_2  -1.0
    x_6_0     disj1_6_7_2  -1.0
    x_6_0     disj2_6_7_2  1.0
    x_6_0     disj1_6_8_2  -1.0
    x_6_0     disj2_6_8_2  1.0
    x_6_0     disj1_6_9_2  -1.0
    x_6_0     disj2_6_9_2  1.0
    x_6_0     disj1_6_10_2  -1.0
    x_6_0     disj2_6_10_2  1.0
    x_6_0     disj1_6_11_2  -1.0
    x_6_0     disj2_6_11_2  1.0
    x_6_0     disj1_6_12_2  -1.0
    x_6_0     disj2_6_12_2  1.0
    x_6_0     disj1_6_13_2  -1.0
    x_6_0     disj2_6_13_2  1.0
    x_6_0     disj1_6_14_2  -1.0
    x_6_0     disj2_6_14_2  1.0
    x_6_1     prec_6_0  1.0
    x_6_1     prec_6_1  -1.0
    x_6_1     disj1_0_6_0  1.0
    x_6_1     disj2_0_6_0  -1.0
    x_6_1     disj1_1_6_0  1.0
    x_6_1     disj2_1_6_0  -1.0
    x_6_1     disj1_2_6_0  1.0
    x_6_1     disj2_2_6_0  -1.0
    x_6_1     disj1_3_6_0  1.0
    x_6_1     disj2_3_6_0  -1.0
    x_6_1     disj1_4_6_0  1.0
    x_6_1     disj2_4_6_0  -1.0
    x_6_1     disj1_5_6_0  1.0
    x_6_1     disj2_5_6_0  -1.0
    x_6_1     disj1_6_7_0  -1.0
    x_6_1     disj2_6_7_0  1.0
    x_6_1     disj1_6_8_0  -1.0
    x_6_1     disj2_6_8_0  1.0
    x_6_1     disj1_6_9_0  -1.0
    x_6_1     disj2_6_9_0  1.0
    x_6_1     disj1_6_10_0  -1.0
    x_6_1     disj2_6_10_0  1.0
    x_6_1     disj1_6_11_0  -1.0
    x_6_1     disj2_6_11_0  1.0
    x_6_1     disj1_6_12_0  -1.0
    x_6_1     disj2_6_12_0  1.0
    x_6_1     disj1_6_13_0  -1.0
    x_6_1     disj2_6_13_0  1.0
    x_6_1     disj1_6_14_0  -1.0
    x_6_1     disj2_6_14_0  1.0
    x_6_2     prec_6_1  1.0
    x_6_2     prec_6_2  -1.0
    x_6_2     disj1_0_6_1  1.0
    x_6_2     disj2_0_6_1  -1.0
    x_6_2     disj1_1_6_1  1.0
    x_6_2     disj2_1_6_1  -1.0
    x_6_2     disj1_2_6_1  1.0
    x_6_2     disj2_2_6_1  -1.0
    x_6_2     disj1_3_6_1  1.0
    x_6_2     disj2_3_6_1  -1.0
    x_6_2     disj1_4_6_1  1.0
    x_6_2     disj2_4_6_1  -1.0
    x_6_2     disj1_5_6_1  1.0
    x_6_2     disj2_5_6_1  -1.0
    x_6_2     disj1_6_7_1  -1.0
    x_6_2     disj2_6_7_1  1.0
    x_6_2     disj1_6_8_1  -1.0
    x_6_2     disj2_6_8_1  1.0
    x_6_2     disj1_6_9_1  -1.0
    x_6_2     disj2_6_9_1  1.0
    x_6_2     disj1_6_10_1  -1.0
    x_6_2     disj2_6_10_1  1.0
    x_6_2     disj1_6_11_1  -1.0
    x_6_2     disj2_6_11_1  1.0
    x_6_2     disj1_6_12_1  -1.0
    x_6_2     disj2_6_12_1  1.0
    x_6_2     disj1_6_13_1  -1.0
    x_6_2     disj2_6_13_1  1.0
    x_6_2     disj1_6_14_1  -1.0
    x_6_2     disj2_6_14_1  1.0
    x_6_3     prec_6_2  1.0
    x_6_3     prec_6_3  -1.0
    x_6_3     disj1_0_6_3  1.0
    x_6_3     disj2_0_6_3  -1.0
    x_6_3     disj1_1_6_3  1.0
    x_6_3     disj2_1_6_3  -1.0
    x_6_3     disj1_2_6_3  1.0
    x_6_3     disj2_2_6_3  -1.0
    x_6_3     disj1_3_6_3  1.0
    x_6_3     disj2_3_6_3  -1.0
    x_6_3     disj1_4_6_3  1.0
    x_6_3     disj2_4_6_3  -1.0
    x_6_3     disj1_5_6_3  1.0
    x_6_3     disj2_5_6_3  -1.0
    x_6_3     disj1_6_7_3  -1.0
    x_6_3     disj2_6_7_3  1.0
    x_6_3     disj1_6_8_3  -1.0
    x_6_3     disj2_6_8_3  1.0
    x_6_3     disj1_6_9_3  -1.0
    x_6_3     disj2_6_9_3  1.0
    x_6_3     disj1_6_10_3  -1.0
    x_6_3     disj2_6_10_3  1.0
    x_6_3     disj1_6_11_3  -1.0
    x_6_3     disj2_6_11_3  1.0
    x_6_3     disj1_6_12_3  -1.0
    x_6_3     disj2_6_12_3  1.0
    x_6_3     disj1_6_13_3  -1.0
    x_6_3     disj2_6_13_3  1.0
    x_6_3     disj1_6_14_3  -1.0
    x_6_3     disj2_6_14_3  1.0
    x_6_4     prec_6_3  1.0
    x_6_4     mksp_6    -1.0
    x_6_4     disj1_0_6_4  1.0
    x_6_4     disj2_0_6_4  -1.0
    x_6_4     disj1_1_6_4  1.0
    x_6_4     disj2_1_6_4  -1.0
    x_6_4     disj1_2_6_4  1.0
    x_6_4     disj2_2_6_4  -1.0
    x_6_4     disj1_3_6_4  1.0
    x_6_4     disj2_3_6_4  -1.0
    x_6_4     disj1_4_6_4  1.0
    x_6_4     disj2_4_6_4  -1.0
    x_6_4     disj1_5_6_4  1.0
    x_6_4     disj2_5_6_4  -1.0
    x_6_4     disj1_6_7_4  -1.0
    x_6_4     disj2_6_7_4  1.0
    x_6_4     disj1_6_8_4  -1.0
    x_6_4     disj2_6_8_4  1.0
    x_6_4     disj1_6_9_4  -1.0
    x_6_4     disj2_6_9_4  1.0
    x_6_4     disj1_6_10_4  -1.0
    x_6_4     disj2_6_10_4  1.0
    x_6_4     disj1_6_11_4  -1.0
    x_6_4     disj2_6_11_4  1.0
    x_6_4     disj1_6_12_4  -1.0
    x_6_4     disj2_6_12_4  1.0
    x_6_4     disj1_6_13_4  -1.0
    x_6_4     disj2_6_13_4  1.0
    x_6_4     disj1_6_14_4  -1.0
    x_6_4     disj2_6_14_4  1.0
    x_7_0     prec_7_0  -1.0
    x_7_0     disj1_0_7_1  1.0
    x_7_0     disj2_0_7_1  -1.0
    x_7_0     disj1_1_7_1  1.0
    x_7_0     disj2_1_7_1  -1.0
    x_7_0     disj1_2_7_1  1.0
    x_7_0     disj2_2_7_1  -1.0
    x_7_0     disj1_3_7_1  1.0
    x_7_0     disj2_3_7_1  -1.0
    x_7_0     disj1_4_7_1  1.0
    x_7_0     disj2_4_7_1  -1.0
    x_7_0     disj1_5_7_1  1.0
    x_7_0     disj2_5_7_1  -1.0
    x_7_0     disj1_6_7_1  1.0
    x_7_0     disj2_6_7_1  -1.0
    x_7_0     disj1_7_8_1  -1.0
    x_7_0     disj2_7_8_1  1.0
    x_7_0     disj1_7_9_1  -1.0
    x_7_0     disj2_7_9_1  1.0
    x_7_0     disj1_7_10_1  -1.0
    x_7_0     disj2_7_10_1  1.0
    x_7_0     disj1_7_11_1  -1.0
    x_7_0     disj2_7_11_1  1.0
    x_7_0     disj1_7_12_1  -1.0
    x_7_0     disj2_7_12_1  1.0
    x_7_0     disj1_7_13_1  -1.0
    x_7_0     disj2_7_13_1  1.0
    x_7_0     disj1_7_14_1  -1.0
    x_7_0     disj2_7_14_1  1.0
    x_7_1     prec_7_0  1.0
    x_7_1     prec_7_1  -1.0
    x_7_1     disj1_0_7_2  1.0
    x_7_1     disj2_0_7_2  -1.0
    x_7_1     disj1_1_7_2  1.0
    x_7_1     disj2_1_7_2  -1.0
    x_7_1     disj1_2_7_2  1.0
    x_7_1     disj2_2_7_2  -1.0
    x_7_1     disj1_3_7_2  1.0
    x_7_1     disj2_3_7_2  -1.0
    x_7_1     disj1_4_7_2  1.0
    x_7_1     disj2_4_7_2  -1.0
    x_7_1     disj1_5_7_2  1.0
    x_7_1     disj2_5_7_2  -1.0
    x_7_1     disj1_6_7_2  1.0
    x_7_1     disj2_6_7_2  -1.0
    x_7_1     disj1_7_8_2  -1.0
    x_7_1     disj2_7_8_2  1.0
    x_7_1     disj1_7_9_2  -1.0
    x_7_1     disj2_7_9_2  1.0
    x_7_1     disj1_7_10_2  -1.0
    x_7_1     disj2_7_10_2  1.0
    x_7_1     disj1_7_11_2  -1.0
    x_7_1     disj2_7_11_2  1.0
    x_7_1     disj1_7_12_2  -1.0
    x_7_1     disj2_7_12_2  1.0
    x_7_1     disj1_7_13_2  -1.0
    x_7_1     disj2_7_13_2  1.0
    x_7_1     disj1_7_14_2  -1.0
    x_7_1     disj2_7_14_2  1.0
    x_7_2     prec_7_1  1.0
    x_7_2     prec_7_2  -1.0
    x_7_2     disj1_0_7_0  1.0
    x_7_2     disj2_0_7_0  -1.0
    x_7_2     disj1_1_7_0  1.0
    x_7_2     disj2_1_7_0  -1.0
    x_7_2     disj1_2_7_0  1.0
    x_7_2     disj2_2_7_0  -1.0
    x_7_2     disj1_3_7_0  1.0
    x_7_2     disj2_3_7_0  -1.0
    x_7_2     disj1_4_7_0  1.0
    x_7_2     disj2_4_7_0  -1.0
    x_7_2     disj1_5_7_0  1.0
    x_7_2     disj2_5_7_0  -1.0
    x_7_2     disj1_6_7_0  1.0
    x_7_2     disj2_6_7_0  -1.0
    x_7_2     disj1_7_8_0  -1.0
    x_7_2     disj2_7_8_0  1.0
    x_7_2     disj1_7_9_0  -1.0
    x_7_2     disj2_7_9_0  1.0
    x_7_2     disj1_7_10_0  -1.0
    x_7_2     disj2_7_10_0  1.0
    x_7_2     disj1_7_11_0  -1.0
    x_7_2     disj2_7_11_0  1.0
    x_7_2     disj1_7_12_0  -1.0
    x_7_2     disj2_7_12_0  1.0
    x_7_2     disj1_7_13_0  -1.0
    x_7_2     disj2_7_13_0  1.0
    x_7_2     disj1_7_14_0  -1.0
    x_7_2     disj2_7_14_0  1.0
    x_7_3     prec_7_2  1.0
    x_7_3     prec_7_3  -1.0
    x_7_3     disj1_0_7_4  1.0
    x_7_3     disj2_0_7_4  -1.0
    x_7_3     disj1_1_7_4  1.0
    x_7_3     disj2_1_7_4  -1.0
    x_7_3     disj1_2_7_4  1.0
    x_7_3     disj2_2_7_4  -1.0
    x_7_3     disj1_3_7_4  1.0
    x_7_3     disj2_3_7_4  -1.0
    x_7_3     disj1_4_7_4  1.0
    x_7_3     disj2_4_7_4  -1.0
    x_7_3     disj1_5_7_4  1.0
    x_7_3     disj2_5_7_4  -1.0
    x_7_3     disj1_6_7_4  1.0
    x_7_3     disj2_6_7_4  -1.0
    x_7_3     disj1_7_8_4  -1.0
    x_7_3     disj2_7_8_4  1.0
    x_7_3     disj1_7_9_4  -1.0
    x_7_3     disj2_7_9_4  1.0
    x_7_3     disj1_7_10_4  -1.0
    x_7_3     disj2_7_10_4  1.0
    x_7_3     disj1_7_11_4  -1.0
    x_7_3     disj2_7_11_4  1.0
    x_7_3     disj1_7_12_4  -1.0
    x_7_3     disj2_7_12_4  1.0
    x_7_3     disj1_7_13_4  -1.0
    x_7_3     disj2_7_13_4  1.0
    x_7_3     disj1_7_14_4  -1.0
    x_7_3     disj2_7_14_4  1.0
    x_7_4     prec_7_3  1.0
    x_7_4     mksp_7    -1.0
    x_7_4     disj1_0_7_3  1.0
    x_7_4     disj2_0_7_3  -1.0
    x_7_4     disj1_1_7_3  1.0
    x_7_4     disj2_1_7_3  -1.0
    x_7_4     disj1_2_7_3  1.0
    x_7_4     disj2_2_7_3  -1.0
    x_7_4     disj1_3_7_3  1.0
    x_7_4     disj2_3_7_3  -1.0
    x_7_4     disj1_4_7_3  1.0
    x_7_4     disj2_4_7_3  -1.0
    x_7_4     disj1_5_7_3  1.0
    x_7_4     disj2_5_7_3  -1.0
    x_7_4     disj1_6_7_3  1.0
    x_7_4     disj2_6_7_3  -1.0
    x_7_4     disj1_7_8_3  -1.0
    x_7_4     disj2_7_8_3  1.0
    x_7_4     disj1_7_9_3  -1.0
    x_7_4     disj2_7_9_3  1.0
    x_7_4     disj1_7_10_3  -1.0
    x_7_4     disj2_7_10_3  1.0
    x_7_4     disj1_7_11_3  -1.0
    x_7_4     disj2_7_11_3  1.0
    x_7_4     disj1_7_12_3  -1.0
    x_7_4     disj2_7_12_3  1.0
    x_7_4     disj1_7_13_3  -1.0
    x_7_4     disj2_7_13_3  1.0
    x_7_4     disj1_7_14_3  -1.0
    x_7_4     disj2_7_14_3  1.0
    x_8_0     prec_8_0  -1.0
    x_8_0     disj1_0_8_3  1.0
    x_8_0     disj2_0_8_3  -1.0
    x_8_0     disj1_1_8_3  1.0
    x_8_0     disj2_1_8_3  -1.0
    x_8_0     disj1_2_8_3  1.0
    x_8_0     disj2_2_8_3  -1.0
    x_8_0     disj1_3_8_3  1.0
    x_8_0     disj2_3_8_3  -1.0
    x_8_0     disj1_4_8_3  1.0
    x_8_0     disj2_4_8_3  -1.0
    x_8_0     disj1_5_8_3  1.0
    x_8_0     disj2_5_8_3  -1.0
    x_8_0     disj1_6_8_3  1.0
    x_8_0     disj2_6_8_3  -1.0
    x_8_0     disj1_7_8_3  1.0
    x_8_0     disj2_7_8_3  -1.0
    x_8_0     disj1_8_9_3  -1.0
    x_8_0     disj2_8_9_3  1.0
    x_8_0     disj1_8_10_3  -1.0
    x_8_0     disj2_8_10_3  1.0
    x_8_0     disj1_8_11_3  -1.0
    x_8_0     disj2_8_11_3  1.0
    x_8_0     disj1_8_12_3  -1.0
    x_8_0     disj2_8_12_3  1.0
    x_8_0     disj1_8_13_3  -1.0
    x_8_0     disj2_8_13_3  1.0
    x_8_0     disj1_8_14_3  -1.0
    x_8_0     disj2_8_14_3  1.0
    x_8_1     prec_8_0  1.0
    x_8_1     prec_8_1  -1.0
    x_8_1     disj1_0_8_1  1.0
    x_8_1     disj2_0_8_1  -1.0
    x_8_1     disj1_1_8_1  1.0
    x_8_1     disj2_1_8_1  -1.0
    x_8_1     disj1_2_8_1  1.0
    x_8_1     disj2_2_8_1  -1.0
    x_8_1     disj1_3_8_1  1.0
    x_8_1     disj2_3_8_1  -1.0
    x_8_1     disj1_4_8_1  1.0
    x_8_1     disj2_4_8_1  -1.0
    x_8_1     disj1_5_8_1  1.0
    x_8_1     disj2_5_8_1  -1.0
    x_8_1     disj1_6_8_1  1.0
    x_8_1     disj2_6_8_1  -1.0
    x_8_1     disj1_7_8_1  1.0
    x_8_1     disj2_7_8_1  -1.0
    x_8_1     disj1_8_9_1  -1.0
    x_8_1     disj2_8_9_1  1.0
    x_8_1     disj1_8_10_1  -1.0
    x_8_1     disj2_8_10_1  1.0
    x_8_1     disj1_8_11_1  -1.0
    x_8_1     disj2_8_11_1  1.0
    x_8_1     disj1_8_12_1  -1.0
    x_8_1     disj2_8_12_1  1.0
    x_8_1     disj1_8_13_1  -1.0
    x_8_1     disj2_8_13_1  1.0
    x_8_1     disj1_8_14_1  -1.0
    x_8_1     disj2_8_14_1  1.0
    x_8_2     prec_8_1  1.0
    x_8_2     prec_8_2  -1.0
    x_8_2     disj1_0_8_4  1.0
    x_8_2     disj2_0_8_4  -1.0
    x_8_2     disj1_1_8_4  1.0
    x_8_2     disj2_1_8_4  -1.0
    x_8_2     disj1_2_8_4  1.0
    x_8_2     disj2_2_8_4  -1.0
    x_8_2     disj1_3_8_4  1.0
    x_8_2     disj2_3_8_4  -1.0
    x_8_2     disj1_4_8_4  1.0
    x_8_2     disj2_4_8_4  -1.0
    x_8_2     disj1_5_8_4  1.0
    x_8_2     disj2_5_8_4  -1.0
    x_8_2     disj1_6_8_4  1.0
    x_8_2     disj2_6_8_4  -1.0
    x_8_2     disj1_7_8_4  1.0
    x_8_2     disj2_7_8_4  -1.0
    x_8_2     disj1_8_9_4  -1.0
    x_8_2     disj2_8_9_4  1.0
    x_8_2     disj1_8_10_4  -1.0
    x_8_2     disj2_8_10_4  1.0
    x_8_2     disj1_8_11_4  -1.0
    x_8_2     disj2_8_11_4  1.0
    x_8_2     disj1_8_12_4  -1.0
    x_8_2     disj2_8_12_4  1.0
    x_8_2     disj1_8_13_4  -1.0
    x_8_2     disj2_8_13_4  1.0
    x_8_2     disj1_8_14_4  -1.0
    x_8_2     disj2_8_14_4  1.0
    x_8_3     prec_8_2  1.0
    x_8_3     prec_8_3  -1.0
    x_8_3     disj1_0_8_0  1.0
    x_8_3     disj2_0_8_0  -1.0
    x_8_3     disj1_1_8_0  1.0
    x_8_3     disj2_1_8_0  -1.0
    x_8_3     disj1_2_8_0  1.0
    x_8_3     disj2_2_8_0  -1.0
    x_8_3     disj1_3_8_0  1.0
    x_8_3     disj2_3_8_0  -1.0
    x_8_3     disj1_4_8_0  1.0
    x_8_3     disj2_4_8_0  -1.0
    x_8_3     disj1_5_8_0  1.0
    x_8_3     disj2_5_8_0  -1.0
    x_8_3     disj1_6_8_0  1.0
    x_8_3     disj2_6_8_0  -1.0
    x_8_3     disj1_7_8_0  1.0
    x_8_3     disj2_7_8_0  -1.0
    x_8_3     disj1_8_9_0  -1.0
    x_8_3     disj2_8_9_0  1.0
    x_8_3     disj1_8_10_0  -1.0
    x_8_3     disj2_8_10_0  1.0
    x_8_3     disj1_8_11_0  -1.0
    x_8_3     disj2_8_11_0  1.0
    x_8_3     disj1_8_12_0  -1.0
    x_8_3     disj2_8_12_0  1.0
    x_8_3     disj1_8_13_0  -1.0
    x_8_3     disj2_8_13_0  1.0
    x_8_3     disj1_8_14_0  -1.0
    x_8_3     disj2_8_14_0  1.0
    x_8_4     prec_8_3  1.0
    x_8_4     mksp_8    -1.0
    x_8_4     disj1_0_8_2  1.0
    x_8_4     disj2_0_8_2  -1.0
    x_8_4     disj1_1_8_2  1.0
    x_8_4     disj2_1_8_2  -1.0
    x_8_4     disj1_2_8_2  1.0
    x_8_4     disj2_2_8_2  -1.0
    x_8_4     disj1_3_8_2  1.0
    x_8_4     disj2_3_8_2  -1.0
    x_8_4     disj1_4_8_2  1.0
    x_8_4     disj2_4_8_2  -1.0
    x_8_4     disj1_5_8_2  1.0
    x_8_4     disj2_5_8_2  -1.0
    x_8_4     disj1_6_8_2  1.0
    x_8_4     disj2_6_8_2  -1.0
    x_8_4     disj1_7_8_2  1.0
    x_8_4     disj2_7_8_2  -1.0
    x_8_4     disj1_8_9_2  -1.0
    x_8_4     disj2_8_9_2  1.0
    x_8_4     disj1_8_10_2  -1.0
    x_8_4     disj2_8_10_2  1.0
    x_8_4     disj1_8_11_2  -1.0
    x_8_4     disj2_8_11_2  1.0
    x_8_4     disj1_8_12_2  -1.0
    x_8_4     disj2_8_12_2  1.0
    x_8_4     disj1_8_13_2  -1.0
    x_8_4     disj2_8_13_2  1.0
    x_8_4     disj1_8_14_2  -1.0
    x_8_4     disj2_8_14_2  1.0
    x_9_0     prec_9_0  -1.0
    x_9_0     disj1_0_9_0  1.0
    x_9_0     disj2_0_9_0  -1.0
    x_9_0     disj1_1_9_0  1.0
    x_9_0     disj2_1_9_0  -1.0
    x_9_0     disj1_2_9_0  1.0
    x_9_0     disj2_2_9_0  -1.0
    x_9_0     disj1_3_9_0  1.0
    x_9_0     disj2_3_9_0  -1.0
    x_9_0     disj1_4_9_0  1.0
    x_9_0     disj2_4_9_0  -1.0
    x_9_0     disj1_5_9_0  1.0
    x_9_0     disj2_5_9_0  -1.0
    x_9_0     disj1_6_9_0  1.0
    x_9_0     disj2_6_9_0  -1.0
    x_9_0     disj1_7_9_0  1.0
    x_9_0     disj2_7_9_0  -1.0
    x_9_0     disj1_8_9_0  1.0
    x_9_0     disj2_8_9_0  -1.0
    x_9_0     disj1_9_10_0  -1.0
    x_9_0     disj2_9_10_0  1.0
    x_9_0     disj1_9_11_0  -1.0
    x_9_0     disj2_9_11_0  1.0
    x_9_0     disj1_9_12_0  -1.0
    x_9_0     disj2_9_12_0  1.0
    x_9_0     disj1_9_13_0  -1.0
    x_9_0     disj2_9_13_0  1.0
    x_9_0     disj1_9_14_0  -1.0
    x_9_0     disj2_9_14_0  1.0
    x_9_1     prec_9_0  1.0
    x_9_1     prec_9_1  -1.0
    x_9_1     disj1_0_9_3  1.0
    x_9_1     disj2_0_9_3  -1.0
    x_9_1     disj1_1_9_3  1.0
    x_9_1     disj2_1_9_3  -1.0
    x_9_1     disj1_2_9_3  1.0
    x_9_1     disj2_2_9_3  -1.0
    x_9_1     disj1_3_9_3  1.0
    x_9_1     disj2_3_9_3  -1.0
    x_9_1     disj1_4_9_3  1.0
    x_9_1     disj2_4_9_3  -1.0
    x_9_1     disj1_5_9_3  1.0
    x_9_1     disj2_5_9_3  -1.0
    x_9_1     disj1_6_9_3  1.0
    x_9_1     disj2_6_9_3  -1.0
    x_9_1     disj1_7_9_3  1.0
    x_9_1     disj2_7_9_3  -1.0
    x_9_1     disj1_8_9_3  1.0
    x_9_1     disj2_8_9_3  -1.0
    x_9_1     disj1_9_10_3  -1.0
    x_9_1     disj2_9_10_3  1.0
    x_9_1     disj1_9_11_3  -1.0
    x_9_1     disj2_9_11_3  1.0
    x_9_1     disj1_9_12_3  -1.0
    x_9_1     disj2_9_12_3  1.0
    x_9_1     disj1_9_13_3  -1.0
    x_9_1     disj2_9_13_3  1.0
    x_9_1     disj1_9_14_3  -1.0
    x_9_1     disj2_9_14_3  1.0
    x_9_2     prec_9_1  1.0
    x_9_2     prec_9_2  -1.0
    x_9_2     disj1_0_9_2  1.0
    x_9_2     disj2_0_9_2  -1.0
    x_9_2     disj1_1_9_2  1.0
    x_9_2     disj2_1_9_2  -1.0
    x_9_2     disj1_2_9_2  1.0
    x_9_2     disj2_2_9_2  -1.0
    x_9_2     disj1_3_9_2  1.0
    x_9_2     disj2_3_9_2  -1.0
    x_9_2     disj1_4_9_2  1.0
    x_9_2     disj2_4_9_2  -1.0
    x_9_2     disj1_5_9_2  1.0
    x_9_2     disj2_5_9_2  -1.0
    x_9_2     disj1_6_9_2  1.0
    x_9_2     disj2_6_9_2  -1.0
    x_9_2     disj1_7_9_2  1.0
    x_9_2     disj2_7_9_2  -1.0
    x_9_2     disj1_8_9_2  1.0
    x_9_2     disj2_8_9_2  -1.0
    x_9_2     disj1_9_10_2  -1.0
    x_9_2     disj2_9_10_2  1.0
    x_9_2     disj1_9_11_2  -1.0
    x_9_2     disj2_9_11_2  1.0
    x_9_2     disj1_9_12_2  -1.0
    x_9_2     disj2_9_12_2  1.0
    x_9_2     disj1_9_13_2  -1.0
    x_9_2     disj2_9_13_2  1.0
    x_9_2     disj1_9_14_2  -1.0
    x_9_2     disj2_9_14_2  1.0
    x_9_3     prec_9_2  1.0
    x_9_3     prec_9_3  -1.0
    x_9_3     disj1_0_9_4  1.0
    x_9_3     disj2_0_9_4  -1.0
    x_9_3     disj1_1_9_4  1.0
    x_9_3     disj2_1_9_4  -1.0
    x_9_3     disj1_2_9_4  1.0
    x_9_3     disj2_2_9_4  -1.0
    x_9_3     disj1_3_9_4  1.0
    x_9_3     disj2_3_9_4  -1.0
    x_9_3     disj1_4_9_4  1.0
    x_9_3     disj2_4_9_4  -1.0
    x_9_3     disj1_5_9_4  1.0
    x_9_3     disj2_5_9_4  -1.0
    x_9_3     disj1_6_9_4  1.0
    x_9_3     disj2_6_9_4  -1.0
    x_9_3     disj1_7_9_4  1.0
    x_9_3     disj2_7_9_4  -1.0
    x_9_3     disj1_8_9_4  1.0
    x_9_3     disj2_8_9_4  -1.0
    x_9_3     disj1_9_10_4  -1.0
    x_9_3     disj2_9_10_4  1.0
    x_9_3     disj1_9_11_4  -1.0
    x_9_3     disj2_9_11_4  1.0
    x_9_3     disj1_9_12_4  -1.0
    x_9_3     disj2_9_12_4  1.0
    x_9_3     disj1_9_13_4  -1.0
    x_9_3     disj2_9_13_4  1.0
    x_9_3     disj1_9_14_4  -1.0
    x_9_3     disj2_9_14_4  1.0
    x_9_4     prec_9_3  1.0
    x_9_4     mksp_9    -1.0
    x_9_4     disj1_0_9_1  1.0
    x_9_4     disj2_0_9_1  -1.0
    x_9_4     disj1_1_9_1  1.0
    x_9_4     disj2_1_9_1  -1.0
    x_9_4     disj1_2_9_1  1.0
    x_9_4     disj2_2_9_1  -1.0
    x_9_4     disj1_3_9_1  1.0
    x_9_4     disj2_3_9_1  -1.0
    x_9_4     disj1_4_9_1  1.0
    x_9_4     disj2_4_9_1  -1.0
    x_9_4     disj1_5_9_1  1.0
    x_9_4     disj2_5_9_1  -1.0
    x_9_4     disj1_6_9_1  1.0
    x_9_4     disj2_6_9_1  -1.0
    x_9_4     disj1_7_9_1  1.0
    x_9_4     disj2_7_9_1  -1.0
    x_9_4     disj1_8_9_1  1.0
    x_9_4     disj2_8_9_1  -1.0
    x_9_4     disj1_9_10_1  -1.0
    x_9_4     disj2_9_10_1  1.0
    x_9_4     disj1_9_11_1  -1.0
    x_9_4     disj2_9_11_1  1.0
    x_9_4     disj1_9_12_1  -1.0
    x_9_4     disj2_9_12_1  1.0
    x_9_4     disj1_9_13_1  -1.0
    x_9_4     disj2_9_13_1  1.0
    x_9_4     disj1_9_14_1  -1.0
    x_9_4     disj2_9_14_1  1.0
    x_10_0    prec_10_0  -1.0
    x_10_0    disj1_0_10_2  1.0
    x_10_0    disj2_0_10_2  -1.0
    x_10_0    disj1_1_10_2  1.0
    x_10_0    disj2_1_10_2  -1.0
    x_10_0    disj1_2_10_2  1.0
    x_10_0    disj2_2_10_2  -1.0
    x_10_0    disj1_3_10_2  1.0
    x_10_0    disj2_3_10_2  -1.0
    x_10_0    disj1_4_10_2  1.0
    x_10_0    disj2_4_10_2  -1.0
    x_10_0    disj1_5_10_2  1.0
    x_10_0    disj2_5_10_2  -1.0
    x_10_0    disj1_6_10_2  1.0
    x_10_0    disj2_6_10_2  -1.0
    x_10_0    disj1_7_10_2  1.0
    x_10_0    disj2_7_10_2  -1.0
    x_10_0    disj1_8_10_2  1.0
    x_10_0    disj2_8_10_2  -1.0
    x_10_0    disj1_9_10_2  1.0
    x_10_0    disj2_9_10_2  -1.0
    x_10_0    disj1_10_11_2  -1.0
    x_10_0    disj2_10_11_2  1.0
    x_10_0    disj1_10_12_2  -1.0
    x_10_0    disj2_10_12_2  1.0
    x_10_0    disj1_10_13_2  -1.0
    x_10_0    disj2_10_13_2  1.0
    x_10_0    disj1_10_14_2  -1.0
    x_10_0    disj2_10_14_2  1.0
    x_10_1    prec_10_0  1.0
    x_10_1    prec_10_1  -1.0
    x_10_1    disj1_0_10_4  1.0
    x_10_1    disj2_0_10_4  -1.0
    x_10_1    disj1_1_10_4  1.0
    x_10_1    disj2_1_10_4  -1.0
    x_10_1    disj1_2_10_4  1.0
    x_10_1    disj2_2_10_4  -1.0
    x_10_1    disj1_3_10_4  1.0
    x_10_1    disj2_3_10_4  -1.0
    x_10_1    disj1_4_10_4  1.0
    x_10_1    disj2_4_10_4  -1.0
    x_10_1    disj1_5_10_4  1.0
    x_10_1    disj2_5_10_4  -1.0
    x_10_1    disj1_6_10_4  1.0
    x_10_1    disj2_6_10_4  -1.0
    x_10_1    disj1_7_10_4  1.0
    x_10_1    disj2_7_10_4  -1.0
    x_10_1    disj1_8_10_4  1.0
    x_10_1    disj2_8_10_4  -1.0
    x_10_1    disj1_9_10_4  1.0
    x_10_1    disj2_9_10_4  -1.0
    x_10_1    disj1_10_11_4  -1.0
    x_10_1    disj2_10_11_4  1.0
    x_10_1    disj1_10_12_4  -1.0
    x_10_1    disj2_10_12_4  1.0
    x_10_1    disj1_10_13_4  -1.0
    x_10_1    disj2_10_13_4  1.0
    x_10_1    disj1_10_14_4  -1.0
    x_10_1    disj2_10_14_4  1.0
    x_10_2    prec_10_1  1.0
    x_10_2    prec_10_2  -1.0
    x_10_2    disj1_0_10_1  1.0
    x_10_2    disj2_0_10_1  -1.0
    x_10_2    disj1_1_10_1  1.0
    x_10_2    disj2_1_10_1  -1.0
    x_10_2    disj1_2_10_1  1.0
    x_10_2    disj2_2_10_1  -1.0
    x_10_2    disj1_3_10_1  1.0
    x_10_2    disj2_3_10_1  -1.0
    x_10_2    disj1_4_10_1  1.0
    x_10_2    disj2_4_10_1  -1.0
    x_10_2    disj1_5_10_1  1.0
    x_10_2    disj2_5_10_1  -1.0
    x_10_2    disj1_6_10_1  1.0
    x_10_2    disj2_6_10_1  -1.0
    x_10_2    disj1_7_10_1  1.0
    x_10_2    disj2_7_10_1  -1.0
    x_10_2    disj1_8_10_1  1.0
    x_10_2    disj2_8_10_1  -1.0
    x_10_2    disj1_9_10_1  1.0
    x_10_2    disj2_9_10_1  -1.0
    x_10_2    disj1_10_11_1  -1.0
    x_10_2    disj2_10_11_1  1.0
    x_10_2    disj1_10_12_1  -1.0
    x_10_2    disj2_10_12_1  1.0
    x_10_2    disj1_10_13_1  -1.0
    x_10_2    disj2_10_13_1  1.0
    x_10_2    disj1_10_14_1  -1.0
    x_10_2    disj2_10_14_1  1.0
    x_10_3    prec_10_2  1.0
    x_10_3    prec_10_3  -1.0
    x_10_3    disj1_0_10_0  1.0
    x_10_3    disj2_0_10_0  -1.0
    x_10_3    disj1_1_10_0  1.0
    x_10_3    disj2_1_10_0  -1.0
    x_10_3    disj1_2_10_0  1.0
    x_10_3    disj2_2_10_0  -1.0
    x_10_3    disj1_3_10_0  1.0
    x_10_3    disj2_3_10_0  -1.0
    x_10_3    disj1_4_10_0  1.0
    x_10_3    disj2_4_10_0  -1.0
    x_10_3    disj1_5_10_0  1.0
    x_10_3    disj2_5_10_0  -1.0
    x_10_3    disj1_6_10_0  1.0
    x_10_3    disj2_6_10_0  -1.0
    x_10_3    disj1_7_10_0  1.0
    x_10_3    disj2_7_10_0  -1.0
    x_10_3    disj1_8_10_0  1.0
    x_10_3    disj2_8_10_0  -1.0
    x_10_3    disj1_9_10_0  1.0
    x_10_3    disj2_9_10_0  -1.0
    x_10_3    disj1_10_11_0  -1.0
    x_10_3    disj2_10_11_0  1.0
    x_10_3    disj1_10_12_0  -1.0
    x_10_3    disj2_10_12_0  1.0
    x_10_3    disj1_10_13_0  -1.0
    x_10_3    disj2_10_13_0  1.0
    x_10_3    disj1_10_14_0  -1.0
    x_10_3    disj2_10_14_0  1.0
    x_10_4    prec_10_3  1.0
    x_10_4    mksp_10   -1.0
    x_10_4    disj1_0_10_3  1.0
    x_10_4    disj2_0_10_3  -1.0
    x_10_4    disj1_1_10_3  1.0
    x_10_4    disj2_1_10_3  -1.0
    x_10_4    disj1_2_10_3  1.0
    x_10_4    disj2_2_10_3  -1.0
    x_10_4    disj1_3_10_3  1.0
    x_10_4    disj2_3_10_3  -1.0
    x_10_4    disj1_4_10_3  1.0
    x_10_4    disj2_4_10_3  -1.0
    x_10_4    disj1_5_10_3  1.0
    x_10_4    disj2_5_10_3  -1.0
    x_10_4    disj1_6_10_3  1.0
    x_10_4    disj2_6_10_3  -1.0
    x_10_4    disj1_7_10_3  1.0
    x_10_4    disj2_7_10_3  -1.0
    x_10_4    disj1_8_10_3  1.0
    x_10_4    disj2_8_10_3  -1.0
    x_10_4    disj1_9_10_3  1.0
    x_10_4    disj2_9_10_3  -1.0
    x_10_4    disj1_10_11_3  -1.0
    x_10_4    disj2_10_11_3  1.0
    x_10_4    disj1_10_12_3  -1.0
    x_10_4    disj2_10_12_3  1.0
    x_10_4    disj1_10_13_3  -1.0
    x_10_4    disj2_10_13_3  1.0
    x_10_4    disj1_10_14_3  -1.0
    x_10_4    disj2_10_14_3  1.0
    x_11_0    prec_11_0  -1.0
    x_11_0    disj1_0_11_4  1.0
    x_11_0    disj2_0_11_4  -1.0
    x_11_0    disj1_1_11_4  1.0
    x_11_0    disj2_1_11_4  -1.0
    x_11_0    disj1_2_11_4  1.0
    x_11_0    disj2_2_11_4  -1.0
    x_11_0    disj1_3_11_4  1.0
    x_11_0    disj2_3_11_4  -1.0
    x_11_0    disj1_4_11_4  1.0
    x_11_0    disj2_4_11_4  -1.0
    x_11_0    disj1_5_11_4  1.0
    x_11_0    disj2_5_11_4  -1.0
    x_11_0    disj1_6_11_4  1.0
    x_11_0    disj2_6_11_4  -1.0
    x_11_0    disj1_7_11_4  1.0
    x_11_0    disj2_7_11_4  -1.0
    x_11_0    disj1_8_11_4  1.0
    x_11_0    disj2_8_11_4  -1.0
    x_11_0    disj1_9_11_4  1.0
    x_11_0    disj2_9_11_4  -1.0
    x_11_0    disj1_10_11_4  1.0
    x_11_0    disj2_10_11_4  -1.0
    x_11_0    disj1_11_12_4  -1.0
    x_11_0    disj2_11_12_4  1.0
    x_11_0    disj1_11_13_4  -1.0
    x_11_0    disj2_11_13_4  1.0
    x_11_0    disj1_11_14_4  -1.0
    x_11_0    disj2_11_14_4  1.0
    x_11_1    prec_11_0  1.0
    x_11_1    prec_11_1  -1.0
    x_11_1    disj1_0_11_3  1.0
    x_11_1    disj2_0_11_3  -1.0
    x_11_1    disj1_1_11_3  1.0
    x_11_1    disj2_1_11_3  -1.0
    x_11_1    disj1_2_11_3  1.0
    x_11_1    disj2_2_11_3  -1.0
    x_11_1    disj1_3_11_3  1.0
    x_11_1    disj2_3_11_3  -1.0
    x_11_1    disj1_4_11_3  1.0
    x_11_1    disj2_4_11_3  -1.0
    x_11_1    disj1_5_11_3  1.0
    x_11_1    disj2_5_11_3  -1.0
    x_11_1    disj1_6_11_3  1.0
    x_11_1    disj2_6_11_3  -1.0
    x_11_1    disj1_7_11_3  1.0
    x_11_1    disj2_7_11_3  -1.0
    x_11_1    disj1_8_11_3  1.0
    x_11_1    disj2_8_11_3  -1.0
    x_11_1    disj1_9_11_3  1.0
    x_11_1    disj2_9_11_3  -1.0
    x_11_1    disj1_10_11_3  1.0
    x_11_1    disj2_10_11_3  -1.0
    x_11_1    disj1_11_12_3  -1.0
    x_11_1    disj2_11_12_3  1.0
    x_11_1    disj1_11_13_3  -1.0
    x_11_1    disj2_11_13_3  1.0
    x_11_1    disj1_11_14_3  -1.0
    x_11_1    disj2_11_14_3  1.0
    x_11_2    prec_11_1  1.0
    x_11_2    prec_11_2  -1.0
    x_11_2    disj1_0_11_0  1.0
    x_11_2    disj2_0_11_0  -1.0
    x_11_2    disj1_1_11_0  1.0
    x_11_2    disj2_1_11_0  -1.0
    x_11_2    disj1_2_11_0  1.0
    x_11_2    disj2_2_11_0  -1.0
    x_11_2    disj1_3_11_0  1.0
    x_11_2    disj2_3_11_0  -1.0
    x_11_2    disj1_4_11_0  1.0
    x_11_2    disj2_4_11_0  -1.0
    x_11_2    disj1_5_11_0  1.0
    x_11_2    disj2_5_11_0  -1.0
    x_11_2    disj1_6_11_0  1.0
    x_11_2    disj2_6_11_0  -1.0
    x_11_2    disj1_7_11_0  1.0
    x_11_2    disj2_7_11_0  -1.0
    x_11_2    disj1_8_11_0  1.0
    x_11_2    disj2_8_11_0  -1.0
    x_11_2    disj1_9_11_0  1.0
    x_11_2    disj2_9_11_0  -1.0
    x_11_2    disj1_10_11_0  1.0
    x_11_2    disj2_10_11_0  -1.0
    x_11_2    disj1_11_12_0  -1.0
    x_11_2    disj2_11_12_0  1.0
    x_11_2    disj1_11_13_0  -1.0
    x_11_2    disj2_11_13_0  1.0
    x_11_2    disj1_11_14_0  -1.0
    x_11_2    disj2_11_14_0  1.0
    x_11_3    prec_11_2  1.0
    x_11_3    prec_11_3  -1.0
    x_11_3    disj1_0_11_2  1.0
    x_11_3    disj2_0_11_2  -1.0
    x_11_3    disj1_1_11_2  1.0
    x_11_3    disj2_1_11_2  -1.0
    x_11_3    disj1_2_11_2  1.0
    x_11_3    disj2_2_11_2  -1.0
    x_11_3    disj1_3_11_2  1.0
    x_11_3    disj2_3_11_2  -1.0
    x_11_3    disj1_4_11_2  1.0
    x_11_3    disj2_4_11_2  -1.0
    x_11_3    disj1_5_11_2  1.0
    x_11_3    disj2_5_11_2  -1.0
    x_11_3    disj1_6_11_2  1.0
    x_11_3    disj2_6_11_2  -1.0
    x_11_3    disj1_7_11_2  1.0
    x_11_3    disj2_7_11_2  -1.0
    x_11_3    disj1_8_11_2  1.0
    x_11_3    disj2_8_11_2  -1.0
    x_11_3    disj1_9_11_2  1.0
    x_11_3    disj2_9_11_2  -1.0
    x_11_3    disj1_10_11_2  1.0
    x_11_3    disj2_10_11_2  -1.0
    x_11_3    disj1_11_12_2  -1.0
    x_11_3    disj2_11_12_2  1.0
    x_11_3    disj1_11_13_2  -1.0
    x_11_3    disj2_11_13_2  1.0
    x_11_3    disj1_11_14_2  -1.0
    x_11_3    disj2_11_14_2  1.0
    x_11_4    prec_11_3  1.0
    x_11_4    mksp_11   -1.0
    x_11_4    disj1_0_11_1  1.0
    x_11_4    disj2_0_11_1  -1.0
    x_11_4    disj1_1_11_1  1.0
    x_11_4    disj2_1_11_1  -1.0
    x_11_4    disj1_2_11_1  1.0
    x_11_4    disj2_2_11_1  -1.0
    x_11_4    disj1_3_11_1  1.0
    x_11_4    disj2_3_11_1  -1.0
    x_11_4    disj1_4_11_1  1.0
    x_11_4    disj2_4_11_1  -1.0
    x_11_4    disj1_5_11_1  1.0
    x_11_4    disj2_5_11_1  -1.0
    x_11_4    disj1_6_11_1  1.0
    x_11_4    disj2_6_11_1  -1.0
    x_11_4    disj1_7_11_1  1.0
    x_11_4    disj2_7_11_1  -1.0
    x_11_4    disj1_8_11_1  1.0
    x_11_4    disj2_8_11_1  -1.0
    x_11_4    disj1_9_11_1  1.0
    x_11_4    disj2_9_11_1  -1.0
    x_11_4    disj1_10_11_1  1.0
    x_11_4    disj2_10_11_1  -1.0
    x_11_4    disj1_11_12_1  -1.0
    x_11_4    disj2_11_12_1  1.0
    x_11_4    disj1_11_13_1  -1.0
    x_11_4    disj2_11_13_1  1.0
    x_11_4    disj1_11_14_1  -1.0
    x_11_4    disj2_11_14_1  1.0
    x_12_0    prec_12_0  -1.0
    x_12_0    disj1_0_12_1  1.0
    x_12_0    disj2_0_12_1  -1.0
    x_12_0    disj1_1_12_1  1.0
    x_12_0    disj2_1_12_1  -1.0
    x_12_0    disj1_2_12_1  1.0
    x_12_0    disj2_2_12_1  -1.0
    x_12_0    disj1_3_12_1  1.0
    x_12_0    disj2_3_12_1  -1.0
    x_12_0    disj1_4_12_1  1.0
    x_12_0    disj2_4_12_1  -1.0
    x_12_0    disj1_5_12_1  1.0
    x_12_0    disj2_5_12_1  -1.0
    x_12_0    disj1_6_12_1  1.0
    x_12_0    disj2_6_12_1  -1.0
    x_12_0    disj1_7_12_1  1.0
    x_12_0    disj2_7_12_1  -1.0
    x_12_0    disj1_8_12_1  1.0
    x_12_0    disj2_8_12_1  -1.0
    x_12_0    disj1_9_12_1  1.0
    x_12_0    disj2_9_12_1  -1.0
    x_12_0    disj1_10_12_1  1.0
    x_12_0    disj2_10_12_1  -1.0
    x_12_0    disj1_11_12_1  1.0
    x_12_0    disj2_11_12_1  -1.0
    x_12_0    disj1_12_13_1  -1.0
    x_12_0    disj2_12_13_1  1.0
    x_12_0    disj1_12_14_1  -1.0
    x_12_0    disj2_12_14_1  1.0
    x_12_1    prec_12_0  1.0
    x_12_1    prec_12_1  -1.0
    x_12_1    disj1_0_12_4  1.0
    x_12_1    disj2_0_12_4  -1.0
    x_12_1    disj1_1_12_4  1.0
    x_12_1    disj2_1_12_4  -1.0
    x_12_1    disj1_2_12_4  1.0
    x_12_1    disj2_2_12_4  -1.0
    x_12_1    disj1_3_12_4  1.0
    x_12_1    disj2_3_12_4  -1.0
    x_12_1    disj1_4_12_4  1.0
    x_12_1    disj2_4_12_4  -1.0
    x_12_1    disj1_5_12_4  1.0
    x_12_1    disj2_5_12_4  -1.0
    x_12_1    disj1_6_12_4  1.0
    x_12_1    disj2_6_12_4  -1.0
    x_12_1    disj1_7_12_4  1.0
    x_12_1    disj2_7_12_4  -1.0
    x_12_1    disj1_8_12_4  1.0
    x_12_1    disj2_8_12_4  -1.0
    x_12_1    disj1_9_12_4  1.0
    x_12_1    disj2_9_12_4  -1.0
    x_12_1    disj1_10_12_4  1.0
    x_12_1    disj2_10_12_4  -1.0
    x_12_1    disj1_11_12_4  1.0
    x_12_1    disj2_11_12_4  -1.0
    x_12_1    disj1_12_13_4  -1.0
    x_12_1    disj2_12_13_4  1.0
    x_12_1    disj1_12_14_4  -1.0
    x_12_1    disj2_12_14_4  1.0
    x_12_2    prec_12_1  1.0
    x_12_2    prec_12_2  -1.0
    x_12_2    disj1_0_12_2  1.0
    x_12_2    disj2_0_12_2  -1.0
    x_12_2    disj1_1_12_2  1.0
    x_12_2    disj2_1_12_2  -1.0
    x_12_2    disj1_2_12_2  1.0
    x_12_2    disj2_2_12_2  -1.0
    x_12_2    disj1_3_12_2  1.0
    x_12_2    disj2_3_12_2  -1.0
    x_12_2    disj1_4_12_2  1.0
    x_12_2    disj2_4_12_2  -1.0
    x_12_2    disj1_5_12_2  1.0
    x_12_2    disj2_5_12_2  -1.0
    x_12_2    disj1_6_12_2  1.0
    x_12_2    disj2_6_12_2  -1.0
    x_12_2    disj1_7_12_2  1.0
    x_12_2    disj2_7_12_2  -1.0
    x_12_2    disj1_8_12_2  1.0
    x_12_2    disj2_8_12_2  -1.0
    x_12_2    disj1_9_12_2  1.0
    x_12_2    disj2_9_12_2  -1.0
    x_12_2    disj1_10_12_2  1.0
    x_12_2    disj2_10_12_2  -1.0
    x_12_2    disj1_11_12_2  1.0
    x_12_2    disj2_11_12_2  -1.0
    x_12_2    disj1_12_13_2  -1.0
    x_12_2    disj2_12_13_2  1.0
    x_12_2    disj1_12_14_2  -1.0
    x_12_2    disj2_12_14_2  1.0
    x_12_3    prec_12_2  1.0
    x_12_3    prec_12_3  -1.0
    x_12_3    disj1_0_12_0  1.0
    x_12_3    disj2_0_12_0  -1.0
    x_12_3    disj1_1_12_0  1.0
    x_12_3    disj2_1_12_0  -1.0
    x_12_3    disj1_2_12_0  1.0
    x_12_3    disj2_2_12_0  -1.0
    x_12_3    disj1_3_12_0  1.0
    x_12_3    disj2_3_12_0  -1.0
    x_12_3    disj1_4_12_0  1.0
    x_12_3    disj2_4_12_0  -1.0
    x_12_3    disj1_5_12_0  1.0
    x_12_3    disj2_5_12_0  -1.0
    x_12_3    disj1_6_12_0  1.0
    x_12_3    disj2_6_12_0  -1.0
    x_12_3    disj1_7_12_0  1.0
    x_12_3    disj2_7_12_0  -1.0
    x_12_3    disj1_8_12_0  1.0
    x_12_3    disj2_8_12_0  -1.0
    x_12_3    disj1_9_12_0  1.0
    x_12_3    disj2_9_12_0  -1.0
    x_12_3    disj1_10_12_0  1.0
    x_12_3    disj2_10_12_0  -1.0
    x_12_3    disj1_11_12_0  1.0
    x_12_3    disj2_11_12_0  -1.0
    x_12_3    disj1_12_13_0  -1.0
    x_12_3    disj2_12_13_0  1.0
    x_12_3    disj1_12_14_0  -1.0
    x_12_3    disj2_12_14_0  1.0
    x_12_4    prec_12_3  1.0
    x_12_4    mksp_12   -1.0
    x_12_4    disj1_0_12_3  1.0
    x_12_4    disj2_0_12_3  -1.0
    x_12_4    disj1_1_12_3  1.0
    x_12_4    disj2_1_12_3  -1.0
    x_12_4    disj1_2_12_3  1.0
    x_12_4    disj2_2_12_3  -1.0
    x_12_4    disj1_3_12_3  1.0
    x_12_4    disj2_3_12_3  -1.0
    x_12_4    disj1_4_12_3  1.0
    x_12_4    disj2_4_12_3  -1.0
    x_12_4    disj1_5_12_3  1.0
    x_12_4    disj2_5_12_3  -1.0
    x_12_4    disj1_6_12_3  1.0
    x_12_4    disj2_6_12_3  -1.0
    x_12_4    disj1_7_12_3  1.0
    x_12_4    disj2_7_12_3  -1.0
    x_12_4    disj1_8_12_3  1.0
    x_12_4    disj2_8_12_3  -1.0
    x_12_4    disj1_9_12_3  1.0
    x_12_4    disj2_9_12_3  -1.0
    x_12_4    disj1_10_12_3  1.0
    x_12_4    disj2_10_12_3  -1.0
    x_12_4    disj1_11_12_3  1.0
    x_12_4    disj2_11_12_3  -1.0
    x_12_4    disj1_12_13_3  -1.0
    x_12_4    disj2_12_13_3  1.0
    x_12_4    disj1_12_14_3  -1.0
    x_12_4    disj2_12_14_3  1.0
    x_13_0    prec_13_0  -1.0
    x_13_0    disj1_0_13_0  1.0
    x_13_0    disj2_0_13_0  -1.0
    x_13_0    disj1_1_13_0  1.0
    x_13_0    disj2_1_13_0  -1.0
    x_13_0    disj1_2_13_0  1.0
    x_13_0    disj2_2_13_0  -1.0
    x_13_0    disj1_3_13_0  1.0
    x_13_0    disj2_3_13_0  -1.0
    x_13_0    disj1_4_13_0  1.0
    x_13_0    disj2_4_13_0  -1.0
    x_13_0    disj1_5_13_0  1.0
    x_13_0    disj2_5_13_0  -1.0
    x_13_0    disj1_6_13_0  1.0
    x_13_0    disj2_6_13_0  -1.0
    x_13_0    disj1_7_13_0  1.0
    x_13_0    disj2_7_13_0  -1.0
    x_13_0    disj1_8_13_0  1.0
    x_13_0    disj2_8_13_0  -1.0
    x_13_0    disj1_9_13_0  1.0
    x_13_0    disj2_9_13_0  -1.0
    x_13_0    disj1_10_13_0  1.0
    x_13_0    disj2_10_13_0  -1.0
    x_13_0    disj1_11_13_0  1.0
    x_13_0    disj2_11_13_0  -1.0
    x_13_0    disj1_12_13_0  1.0
    x_13_0    disj2_12_13_0  -1.0
    x_13_0    disj1_13_14_0  -1.0
    x_13_0    disj2_13_14_0  1.0
    x_13_1    prec_13_0  1.0
    x_13_1    prec_13_1  -1.0
    x_13_1    disj1_0_13_1  1.0
    x_13_1    disj2_0_13_1  -1.0
    x_13_1    disj1_1_13_1  1.0
    x_13_1    disj2_1_13_1  -1.0
    x_13_1    disj1_2_13_1  1.0
    x_13_1    disj2_2_13_1  -1.0
    x_13_1    disj1_3_13_1  1.0
    x_13_1    disj2_3_13_1  -1.0
    x_13_1    disj1_4_13_1  1.0
    x_13_1    disj2_4_13_1  -1.0
    x_13_1    disj1_5_13_1  1.0
    x_13_1    disj2_5_13_1  -1.0
    x_13_1    disj1_6_13_1  1.0
    x_13_1    disj2_6_13_1  -1.0
    x_13_1    disj1_7_13_1  1.0
    x_13_1    disj2_7_13_1  -1.0
    x_13_1    disj1_8_13_1  1.0
    x_13_1    disj2_8_13_1  -1.0
    x_13_1    disj1_9_13_1  1.0
    x_13_1    disj2_9_13_1  -1.0
    x_13_1    disj1_10_13_1  1.0
    x_13_1    disj2_10_13_1  -1.0
    x_13_1    disj1_11_13_1  1.0
    x_13_1    disj2_11_13_1  -1.0
    x_13_1    disj1_12_13_1  1.0
    x_13_1    disj2_12_13_1  -1.0
    x_13_1    disj1_13_14_1  -1.0
    x_13_1    disj2_13_14_1  1.0
    x_13_2    prec_13_1  1.0
    x_13_2    prec_13_2  -1.0
    x_13_2    disj1_0_13_3  1.0
    x_13_2    disj2_0_13_3  -1.0
    x_13_2    disj1_1_13_3  1.0
    x_13_2    disj2_1_13_3  -1.0
    x_13_2    disj1_2_13_3  1.0
    x_13_2    disj2_2_13_3  -1.0
    x_13_2    disj1_3_13_3  1.0
    x_13_2    disj2_3_13_3  -1.0
    x_13_2    disj1_4_13_3  1.0
    x_13_2    disj2_4_13_3  -1.0
    x_13_2    disj1_5_13_3  1.0
    x_13_2    disj2_5_13_3  -1.0
    x_13_2    disj1_6_13_3  1.0
    x_13_2    disj2_6_13_3  -1.0
    x_13_2    disj1_7_13_3  1.0
    x_13_2    disj2_7_13_3  -1.0
    x_13_2    disj1_8_13_3  1.0
    x_13_2    disj2_8_13_3  -1.0
    x_13_2    disj1_9_13_3  1.0
    x_13_2    disj2_9_13_3  -1.0
    x_13_2    disj1_10_13_3  1.0
    x_13_2    disj2_10_13_3  -1.0
    x_13_2    disj1_11_13_3  1.0
    x_13_2    disj2_11_13_3  -1.0
    x_13_2    disj1_12_13_3  1.0
    x_13_2    disj2_12_13_3  -1.0
    x_13_2    disj1_13_14_3  -1.0
    x_13_2    disj2_13_14_3  1.0
    x_13_3    prec_13_2  1.0
    x_13_3    prec_13_3  -1.0
    x_13_3    disj1_0_13_4  1.0
    x_13_3    disj2_0_13_4  -1.0
    x_13_3    disj1_1_13_4  1.0
    x_13_3    disj2_1_13_4  -1.0
    x_13_3    disj1_2_13_4  1.0
    x_13_3    disj2_2_13_4  -1.0
    x_13_3    disj1_3_13_4  1.0
    x_13_3    disj2_3_13_4  -1.0
    x_13_3    disj1_4_13_4  1.0
    x_13_3    disj2_4_13_4  -1.0
    x_13_3    disj1_5_13_4  1.0
    x_13_3    disj2_5_13_4  -1.0
    x_13_3    disj1_6_13_4  1.0
    x_13_3    disj2_6_13_4  -1.0
    x_13_3    disj1_7_13_4  1.0
    x_13_3    disj2_7_13_4  -1.0
    x_13_3    disj1_8_13_4  1.0
    x_13_3    disj2_8_13_4  -1.0
    x_13_3    disj1_9_13_4  1.0
    x_13_3    disj2_9_13_4  -1.0
    x_13_3    disj1_10_13_4  1.0
    x_13_3    disj2_10_13_4  -1.0
    x_13_3    disj1_11_13_4  1.0
    x_13_3    disj2_11_13_4  -1.0
    x_13_3    disj1_12_13_4  1.0
    x_13_3    disj2_12_13_4  -1.0
    x_13_3    disj1_13_14_4  -1.0
    x_13_3    disj2_13_14_4  1.0
    x_13_4    prec_13_3  1.0
    x_13_4    mksp_13   -1.0
    x_13_4    disj1_0_13_2  1.0
    x_13_4    disj2_0_13_2  -1.0
    x_13_4    disj1_1_13_2  1.0
    x_13_4    disj2_1_13_2  -1.0
    x_13_4    disj1_2_13_2  1.0
    x_13_4    disj2_2_13_2  -1.0
    x_13_4    disj1_3_13_2  1.0
    x_13_4    disj2_3_13_2  -1.0
    x_13_4    disj1_4_13_2  1.0
    x_13_4    disj2_4_13_2  -1.0
    x_13_4    disj1_5_13_2  1.0
    x_13_4    disj2_5_13_2  -1.0
    x_13_4    disj1_6_13_2  1.0
    x_13_4    disj2_6_13_2  -1.0
    x_13_4    disj1_7_13_2  1.0
    x_13_4    disj2_7_13_2  -1.0
    x_13_4    disj1_8_13_2  1.0
    x_13_4    disj2_8_13_2  -1.0
    x_13_4    disj1_9_13_2  1.0
    x_13_4    disj2_9_13_2  -1.0
    x_13_4    disj1_10_13_2  1.0
    x_13_4    disj2_10_13_2  -1.0
    x_13_4    disj1_11_13_2  1.0
    x_13_4    disj2_11_13_2  -1.0
    x_13_4    disj1_12_13_2  1.0
    x_13_4    disj2_12_13_2  -1.0
    x_13_4    disj1_13_14_2  -1.0
    x_13_4    disj2_13_14_2  1.0
    x_14_0    prec_14_0  -1.0
    x_14_0    disj1_0_14_3  1.0
    x_14_0    disj2_0_14_3  -1.0
    x_14_0    disj1_1_14_3  1.0
    x_14_0    disj2_1_14_3  -1.0
    x_14_0    disj1_2_14_3  1.0
    x_14_0    disj2_2_14_3  -1.0
    x_14_0    disj1_3_14_3  1.0
    x_14_0    disj2_3_14_3  -1.0
    x_14_0    disj1_4_14_3  1.0
    x_14_0    disj2_4_14_3  -1.0
    x_14_0    disj1_5_14_3  1.0
    x_14_0    disj2_5_14_3  -1.0
    x_14_0    disj1_6_14_3  1.0
    x_14_0    disj2_6_14_3  -1.0
    x_14_0    disj1_7_14_3  1.0
    x_14_0    disj2_7_14_3  -1.0
    x_14_0    disj1_8_14_3  1.0
    x_14_0    disj2_8_14_3  -1.0
    x_14_0    disj1_9_14_3  1.0
    x_14_0    disj2_9_14_3  -1.0
    x_14_0    disj1_10_14_3  1.0
    x_14_0    disj2_10_14_3  -1.0
    x_14_0    disj1_11_14_3  1.0
    x_14_0    disj2_11_14_3  -1.0
    x_14_0    disj1_12_14_3  1.0
    x_14_0    disj2_12_14_3  -1.0
    x_14_0    disj1_13_14_3  1.0
    x_14_0    disj2_13_14_3  -1.0
    x_14_1    prec_14_0  1.0
    x_14_1    prec_14_1  -1.0
    x_14_1    disj1_0_14_4  1.0
    x_14_1    disj2_0_14_4  -1.0
    x_14_1    disj1_1_14_4  1.0
    x_14_1    disj2_1_14_4  -1.0
    x_14_1    disj1_2_14_4  1.0
    x_14_1    disj2_2_14_4  -1.0
    x_14_1    disj1_3_14_4  1.0
    x_14_1    disj2_3_14_4  -1.0
    x_14_1    disj1_4_14_4  1.0
    x_14_1    disj2_4_14_4  -1.0
    x_14_1    disj1_5_14_4  1.0
    x_14_1    disj2_5_14_4  -1.0
    x_14_1    disj1_6_14_4  1.0
    x_14_1    disj2_6_14_4  -1.0
    x_14_1    disj1_7_14_4  1.0
    x_14_1    disj2_7_14_4  -1.0
    x_14_1    disj1_8_14_4  1.0
    x_14_1    disj2_8_14_4  -1.0
    x_14_1    disj1_9_14_4  1.0
    x_14_1    disj2_9_14_4  -1.0
    x_14_1    disj1_10_14_4  1.0
    x_14_1    disj2_10_14_4  -1.0
    x_14_1    disj1_11_14_4  1.0
    x_14_1    disj2_11_14_4  -1.0
    x_14_1    disj1_12_14_4  1.0
    x_14_1    disj2_12_14_4  -1.0
    x_14_1    disj1_13_14_4  1.0
    x_14_1    disj2_13_14_4  -1.0
    x_14_2    prec_14_1  1.0
    x_14_2    prec_14_2  -1.0
    x_14_2    disj1_0_14_0  1.0
    x_14_2    disj2_0_14_0  -1.0
    x_14_2    disj1_1_14_0  1.0
    x_14_2    disj2_1_14_0  -1.0
    x_14_2    disj1_2_14_0  1.0
    x_14_2    disj2_2_14_0  -1.0
    x_14_2    disj1_3_14_0  1.0
    x_14_2    disj2_3_14_0  -1.0
    x_14_2    disj1_4_14_0  1.0
    x_14_2    disj2_4_14_0  -1.0
    x_14_2    disj1_5_14_0  1.0
    x_14_2    disj2_5_14_0  -1.0
    x_14_2    disj1_6_14_0  1.0
    x_14_2    disj2_6_14_0  -1.0
    x_14_2    disj1_7_14_0  1.0
    x_14_2    disj2_7_14_0  -1.0
    x_14_2    disj1_8_14_0  1.0
    x_14_2    disj2_8_14_0  -1.0
    x_14_2    disj1_9_14_0  1.0
    x_14_2    disj2_9_14_0  -1.0
    x_14_2    disj1_10_14_0  1.0
    x_14_2    disj2_10_14_0  -1.0
    x_14_2    disj1_11_14_0  1.0
    x_14_2    disj2_11_14_0  -1.0
    x_14_2    disj1_12_14_0  1.0
    x_14_2    disj2_12_14_0  -1.0
    x_14_2    disj1_13_14_0  1.0
    x_14_2    disj2_13_14_0  -1.0
    x_14_3    prec_14_2  1.0
    x_14_3    prec_14_3  -1.0
    x_14_3    disj1_0_14_2  1.0
    x_14_3    disj2_0_14_2  -1.0
    x_14_3    disj1_1_14_2  1.0
    x_14_3    disj2_1_14_2  -1.0
    x_14_3    disj1_2_14_2  1.0
    x_14_3    disj2_2_14_2  -1.0
    x_14_3    disj1_3_14_2  1.0
    x_14_3    disj2_3_14_2  -1.0
    x_14_3    disj1_4_14_2  1.0
    x_14_3    disj2_4_14_2  -1.0
    x_14_3    disj1_5_14_2  1.0
    x_14_3    disj2_5_14_2  -1.0
    x_14_3    disj1_6_14_2  1.0
    x_14_3    disj2_6_14_2  -1.0
    x_14_3    disj1_7_14_2  1.0
    x_14_3    disj2_7_14_2  -1.0
    x_14_3    disj1_8_14_2  1.0
    x_14_3    disj2_8_14_2  -1.0
    x_14_3    disj1_9_14_2  1.0
    x_14_3    disj2_9_14_2  -1.0
    x_14_3    disj1_10_14_2  1.0
    x_14_3    disj2_10_14_2  -1.0
    x_14_3    disj1_11_14_2  1.0
    x_14_3    disj2_11_14_2  -1.0
    x_14_3    disj1_12_14_2  1.0
    x_14_3    disj2_12_14_2  -1.0
    x_14_3    disj1_13_14_2  1.0
    x_14_3    disj2_13_14_2  -1.0
    x_14_4    prec_14_3  1.0
    x_14_4    mksp_14   -1.0
    x_14_4    disj1_0_14_1  1.0
    x_14_4    disj2_0_14_1  -1.0
    x_14_4    disj1_1_14_1  1.0
    x_14_4    disj2_1_14_1  -1.0
    x_14_4    disj1_2_14_1  1.0
    x_14_4    disj2_2_14_1  -1.0
    x_14_4    disj1_3_14_1  1.0
    x_14_4    disj2_3_14_1  -1.0
    x_14_4    disj1_4_14_1  1.0
    x_14_4    disj2_4_14_1  -1.0
    x_14_4    disj1_5_14_1  1.0
    x_14_4    disj2_5_14_1  -1.0
    x_14_4    disj1_6_14_1  1.0
    x_14_4    disj2_6_14_1  -1.0
    x_14_4    disj1_7_14_1  1.0
    x_14_4    disj2_7_14_1  -1.0
    x_14_4    disj1_8_14_1  1.0
    x_14_4    disj2_8_14_1  -1.0
    x_14_4    disj1_9_14_1  1.0
    x_14_4    disj2_9_14_1  -1.0
    x_14_4    disj1_10_14_1  1.0
    x_14_4    disj2_10_14_1  -1.0
    x_14_4    disj1_11_14_1  1.0
    x_14_4    disj2_11_14_1  -1.0
    x_14_4    disj1_12_14_1  1.0
    x_14_4    disj2_12_14_1  -1.0
    x_14_4    disj1_13_14_1  1.0
    x_14_4    disj2_13_14_1  -1.0
    MARK0000  'MARKER'                 'INTORG'
    y_0_1_0   disj1_0_1_0  4090
    y_0_1_0   disj2_0_1_0  -4090
    y_0_1_1   disj1_0_1_1  4090
    y_0_1_1   disj2_0_1_1  -4090
    y_0_1_2   disj1_0_1_2  4090
    y_0_1_2   disj2_0_1_2  -4090
    y_0_1_3   disj1_0_1_3  4090
    y_0_1_3   disj2_0_1_3  -4090
    y_0_1_4   disj1_0_1_4  4090
    y_0_1_4   disj2_0_1_4  -4090
    y_0_2_0   disj1_0_2_0  4090
    y_0_2_0   disj2_0_2_0  -4090
    y_0_2_1   disj1_0_2_1  4090
    y_0_2_1   disj2_0_2_1  -4090
    y_0_2_2   disj1_0_2_2  4090
    y_0_2_2   disj2_0_2_2  -4090
    y_0_2_3   disj1_0_2_3  4090
    y_0_2_3   disj2_0_2_3  -4090
    y_0_2_4   disj1_0_2_4  4090
    y_0_2_4   disj2_0_2_4  -4090
    y_0_3_0   disj1_0_3_0  4090
    y_0_3_0   disj2_0_3_0  -4090
    y_0_3_1   disj1_0_3_1  4090
    y_0_3_1   disj2_0_3_1  -4090
    y_0_3_2   disj1_0_3_2  4090
    y_0_3_2   disj2_0_3_2  -4090
    y_0_3_3   disj1_0_3_3  4090
    y_0_3_3   disj2_0_3_3  -4090
    y_0_3_4   disj1_0_3_4  4090
    y_0_3_4   disj2_0_3_4  -4090
    y_0_4_0   disj1_0_4_0  4090
    y_0_4_0   disj2_0_4_0  -4090
    y_0_4_1   disj1_0_4_1  4090
    y_0_4_1   disj2_0_4_1  -4090
    y_0_4_2   disj1_0_4_2  4090
    y_0_4_2   disj2_0_4_2  -4090
    y_0_4_3   disj1_0_4_3  4090
    y_0_4_3   disj2_0_4_3  -4090
    y_0_4_4   disj1_0_4_4  4090
    y_0_4_4   disj2_0_4_4  -4090
    y_0_5_0   disj1_0_5_0  4090
    y_0_5_0   disj2_0_5_0  -4090
    y_0_5_1   disj1_0_5_1  4090
    y_0_5_1   disj2_0_5_1  -4090
    y_0_5_2   disj1_0_5_2  4090
    y_0_5_2   disj2_0_5_2  -4090
    y_0_5_3   disj1_0_5_3  4090
    y_0_5_3   disj2_0_5_3  -4090
    y_0_5_4   disj1_0_5_4  4090
    y_0_5_4   disj2_0_5_4  -4090
    y_0_6_0   disj1_0_6_0  4090
    y_0_6_0   disj2_0_6_0  -4090
    y_0_6_1   disj1_0_6_1  4090
    y_0_6_1   disj2_0_6_1  -4090
    y_0_6_2   disj1_0_6_2  4090
    y_0_6_2   disj2_0_6_2  -4090
    y_0_6_3   disj1_0_6_3  4090
    y_0_6_3   disj2_0_6_3  -4090
    y_0_6_4   disj1_0_6_4  4090
    y_0_6_4   disj2_0_6_4  -4090
    y_0_7_0   disj1_0_7_0  4090
    y_0_7_0   disj2_0_7_0  -4090
    y_0_7_1   disj1_0_7_1  4090
    y_0_7_1   disj2_0_7_1  -4090
    y_0_7_2   disj1_0_7_2  4090
    y_0_7_2   disj2_0_7_2  -4090
    y_0_7_3   disj1_0_7_3  4090
    y_0_7_3   disj2_0_7_3  -4090
    y_0_7_4   disj1_0_7_4  4090
    y_0_7_4   disj2_0_7_4  -4090
    y_0_8_0   disj1_0_8_0  4090
    y_0_8_0   disj2_0_8_0  -4090
    y_0_8_1   disj1_0_8_1  4090
    y_0_8_1   disj2_0_8_1  -4090
    y_0_8_2   disj1_0_8_2  4090
    y_0_8_2   disj2_0_8_2  -4090
    y_0_8_3   disj1_0_8_3  4090
    y_0_8_3   disj2_0_8_3  -4090
    y_0_8_4   disj1_0_8_4  4090
    y_0_8_4   disj2_0_8_4  -4090
    y_0_9_0   disj1_0_9_0  4090
    y_0_9_0   disj2_0_9_0  -4090
    y_0_9_1   disj1_0_9_1  4090
    y_0_9_1   disj2_0_9_1  -4090
    y_0_9_2   disj1_0_9_2  4090
    y_0_9_2   disj2_0_9_2  -4090
    y_0_9_3   disj1_0_9_3  4090
    y_0_9_3   disj2_0_9_3  -4090
    y_0_9_4   disj1_0_9_4  4090
    y_0_9_4   disj2_0_9_4  -4090
    y_0_10_0  disj1_0_10_0  4090
    y_0_10_0  disj2_0_10_0  -4090
    y_0_10_1  disj1_0_10_1  4090
    y_0_10_1  disj2_0_10_1  -4090
    y_0_10_2  disj1_0_10_2  4090
    y_0_10_2  disj2_0_10_2  -4090
    y_0_10_3  disj1_0_10_3  4090
    y_0_10_3  disj2_0_10_3  -4090
    y_0_10_4  disj1_0_10_4  4090
    y_0_10_4  disj2_0_10_4  -4090
    y_0_11_0  disj1_0_11_0  4090
    y_0_11_0  disj2_0_11_0  -4090
    y_0_11_1  disj1_0_11_1  4090
    y_0_11_1  disj2_0_11_1  -4090
    y_0_11_2  disj1_0_11_2  4090
    y_0_11_2  disj2_0_11_2  -4090
    y_0_11_3  disj1_0_11_3  4090
    y_0_11_3  disj2_0_11_3  -4090
    y_0_11_4  disj1_0_11_4  4090
    y_0_11_4  disj2_0_11_4  -4090
    y_0_12_0  disj1_0_12_0  4090
    y_0_12_0  disj2_0_12_0  -4090
    y_0_12_1  disj1_0_12_1  4090
    y_0_12_1  disj2_0_12_1  -4090
    y_0_12_2  disj1_0_12_2  4090
    y_0_12_2  disj2_0_12_2  -4090
    y_0_12_3  disj1_0_12_3  4090
    y_0_12_3  disj2_0_12_3  -4090
    y_0_12_4  disj1_0_12_4  4090
    y_0_12_4  disj2_0_12_4  -4090
    y_0_13_0  disj1_0_13_0  4090
    y_0_13_0  disj2_0_13_0  -4090
    y_0_13_1  disj1_0_13_1  4090
    y_0_13_1  disj2_0_13_1  -4090
    y_0_13_2  disj1_0_13_2  4090
    y_0_13_2  disj2_0_13_2  -4090
    y_0_13_3  disj1_0_13_3  4090
    y_0_13_3  disj2_0_13_3  -4090
    y_0_13_4  disj1_0_13_4  4090
    y_0_13_4  disj2_0_13_4  -4090
    y_0_14_0  disj1_0_14_0  4090
    y_0_14_0  disj2_0_14_0  -4090
    y_0_14_1  disj1_0_14_1  4090
    y_0_14_1  disj2_0_14_1  -4090
    y_0_14_2  disj1_0_14_2  4090
    y_0_14_2  disj2_0_14_2  -4090
    y_0_14_3  disj1_0_14_3  4090
    y_0_14_3  disj2_0_14_3  -4090
    y_0_14_4  disj1_0_14_4  4090
    y_0_14_4  disj2_0_14_4  -4090
    y_1_2_0   disj1_1_2_0  4090
    y_1_2_0   disj2_1_2_0  -4090
    y_1_2_1   disj1_1_2_1  4090
    y_1_2_1   disj2_1_2_1  -4090
    y_1_2_2   disj1_1_2_2  4090
    y_1_2_2   disj2_1_2_2  -4090
    y_1_2_3   disj1_1_2_3  4090
    y_1_2_3   disj2_1_2_3  -4090
    y_1_2_4   disj1_1_2_4  4090
    y_1_2_4   disj2_1_2_4  -4090
    y_1_3_0   disj1_1_3_0  4090
    y_1_3_0   disj2_1_3_0  -4090
    y_1_3_1   disj1_1_3_1  4090
    y_1_3_1   disj2_1_3_1  -4090
    y_1_3_2   disj1_1_3_2  4090
    y_1_3_2   disj2_1_3_2  -4090
    y_1_3_3   disj1_1_3_3  4090
    y_1_3_3   disj2_1_3_3  -4090
    y_1_3_4   disj1_1_3_4  4090
    y_1_3_4   disj2_1_3_4  -4090
    y_1_4_0   disj1_1_4_0  4090
    y_1_4_0   disj2_1_4_0  -4090
    y_1_4_1   disj1_1_4_1  4090
    y_1_4_1   disj2_1_4_1  -4090
    y_1_4_2   disj1_1_4_2  4090
    y_1_4_2   disj2_1_4_2  -4090
    y_1_4_3   disj1_1_4_3  4090
    y_1_4_3   disj2_1_4_3  -4090
    y_1_4_4   disj1_1_4_4  4090
    y_1_4_4   disj2_1_4_4  -4090
    y_1_5_0   disj1_1_5_0  4090
    y_1_5_0   disj2_1_5_0  -4090
    y_1_5_1   disj1_1_5_1  4090
    y_1_5_1   disj2_1_5_1  -4090
    y_1_5_2   disj1_1_5_2  4090
    y_1_5_2   disj2_1_5_2  -4090
    y_1_5_3   disj1_1_5_3  4090
    y_1_5_3   disj2_1_5_3  -4090
    y_1_5_4   disj1_1_5_4  4090
    y_1_5_4   disj2_1_5_4  -4090
    y_1_6_0   disj1_1_6_0  4090
    y_1_6_0   disj2_1_6_0  -4090
    y_1_6_1   disj1_1_6_1  4090
    y_1_6_1   disj2_1_6_1  -4090
    y_1_6_2   disj1_1_6_2  4090
    y_1_6_2   disj2_1_6_2  -4090
    y_1_6_3   disj1_1_6_3  4090
    y_1_6_3   disj2_1_6_3  -4090
    y_1_6_4   disj1_1_6_4  4090
    y_1_6_4   disj2_1_6_4  -4090
    y_1_7_0   disj1_1_7_0  4090
    y_1_7_0   disj2_1_7_0  -4090
    y_1_7_1   disj1_1_7_1  4090
    y_1_7_1   disj2_1_7_1  -4090
    y_1_7_2   disj1_1_7_2  4090
    y_1_7_2   disj2_1_7_2  -4090
    y_1_7_3   disj1_1_7_3  4090
    y_1_7_3   disj2_1_7_3  -4090
    y_1_7_4   disj1_1_7_4  4090
    y_1_7_4   disj2_1_7_4  -4090
    y_1_8_0   disj1_1_8_0  4090
    y_1_8_0   disj2_1_8_0  -4090
    y_1_8_1   disj1_1_8_1  4090
    y_1_8_1   disj2_1_8_1  -4090
    y_1_8_2   disj1_1_8_2  4090
    y_1_8_2   disj2_1_8_2  -4090
    y_1_8_3   disj1_1_8_3  4090
    y_1_8_3   disj2_1_8_3  -4090
    y_1_8_4   disj1_1_8_4  4090
    y_1_8_4   disj2_1_8_4  -4090
    y_1_9_0   disj1_1_9_0  4090
    y_1_9_0   disj2_1_9_0  -4090
    y_1_9_1   disj1_1_9_1  4090
    y_1_9_1   disj2_1_9_1  -4090
    y_1_9_2   disj1_1_9_2  4090
    y_1_9_2   disj2_1_9_2  -4090
    y_1_9_3   disj1_1_9_3  4090
    y_1_9_3   disj2_1_9_3  -4090
    y_1_9_4   disj1_1_9_4  4090
    y_1_9_4   disj2_1_9_4  -4090
    y_1_10_0  disj1_1_10_0  4090
    y_1_10_0  disj2_1_10_0  -4090
    y_1_10_1  disj1_1_10_1  4090
    y_1_10_1  disj2_1_10_1  -4090
    y_1_10_2  disj1_1_10_2  4090
    y_1_10_2  disj2_1_10_2  -4090
    y_1_10_3  disj1_1_10_3  4090
    y_1_10_3  disj2_1_10_3  -4090
    y_1_10_4  disj1_1_10_4  4090
    y_1_10_4  disj2_1_10_4  -4090
    y_1_11_0  disj1_1_11_0  4090
    y_1_11_0  disj2_1_11_0  -4090
    y_1_11_1  disj1_1_11_1  4090
    y_1_11_1  disj2_1_11_1  -4090
    y_1_11_2  disj1_1_11_2  4090
    y_1_11_2  disj2_1_11_2  -4090
    y_1_11_3  disj1_1_11_3  4090
    y_1_11_3  disj2_1_11_3  -4090
    y_1_11_4  disj1_1_11_4  4090
    y_1_11_4  disj2_1_11_4  -4090
    y_1_12_0  disj1_1_12_0  4090
    y_1_12_0  disj2_1_12_0  -4090
    y_1_12_1  disj1_1_12_1  4090
    y_1_12_1  disj2_1_12_1  -4090
    y_1_12_2  disj1_1_12_2  4090
    y_1_12_2  disj2_1_12_2  -4090
    y_1_12_3  disj1_1_12_3  4090
    y_1_12_3  disj2_1_12_3  -4090
    y_1_12_4  disj1_1_12_4  4090
    y_1_12_4  disj2_1_12_4  -4090
    y_1_13_0  disj1_1_13_0  4090
    y_1_13_0  disj2_1_13_0  -4090
    y_1_13_1  disj1_1_13_1  4090
    y_1_13_1  disj2_1_13_1  -4090
    y_1_13_2  disj1_1_13_2  4090
    y_1_13_2  disj2_1_13_2  -4090
    y_1_13_3  disj1_1_13_3  4090
    y_1_13_3  disj2_1_13_3  -4090
    y_1_13_4  disj1_1_13_4  4090
    y_1_13_4  disj2_1_13_4  -4090
    y_1_14_0  disj1_1_14_0  4090
    y_1_14_0  disj2_1_14_0  -4090
    y_1_14_1  disj1_1_14_1  4090
    y_1_14_1  disj2_1_14_1  -4090
    y_1_14_2  disj1_1_14_2  4090
    y_1_14_2  disj2_1_14_2  -4090
    y_1_14_3  disj1_1_14_3  4090
    y_1_14_3  disj2_1_14_3  -4090
    y_1_14_4  disj1_1_14_4  4090
    y_1_14_4  disj2_1_14_4  -4090
    y_2_3_0   disj1_2_3_0  4090
    y_2_3_0   disj2_2_3_0  -4090
    y_2_3_1   disj1_2_3_1  4090
    y_2_3_1   disj2_2_3_1  -4090
    y_2_3_2   disj1_2_3_2  4090
    y_2_3_2   disj2_2_3_2  -4090
    y_2_3_3   disj1_2_3_3  4090
    y_2_3_3   disj2_2_3_3  -4090
    y_2_3_4   disj1_2_3_4  4090
    y_2_3_4   disj2_2_3_4  -4090
    y_2_4_0   disj1_2_4_0  4090
    y_2_4_0   disj2_2_4_0  -4090
    y_2_4_1   disj1_2_4_1  4090
    y_2_4_1   disj2_2_4_1  -4090
    y_2_4_2   disj1_2_4_2  4090
    y_2_4_2   disj2_2_4_2  -4090
    y_2_4_3   disj1_2_4_3  4090
    y_2_4_3   disj2_2_4_3  -4090
    y_2_4_4   disj1_2_4_4  4090
    y_2_4_4   disj2_2_4_4  -4090
    y_2_5_0   disj1_2_5_0  4090
    y_2_5_0   disj2_2_5_0  -4090
    y_2_5_1   disj1_2_5_1  4090
    y_2_5_1   disj2_2_5_1  -4090
    y_2_5_2   disj1_2_5_2  4090
    y_2_5_2   disj2_2_5_2  -4090
    y_2_5_3   disj1_2_5_3  4090
    y_2_5_3   disj2_2_5_3  -4090
    y_2_5_4   disj1_2_5_4  4090
    y_2_5_4   disj2_2_5_4  -4090
    y_2_6_0   disj1_2_6_0  4090
    y_2_6_0   disj2_2_6_0  -4090
    y_2_6_1   disj1_2_6_1  4090
    y_2_6_1   disj2_2_6_1  -4090
    y_2_6_2   disj1_2_6_2  4090
    y_2_6_2   disj2_2_6_2  -4090
    y_2_6_3   disj1_2_6_3  4090
    y_2_6_3   disj2_2_6_3  -4090
    y_2_6_4   disj1_2_6_4  4090
    y_2_6_4   disj2_2_6_4  -4090
    y_2_7_0   disj1_2_7_0  4090
    y_2_7_0   disj2_2_7_0  -4090
    y_2_7_1   disj1_2_7_1  4090
    y_2_7_1   disj2_2_7_1  -4090
    y_2_7_2   disj1_2_7_2  4090
    y_2_7_2   disj2_2_7_2  -4090
    y_2_7_3   disj1_2_7_3  4090
    y_2_7_3   disj2_2_7_3  -4090
    y_2_7_4   disj1_2_7_4  4090
    y_2_7_4   disj2_2_7_4  -4090
    y_2_8_0   disj1_2_8_0  4090
    y_2_8_0   disj2_2_8_0  -4090
    y_2_8_1   disj1_2_8_1  4090
    y_2_8_1   disj2_2_8_1  -4090
    y_2_8_2   disj1_2_8_2  4090
    y_2_8_2   disj2_2_8_2  -4090
    y_2_8_3   disj1_2_8_3  4090
    y_2_8_3   disj2_2_8_3  -4090
    y_2_8_4   disj1_2_8_4  4090
    y_2_8_4   disj2_2_8_4  -4090
    y_2_9_0   disj1_2_9_0  4090
    y_2_9_0   disj2_2_9_0  -4090
    y_2_9_1   disj1_2_9_1  4090
    y_2_9_1   disj2_2_9_1  -4090
    y_2_9_2   disj1_2_9_2  4090
    y_2_9_2   disj2_2_9_2  -4090
    y_2_9_3   disj1_2_9_3  4090
    y_2_9_3   disj2_2_9_3  -4090
    y_2_9_4   disj1_2_9_4  4090
    y_2_9_4   disj2_2_9_4  -4090
    y_2_10_0  disj1_2_10_0  4090
    y_2_10_0  disj2_2_10_0  -4090
    y_2_10_1  disj1_2_10_1  4090
    y_2_10_1  disj2_2_10_1  -4090
    y_2_10_2  disj1_2_10_2  4090
    y_2_10_2  disj2_2_10_2  -4090
    y_2_10_3  disj1_2_10_3  4090
    y_2_10_3  disj2_2_10_3  -4090
    y_2_10_4  disj1_2_10_4  4090
    y_2_10_4  disj2_2_10_4  -4090
    y_2_11_0  disj1_2_11_0  4090
    y_2_11_0  disj2_2_11_0  -4090
    y_2_11_1  disj1_2_11_1  4090
    y_2_11_1  disj2_2_11_1  -4090
    y_2_11_2  disj1_2_11_2  4090
    y_2_11_2  disj2_2_11_2  -4090
    y_2_11_3  disj1_2_11_3  4090
    y_2_11_3  disj2_2_11_3  -4090
    y_2_11_4  disj1_2_11_4  4090
    y_2_11_4  disj2_2_11_4  -4090
    y_2_12_0  disj1_2_12_0  4090
    y_2_12_0  disj2_2_12_0  -4090
    y_2_12_1  disj1_2_12_1  4090
    y_2_12_1  disj2_2_12_1  -4090
    y_2_12_2  disj1_2_12_2  4090
    y_2_12_2  disj2_2_12_2  -4090
    y_2_12_3  disj1_2_12_3  4090
    y_2_12_3  disj2_2_12_3  -4090
    y_2_12_4  disj1_2_12_4  4090
    y_2_12_4  disj2_2_12_4  -4090
    y_2_13_0  disj1_2_13_0  4090
    y_2_13_0  disj2_2_13_0  -4090
    y_2_13_1  disj1_2_13_1  4090
    y_2_13_1  disj2_2_13_1  -4090
    y_2_13_2  disj1_2_13_2  4090
    y_2_13_2  disj2_2_13_2  -4090
    y_2_13_3  disj1_2_13_3  4090
    y_2_13_3  disj2_2_13_3  -4090
    y_2_13_4  disj1_2_13_4  4090
    y_2_13_4  disj2_2_13_4  -4090
    y_2_14_0  disj1_2_14_0  4090
    y_2_14_0  disj2_2_14_0  -4090
    y_2_14_1  disj1_2_14_1  4090
    y_2_14_1  disj2_2_14_1  -4090
    y_2_14_2  disj1_2_14_2  4090
    y_2_14_2  disj2_2_14_2  -4090
    y_2_14_3  disj1_2_14_3  4090
    y_2_14_3  disj2_2_14_3  -4090
    y_2_14_4  disj1_2_14_4  4090
    y_2_14_4  disj2_2_14_4  -4090
    y_3_4_0   disj1_3_4_0  4090
    y_3_4_0   disj2_3_4_0  -4090
    y_3_4_1   disj1_3_4_1  4090
    y_3_4_1   disj2_3_4_1  -4090
    y_3_4_2   disj1_3_4_2  4090
    y_3_4_2   disj2_3_4_2  -4090
    y_3_4_3   disj1_3_4_3  4090
    y_3_4_3   disj2_3_4_3  -4090
    y_3_4_4   disj1_3_4_4  4090
    y_3_4_4   disj2_3_4_4  -4090
    y_3_5_0   disj1_3_5_0  4090
    y_3_5_0   disj2_3_5_0  -4090
    y_3_5_1   disj1_3_5_1  4090
    y_3_5_1   disj2_3_5_1  -4090
    y_3_5_2   disj1_3_5_2  4090
    y_3_5_2   disj2_3_5_2  -4090
    y_3_5_3   disj1_3_5_3  4090
    y_3_5_3   disj2_3_5_3  -4090
    y_3_5_4   disj1_3_5_4  4090
    y_3_5_4   disj2_3_5_4  -4090
    y_3_6_0   disj1_3_6_0  4090
    y_3_6_0   disj2_3_6_0  -4090
    y_3_6_1   disj1_3_6_1  4090
    y_3_6_1   disj2_3_6_1  -4090
    y_3_6_2   disj1_3_6_2  4090
    y_3_6_2   disj2_3_6_2  -4090
    y_3_6_3   disj1_3_6_3  4090
    y_3_6_3   disj2_3_6_3  -4090
    y_3_6_4   disj1_3_6_4  4090
    y_3_6_4   disj2_3_6_4  -4090
    y_3_7_0   disj1_3_7_0  4090
    y_3_7_0   disj2_3_7_0  -4090
    y_3_7_1   disj1_3_7_1  4090
    y_3_7_1   disj2_3_7_1  -4090
    y_3_7_2   disj1_3_7_2  4090
    y_3_7_2   disj2_3_7_2  -4090
    y_3_7_3   disj1_3_7_3  4090
    y_3_7_3   disj2_3_7_3  -4090
    y_3_7_4   disj1_3_7_4  4090
    y_3_7_4   disj2_3_7_4  -4090
    y_3_8_0   disj1_3_8_0  4090
    y_3_8_0   disj2_3_8_0  -4090
    y_3_8_1   disj1_3_8_1  4090
    y_3_8_1   disj2_3_8_1  -4090
    y_3_8_2   disj1_3_8_2  4090
    y_3_8_2   disj2_3_8_2  -4090
    y_3_8_3   disj1_3_8_3  4090
    y_3_8_3   disj2_3_8_3  -4090
    y_3_8_4   disj1_3_8_4  4090
    y_3_8_4   disj2_3_8_4  -4090
    y_3_9_0   disj1_3_9_0  4090
    y_3_9_0   disj2_3_9_0  -4090
    y_3_9_1   disj1_3_9_1  4090
    y_3_9_1   disj2_3_9_1  -4090
    y_3_9_2   disj1_3_9_2  4090
    y_3_9_2   disj2_3_9_2  -4090
    y_3_9_3   disj1_3_9_3  4090
    y_3_9_3   disj2_3_9_3  -4090
    y_3_9_4   disj1_3_9_4  4090
    y_3_9_4   disj2_3_9_4  -4090
    y_3_10_0  disj1_3_10_0  4090
    y_3_10_0  disj2_3_10_0  -4090
    y_3_10_1  disj1_3_10_1  4090
    y_3_10_1  disj2_3_10_1  -4090
    y_3_10_2  disj1_3_10_2  4090
    y_3_10_2  disj2_3_10_2  -4090
    y_3_10_3  disj1_3_10_3  4090
    y_3_10_3  disj2_3_10_3  -4090
    y_3_10_4  disj1_3_10_4  4090
    y_3_10_4  disj2_3_10_4  -4090
    y_3_11_0  disj1_3_11_0  4090
    y_3_11_0  disj2_3_11_0  -4090
    y_3_11_1  disj1_3_11_1  4090
    y_3_11_1  disj2_3_11_1  -4090
    y_3_11_2  disj1_3_11_2  4090
    y_3_11_2  disj2_3_11_2  -4090
    y_3_11_3  disj1_3_11_3  4090
    y_3_11_3  disj2_3_11_3  -4090
    y_3_11_4  disj1_3_11_4  4090
    y_3_11_4  disj2_3_11_4  -4090
    y_3_12_0  disj1_3_12_0  4090
    y_3_12_0  disj2_3_12_0  -4090
    y_3_12_1  disj1_3_12_1  4090
    y_3_12_1  disj2_3_12_1  -4090
    y_3_12_2  disj1_3_12_2  4090
    y_3_12_2  disj2_3_12_2  -4090
    y_3_12_3  disj1_3_12_3  4090
    y_3_12_3  disj2_3_12_3  -4090
    y_3_12_4  disj1_3_12_4  4090
    y_3_12_4  disj2_3_12_4  -4090
    y_3_13_0  disj1_3_13_0  4090
    y_3_13_0  disj2_3_13_0  -4090
    y_3_13_1  disj1_3_13_1  4090
    y_3_13_1  disj2_3_13_1  -4090
    y_3_13_2  disj1_3_13_2  4090
    y_3_13_2  disj2_3_13_2  -4090
    y_3_13_3  disj1_3_13_3  4090
    y_3_13_3  disj2_3_13_3  -4090
    y_3_13_4  disj1_3_13_4  4090
    y_3_13_4  disj2_3_13_4  -4090
    y_3_14_0  disj1_3_14_0  4090
    y_3_14_0  disj2_3_14_0  -4090
    y_3_14_1  disj1_3_14_1  4090
    y_3_14_1  disj2_3_14_1  -4090
    y_3_14_2  disj1_3_14_2  4090
    y_3_14_2  disj2_3_14_2  -4090
    y_3_14_3  disj1_3_14_3  4090
    y_3_14_3  disj2_3_14_3  -4090
    y_3_14_4  disj1_3_14_4  4090
    y_3_14_4  disj2_3_14_4  -4090
    y_4_5_0   disj1_4_5_0  4090
    y_4_5_0   disj2_4_5_0  -4090
    y_4_5_1   disj1_4_5_1  4090
    y_4_5_1   disj2_4_5_1  -4090
    y_4_5_2   disj1_4_5_2  4090
    y_4_5_2   disj2_4_5_2  -4090
    y_4_5_3   disj1_4_5_3  4090
    y_4_5_3   disj2_4_5_3  -4090
    y_4_5_4   disj1_4_5_4  4090
    y_4_5_4   disj2_4_5_4  -4090
    y_4_6_0   disj1_4_6_0  4090
    y_4_6_0   disj2_4_6_0  -4090
    y_4_6_1   disj1_4_6_1  4090
    y_4_6_1   disj2_4_6_1  -4090
    y_4_6_2   disj1_4_6_2  4090
    y_4_6_2   disj2_4_6_2  -4090
    y_4_6_3   disj1_4_6_3  4090
    y_4_6_3   disj2_4_6_3  -4090
    y_4_6_4   disj1_4_6_4  4090
    y_4_6_4   disj2_4_6_4  -4090
    y_4_7_0   disj1_4_7_0  4090
    y_4_7_0   disj2_4_7_0  -4090
    y_4_7_1   disj1_4_7_1  4090
    y_4_7_1   disj2_4_7_1  -4090
    y_4_7_2   disj1_4_7_2  4090
    y_4_7_2   disj2_4_7_2  -4090
    y_4_7_3   disj1_4_7_3  4090
    y_4_7_3   disj2_4_7_3  -4090
    y_4_7_4   disj1_4_7_4  4090
    y_4_7_4   disj2_4_7_4  -4090
    y_4_8_0   disj1_4_8_0  4090
    y_4_8_0   disj2_4_8_0  -4090
    y_4_8_1   disj1_4_8_1  4090
    y_4_8_1   disj2_4_8_1  -4090
    y_4_8_2   disj1_4_8_2  4090
    y_4_8_2   disj2_4_8_2  -4090
    y_4_8_3   disj1_4_8_3  4090
    y_4_8_3   disj2_4_8_3  -4090
    y_4_8_4   disj1_4_8_4  4090
    y_4_8_4   disj2_4_8_4  -4090
    y_4_9_0   disj1_4_9_0  4090
    y_4_9_0   disj2_4_9_0  -4090
    y_4_9_1   disj1_4_9_1  4090
    y_4_9_1   disj2_4_9_1  -4090
    y_4_9_2   disj1_4_9_2  4090
    y_4_9_2   disj2_4_9_2  -4090
    y_4_9_3   disj1_4_9_3  4090
    y_4_9_3   disj2_4_9_3  -4090
    y_4_9_4   disj1_4_9_4  4090
    y_4_9_4   disj2_4_9_4  -4090
    y_4_10_0  disj1_4_10_0  4090
    y_4_10_0  disj2_4_10_0  -4090
    y_4_10_1  disj1_4_10_1  4090
    y_4_10_1  disj2_4_10_1  -4090
    y_4_10_2  disj1_4_10_2  4090
    y_4_10_2  disj2_4_10_2  -4090
    y_4_10_3  disj1_4_10_3  4090
    y_4_10_3  disj2_4_10_3  -4090
    y_4_10_4  disj1_4_10_4  4090
    y_4_10_4  disj2_4_10_4  -4090
    y_4_11_0  disj1_4_11_0  4090
    y_4_11_0  disj2_4_11_0  -4090
    y_4_11_1  disj1_4_11_1  4090
    y_4_11_1  disj2_4_11_1  -4090
    y_4_11_2  disj1_4_11_2  4090
    y_4_11_2  disj2_4_11_2  -4090
    y_4_11_3  disj1_4_11_3  4090
    y_4_11_3  disj2_4_11_3  -4090
    y_4_11_4  disj1_4_11_4  4090
    y_4_11_4  disj2_4_11_4  -4090
    y_4_12_0  disj1_4_12_0  4090
    y_4_12_0  disj2_4_12_0  -4090
    y_4_12_1  disj1_4_12_1  4090
    y_4_12_1  disj2_4_12_1  -4090
    y_4_12_2  disj1_4_12_2  4090
    y_4_12_2  disj2_4_12_2  -4090
    y_4_12_3  disj1_4_12_3  4090
    y_4_12_3  disj2_4_12_3  -4090
    y_4_12_4  disj1_4_12_4  4090
    y_4_12_4  disj2_4_12_4  -4090
    y_4_13_0  disj1_4_13_0  4090
    y_4_13_0  disj2_4_13_0  -4090
    y_4_13_1  disj1_4_13_1  4090
    y_4_13_1  disj2_4_13_1  -4090
    y_4_13_2  disj1_4_13_2  4090
    y_4_13_2  disj2_4_13_2  -4090
    y_4_13_3  disj1_4_13_3  4090
    y_4_13_3  disj2_4_13_3  -4090
    y_4_13_4  disj1_4_13_4  4090
    y_4_13_4  disj2_4_13_4  -4090
    y_4_14_0  disj1_4_14_0  4090
    y_4_14_0  disj2_4_14_0  -4090
    y_4_14_1  disj1_4_14_1  4090
    y_4_14_1  disj2_4_14_1  -4090
    y_4_14_2  disj1_4_14_2  4090
    y_4_14_2  disj2_4_14_2  -4090
    y_4_14_3  disj1_4_14_3  4090
    y_4_14_3  disj2_4_14_3  -4090
    y_4_14_4  disj1_4_14_4  4090
    y_4_14_4  disj2_4_14_4  -4090
    y_5_6_0   disj1_5_6_0  4090
    y_5_6_0   disj2_5_6_0  -4090
    y_5_6_1   disj1_5_6_1  4090
    y_5_6_1   disj2_5_6_1  -4090
    y_5_6_2   disj1_5_6_2  4090
    y_5_6_2   disj2_5_6_2  -4090
    y_5_6_3   disj1_5_6_3  4090
    y_5_6_3   disj2_5_6_3  -4090
    y_5_6_4   disj1_5_6_4  4090
    y_5_6_4   disj2_5_6_4  -4090
    y_5_7_0   disj1_5_7_0  4090
    y_5_7_0   disj2_5_7_0  -4090
    y_5_7_1   disj1_5_7_1  4090
    y_5_7_1   disj2_5_7_1  -4090
    y_5_7_2   disj1_5_7_2  4090
    y_5_7_2   disj2_5_7_2  -4090
    y_5_7_3   disj1_5_7_3  4090
    y_5_7_3   disj2_5_7_3  -4090
    y_5_7_4   disj1_5_7_4  4090
    y_5_7_4   disj2_5_7_4  -4090
    y_5_8_0   disj1_5_8_0  4090
    y_5_8_0   disj2_5_8_0  -4090
    y_5_8_1   disj1_5_8_1  4090
    y_5_8_1   disj2_5_8_1  -4090
    y_5_8_2   disj1_5_8_2  4090
    y_5_8_2   disj2_5_8_2  -4090
    y_5_8_3   disj1_5_8_3  4090
    y_5_8_3   disj2_5_8_3  -4090
    y_5_8_4   disj1_5_8_4  4090
    y_5_8_4   disj2_5_8_4  -4090
    y_5_9_0   disj1_5_9_0  4090
    y_5_9_0   disj2_5_9_0  -4090
    y_5_9_1   disj1_5_9_1  4090
    y_5_9_1   disj2_5_9_1  -4090
    y_5_9_2   disj1_5_9_2  4090
    y_5_9_2   disj2_5_9_2  -4090
    y_5_9_3   disj1_5_9_3  4090
    y_5_9_3   disj2_5_9_3  -4090
    y_5_9_4   disj1_5_9_4  4090
    y_5_9_4   disj2_5_9_4  -4090
    y_5_10_0  disj1_5_10_0  4090
    y_5_10_0  disj2_5_10_0  -4090
    y_5_10_1  disj1_5_10_1  4090
    y_5_10_1  disj2_5_10_1  -4090
    y_5_10_2  disj1_5_10_2  4090
    y_5_10_2  disj2_5_10_2  -4090
    y_5_10_3  disj1_5_10_3  4090
    y_5_10_3  disj2_5_10_3  -4090
    y_5_10_4  disj1_5_10_4  4090
    y_5_10_4  disj2_5_10_4  -4090
    y_5_11_0  disj1_5_11_0  4090
    y_5_11_0  disj2_5_11_0  -4090
    y_5_11_1  disj1_5_11_1  4090
    y_5_11_1  disj2_5_11_1  -4090
    y_5_11_2  disj1_5_11_2  4090
    y_5_11_2  disj2_5_11_2  -4090
    y_5_11_3  disj1_5_11_3  4090
    y_5_11_3  disj2_5_11_3  -4090
    y_5_11_4  disj1_5_11_4  4090
    y_5_11_4  disj2_5_11_4  -4090
    y_5_12_0  disj1_5_12_0  4090
    y_5_12_0  disj2_5_12_0  -4090
    y_5_12_1  disj1_5_12_1  4090
    y_5_12_1  disj2_5_12_1  -4090
    y_5_12_2  disj1_5_12_2  4090
    y_5_12_2  disj2_5_12_2  -4090
    y_5_12_3  disj1_5_12_3  4090
    y_5_12_3  disj2_5_12_3  -4090
    y_5_12_4  disj1_5_12_4  4090
    y_5_12_4  disj2_5_12_4  -4090
    y_5_13_0  disj1_5_13_0  4090
    y_5_13_0  disj2_5_13_0  -4090
    y_5_13_1  disj1_5_13_1  4090
    y_5_13_1  disj2_5_13_1  -4090
    y_5_13_2  disj1_5_13_2  4090
    y_5_13_2  disj2_5_13_2  -4090
    y_5_13_3  disj1_5_13_3  4090
    y_5_13_3  disj2_5_13_3  -4090
    y_5_13_4  disj1_5_13_4  4090
    y_5_13_4  disj2_5_13_4  -4090
    y_5_14_0  disj1_5_14_0  4090
    y_5_14_0  disj2_5_14_0  -4090
    y_5_14_1  disj1_5_14_1  4090
    y_5_14_1  disj2_5_14_1  -4090
    y_5_14_2  disj1_5_14_2  4090
    y_5_14_2  disj2_5_14_2  -4090
    y_5_14_3  disj1_5_14_3  4090
    y_5_14_3  disj2_5_14_3  -4090
    y_5_14_4  disj1_5_14_4  4090
    y_5_14_4  disj2_5_14_4  -4090
    y_6_7_0   disj1_6_7_0  4090
    y_6_7_0   disj2_6_7_0  -4090
    y_6_7_1   disj1_6_7_1  4090
    y_6_7_1   disj2_6_7_1  -4090
    y_6_7_2   disj1_6_7_2  4090
    y_6_7_2   disj2_6_7_2  -4090
    y_6_7_3   disj1_6_7_3  4090
    y_6_7_3   disj2_6_7_3  -4090
    y_6_7_4   disj1_6_7_4  4090
    y_6_7_4   disj2_6_7_4  -4090
    y_6_8_0   disj1_6_8_0  4090
    y_6_8_0   disj2_6_8_0  -4090
    y_6_8_1   disj1_6_8_1  4090
    y_6_8_1   disj2_6_8_1  -4090
    y_6_8_2   disj1_6_8_2  4090
    y_6_8_2   disj2_6_8_2  -4090
    y_6_8_3   disj1_6_8_3  4090
    y_6_8_3   disj2_6_8_3  -4090
    y_6_8_4   disj1_6_8_4  4090
    y_6_8_4   disj2_6_8_4  -4090
    y_6_9_0   disj1_6_9_0  4090
    y_6_9_0   disj2_6_9_0  -4090
    y_6_9_1   disj1_6_9_1  4090
    y_6_9_1   disj2_6_9_1  -4090
    y_6_9_2   disj1_6_9_2  4090
    y_6_9_2   disj2_6_9_2  -4090
    y_6_9_3   disj1_6_9_3  4090
    y_6_9_3   disj2_6_9_3  -4090
    y_6_9_4   disj1_6_9_4  4090
    y_6_9_4   disj2_6_9_4  -4090
    y_6_10_0  disj1_6_10_0  4090
    y_6_10_0  disj2_6_10_0  -4090
    y_6_10_1  disj1_6_10_1  4090
    y_6_10_1  disj2_6_10_1  -4090
    y_6_10_2  disj1_6_10_2  4090
    y_6_10_2  disj2_6_10_2  -4090
    y_6_10_3  disj1_6_10_3  4090
    y_6_10_3  disj2_6_10_3  -4090
    y_6_10_4  disj1_6_10_4  4090
    y_6_10_4  disj2_6_10_4  -4090
    y_6_11_0  disj1_6_11_0  4090
    y_6_11_0  disj2_6_11_0  -4090
    y_6_11_1  disj1_6_11_1  4090
    y_6_11_1  disj2_6_11_1  -4090
    y_6_11_2  disj1_6_11_2  4090
    y_6_11_2  disj2_6_11_2  -4090
    y_6_11_3  disj1_6_11_3  4090
    y_6_11_3  disj2_6_11_3  -4090
    y_6_11_4  disj1_6_11_4  4090
    y_6_11_4  disj2_6_11_4  -4090
    y_6_12_0  disj1_6_12_0  4090
    y_6_12_0  disj2_6_12_0  -4090
    y_6_12_1  disj1_6_12_1  4090
    y_6_12_1  disj2_6_12_1  -4090
    y_6_12_2  disj1_6_12_2  4090
    y_6_12_2  disj2_6_12_2  -4090
    y_6_12_3  disj1_6_12_3  4090
    y_6_12_3  disj2_6_12_3  -4090
    y_6_12_4  disj1_6_12_4  4090
    y_6_12_4  disj2_6_12_4  -4090
    y_6_13_0  disj1_6_13_0  4090
    y_6_13_0  disj2_6_13_0  -4090
    y_6_13_1  disj1_6_13_1  4090
    y_6_13_1  disj2_6_13_1  -4090
    y_6_13_2  disj1_6_13_2  4090
    y_6_13_2  disj2_6_13_2  -4090
    y_6_13_3  disj1_6_13_3  4090
    y_6_13_3  disj2_6_13_3  -4090
    y_6_13_4  disj1_6_13_4  4090
    y_6_13_4  disj2_6_13_4  -4090
    y_6_14_0  disj1_6_14_0  4090
    y_6_14_0  disj2_6_14_0  -4090
    y_6_14_1  disj1_6_14_1  4090
    y_6_14_1  disj2_6_14_1  -4090
    y_6_14_2  disj1_6_14_2  4090
    y_6_14_2  disj2_6_14_2  -4090
    y_6_14_3  disj1_6_14_3  4090
    y_6_14_3  disj2_6_14_3  -4090
    y_6_14_4  disj1_6_14_4  4090
    y_6_14_4  disj2_6_14_4  -4090
    y_7_8_0   disj1_7_8_0  4090
    y_7_8_0   disj2_7_8_0  -4090
    y_7_8_1   disj1_7_8_1  4090
    y_7_8_1   disj2_7_8_1  -4090
    y_7_8_2   disj1_7_8_2  4090
    y_7_8_2   disj2_7_8_2  -4090
    y_7_8_3   disj1_7_8_3  4090
    y_7_8_3   disj2_7_8_3  -4090
    y_7_8_4   disj1_7_8_4  4090
    y_7_8_4   disj2_7_8_4  -4090
    y_7_9_0   disj1_7_9_0  4090
    y_7_9_0   disj2_7_9_0  -4090
    y_7_9_1   disj1_7_9_1  4090
    y_7_9_1   disj2_7_9_1  -4090
    y_7_9_2   disj1_7_9_2  4090
    y_7_9_2   disj2_7_9_2  -4090
    y_7_9_3   disj1_7_9_3  4090
    y_7_9_3   disj2_7_9_3  -4090
    y_7_9_4   disj1_7_9_4  4090
    y_7_9_4   disj2_7_9_4  -4090
    y_7_10_0  disj1_7_10_0  4090
    y_7_10_0  disj2_7_10_0  -4090
    y_7_10_1  disj1_7_10_1  4090
    y_7_10_1  disj2_7_10_1  -4090
    y_7_10_2  disj1_7_10_2  4090
    y_7_10_2  disj2_7_10_2  -4090
    y_7_10_3  disj1_7_10_3  4090
    y_7_10_3  disj2_7_10_3  -4090
    y_7_10_4  disj1_7_10_4  4090
    y_7_10_4  disj2_7_10_4  -4090
    y_7_11_0  disj1_7_11_0  4090
    y_7_11_0  disj2_7_11_0  -4090
    y_7_11_1  disj1_7_11_1  4090
    y_7_11_1  disj2_7_11_1  -4090
    y_7_11_2  disj1_7_11_2  4090
    y_7_11_2  disj2_7_11_2  -4090
    y_7_11_3  disj1_7_11_3  4090
    y_7_11_3  disj2_7_11_3  -4090
    y_7_11_4  disj1_7_11_4  4090
    y_7_11_4  disj2_7_11_4  -4090
    y_7_12_0  disj1_7_12_0  4090
    y_7_12_0  disj2_7_12_0  -4090
    y_7_12_1  disj1_7_12_1  4090
    y_7_12_1  disj2_7_12_1  -4090
    y_7_12_2  disj1_7_12_2  4090
    y_7_12_2  disj2_7_12_2  -4090
    y_7_12_3  disj1_7_12_3  4090
    y_7_12_3  disj2_7_12_3  -4090
    y_7_12_4  disj1_7_12_4  4090
    y_7_12_4  disj2_7_12_4  -4090
    y_7_13_0  disj1_7_13_0  4090
    y_7_13_0  disj2_7_13_0  -4090
    y_7_13_1  disj1_7_13_1  4090
    y_7_13_1  disj2_7_13_1  -4090
    y_7_13_2  disj1_7_13_2  4090
    y_7_13_2  disj2_7_13_2  -4090
    y_7_13_3  disj1_7_13_3  4090
    y_7_13_3  disj2_7_13_3  -4090
    y_7_13_4  disj1_7_13_4  4090
    y_7_13_4  disj2_7_13_4  -4090
    y_7_14_0  disj1_7_14_0  4090
    y_7_14_0  disj2_7_14_0  -4090
    y_7_14_1  disj1_7_14_1  4090
    y_7_14_1  disj2_7_14_1  -4090
    y_7_14_2  disj1_7_14_2  4090
    y_7_14_2  disj2_7_14_2  -4090
    y_7_14_3  disj1_7_14_3  4090
    y_7_14_3  disj2_7_14_3  -4090
    y_7_14_4  disj1_7_14_4  4090
    y_7_14_4  disj2_7_14_4  -4090
    y_8_9_0   disj1_8_9_0  4090
    y_8_9_0   disj2_8_9_0  -4090
    y_8_9_1   disj1_8_9_1  4090
    y_8_9_1   disj2_8_9_1  -4090
    y_8_9_2   disj1_8_9_2  4090
    y_8_9_2   disj2_8_9_2  -4090
    y_8_9_3   disj1_8_9_3  4090
    y_8_9_3   disj2_8_9_3  -4090
    y_8_9_4   disj1_8_9_4  4090
    y_8_9_4   disj2_8_9_4  -4090
    y_8_10_0  disj1_8_10_0  4090
    y_8_10_0  disj2_8_10_0  -4090
    y_8_10_1  disj1_8_10_1  4090
    y_8_10_1  disj2_8_10_1  -4090
    y_8_10_2  disj1_8_10_2  4090
    y_8_10_2  disj2_8_10_2  -4090
    y_8_10_3  disj1_8_10_3  4090
    y_8_10_3  disj2_8_10_3  -4090
    y_8_10_4  disj1_8_10_4  4090
    y_8_10_4  disj2_8_10_4  -4090
    y_8_11_0  disj1_8_11_0  4090
    y_8_11_0  disj2_8_11_0  -4090
    y_8_11_1  disj1_8_11_1  4090
    y_8_11_1  disj2_8_11_1  -4090
    y_8_11_2  disj1_8_11_2  4090
    y_8_11_2  disj2_8_11_2  -4090
    y_8_11_3  disj1_8_11_3  4090
    y_8_11_3  disj2_8_11_3  -4090
    y_8_11_4  disj1_8_11_4  4090
    y_8_11_4  disj2_8_11_4  -4090
    y_8_12_0  disj1_8_12_0  4090
    y_8_12_0  disj2_8_12_0  -4090
    y_8_12_1  disj1_8_12_1  4090
    y_8_12_1  disj2_8_12_1  -4090
    y_8_12_2  disj1_8_12_2  4090
    y_8_12_2  disj2_8_12_2  -4090
    y_8_12_3  disj1_8_12_3  4090
    y_8_12_3  disj2_8_12_3  -4090
    y_8_12_4  disj1_8_12_4  4090
    y_8_12_4  disj2_8_12_4  -4090
    y_8_13_0  disj1_8_13_0  4090
    y_8_13_0  disj2_8_13_0  -4090
    y_8_13_1  disj1_8_13_1  4090
    y_8_13_1  disj2_8_13_1  -4090
    y_8_13_2  disj1_8_13_2  4090
    y_8_13_2  disj2_8_13_2  -4090
    y_8_13_3  disj1_8_13_3  4090
    y_8_13_3  disj2_8_13_3  -4090
    y_8_13_4  disj1_8_13_4  4090
    y_8_13_4  disj2_8_13_4  -4090
    y_8_14_0  disj1_8_14_0  4090
    y_8_14_0  disj2_8_14_0  -4090
    y_8_14_1  disj1_8_14_1  4090
    y_8_14_1  disj2_8_14_1  -4090
    y_8_14_2  disj1_8_14_2  4090
    y_8_14_2  disj2_8_14_2  -4090
    y_8_14_3  disj1_8_14_3  4090
    y_8_14_3  disj2_8_14_3  -4090
    y_8_14_4  disj1_8_14_4  4090
    y_8_14_4  disj2_8_14_4  -4090
    y_9_10_0  disj1_9_10_0  4090
    y_9_10_0  disj2_9_10_0  -4090
    y_9_10_1  disj1_9_10_1  4090
    y_9_10_1  disj2_9_10_1  -4090
    y_9_10_2  disj1_9_10_2  4090
    y_9_10_2  disj2_9_10_2  -4090
    y_9_10_3  disj1_9_10_3  4090
    y_9_10_3  disj2_9_10_3  -4090
    y_9_10_4  disj1_9_10_4  4090
    y_9_10_4  disj2_9_10_4  -4090
    y_9_11_0  disj1_9_11_0  4090
    y_9_11_0  disj2_9_11_0  -4090
    y_9_11_1  disj1_9_11_1  4090
    y_9_11_1  disj2_9_11_1  -4090
    y_9_11_2  disj1_9_11_2  4090
    y_9_11_2  disj2_9_11_2  -4090
    y_9_11_3  disj1_9_11_3  4090
    y_9_11_3  disj2_9_11_3  -4090
    y_9_11_4  disj1_9_11_4  4090
    y_9_11_4  disj2_9_11_4  -4090
    y_9_12_0  disj1_9_12_0  4090
    y_9_12_0  disj2_9_12_0  -4090
    y_9_12_1  disj1_9_12_1  4090
    y_9_12_1  disj2_9_12_1  -4090
    y_9_12_2  disj1_9_12_2  4090
    y_9_12_2  disj2_9_12_2  -4090
    y_9_12_3  disj1_9_12_3  4090
    y_9_12_3  disj2_9_12_3  -4090
    y_9_12_4  disj1_9_12_4  4090
    y_9_12_4  disj2_9_12_4  -4090
    y_9_13_0  disj1_9_13_0  4090
    y_9_13_0  disj2_9_13_0  -4090
    y_9_13_1  disj1_9_13_1  4090
    y_9_13_1  disj2_9_13_1  -4090
    y_9_13_2  disj1_9_13_2  4090
    y_9_13_2  disj2_9_13_2  -4090
    y_9_13_3  disj1_9_13_3  4090
    y_9_13_3  disj2_9_13_3  -4090
    y_9_13_4  disj1_9_13_4  4090
    y_9_13_4  disj2_9_13_4  -4090
    y_9_14_0  disj1_9_14_0  4090
    y_9_14_0  disj2_9_14_0  -4090
    y_9_14_1  disj1_9_14_1  4090
    y_9_14_1  disj2_9_14_1  -4090
    y_9_14_2  disj1_9_14_2  4090
    y_9_14_2  disj2_9_14_2  -4090
    y_9_14_3  disj1_9_14_3  4090
    y_9_14_3  disj2_9_14_3  -4090
    y_9_14_4  disj1_9_14_4  4090
    y_9_14_4  disj2_9_14_4  -4090
    y_10_11_0  disj1_10_11_0  4090
    y_10_11_0  disj2_10_11_0  -4090
    y_10_11_1  disj1_10_11_1  4090
    y_10_11_1  disj2_10_11_1  -4090
    y_10_11_2  disj1_10_11_2  4090
    y_10_11_2  disj2_10_11_2  -4090
    y_10_11_3  disj1_10_11_3  4090
    y_10_11_3  disj2_10_11_3  -4090
    y_10_11_4  disj1_10_11_4  4090
    y_10_11_4  disj2_10_11_4  -4090
    y_10_12_0  disj1_10_12_0  4090
    y_10_12_0  disj2_10_12_0  -4090
    y_10_12_1  disj1_10_12_1  4090
    y_10_12_1  disj2_10_12_1  -4090
    y_10_12_2  disj1_10_12_2  4090
    y_10_12_2  disj2_10_12_2  -4090
    y_10_12_3  disj1_10_12_3  4090
    y_10_12_3  disj2_10_12_3  -4090
    y_10_12_4  disj1_10_12_4  4090
    y_10_12_4  disj2_10_12_4  -4090
    y_10_13_0  disj1_10_13_0  4090
    y_10_13_0  disj2_10_13_0  -4090
    y_10_13_1  disj1_10_13_1  4090
    y_10_13_1  disj2_10_13_1  -4090
    y_10_13_2  disj1_10_13_2  4090
    y_10_13_2  disj2_10_13_2  -4090
    y_10_13_3  disj1_10_13_3  4090
    y_10_13_3  disj2_10_13_3  -4090
    y_10_13_4  disj1_10_13_4  4090
    y_10_13_4  disj2_10_13_4  -4090
    y_10_14_0  disj1_10_14_0  4090
    y_10_14_0  disj2_10_14_0  -4090
    y_10_14_1  disj1_10_14_1  4090
    y_10_14_1  disj2_10_14_1  -4090
    y_10_14_2  disj1_10_14_2  4090
    y_10_14_2  disj2_10_14_2  -4090
    y_10_14_3  disj1_10_14_3  4090
    y_10_14_3  disj2_10_14_3  -4090
    y_10_14_4  disj1_10_14_4  4090
    y_10_14_4  disj2_10_14_4  -4090
    y_11_12_0  disj1_11_12_0  4090
    y_11_12_0  disj2_11_12_0  -4090
    y_11_12_1  disj1_11_12_1  4090
    y_11_12_1  disj2_11_12_1  -4090
    y_11_12_2  disj1_11_12_2  4090
    y_11_12_2  disj2_11_12_2  -4090
    y_11_12_3  disj1_11_12_3  4090
    y_11_12_3  disj2_11_12_3  -4090
    y_11_12_4  disj1_11_12_4  4090
    y_11_12_4  disj2_11_12_4  -4090
    y_11_13_0  disj1_11_13_0  4090
    y_11_13_0  disj2_11_13_0  -4090
    y_11_13_1  disj1_11_13_1  4090
    y_11_13_1  disj2_11_13_1  -4090
    y_11_13_2  disj1_11_13_2  4090
    y_11_13_2  disj2_11_13_2  -4090
    y_11_13_3  disj1_11_13_3  4090
    y_11_13_3  disj2_11_13_3  -4090
    y_11_13_4  disj1_11_13_4  4090
    y_11_13_4  disj2_11_13_4  -4090
    y_11_14_0  disj1_11_14_0  4090
    y_11_14_0  disj2_11_14_0  -4090
    y_11_14_1  disj1_11_14_1  4090
    y_11_14_1  disj2_11_14_1  -4090
    y_11_14_2  disj1_11_14_2  4090
    y_11_14_2  disj2_11_14_2  -4090
    y_11_14_3  disj1_11_14_3  4090
    y_11_14_3  disj2_11_14_3  -4090
    y_11_14_4  disj1_11_14_4  4090
    y_11_14_4  disj2_11_14_4  -4090
    y_12_13_0  disj1_12_13_0  4090
    y_12_13_0  disj2_12_13_0  -4090
    y_12_13_1  disj1_12_13_1  4090
    y_12_13_1  disj2_12_13_1  -4090
    y_12_13_2  disj1_12_13_2  4090
    y_12_13_2  disj2_12_13_2  -4090
    y_12_13_3  disj1_12_13_3  4090
    y_12_13_3  disj2_12_13_3  -4090
    y_12_13_4  disj1_12_13_4  4090
    y_12_13_4  disj2_12_13_4  -4090
    y_12_14_0  disj1_12_14_0  4090
    y_12_14_0  disj2_12_14_0  -4090
    y_12_14_1  disj1_12_14_1  4090
    y_12_14_1  disj2_12_14_1  -4090
    y_12_14_2  disj1_12_14_2  4090
    y_12_14_2  disj2_12_14_2  -4090
    y_12_14_3  disj1_12_14_3  4090
    y_12_14_3  disj2_12_14_3  -4090
    y_12_14_4  disj1_12_14_4  4090
    y_12_14_4  disj2_12_14_4  -4090
    y_13_14_0  disj1_13_14_0  4090
    y_13_14_0  disj2_13_14_0  -4090
    y_13_14_1  disj1_13_14_1  4090
    y_13_14_1  disj2_13_14_1  -4090
    y_13_14_2  disj1_13_14_2  4090
    y_13_14_2  disj2_13_14_2  -4090
    y_13_14_3  disj1_13_14_3  4090
    y_13_14_3  disj2_13_14_3  -4090
    y_13_14_4  disj1_13_14_4  4090
    y_13_14_4  disj2_13_14_4  -4090
    MARK9999  'MARKER'                 'INTEND'
RHS
    RHS       prec_0_0  21
    RHS       prec_0_1  34
    RHS       prec_0_2  95
    RHS       prec_0_3  41
    RHS       prec_1_0  52
    RHS       prec_1_1  16
    RHS       prec_1_2  31
    RHS       prec_1_3  21
    RHS       prec_2_0  42
    RHS       prec_2_1  39
    RHS       prec_2_2  98
    RHS       prec_2_3  54
    RHS       prec_3_0  55
    RHS       prec_3_1  79
    RHS       prec_3_2  77
    RHS       prec_3_3  98
    RHS       prec_4_0  34
    RHS       prec_4_1  64
    RHS       prec_4_2  30
    RHS       prec_4_3  83
    RHS       prec_5_0  92
    RHS       prec_5_1  62
    RHS       prec_5_2  54
    RHS       prec_5_3  43
    RHS       prec_6_0  69
    RHS       prec_6_1  77
    RHS       prec_6_2  87
    RHS       prec_6_3  93
    RHS       prec_7_0  38
    RHS       prec_7_1  60
    RHS       prec_7_2  41
    RHS       prec_7_3  83
    RHS       prec_8_0  17
    RHS       prec_8_1  49
    RHS       prec_8_2  25
    RHS       prec_8_3  44
    RHS       prec_9_0  96
    RHS       prec_9_1  77
    RHS       prec_9_2  79
    RHS       prec_9_3  75
    RHS       prec_10_0  28
    RHS       prec_10_1  35
    RHS       prec_10_2  95
    RHS       prec_10_3  76
    RHS       prec_11_0  9
    RHS       prec_11_1  10
    RHS       prec_11_2  91
    RHS       prec_11_3  59
    RHS       prec_12_0  46
    RHS       prec_12_1  28
    RHS       prec_12_2  52
    RHS       prec_12_3  16
    RHS       prec_13_0  91
    RHS       prec_13_1  50
    RHS       prec_13_2  59
    RHS       prec_13_3  43
    RHS       prec_14_0  27
    RHS       prec_14_1  59
    RHS       prec_14_2  46
    RHS       prec_14_3  45
    RHS       mksp_0    66
    RHS       mksp_1    26
    RHS       mksp_2    16
    RHS       mksp_3    77
    RHS       mksp_4    19
    RHS       mksp_5    79
    RHS       mksp_6    87
    RHS       mksp_7    24
    RHS       mksp_8    98
    RHS       mksp_9    43
    RHS       mksp_10   7
    RHS       mksp_11   59
    RHS       mksp_12   59
    RHS       mksp_13   50
    RHS       mksp_14   90
    RHS       disj1_0_1_0  34
    RHS       disj2_0_1_0  -4038
    RHS       disj1_0_2_0  34
    RHS       disj2_0_2_0  -3992
    RHS       disj1_0_3_0  34
    RHS       disj2_0_3_0  -4013
    RHS       disj1_0_4_0  34
    RHS       disj2_0_4_0  -4007
    RHS       disj1_0_5_0  34
    RHS       disj2_0_5_0  -3998
    RHS       disj1_0_6_0  34
    RHS       disj2_0_6_0  -4013
    RHS       disj1_0_7_0  34
    RHS       disj2_0_7_0  -4049
    RHS       disj1_0_8_0  34
    RHS       disj2_0_8_0  -4046
    RHS       disj1_0_9_0  34
    RHS       disj2_0_9_0  -3994
    RHS       disj1_0_10_0  34
    RHS       disj2_0_10_0  -4014
    RHS       disj1_0_11_0  34
    RHS       disj2_0_11_0  -3999
    RHS       disj1_0_12_0  34
    RHS       disj2_0_12_0  -4074
    RHS       disj1_0_13_0  34
    RHS       disj2_0_13_0  -3999
    RHS       disj1_0_14_0  34
    RHS       disj2_0_14_0  -4044
    RHS       disj1_1_2_0  52
    RHS       disj2_1_2_0  -3992
    RHS       disj1_1_3_0  52
    RHS       disj2_1_3_0  -4013
    RHS       disj1_1_4_0  52
    RHS       disj2_1_4_0  -4007
    RHS       disj1_1_5_0  52
    RHS       disj2_1_5_0  -3998
    RHS       disj1_1_6_0  52
    RHS       disj2_1_6_0  -4013
    RHS       disj1_1_7_0  52
    RHS       disj2_1_7_0  -4049
    RHS       disj1_1_8_0  52
    RHS       disj2_1_8_0  -4046
    RHS       disj1_1_9_0  52
    RHS       disj2_1_9_0  -3994
    RHS       disj1_1_10_0  52
    RHS       disj2_1_10_0  -4014
    RHS       disj1_1_11_0  52
    RHS       disj2_1_11_0  -3999
    RHS       disj1_1_12_0  52
    RHS       disj2_1_12_0  -4074
    RHS       disj1_1_13_0  52
    RHS       disj2_1_13_0  -3999
    RHS       disj1_1_14_0  52
    RHS       disj2_1_14_0  -4044
    RHS       disj1_2_3_0  98
    RHS       disj2_2_3_0  -4013
    RHS       disj1_2_4_0  98
    RHS       disj2_2_4_0  -4007
    RHS       disj1_2_5_0  98
    RHS       disj2_2_5_0  -3998
    RHS       disj1_2_6_0  98
    RHS       disj2_2_6_0  -4013
    RHS       disj1_2_7_0  98
    RHS       disj2_2_7_0  -4049
    RHS       disj1_2_8_0  98
    RHS       disj2_2_8_0  -4046
    RHS       disj1_2_9_0  98
    RHS       disj2_2_9_0  -3994
    RHS       disj1_2_10_0  98
    RHS       disj2_2_10_0  -4014
    RHS       disj1_2_11_0  98
    RHS       disj2_2_11_0  -3999
    RHS       disj1_2_12_0  98
    RHS       disj2_2_12_0  -4074
    RHS       disj1_2_13_0  98
    RHS       disj2_2_13_0  -3999
    RHS       disj1_2_14_0  98
    RHS       disj2_2_14_0  -4044
    RHS       disj1_3_4_0  77
    RHS       disj2_3_4_0  -4007
    RHS       disj1_3_5_0  77
    RHS       disj2_3_5_0  -3998
    RHS       disj1_3_6_0  77
    RHS       disj2_3_6_0  -4013
    RHS       disj1_3_7_0  77
    RHS       disj2_3_7_0  -4049
    RHS       disj1_3_8_0  77
    RHS       disj2_3_8_0  -4046
    RHS       disj1_3_9_0  77
    RHS       disj2_3_9_0  -3994
    RHS       disj1_3_10_0  77
    RHS       disj2_3_10_0  -4014
    RHS       disj1_3_11_0  77
    RHS       disj2_3_11_0  -3999
    RHS       disj1_3_12_0  77
    RHS       disj2_3_12_0  -4074
    RHS       disj1_3_13_0  77
    RHS       disj2_3_13_0  -3999
    RHS       disj1_3_14_0  77
    RHS       disj2_3_14_0  -4044
    RHS       disj1_4_5_0  83
    RHS       disj2_4_5_0  -3998
    RHS       disj1_4_6_0  83
    RHS       disj2_4_6_0  -4013
    RHS       disj1_4_7_0  83
    RHS       disj2_4_7_0  -4049
    RHS       disj1_4_8_0  83
    RHS       disj2_4_8_0  -4046
    RHS       disj1_4_9_0  83
    RHS       disj2_4_9_0  -3994
    RHS       disj1_4_10_0  83
    RHS       disj2_4_10_0  -4014
    RHS       disj1_4_11_0  83
    RHS       disj2_4_11_0  -3999
    RHS       disj1_4_12_0  83
    RHS       disj2_4_12_0  -4074
    RHS       disj1_4_13_0  83
    RHS       disj2_4_13_0  -3999
    RHS       disj1_4_14_0  83
    RHS       disj2_4_14_0  -4044
    RHS       disj1_5_6_0  92
    RHS       disj2_5_6_0  -4013
    RHS       disj1_5_7_0  92
    RHS       disj2_5_7_0  -4049
    RHS       disj1_5_8_0  92
    RHS       disj2_5_8_0  -4046
    RHS       disj1_5_9_0  92
    RHS       disj2_5_9_0  -3994
    RHS       disj1_5_10_0  92
    RHS       disj2_5_10_0  -4014
    RHS       disj1_5_11_0  92
    RHS       disj2_5_11_0  -3999
    RHS       disj1_5_12_0  92
    RHS       disj2_5_12_0  -4074
    RHS       disj1_5_13_0  92
    RHS       disj2_5_13_0  -3999
    RHS       disj1_5_14_0  92
    RHS       disj2_5_14_0  -4044
    RHS       disj1_6_7_0  77
    RHS       disj2_6_7_0  -4049
    RHS       disj1_6_8_0  77
    RHS       disj2_6_8_0  -4046
    RHS       disj1_6_9_0  77
    RHS       disj2_6_9_0  -3994
    RHS       disj1_6_10_0  77
    RHS       disj2_6_10_0  -4014
    RHS       disj1_6_11_0  77
    RHS       disj2_6_11_0  -3999
    RHS       disj1_6_12_0  77
    RHS       disj2_6_12_0  -4074
    RHS       disj1_6_13_0  77
    RHS       disj2_6_13_0  -3999
    RHS       disj1_6_14_0  77
    RHS       disj2_6_14_0  -4044
    RHS       disj1_7_8_0  41
    RHS       disj2_7_8_0  -4046
    RHS       disj1_7_9_0  41
    RHS       disj2_7_9_0  -3994
    RHS       disj1_7_10_0  41
    RHS       disj2_7_10_0  -4014
    RHS       disj1_7_11_0  41
    RHS       disj2_7_11_0  -3999
    RHS       disj1_7_12_0  41
    RHS       disj2_7_12_0  -4074
    RHS       disj1_7_13_0  41
    RHS       disj2_7_13_0  -3999
    RHS       disj1_7_14_0  41
    RHS       disj2_7_14_0  -4044
    RHS       disj1_8_9_0  44
    RHS       disj2_8_9_0  -3994
    RHS       disj1_8_10_0  44
    RHS       disj2_8_10_0  -4014
    RHS       disj1_8_11_0  44
    RHS       disj2_8_11_0  -3999
    RHS       disj1_8_12_0  44
    RHS       disj2_8_12_0  -4074
    RHS       disj1_8_13_0  44
    RHS       disj2_8_13_0  -3999
    RHS       disj1_8_14_0  44
    RHS       disj2_8_14_0  -4044
    RHS       disj1_9_10_0  96
    RHS       disj2_9_10_0  -4014
    RHS       disj1_9_11_0  96
    RHS       disj2_9_11_0  -3999
    RHS       disj1_9_12_0  96
    RHS       disj2_9_12_0  -4074
    RHS       disj1_9_13_0  96
    RHS       disj2_9_13_0  -3999
    RHS       disj1_9_14_0  96
    RHS       disj2_9_14_0  -4044
    RHS       disj1_10_11_0  76
    RHS       disj2_10_11_0  -3999
    RHS       disj1_10_12_0  76
    RHS       disj2_10_12_0  -4074
    RHS       disj1_10_13_0  76
    RHS       disj2_10_13_0  -3999
    RHS       disj1_10_14_0  76
    RHS       disj2_10_14_0  -4044
    RHS       disj1_11_12_0  91
    RHS       disj2_11_12_0  -4074
    RHS       disj1_11_13_0  91
    RHS       disj2_11_13_0  -3999
    RHS       disj1_11_14_0  91
    RHS       disj2_11_14_0  -4044
    RHS       disj1_12_13_0  16
    RHS       disj2_12_13_0  -3999
    RHS       disj1_12_14_0  16
    RHS       disj2_12_14_0  -4044
    RHS       disj1_13_14_0  91
    RHS       disj2_13_14_0  -4044
    RHS       disj1_0_1_1  21
    RHS       disj2_0_1_1  -4074
    RHS       disj1_0_2_1  21
    RHS       disj2_0_2_1  -4036
    RHS       disj1_0_3_1  21
    RHS       disj2_0_3_1  -4035
    RHS       disj1_0_4_1  21
    RHS       disj2_0_4_1  -4026
    RHS       disj1_0_5_1  21
    RHS       disj2_0_5_1  -4028
    RHS       disj1_0_6_1  21
    RHS       disj2_0_6_1  -4003
    RHS       disj1_0_7_1  21
    RHS       disj2_0_7_1  -4052
    RHS       disj1_0_8_1  21
    RHS       disj2_0_8_1  -4041
    RHS       disj1_0_9_1  21
    RHS       disj2_0_9_1  -4047
    RHS       disj1_0_10_1  21
    RHS       disj2_0_10_1  -3995
    RHS       disj1_0_11_1  21
    RHS       disj2_0_11_1  -4031
    RHS       disj1_0_12_1  21
    RHS       disj2_0_12_1  -4044
    RHS       disj1_0_13_1  21
    RHS       disj2_0_13_1  -4040
    RHS       disj1_0_14_1  21
    RHS       disj2_0_14_1  -4000
    RHS       disj1_1_2_1  16
    RHS       disj2_1_2_1  -4036
    RHS       disj1_1_3_1  16
    RHS       disj2_1_3_1  -4035
    RHS       disj1_1_4_1  16
    RHS       disj2_1_4_1  -4026
    RHS       disj1_1_5_1  16
    RHS       disj2_1_5_1  -4028
    RHS       disj1_1_6_1  16
    RHS       disj2_1_6_1  -4003
    RHS       disj1_1_7_1  16
    RHS       disj2_1_7_1  -4052
    RHS       disj1_1_8_1  16
    RHS       disj2_1_8_1  -4041
    RHS       disj1_1_9_1  16
    RHS       disj2_1_9_1  -4047
    RHS       disj1_1_10_1  16
    RHS       disj2_1_10_1  -3995
    RHS       disj1_1_11_1  16
    RHS       disj2_1_11_1  -4031
    RHS       disj1_1_12_1  16
    RHS       disj2_1_12_1  -4044
    RHS       disj1_1_13_1  16
    RHS       disj2_1_13_1  -4040
    RHS       disj1_1_14_1  16
    RHS       disj2_1_14_1  -4000
    RHS       disj1_2_3_1  54
    RHS       disj2_2_3_1  -4035
    RHS       disj1_2_4_1  54
    RHS       disj2_2_4_1  -4026
    RHS       disj1_2_5_1  54
    RHS       disj2_2_5_1  -4028
    RHS       disj1_2_6_1  54
    RHS       disj2_2_6_1  -4003
    RHS       disj1_2_7_1  54
    RHS       disj2_2_7_1  -4052
    RHS       disj1_2_8_1  54
    RHS       disj2_2_8_1  -4041
    RHS       disj1_2_9_1  54
    RHS       disj2_2_9_1  -4047
    RHS       disj1_2_10_1  54
    RHS       disj2_2_10_1  -3995
    RHS       disj1_2_11_1  54
    RHS       disj2_2_11_1  -4031
    RHS       disj1_2_12_1  54
    RHS       disj2_2_12_1  -4044
    RHS       disj1_2_13_1  54
    RHS       disj2_2_13_1  -4040
    RHS       disj1_2_14_1  54
    RHS       disj2_2_14_1  -4000
    RHS       disj1_3_4_1  55
    RHS       disj2_3_4_1  -4026
    RHS       disj1_3_5_1  55
    RHS       disj2_3_5_1  -4028
    RHS       disj1_3_6_1  55
    RHS       disj2_3_6_1  -4003
    RHS       disj1_3_7_1  55
    RHS       disj2_3_7_1  -4052
    RHS       disj1_3_8_1  55
    RHS       disj2_3_8_1  -4041
    RHS       disj1_3_9_1  55
    RHS       disj2_3_9_1  -4047
    RHS       disj1_3_10_1  55
    RHS       disj2_3_10_1  -3995
    RHS       disj1_3_11_1  55
    RHS       disj2_3_11_1  -4031
    RHS       disj1_3_12_1  55
    RHS       disj2_3_12_1  -4044
    RHS       disj1_3_13_1  55
    RHS       disj2_3_13_1  -4040
    RHS       disj1_3_14_1  55
    RHS       disj2_3_14_1  -4000
    RHS       disj1_4_5_1  64
    RHS       disj2_4_5_1  -4028
    RHS       disj1_4_6_1  64
    RHS       disj2_4_6_1  -4003
    RHS       disj1_4_7_1  64
    RHS       disj2_4_7_1  -4052
    RHS       disj1_4_8_1  64
    RHS       disj2_4_8_1  -4041
    RHS       disj1_4_9_1  64
    RHS       disj2_4_9_1  -4047
    RHS       disj1_4_10_1  64
    RHS       disj2_4_10_1  -3995
    RHS       disj1_4_11_1  64
    RHS       disj2_4_11_1  -4031
    RHS       disj1_4_12_1  64
    RHS       disj2_4_12_1  -4044
    RHS       disj1_4_13_1  64
    RHS       disj2_4_13_1  -4040
    RHS       disj1_4_14_1  64
    RHS       disj2_4_14_1  -4000
    RHS       disj1_5_6_1  62
    RHS       disj2_5_6_1  -4003
    RHS       disj1_5_7_1  62
    RHS       disj2_5_7_1  -4052
    RHS       disj1_5_8_1  62
    RHS       disj2_5_8_1  -4041
    RHS       disj1_5_9_1  62
    RHS       disj2_5_9_1  -4047
    RHS       disj1_5_10_1  62
    RHS       disj2_5_10_1  -3995
    RHS       disj1_5_11_1  62
    RHS       disj2_5_11_1  -4031
    RHS       disj1_5_12_1  62
    RHS       disj2_5_12_1  -4044
    RHS       disj1_5_13_1  62
    RHS       disj2_5_13_1  -4040
    RHS       disj1_5_14_1  62
    RHS       disj2_5_14_1  -4000
    RHS       disj1_6_7_1  87
    RHS       disj2_6_7_1  -4052
    RHS       disj1_6_8_1  87
    RHS       disj2_6_8_1  -4041
    RHS       disj1_6_9_1  87
    RHS       disj2_6_9_1  -4047
    RHS       disj1_6_10_1  87
    RHS       disj2_6_10_1  -3995
    RHS       disj1_6_11_1  87
    RHS       disj2_6_11_1  -4031
    RHS       disj1_6_12_1  87
    RHS       disj2_6_12_1  -4044
    RHS       disj1_6_13_1  87
    RHS       disj2_6_13_1  -4040
    RHS       disj1_6_14_1  87
    RHS       disj2_6_14_1  -4000
    RHS       disj1_7_8_1  38
    RHS       disj2_7_8_1  -4041
    RHS       disj1_7_9_1  38
    RHS       disj2_7_9_1  -4047
    RHS       disj1_7_10_1  38
    RHS       disj2_7_10_1  -3995
    RHS       disj1_7_11_1  38
    RHS       disj2_7_11_1  -4031
    RHS       disj1_7_12_1  38
    RHS       disj2_7_12_1  -4044
    RHS       disj1_7_13_1  38
    RHS       disj2_7_13_1  -4040
    RHS       disj1_7_14_1  38
    RHS       disj2_7_14_1  -4000
    RHS       disj1_8_9_1  49
    RHS       disj2_8_9_1  -4047
    RHS       disj1_8_10_1  49
    RHS       disj2_8_10_1  -3995
    RHS       disj1_8_11_1  49
    RHS       disj2_8_11_1  -4031
    RHS       disj1_8_12_1  49
    RHS       disj2_8_12_1  -4044
    RHS       disj1_8_13_1  49
    RHS       disj2_8_13_1  -4040
    RHS       disj1_8_14_1  49
    RHS       disj2_8_14_1  -4000
    RHS       disj1_9_10_1  43
    RHS       disj2_9_10_1  -3995
    RHS       disj1_9_11_1  43
    RHS       disj2_9_11_1  -4031
    RHS       disj1_9_12_1  43
    RHS       disj2_9_12_1  -4044
    RHS       disj1_9_13_1  43
    RHS       disj2_9_13_1  -4040
    RHS       disj1_9_14_1  43
    RHS       disj2_9_14_1  -4000
    RHS       disj1_10_11_1  95
    RHS       disj2_10_11_1  -4031
    RHS       disj1_10_12_1  95
    RHS       disj2_10_12_1  -4044
    RHS       disj1_10_13_1  95
    RHS       disj2_10_13_1  -4040
    RHS       disj1_10_14_1  95
    RHS       disj2_10_14_1  -4000
    RHS       disj1_11_12_1  59
    RHS       disj2_11_12_1  -4044
    RHS       disj1_11_13_1  59
    RHS       disj2_11_13_1  -4040
    RHS       disj1_11_14_1  59
    RHS       disj2_11_14_1  -4000
    RHS       disj1_12_13_1  46
    RHS       disj2_12_13_1  -4040
    RHS       disj1_12_14_1  46
    RHS       disj2_12_14_1  -4000
    RHS       disj1_13_14_1  50
    RHS       disj2_13_14_1  -4000
    RHS       disj1_0_1_2  41
    RHS       disj2_0_1_2  -4064
    RHS       disj1_0_2_2  41
    RHS       disj2_0_2_2  -4051
    RHS       disj1_0_3_2  41
    RHS       disj2_0_3_2  -4013
    RHS       disj1_0_4_2  41
    RHS       disj2_0_4_2  -4071
    RHS       disj1_0_5_2  41
    RHS       disj2_0_5_2  -4047
    RHS       disj1_0_6_2  41
    RHS       disj2_0_6_2  -4021
    RHS       disj1_0_7_2  41
    RHS       disj2_0_7_2  -4030
    RHS       disj1_0_8_2  41
    RHS       disj2_0_8_2  -3992
    RHS       disj1_0_9_2  41
    RHS       disj2_0_9_2  -4011
    RHS       disj1_0_10_2  41
    RHS       disj2_0_10_2  -4062
    RHS       disj1_0_11_2  41
    RHS       disj2_0_11_2  -4031
    RHS       disj1_0_12_2  41
    RHS       disj2_0_12_2  -4038
    RHS       disj1_0_13_2  41
    RHS       disj2_0_13_2  -4040
    RHS       disj1_0_14_2  41
    RHS       disj2_0_14_2  -4045
    RHS       disj1_1_2_2  26
    RHS       disj2_1_2_2  -4051
    RHS       disj1_1_3_2  26
    RHS       disj2_1_3_2  -4013
    RHS       disj1_1_4_2  26
    RHS       disj2_1_4_2  -4071
    RHS       disj1_1_5_2  26
    RHS       disj2_1_5_2  -4047
    RHS       disj1_1_6_2  26
    RHS       disj2_1_6_2  -4021
    RHS       disj1_1_7_2  26
    RHS       disj2_1_7_2  -4030
    RHS       disj1_1_8_2  26
    RHS       disj2_1_8_2  -3992
    RHS       disj1_1_9_2  26
    RHS       disj2_1_9_2  -4011
    RHS       disj1_1_10_2  26
    RHS       disj2_1_10_2  -4062
    RHS       disj1_1_11_2  26
    RHS       disj2_1_11_2  -4031
    RHS       disj1_1_12_2  26
    RHS       disj2_1_12_2  -4038
    RHS       disj1_1_13_2  26
    RHS       disj2_1_13_2  -4040
    RHS       disj1_1_14_2  26
    RHS       disj2_1_14_2  -4045
    RHS       disj1_2_3_2  39
    RHS       disj2_2_3_2  -4013
    RHS       disj1_2_4_2  39
    RHS       disj2_2_4_2  -4071
    RHS       disj1_2_5_2  39
    RHS       disj2_2_5_2  -4047
    RHS       disj1_2_6_2  39
    RHS       disj2_2_6_2  -4021
    RHS       disj1_2_7_2  39
    RHS       disj2_2_7_2  -4030
    RHS       disj1_2_8_2  39
    RHS       disj2_2_8_2  -3992
    RHS       disj1_2_9_2  39
    RHS       disj2_2_9_2  -4011
    RHS       disj1_2_10_2  39
    RHS       disj2_2_10_2  -4062
    RHS       disj1_2_11_2  39
    RHS       disj2_2_11_2  -4031
    RHS       disj1_2_12_2  39
    RHS       disj2_2_12_2  -4038
    RHS       disj1_2_13_2  39
    RHS       disj2_2_13_2  -4040
    RHS       disj1_2_14_2  39
    RHS       disj2_2_14_2  -4045
    RHS       disj1_3_4_2  77
    RHS       disj2_3_4_2  -4071
    RHS       disj1_3_5_2  77
    RHS       disj2_3_5_2  -4047
    RHS       disj1_3_6_2  77
    RHS       disj2_3_6_2  -4021
    RHS       disj1_3_7_2  77
    RHS       disj2_3_7_2  -4030
    RHS       disj1_3_8_2  77
    RHS       disj2_3_8_2  -3992
    RHS       disj1_3_9_2  77
    RHS       disj2_3_9_2  -4011
    RHS       disj1_3_10_2  77
    RHS       disj2_3_10_2  -4062
    RHS       disj1_3_11_2  77
    RHS       disj2_3_11_2  -4031
    RHS       disj1_3_12_2  77
    RHS       disj2_3_12_2  -4038
    RHS       disj1_3_13_2  77
    RHS       disj2_3_13_2  -4040
    RHS       disj1_3_14_2  77
    RHS       disj2_3_14_2  -4045
    RHS       disj1_4_5_2  19
    RHS       disj2_4_5_2  -4047
    RHS       disj1_4_6_2  19
    RHS       disj2_4_6_2  -4021
    RHS       disj1_4_7_2  19
    RHS       disj2_4_7_2  -4030
    RHS       disj1_4_8_2  19
    RHS       disj2_4_8_2  -3992
    RHS       disj1_4_9_2  19
    RHS       disj2_4_9_2  -4011
    RHS       disj1_4_10_2  19
    RHS       disj2_4_10_2  -4062
    RHS       disj1_4_11_2  19
    RHS       disj2_4_11_2  -4031
    RHS       disj1_4_12_2  19
    RHS       disj2_4_12_2  -4038
    RHS       disj1_4_13_2  19
    RHS       disj2_4_13_2  -4040
    RHS       disj1_4_14_2  19
    RHS       disj2_4_14_2  -4045
    RHS       disj1_5_6_2  43
    RHS       disj2_5_6_2  -4021
    RHS       disj1_5_7_2  43
    RHS       disj2_5_7_2  -4030
    RHS       disj1_5_8_2  43
    RHS       disj2_5_8_2  -3992
    RHS       disj1_5_9_2  43
    RHS       disj2_5_9_2  -4011
    RHS       disj1_5_10_2  43
    RHS       disj2_5_10_2  -4062
    RHS       disj1_5_11_2  43
    RHS       disj2_5_11_2  -4031
    RHS       disj1_5_12_2  43
    RHS       disj2_5_12_2  -4038
    RHS       disj1_5_13_2  43
    RHS       disj2_5_13_2  -4040
    RHS       disj1_5_14_2  43
    RHS       disj2_5_14_2  -4045
    RHS       disj1_6_7_2  69
    RHS       disj2_6_7_2  -4030
    RHS       disj1_6_8_2  69
    RHS       disj2_6_8_2  -3992
    RHS       disj1_6_9_2  69
    RHS       disj2_6_9_2  -4011
    RHS       disj1_6_10_2  69
    RHS       disj2_6_10_2  -4062
    RHS       disj1_6_11_2  69
    RHS       disj2_6_11_2  -4031
    RHS       disj1_6_12_2  69
    RHS       disj2_6_12_2  -4038
    RHS       disj1_6_13_2  69
    RHS       disj2_6_13_2  -4040
    RHS       disj1_6_14_2  69
    RHS       disj2_6_14_2  -4045
    RHS       disj1_7_8_2  60
    RHS       disj2_7_8_2  -3992
    RHS       disj1_7_9_2  60
    RHS       disj2_7_9_2  -4011
    RHS       disj1_7_10_2  60
    RHS       disj2_7_10_2  -4062
    RHS       disj1_7_11_2  60
    RHS       disj2_7_11_2  -4031
    RHS       disj1_7_12_2  60
    RHS       disj2_7_12_2  -4038
    RHS       disj1_7_13_2  60
    RHS       disj2_7_13_2  -4040
    RHS       disj1_7_14_2  60
    RHS       disj2_7_14_2  -4045
    RHS       disj1_8_9_2  98
    RHS       disj2_8_9_2  -4011
    RHS       disj1_8_10_2  98
    RHS       disj2_8_10_2  -4062
    RHS       disj1_8_11_2  98
    RHS       disj2_8_11_2  -4031
    RHS       disj1_8_12_2  98
    RHS       disj2_8_12_2  -4038
    RHS       disj1_8_13_2  98
    RHS       disj2_8_13_2  -4040
    RHS       disj1_8_14_2  98
    RHS       disj2_8_14_2  -4045
    RHS       disj1_9_10_2  79
    RHS       disj2_9_10_2  -4062
    RHS       disj1_9_11_2  79
    RHS       disj2_9_11_2  -4031
    RHS       disj1_9_12_2  79
    RHS       disj2_9_12_2  -4038
    RHS       disj1_9_13_2  79
    RHS       disj2_9_13_2  -4040
    RHS       disj1_9_14_2  79
    RHS       disj2_9_14_2  -4045
    RHS       disj1_10_11_2  28
    RHS       disj2_10_11_2  -4031
    RHS       disj1_10_12_2  28
    RHS       disj2_10_12_2  -4038
    RHS       disj1_10_13_2  28
    RHS       disj2_10_13_2  -4040
    RHS       disj1_10_14_2  28
    RHS       disj2_10_14_2  -4045
    RHS       disj1_11_12_2  59
    RHS       disj2_11_12_2  -4038
    RHS       disj1_11_13_2  59
    RHS       disj2_11_13_2  -4040
    RHS       disj1_11_14_2  59
    RHS       disj2_11_14_2  -4045
    RHS       disj1_12_13_2  52
    RHS       disj2_12_13_2  -4040
    RHS       disj1_12_14_2  52
    RHS       disj2_12_14_2  -4045
    RHS       disj1_13_14_2  50
    RHS       disj2_13_14_2  -4045
    RHS       disj1_0_1_3  95
    RHS       disj2_0_1_3  -4069
    RHS       disj1_0_2_3  95
    RHS       disj2_0_2_3  -4048
    RHS       disj1_0_3_3  95
    RHS       disj2_0_3_3  -4011
    RHS       disj1_0_4_3  95
    RHS       disj2_0_4_3  -4056
    RHS       disj1_0_5_3  95
    RHS       disj2_0_5_3  -4036
    RHS       disj1_0_6_3  95
    RHS       disj2_0_6_3  -3997
    RHS       disj1_0_7_3  95
    RHS       disj2_0_7_3  -4066
    RHS       disj1_0_8_3  95
    RHS       disj2_0_8_3  -4073
    RHS       disj1_0_9_3  95
    RHS       disj2_0_9_3  -4013
    RHS       disj1_0_10_3  95
    RHS       disj2_0_10_3  -4083
    RHS       disj1_0_11_3  95
    RHS       disj2_0_11_3  -4080
    RHS       disj1_0_12_3  95
    RHS       disj2_0_12_3  -4031
    RHS       disj1_0_13_3  95
    RHS       disj2_0_13_3  -4031
    RHS       disj1_0_14_3  95
    RHS       disj2_0_14_3  -4063
    RHS       disj1_1_2_3  21
    RHS       disj2_1_2_3  -4048
    RHS       disj1_1_3_3  21
    RHS       disj2_1_3_3  -4011
    RHS       disj1_1_4_3  21
    RHS       disj2_1_4_3  -4056
    RHS       disj1_1_5_3  21
    RHS       disj2_1_5_3  -4036
    RHS       disj1_1_6_3  21
    RHS       disj2_1_6_3  -3997
    RHS       disj1_1_7_3  21
    RHS       disj2_1_7_3  -4066
    RHS       disj1_1_8_3  21
    RHS       disj2_1_8_3  -4073
    RHS       disj1_1_9_3  21
    RHS       disj2_1_9_3  -4013
    RHS       disj1_1_10_3  21
    RHS       disj2_1_10_3  -4083
    RHS       disj1_1_11_3  21
    RHS       disj2_1_11_3  -4080
    RHS       disj1_1_12_3  21
    RHS       disj2_1_12_3  -4031
    RHS       disj1_1_13_3  21
    RHS       disj2_1_13_3  -4031
    RHS       disj1_1_14_3  21
    RHS       disj2_1_14_3  -4063
    RHS       disj1_2_3_3  42
    RHS       disj2_2_3_3  -4011
    RHS       disj1_2_4_3  42
    RHS       disj2_2_4_3  -4056
    RHS       disj1_2_5_3  42
    RHS       disj2_2_5_3  -4036
    RHS       disj1_2_6_3  42
    RHS       disj2_2_6_3  -3997
    RHS       disj1_2_7_3  42
    RHS       disj2_2_7_3  -4066
    RHS       disj1_2_8_3  42
    RHS       disj2_2_8_3  -4073
    RHS       disj1_2_9_3  42
    RHS       disj2_2_9_3  -4013
    RHS       disj1_2_10_3  42
    RHS       disj2_2_10_3  -4083
    RHS       disj1_2_11_3  42
    RHS       disj2_2_11_3  -4080
    RHS       disj1_2_12_3  42
    RHS       disj2_2_12_3  -4031
    RHS       disj1_2_13_3  42
    RHS       disj2_2_13_3  -4031
    RHS       disj1_2_14_3  42
    RHS       disj2_2_14_3  -4063
    RHS       disj1_3_4_3  79
    RHS       disj2_3_4_3  -4056
    RHS       disj1_3_5_3  79
    RHS       disj2_3_5_3  -4036
    RHS       disj1_3_6_3  79
    RHS       disj2_3_6_3  -3997
    RHS       disj1_3_7_3  79
    RHS       disj2_3_7_3  -4066
    RHS       disj1_3_8_3  79
    RHS       disj2_3_8_3  -4073
    RHS       disj1_3_9_3  79
    RHS       disj2_3_9_3  -4013
    RHS       disj1_3_10_3  79
    RHS       disj2_3_10_3  -4083
    RHS       disj1_3_11_3  79
    RHS       disj2_3_11_3  -4080
    RHS       disj1_3_12_3  79
    RHS       disj2_3_12_3  -4031
    RHS       disj1_3_13_3  79
    RHS       disj2_3_13_3  -4031
    RHS       disj1_3_14_3  79
    RHS       disj2_3_14_3  -4063
    RHS       disj1_4_5_3  34
    RHS       disj2_4_5_3  -4036
    RHS       disj1_4_6_3  34
    RHS       disj2_4_6_3  -3997
    RHS       disj1_4_7_3  34
    RHS       disj2_4_7_3  -4066
    RHS       disj1_4_8_3  34
    RHS       disj2_4_8_3  -4073
    RHS       disj1_4_9_3  34
    RHS       disj2_4_9_3  -4013
    RHS       disj1_4_10_3  34
    RHS       disj2_4_10_3  -4083
    RHS       disj1_4_11_3  34
    RHS       disj2_4_11_3  -4080
    RHS       disj1_4_12_3  34
    RHS       disj2_4_12_3  -4031
    RHS       disj1_4_13_3  34
    RHS       disj2_4_13_3  -4031
    RHS       disj1_4_14_3  34
    RHS       disj2_4_14_3  -4063
    RHS       disj1_5_6_3  54
    RHS       disj2_5_6_3  -3997
    RHS       disj1_5_7_3  54
    RHS       disj2_5_7_3  -4066
    RHS       disj1_5_8_3  54
    RHS       disj2_5_8_3  -4073
    RHS       disj1_5_9_3  54
    RHS       disj2_5_9_3  -4013
    RHS       disj1_5_10_3  54
    RHS       disj2_5_10_3  -4083
    RHS       disj1_5_11_3  54
    RHS       disj2_5_11_3  -4080
    RHS       disj1_5_12_3  54
    RHS       disj2_5_12_3  -4031
    RHS       disj1_5_13_3  54
    RHS       disj2_5_13_3  -4031
    RHS       disj1_5_14_3  54
    RHS       disj2_5_14_3  -4063
    RHS       disj1_6_7_3  93
    RHS       disj2_6_7_3  -4066
    RHS       disj1_6_8_3  93
    RHS       disj2_6_8_3  -4073
    RHS       disj1_6_9_3  93
    RHS       disj2_6_9_3  -4013
    RHS       disj1_6_10_3  93
    RHS       disj2_6_10_3  -4083
    RHS       disj1_6_11_3  93
    RHS       disj2_6_11_3  -4080
    RHS       disj1_6_12_3  93
    RHS       disj2_6_12_3  -4031
    RHS       disj1_6_13_3  93
    RHS       disj2_6_13_3  -4031
    RHS       disj1_6_14_3  93
    RHS       disj2_6_14_3  -4063
    RHS       disj1_7_8_3  24
    RHS       disj2_7_8_3  -4073
    RHS       disj1_7_9_3  24
    RHS       disj2_7_9_3  -4013
    RHS       disj1_7_10_3  24
    RHS       disj2_7_10_3  -4083
    RHS       disj1_7_11_3  24
    RHS       disj2_7_11_3  -4080
    RHS       disj1_7_12_3  24
    RHS       disj2_7_12_3  -4031
    RHS       disj1_7_13_3  24
    RHS       disj2_7_13_3  -4031
    RHS       disj1_7_14_3  24
    RHS       disj2_7_14_3  -4063
    RHS       disj1_8_9_3  17
    RHS       disj2_8_9_3  -4013
    RHS       disj1_8_10_3  17
    RHS       disj2_8_10_3  -4083
    RHS       disj1_8_11_3  17
    RHS       disj2_8_11_3  -4080
    RHS       disj1_8_12_3  17
    RHS       disj2_8_12_3  -4031
    RHS       disj1_8_13_3  17
    RHS       disj2_8_13_3  -4031
    RHS       disj1_8_14_3  17
    RHS       disj2_8_14_3  -4063
    RHS       disj1_9_10_3  77
    RHS       disj2_9_10_3  -4083
    RHS       disj1_9_11_3  77
    RHS       disj2_9_11_3  -4080
    RHS       disj1_9_12_3  77
    RHS       disj2_9_12_3  -4031
    RHS       disj1_9_13_3  77
    RHS       disj2_9_13_3  -4031
    RHS       disj1_9_14_3  77
    RHS       disj2_9_14_3  -4063
    RHS       disj1_10_11_3  7
    RHS       disj2_10_11_3  -4080
    RHS       disj1_10_12_3  7
    RHS       disj2_10_12_3  -4031
    RHS       disj1_10_13_3  7
    RHS       disj2_10_13_3  -4031
    RHS       disj1_10_14_3  7
    RHS       disj2_10_14_3  -4063
    RHS       disj1_11_12_3  10
    RHS       disj2_11_12_3  -4031
    RHS       disj1_11_13_3  10
    RHS       disj2_11_13_3  -4031
    RHS       disj1_11_14_3  10
    RHS       disj2_11_14_3  -4063
    RHS       disj1_12_13_3  59
    RHS       disj2_12_13_3  -4031
    RHS       disj1_12_14_3  59
    RHS       disj2_12_14_3  -4063
    RHS       disj1_13_14_3  59
    RHS       disj2_13_14_3  -4063
    RHS       disj1_0_1_4  66
    RHS       disj2_0_1_4  -4059
    RHS       disj1_0_2_4  66
    RHS       disj2_0_2_4  -4074
    RHS       disj1_0_3_4  66
    RHS       disj2_0_3_4  -3992
    RHS       disj1_0_4_4  66
    RHS       disj2_0_4_4  -4060
    RHS       disj1_0_5_4  66
    RHS       disj2_0_5_4  -4011
    RHS       disj1_0_6_4  66
    RHS       disj2_0_6_4  -4003
    RHS       disj1_0_7_4  66
    RHS       disj2_0_7_4  -4007
    RHS       disj1_0_8_4  66
    RHS       disj2_0_8_4  -4065
    RHS       disj1_0_9_4  66
    RHS       disj2_0_9_4  -4015
    RHS       disj1_0_10_4  66
    RHS       disj2_0_10_4  -4055
    RHS       disj1_0_11_4  66
    RHS       disj2_0_11_4  -4081
    RHS       disj1_0_12_4  66
    RHS       disj2_0_12_4  -4062
    RHS       disj1_0_13_4  66
    RHS       disj2_0_13_4  -4047
    RHS       disj1_0_14_4  66
    RHS       disj2_0_14_4  -4031
    RHS       disj1_1_2_4  31
    RHS       disj2_1_2_4  -4074
    RHS       disj1_1_3_4  31
    RHS       disj2_1_3_4  -3992
    RHS       disj1_1_4_4  31
    RHS       disj2_1_4_4  -4060
    RHS       disj1_1_5_4  31
    RHS       disj2_1_5_4  -4011
    RHS       disj1_1_6_4  31
    RHS       disj2_1_6_4  -4003
    RHS       disj1_1_7_4  31
    RHS       disj2_1_7_4  -4007
    RHS       disj1_1_8_4  31
    RHS       disj2_1_8_4  -4065
    RHS       disj1_1_9_4  31
    RHS       disj2_1_9_4  -4015
    RHS       disj1_1_10_4  31
    RHS       disj2_1_10_4  -4055
    RHS       disj1_1_11_4  31
    RHS       disj2_1_11_4  -4081
    RHS       disj1_1_12_4  31
    RHS       disj2_1_12_4  -4062
    RHS       disj1_1_13_4  31
    RHS       disj2_1_13_4  -4047
    RHS       disj1_1_14_4  31
    RHS       disj2_1_14_4  -4031
    RHS       disj1_2_3_4  16
    RHS       disj2_2_3_4  -3992
    RHS       disj1_2_4_4  16
    RHS       disj2_2_4_4  -4060
    RHS       disj1_2_5_4  16
    RHS       disj2_2_5_4  -4011
    RHS       disj1_2_6_4  16
    RHS       disj2_2_6_4  -4003
    RHS       disj1_2_7_4  16
    RHS       disj2_2_7_4  -4007
    RHS       disj1_2_8_4  16
    RHS       disj2_2_8_4  -4065
    RHS       disj1_2_9_4  16
    RHS       disj2_2_9_4  -4015
    RHS       disj1_2_10_4  16
    RHS       disj2_2_10_4  -4055
    RHS       disj1_2_11_4  16
    RHS       disj2_2_11_4  -4081
    RHS       disj1_2_12_4  16
    RHS       disj2_2_12_4  -4062
    RHS       disj1_2_13_4  16
    RHS       disj2_2_13_4  -4047
    RHS       disj1_2_14_4  16
    RHS       disj2_2_14_4  -4031
    RHS       disj1_3_4_4  98
    RHS       disj2_3_4_4  -4060
    RHS       disj1_3_5_4  98
    RHS       disj2_3_5_4  -4011
    RHS       disj1_3_6_4  98
    RHS       disj2_3_6_4  -4003
    RHS       disj1_3_7_4  98
    RHS       disj2_3_7_4  -4007
    RHS       disj1_3_8_4  98
    RHS       disj2_3_8_4  -4065
    RHS       disj1_3_9_4  98
    RHS       disj2_3_9_4  -4015
    RHS       disj1_3_10_4  98
    RHS       disj2_3_10_4  -4055
    RHS       disj1_3_11_4  98
    RHS       disj2_3_11_4  -4081
    RHS       disj1_3_12_4  98
    RHS       disj2_3_12_4  -4062
    RHS       disj1_3_13_4  98
    RHS       disj2_3_13_4  -4047
    RHS       disj1_3_14_4  98
    RHS       disj2_3_14_4  -4031
    RHS       disj1_4_5_4  30
    RHS       disj2_4_5_4  -4011
    RHS       disj1_4_6_4  30
    RHS       disj2_4_6_4  -4003
    RHS       disj1_4_7_4  30
    RHS       disj2_4_7_4  -4007
    RHS       disj1_4_8_4  30
    RHS       disj2_4_8_4  -4065
    RHS       disj1_4_9_4  30
    RHS       disj2_4_9_4  -4015
    RHS       disj1_4_10_4  30
    RHS       disj2_4_10_4  -4055
    RHS       disj1_4_11_4  30
    RHS       disj2_4_11_4  -4081
    RHS       disj1_4_12_4  30
    RHS       disj2_4_12_4  -4062
    RHS       disj1_4_13_4  30
    RHS       disj2_4_13_4  -4047
    RHS       disj1_4_14_4  30
    RHS       disj2_4_14_4  -4031
    RHS       disj1_5_6_4  79
    RHS       disj2_5_6_4  -4003
    RHS       disj1_5_7_4  79
    RHS       disj2_5_7_4  -4007
    RHS       disj1_5_8_4  79
    RHS       disj2_5_8_4  -4065
    RHS       disj1_5_9_4  79
    RHS       disj2_5_9_4  -4015
    RHS       disj1_5_10_4  79
    RHS       disj2_5_10_4  -4055
    RHS       disj1_5_11_4  79
    RHS       disj2_5_11_4  -4081
    RHS       disj1_5_12_4  79
    RHS       disj2_5_12_4  -4062
    RHS       disj1_5_13_4  79
    RHS       disj2_5_13_4  -4047
    RHS       disj1_5_14_4  79
    RHS       disj2_5_14_4  -4031
    RHS       disj1_6_7_4  87
    RHS       disj2_6_7_4  -4007
    RHS       disj1_6_8_4  87
    RHS       disj2_6_8_4  -4065
    RHS       disj1_6_9_4  87
    RHS       disj2_6_9_4  -4015
    RHS       disj1_6_10_4  87
    RHS       disj2_6_10_4  -4055
    RHS       disj1_6_11_4  87
    RHS       disj2_6_11_4  -4081
    RHS       disj1_6_12_4  87
    RHS       disj2_6_12_4  -4062
    RHS       disj1_6_13_4  87
    RHS       disj2_6_13_4  -4047
    RHS       disj1_6_14_4  87
    RHS       disj2_6_14_4  -4031
    RHS       disj1_7_8_4  83
    RHS       disj2_7_8_4  -4065
    RHS       disj1_7_9_4  83
    RHS       disj2_7_9_4  -4015
    RHS       disj1_7_10_4  83
    RHS       disj2_7_10_4  -4055
    RHS       disj1_7_11_4  83
    RHS       disj2_7_11_4  -4081
    RHS       disj1_7_12_4  83
    RHS       disj2_7_12_4  -4062
    RHS       disj1_7_13_4  83
    RHS       disj2_7_13_4  -4047
    RHS       disj1_7_14_4  83
    RHS       disj2_7_14_4  -4031
    RHS       disj1_8_9_4  25
    RHS       disj2_8_9_4  -4015
    RHS       disj1_8_10_4  25
    RHS       disj2_8_10_4  -4055
    RHS       disj1_8_11_4  25
    RHS       disj2_8_11_4  -4081
    RHS       disj1_8_12_4  25
    RHS       disj2_8_12_4  -4062
    RHS       disj1_8_13_4  25
    RHS       disj2_8_13_4  -4047
    RHS       disj1_8_14_4  25
    RHS       disj2_8_14_4  -4031
    RHS       disj1_9_10_4  75
    RHS       disj2_9_10_4  -4055
    RHS       disj1_9_11_4  75
    RHS       disj2_9_11_4  -4081
    RHS       disj1_9_12_4  75
    RHS       disj2_9_12_4  -4062
    RHS       disj1_9_13_4  75
    RHS       disj2_9_13_4  -4047
    RHS       disj1_9_14_4  75
    RHS       disj2_9_14_4  -4031
    RHS       disj1_10_11_4  35
    RHS       disj2_10_11_4  -4081
    RHS       disj1_10_12_4  35
    RHS       disj2_10_12_4  -4062
    RHS       disj1_10_13_4  35
    RHS       disj2_10_13_4  -4047
    RHS       disj1_10_14_4  35
    RHS       disj2_10_14_4  -4031
    RHS       disj1_11_12_4  9
    RHS       disj2_11_12_4  -4062
    RHS       disj1_11_13_4  9
    RHS       disj2_11_13_4  -4047
    RHS       disj1_11_14_4  9
    RHS       disj2_11_14_4  -4031
    RHS       disj1_12_13_4  28
    RHS       disj2_12_13_4  -4047
    RHS       disj1_12_14_4  28
    RHS       disj2_12_14_4  -4031
    RHS       disj1_13_14_4  43
    RHS       disj2_13_14_4  -4031
BOUNDS
 BV BOUND     y_0_1_0
 BV BOUND     y_0_1_1
 BV BOUND     y_0_1_2
 BV BOUND     y_0_1_3
 BV BOUND     y_0_1_4
 BV BOUND     y_0_2_0
 BV BOUND     y_0_2_1
 BV BOUND     y_0_2_2
 BV BOUND     y_0_2_3
 BV BOUND     y_0_2_4
 BV BOUND     y_0_3_0
 BV BOUND     y_0_3_1
 BV BOUND     y_0_3_2
 BV BOUND     y_0_3_3
 BV BOUND     y_0_3_4
 BV BOUND     y_0_4_0
 BV BOUND     y_0_4_1
 BV BOUND     y_0_4_2
 BV BOUND     y_0_4_3
 BV BOUND     y_0_4_4
 BV BOUND     y_0_5_0
 BV BOUND     y_0_5_1
 BV BOUND     y_0_5_2
 BV BOUND     y_0_5_3
 BV BOUND     y_0_5_4
 BV BOUND     y_0_6_0
 BV BOUND     y_0_6_1
 BV BOUND     y_0_6_2
 BV BOUND     y_0_6_3
 BV BOUND     y_0_6_4
 BV BOUND     y_0_7_0
 BV BOUND     y_0_7_1
 BV BOUND     y_0_7_2
 BV BOUND     y_0_7_3
 BV BOUND     y_0_7_4
 BV BOUND     y_0_8_0
 BV BOUND     y_0_8_1
 BV BOUND     y_0_8_2
 BV BOUND     y_0_8_3
 BV BOUND     y_0_8_4
 BV BOUND     y_0_9_0
 BV BOUND     y_0_9_1
 BV BOUND     y_0_9_2
 BV BOUND     y_0_9_3
 BV BOUND     y_0_9_4
 BV BOUND     y_0_10_0
 BV BOUND     y_0_10_1
 BV BOUND     y_0_10_2
 BV BOUND     y_0_10_3
 BV BOUND     y_0_10_4
 BV BOUND     y_0_11_0
 BV BOUND     y_0_11_1
 BV BOUND     y_0_11_2
 BV BOUND     y_0_11_3
 BV BOUND     y_0_11_4
 BV BOUND     y_0_12_0
 BV BOUND     y_0_12_1
 BV BOUND     y_0_12_2
 BV BOUND     y_0_12_3
 BV BOUND     y_0_12_4
 BV BOUND     y_0_13_0
 BV BOUND     y_0_13_1
 BV BOUND     y_0_13_2
 BV BOUND     y_0_13_3
 BV BOUND     y_0_13_4
 BV BOUND     y_0_14_0
 BV BOUND     y_0_14_1
 BV BOUND     y_0_14_2
 BV BOUND     y_0_14_3
 BV BOUND     y_0_14_4
 BV BOUND     y_1_2_0
 BV BOUND     y_1_2_1
 BV BOUND     y_1_2_2
 BV BOUND     y_1_2_3
 BV BOUND     y_1_2_4
 BV BOUND     y_1_3_0
 BV BOUND     y_1_3_1
 BV BOUND     y_1_3_2
 BV BOUND     y_1_3_3
 BV BOUND     y_1_3_4
 BV BOUND     y_1_4_0
 BV BOUND     y_1_4_1
 BV BOUND     y_1_4_2
 BV BOUND     y_1_4_3
 BV BOUND     y_1_4_4
 BV BOUND     y_1_5_0
 BV BOUND     y_1_5_1
 BV BOUND     y_1_5_2
 BV BOUND     y_1_5_3
 BV BOUND     y_1_5_4
 BV BOUND     y_1_6_0
 BV BOUND     y_1_6_1
 BV BOUND     y_1_6_2
 BV BOUND     y_1_6_3
 BV BOUND     y_1_6_4
 BV BOUND     y_1_7_0
 BV BOUND     y_1_7_1
 BV BOUND     y_1_7_2
 BV BOUND     y_1_7_3
 BV BOUND     y_1_7_4
 BV BOUND     y_1_8_0
 BV BOUND     y_1_8_1
 BV BOUND     y_1_8_2
 BV BOUND     y_1_8_3
 BV BOUND     y_1_8_4
 BV BOUND     y_1_9_0
 BV BOUND     y_1_9_1
 BV BOUND     y_1_9_2
 BV BOUND     y_1_9_3
 BV BOUND     y_1_9_4
 BV BOUND     y_1_10_0
 BV BOUND     y_1_10_1
 BV BOUND     y_1_10_2
 BV BOUND     y_1_10_3
 BV BOUND     y_1_10_4
 BV BOUND     y_1_11_0
 BV BOUND     y_1_11_1
 BV BOUND     y_1_11_2
 BV BOUND     y_1_11_3
 BV BOUND     y_1_11_4
 BV BOUND     y_1_12_0
 BV BOUND     y_1_12_1
 BV BOUND     y_1_12_2
 BV BOUND     y_1_12_3
 BV BOUND     y_1_12_4
 BV BOUND     y_1_13_0
 BV BOUND     y_1_13_1
 BV BOUND     y_1_13_2
 BV BOUND     y_1_13_3
 BV BOUND     y_1_13_4
 BV BOUND     y_1_14_0
 BV BOUND     y_1_14_1
 BV BOUND     y_1_14_2
 BV BOUND     y_1_14_3
 BV BOUND     y_1_14_4
 BV BOUND     y_2_3_0
 BV BOUND     y_2_3_1
 BV BOUND     y_2_3_2
 BV BOUND     y_2_3_3
 BV BOUND     y_2_3_4
 BV BOUND     y_2_4_0
 BV BOUND     y_2_4_1
 BV BOUND     y_2_4_2
 BV BOUND     y_2_4_3
 BV BOUND     y_2_4_4
 BV BOUND     y_2_5_0
 BV BOUND     y_2_5_1
 BV BOUND     y_2_5_2
 BV BOUND     y_2_5_3
 BV BOUND     y_2_5_4
 BV BOUND     y_2_6_0
 BV BOUND     y_2_6_1
 BV BOUND     y_2_6_2
 BV BOUND     y_2_6_3
 BV BOUND     y_2_6_4
 BV BOUND     y_2_7_0
 BV BOUND     y_2_7_1
 BV BOUND     y_2_7_2
 BV BOUND     y_2_7_3
 BV BOUND     y_2_7_4
 BV BOUND     y_2_8_0
 BV BOUND     y_2_8_1
 BV BOUND     y_2_8_2
 BV BOUND     y_2_8_3
 BV BOUND     y_2_8_4
 BV BOUND     y_2_9_0
 BV BOUND     y_2_9_1
 BV BOUND     y_2_9_2
 BV BOUND     y_2_9_3
 BV BOUND     y_2_9_4
 BV BOUND     y_2_10_0
 BV BOUND     y_2_10_1
 BV BOUND     y_2_10_2
 BV BOUND     y_2_10_3
 BV BOUND     y_2_10_4
 BV BOUND     y_2_11_0
 BV BOUND     y_2_11_1
 BV BOUND     y_2_11_2
 BV BOUND     y_2_11_3
 BV BOUND     y_2_11_4
 BV BOUND     y_2_12_0
 BV BOUND     y_2_12_1
 BV BOUND     y_2_12_2
 BV BOUND     y_2_12_3
 BV BOUND     y_2_12_4
 BV BOUND     y_2_13_0
 BV BOUND     y_2_13_1
 BV BOUND     y_2_13_2
 BV BOUND     y_2_13_3
 BV BOUND     y_2_13_4
 BV BOUND     y_2_14_0
 BV BOUND     y_2_14_1
 BV BOUND     y_2_14_2
 BV BOUND     y_2_14_3
 BV BOUND     y_2_14_4
 BV BOUND     y_3_4_0
 BV BOUND     y_3_4_1
 BV BOUND     y_3_4_2
 BV BOUND     y_3_4_3
 BV BOUND     y_3_4_4
 BV BOUND     y_3_5_0
 BV BOUND     y_3_5_1
 BV BOUND     y_3_5_2
 BV BOUND     y_3_5_3
 BV BOUND     y_3_5_4
 BV BOUND     y_3_6_0
 BV BOUND     y_3_6_1
 BV BOUND     y_3_6_2
 BV BOUND     y_3_6_3
 BV BOUND     y_3_6_4
 BV BOUND     y_3_7_0
 BV BOUND     y_3_7_1
 BV BOUND     y_3_7_2
 BV BOUND     y_3_7_3
 BV BOUND     y_3_7_4
 BV BOUND     y_3_8_0
 BV BOUND     y_3_8_1
 BV BOUND     y_3_8_2
 BV BOUND     y_3_8_3
 BV BOUND     y_3_8_4
 BV BOUND     y_3_9_0
 BV BOUND     y_3_9_1
 BV BOUND     y_3_9_2
 BV BOUND     y_3_9_3
 BV BOUND     y_3_9_4
 BV BOUND     y_3_10_0
 BV BOUND     y_3_10_1
 BV BOUND     y_3_10_2
 BV BOUND     y_3_10_3
 BV BOUND     y_3_10_4
 BV BOUND     y_3_11_0
 BV BOUND     y_3_11_1
 BV BOUND     y_3_11_2
 BV BOUND     y_3_11_3
 BV BOUND     y_3_11_4
 BV BOUND     y_3_12_0
 BV BOUND     y_3_12_1
 BV BOUND     y_3_12_2
 BV BOUND     y_3_12_3
 BV BOUND     y_3_12_4
 BV BOUND     y_3_13_0
 BV BOUND     y_3_13_1
 BV BOUND     y_3_13_2
 BV BOUND     y_3_13_3
 BV BOUND     y_3_13_4
 BV BOUND     y_3_14_0
 BV BOUND     y_3_14_1
 BV BOUND     y_3_14_2
 BV BOUND     y_3_14_3
 BV BOUND     y_3_14_4
 BV BOUND     y_4_5_0
 BV BOUND     y_4_5_1
 BV BOUND     y_4_5_2
 BV BOUND     y_4_5_3
 BV BOUND     y_4_5_4
 BV BOUND     y_4_6_0
 BV BOUND     y_4_6_1
 BV BOUND     y_4_6_2
 BV BOUND     y_4_6_3
 BV BOUND     y_4_6_4
 BV BOUND     y_4_7_0
 BV BOUND     y_4_7_1
 BV BOUND     y_4_7_2
 BV BOUND     y_4_7_3
 BV BOUND     y_4_7_4
 BV BOUND     y_4_8_0
 BV BOUND     y_4_8_1
 BV BOUND     y_4_8_2
 BV BOUND     y_4_8_3
 BV BOUND     y_4_8_4
 BV BOUND     y_4_9_0
 BV BOUND     y_4_9_1
 BV BOUND     y_4_9_2
 BV BOUND     y_4_9_3
 BV BOUND     y_4_9_4
 BV BOUND     y_4_10_0
 BV BOUND     y_4_10_1
 BV BOUND     y_4_10_2
 BV BOUND     y_4_10_3
 BV BOUND     y_4_10_4
 BV BOUND     y_4_11_0
 BV BOUND     y_4_11_1
 BV BOUND     y_4_11_2
 BV BOUND     y_4_11_3
 BV BOUND     y_4_11_4
 BV BOUND     y_4_12_0
 BV BOUND     y_4_12_1
 BV BOUND     y_4_12_2
 BV BOUND     y_4_12_3
 BV BOUND     y_4_12_4
 BV BOUND     y_4_13_0
 BV BOUND     y_4_13_1
 BV BOUND     y_4_13_2
 BV BOUND     y_4_13_3
 BV BOUND     y_4_13_4
 BV BOUND     y_4_14_0
 BV BOUND     y_4_14_1
 BV BOUND     y_4_14_2
 BV BOUND     y_4_14_3
 BV BOUND     y_4_14_4
 BV BOUND     y_5_6_0
 BV BOUND     y_5_6_1
 BV BOUND     y_5_6_2
 BV BOUND     y_5_6_3
 BV BOUND     y_5_6_4
 BV BOUND     y_5_7_0
 BV BOUND     y_5_7_1
 BV BOUND     y_5_7_2
 BV BOUND     y_5_7_3
 BV BOUND     y_5_7_4
 BV BOUND     y_5_8_0
 BV BOUND     y_5_8_1
 BV BOUND     y_5_8_2
 BV BOUND     y_5_8_3
 BV BOUND     y_5_8_4
 BV BOUND     y_5_9_0
 BV BOUND     y_5_9_1
 BV BOUND     y_5_9_2
 BV BOUND     y_5_9_3
 BV BOUND     y_5_9_4
 BV BOUND     y_5_10_0
 BV BOUND     y_5_10_1
 BV BOUND     y_5_10_2
 BV BOUND     y_5_10_3
 BV BOUND     y_5_10_4
 BV BOUND     y_5_11_0
 BV BOUND     y_5_11_1
 BV BOUND     y_5_11_2
 BV BOUND     y_5_11_3
 BV BOUND     y_5_11_4
 BV BOUND     y_5_12_0
 BV BOUND     y_5_12_1
 BV BOUND     y_5_12_2
 BV BOUND     y_5_12_3
 BV BOUND     y_5_12_4
 BV BOUND     y_5_13_0
 BV BOUND     y_5_13_1
 BV BOUND     y_5_13_2
 BV BOUND     y_5_13_3
 BV BOUND     y_5_13_4
 BV BOUND     y_5_14_0
 BV BOUND     y_5_14_1
 BV BOUND     y_5_14_2
 BV BOUND     y_5_14_3
 BV BOUND     y_5_14_4
 BV BOUND     y_6_7_0
 BV BOUND     y_6_7_1
 BV BOUND     y_6_7_2
 BV BOUND     y_6_7_3
 BV BOUND     y_6_7_4
 BV BOUND     y_6_8_0
 BV BOUND     y_6_8_1
 BV BOUND     y_6_8_2
 BV BOUND     y_6_8_3
 BV BOUND     y_6_8_4
 BV BOUND     y_6_9_0
 BV BOUND     y_6_9_1
 BV BOUND     y_6_9_2
 BV BOUND     y_6_9_3
 BV BOUND     y_6_9_4
 BV BOUND     y_6_10_0
 BV BOUND     y_6_10_1
 BV BOUND     y_6_10_2
 BV BOUND     y_6_10_3
 BV BOUND     y_6_10_4
 BV BOUND     y_6_11_0
 BV BOUND     y_6_11_1
 BV BOUND     y_6_11_2
 BV BOUND     y_6_11_3
 BV BOUND     y_6_11_4
 BV BOUND     y_6_12_0
 BV BOUND     y_6_12_1
 BV BOUND     y_6_12_2
 BV BOUND     y_6_12_3
 BV BOUND     y_6_12_4
 BV BOUND     y_6_13_0
 BV BOUND     y_6_13_1
 BV BOUND     y_6_13_2
 BV BOUND     y_6_13_3
 BV BOUND     y_6_13_4
 BV BOUND     y_6_14_0
 BV BOUND     y_6_14_1
 BV BOUND     y_6_14_2
 BV BOUND     y_6_14_3
 BV BOUND     y_6_14_4
 BV BOUND     y_7_8_0
 BV BOUND     y_7_8_1
 BV BOUND     y_7_8_2
 BV BOUND     y_7_8_3
 BV BOUND     y_7_8_4
 BV BOUND     y_7_9_0
 BV BOUND     y_7_9_1
 BV BOUND     y_7_9_2
 BV BOUND     y_7_9_3
 BV BOUND     y_7_9_4
 BV BOUND     y_7_10_0
 BV BOUND     y_7_10_1
 BV BOUND     y_7_10_2
 BV BOUND     y_7_10_3
 BV BOUND     y_7_10_4
 BV BOUND     y_7_11_0
 BV BOUND     y_7_11_1
 BV BOUND     y_7_11_2
 BV BOUND     y_7_11_3
 BV BOUND     y_7_11_4
 BV BOUND     y_7_12_0
 BV BOUND     y_7_12_1
 BV BOUND     y_7_12_2
 BV BOUND     y_7_12_3
 BV BOUND     y_7_12_4
 BV BOUND     y_7_13_0
 BV BOUND     y_7_13_1
 BV BOUND     y_7_13_2
 BV BOUND     y_7_13_3
 BV BOUND     y_7_13_4
 BV BOUND     y_7_14_0
 BV BOUND     y_7_14_1
 BV BOUND     y_7_14_2
 BV BOUND     y_7_14_3
 BV BOUND     y_7_14_4
 BV BOUND     y_8_9_0
 BV BOUND     y_8_9_1
 BV BOUND     y_8_9_2
 BV BOUND     y_8_9_3
 BV BOUND     y_8_9_4
 BV BOUND     y_8_10_0
 BV BOUND     y_8_10_1
 BV BOUND     y_8_10_2
 BV BOUND     y_8_10_3
 BV BOUND     y_8_10_4
 BV BOUND     y_8_11_0
 BV BOUND     y_8_11_1
 BV BOUND     y_8_11_2
 BV BOUND     y_8_11_3
 BV BOUND     y_8_11_4
 BV BOUND     y_8_12_0
 BV BOUND     y_8_12_1
 BV BOUND     y_8_12_2
 BV BOUND     y_8_12_3
 BV BOUND     y_8_12_4
 BV BOUND     y_8_13_0
 BV BOUND     y_8_13_1
 BV BOUND     y_8_13_2
 BV BOUND     y_8_13_3
 BV BOUND     y_8_13_4
 BV BOUND     y_8_14_0
 BV BOUND     y_8_14_1
 BV BOUND     y_8_14_2
 BV BOUND     y_8_14_3
 BV BOUND     y_8_14_4
 BV BOUND     y_9_10_0
 BV BOUND     y_9_10_1
 BV BOUND     y_9_10_2
 BV BOUND     y_9_10_3
 BV BOUND     y_9_10_4
 BV BOUND     y_9_11_0
 BV BOUND     y_9_11_1
 BV BOUND     y_9_11_2
 BV BOUND     y_9_11_3
 BV BOUND     y_9_11_4
 BV BOUND     y_9_12_0
 BV BOUND     y_9_12_1
 BV BOUND     y_9_12_2
 BV BOUND     y_9_12_3
 BV BOUND     y_9_12_4
 BV BOUND     y_9_13_0
 BV BOUND     y_9_13_1
 BV BOUND     y_9_13_2
 BV BOUND     y_9_13_3
 BV BOUND     y_9_13_4
 BV BOUND     y_9_14_0
 BV BOUND     y_9_14_1
 BV BOUND     y_9_14_2
 BV BOUND     y_9_14_3
 BV BOUND     y_9_14_4
 BV BOUND     y_10_11_0
 BV BOUND     y_10_11_1
 BV BOUND     y_10_11_2
 BV BOUND     y_10_11_3
 BV BOUND     y_10_11_4
 BV BOUND     y_10_12_0
 BV BOUND     y_10_12_1
 BV BOUND     y_10_12_2
 BV BOUND     y_10_12_3
 BV BOUND     y_10_12_4
 BV BOUND     y_10_13_0
 BV BOUND     y_10_13_1
 BV BOUND     y_10_13_2
 BV BOUND     y_10_13_3
 BV BOUND     y_10_13_4
 BV BOUND     y_10_14_0
 BV BOUND     y_10_14_1
 BV BOUND     y_10_14_2
 BV BOUND     y_10_14_3
 BV BOUND     y_10_14_4
 BV BOUND     y_11_12_0
 BV BOUND     y_11_12_1
 BV BOUND     y_11_12_2
 BV BOUND     y_11_12_3
 BV BOUND     y_11_12_4
 BV BOUND     y_11_13_0
 BV BOUND     y_11_13_1
 BV BOUND     y_11_13_2
 BV BOUND     y_11_13_3
 BV BOUND     y_11_13_4
 BV BOUND     y_11_14_0
 BV BOUND     y_11_14_1
 BV BOUND     y_11_14_2
 BV BOUND     y_11_14_3
 BV BOUND     y_11_14_4
 BV BOUND     y_12_13_0
 BV BOUND     y_12_13_1
 BV BOUND     y_12_13_2
 BV BOUND     y_12_13_3
 BV BOUND     y_12_13_4
 BV BOUND     y_12_14_0
 BV BOUND     y_12_14_1
 BV BOUND     y_12_14_2
 BV BOUND     y_12_14_3
 BV BOUND     y_12_14_4
 BV BOUND     y_13_14_0
 BV BOUND     y_13_14_1
 BV BOUND     y_13_14_2
 BV BOUND     y_13_14_3
 BV BOUND     y_13_14_4
ENDATA
