NAME          SETPART
ROWS
 N  OBJ
 E  PART_0
 E  PART_1
 E  PART_2
 E  PART_3
 E  PART_4
 E  PART_5
 E  PART_6
 E  PART_7
 E  PART_8
 E  PART_9
 E  PART_10
 E  PART_11
 E  PART_12
 E  PART_13
 E  PART_14
 E  PART_15
 E  PART_16
 E  PART_17
 E  PART_18
 E  PART_19
 E  PART_20
 E  PART_21
 E  PART_22
 E  PART_23
 E  PART_24
 E  PART_25
 E  PART_26
 E  PART_27
 E  PART_28
 E  PART_29
COLUMNS
    x_0         OBJ       82
    x_0         PART_27  1.0
    x_1         OBJ       15
    x_2         OBJ       4
    x_2         PART_2  1.0
    x_3         OBJ       95
    x_3         PART_22  1.0
    x_4         OBJ       36
    x_4         PART_2  1.0
    x_4         PART_8  1.0
    x_4         PART_15  1.0
    x_4         PART_25  1.0
    x_5         OBJ       32
    x_5         PART_3  1.0
    x_5         PART_22  1.0
    x_6         OBJ       29
    x_6         PART_4  1.0
    x_7         OBJ       18
    x_7         PART_28  1.0
    x_8         OBJ       95
    x_8         PART_18  1.0
    x_8         PART_21  1.0
    x_9         OBJ       14
    x_9         PART_18  1.0
    x_9         PART_23  1.0
    x_10        OBJ       87
    x_10        PART_6  1.0
    x_10        PART_9  1.0
    x_10        PART_10  1.0
    x_11        OBJ       95
    x_12        OBJ       70
    x_12        PART_2  1.0
    x_13        OBJ       12
    x_13        PART_15  1.0
    x_13        PART_16  1.0
    x_14        OBJ       76
    x_14        PART_3  1.0
    x_14        PART_12  1.0
    x_14        PART_13  1.0
    x_14        PART_21  1.0
    x_15        OBJ       55
    x_16        OBJ       5
    x_16        PART_18  1.0
    x_16        PART_20  1.0
    x_17        OBJ       4
    x_17        PART_5  1.0
    x_17        PART_7  1.0
    x_17        PART_11  1.0
    x_17        PART_15  1.0
    x_17        PART_29  1.0
    x_18        OBJ       12
    x_18        PART_0  1.0
    x_18        PART_3  1.0
    x_19        OBJ       28
    x_20        OBJ       30
    x_20        PART_12  1.0
    x_20        PART_14  1.0
    x_20        PART_16  1.0
    x_21        OBJ       65
    x_22        OBJ       78
    x_22        PART_6  1.0
    x_23        OBJ       4
    x_23        PART_1  1.0
    x_23        PART_6  1.0
    x_23        PART_21  1.0
    x_24        OBJ       72
    x_24        PART_25  1.0
    x_25        OBJ       26
    x_25        PART_17  1.0
    x_25        PART_21  1.0
    x_26        OBJ       92
    x_27        OBJ       84
    x_27        PART_20  1.0
    x_28        OBJ       90
    x_29        OBJ       70
    x_29        PART_5  1.0
    x_29        PART_10  1.0
    x_29        PART_18  1.0
    x_29        PART_26  1.0
    x_30        OBJ       54
    x_31        OBJ       29
    x_31        PART_17  1.0
    x_31        PART_22  1.0
    x_32        OBJ       58
    x_33        OBJ       76
    x_33        PART_26  1.0
    x_34        OBJ       36
    x_34        PART_9  1.0
    x_35        OBJ       1
    x_35        PART_0  1.0
    x_35        PART_12  1.0
    x_35        PART_19  1.0
    x_35        PART_27  1.0
    x_36        OBJ       98
    x_37        OBJ       21
    x_37        PART_20  1.0
    x_38        OBJ       90
    x_38        PART_25  1.0
    x_38        PART_26  1.0
    x_39        OBJ       55
    x_39        PART_1  1.0
    x_40        OBJ       44
    x_40        PART_5  1.0
    x_40        PART_9  1.0
    x_40        PART_11  1.0
    x_40        PART_23  1.0
    x_41        OBJ       36
    x_41        PART_8  1.0
    x_41        PART_29  1.0
    x_42        OBJ       20
    x_42        PART_7  1.0
    x_43        OBJ       28
    x_43        PART_8  1.0
    x_43        PART_12  1.0
    x_43        PART_24  1.0
    x_43        PART_28  1.0
    x_44        OBJ       98
    x_45        OBJ       44
    x_45        PART_2  1.0
    x_45        PART_16  1.0
    x_46        OBJ       14
    x_46        PART_9  1.0
    x_46        PART_28  1.0
    x_47        OBJ       12
    x_47        PART_19  1.0
    x_47        PART_20  1.0
    x_48        OBJ       49
    x_48        PART_22  1.0
    x_48        PART_29  1.0
    x_49        OBJ       13
    x_49        PART_3  1.0
    x_49        PART_29  1.0
    x_50        OBJ       46
    x_50        PART_24  1.0
    x_51        OBJ       45
    x_51        PART_14  1.0
    x_52        OBJ       78
    x_52        PART_13  1.0
    x_53        OBJ       34
    x_54        OBJ       6
    x_55        OBJ       94
    x_55        PART_1  1.0
    x_55        PART_4  1.0
    x_55        PART_27  1.0
    x_56        OBJ       59
    x_56        PART_1  1.0
    x_56        PART_16  1.0
    x_56        PART_17  1.0
    x_56        PART_28  1.0
    x_57        OBJ       69
    x_58        OBJ       16
    x_58        PART_17  1.0
    x_59        OBJ       49
    x_59        PART_8  1.0
    x_59        PART_11  1.0
RHS
    RHS1      PART_0  1.0
    RHS1      PART_1  1.0
    RHS1      PART_2  1.0
    RHS1      PART_3  1.0
    RHS1      PART_4  1.0
    RHS1      PART_5  1.0
    RHS1      PART_6  1.0
    RHS1      PART_7  1.0
    RHS1      PART_8  1.0
    RHS1      PART_9  1.0
    RHS1      PART_10  1.0
    RHS1      PART_11  1.0
    RHS1      PART_12  1.0
    RHS1      PART_13  1.0
    RHS1      PART_14  1.0
    RHS1      PART_15  1.0
    RHS1      PART_16  1.0
    RHS1      PART_17  1.0
    RHS1      PART_18  1.0
    RHS1      PART_19  1.0
    RHS1      PART_20  1.0
    RHS1      PART_21  1.0
    RHS1      PART_22  1.0
    RHS1      PART_23  1.0
    RHS1      PART_24  1.0
    RHS1      PART_25  1.0
    RHS1      PART_26  1.0
    RHS1      PART_27  1.0
    RHS1      PART_28  1.0
    RHS1      PART_29  1.0
BOUNDS
 BV BND1      x_0
 BV BND1      x_1
 BV BND1      x_2
 BV BND1      x_3
 BV BND1      x_4
 BV BND1      x_5
 BV BND1      x_6
 BV BND1      x_7
 BV BND1      x_8
 BV BND1      x_9
 BV BND1      x_10
 BV BND1      x_11
 BV BND1      x_12
 BV BND1      x_13
 BV BND1      x_14
 BV BND1      x_15
 BV BND1      x_16
 BV BND1      x_17
 BV BND1      x_18
 BV BND1      x_19
 BV BND1      x_20
 BV BND1      x_21
 BV BND1      x_22
 BV BND1      x_23
 BV BND1      x_24
 BV BND1      x_25
 BV BND1      x_26
 BV BND1      x_27
 BV BND1      x_28
 BV BND1      x_29
 BV BND1      x_30
 BV BND1      x_31
 BV BND1      x_32
 BV BND1      x_33
 BV BND1      x_34
 BV BND1      x_35
 BV BND1      x_36
 BV BND1      x_37
 BV BND1      x_38
 BV BND1      x_39
 BV BND1      x_40
 BV BND1      x_41
 BV BND1      x_42
 BV BND1      x_43
 BV BND1      x_44
 BV BND1      x_45
 BV BND1      x_46
 BV BND1      x_47
 BV BND1      x_48
 BV BND1      x_49
 BV BND1      x_50
 BV BND1      x_51
 BV BND1      x_52
 BV BND1      x_53
 BV BND1      x_54
 BV BND1      x_55
 BV BND1      x_56
 BV BND1      x_57
 BV BND1      x_58
 BV BND1      x_59
ENDATA
