NAME          BPC
ROWS
 N  OBJ
 E  ASSIGN_0
 E  ASSIGN_1
 E  ASSIGN_2
 E  ASSIGN_3
 E  ASSIGN_4
 E  ASSIGN_5
 E  ASSIGN_6
 E  ASSIGN_7
 E  ASSIGN_8
 E  ASSIGN_9
 E  ASSIGN_10
 E  ASSIGN_11
 E  ASSIGN_12
 E  ASSIGN_13
 E  ASSIGN_14
 E  ASSIGN_15
 E  ASSIGN_16
 E  ASSIGN_17
 E  ASSIGN_18
 E  ASSIGN_19
 E  ASSIGN_20
 E  ASSIGN_21
 E  ASSIGN_22
 E  ASSIGN_23
 E  ASSIGN_24
 L  CAP_0
 L  CAP_1
 L  CAP_2
 L  CAP_3
 L  CAP_4
 L  CAP_5
 L  CAP_6
 L  CAP_7
 L  CAP_8
 L  CAP_9
 L  CAP_10
 L  CAP_11
 L  CAP_12
 L  CAP_13
 L  CAP_14
 L  CAP_15
 L  CAP_16
 L  CAP_17
 L  CAP_18
 L  CAP_19
 L  CAP_20
 L  CAP_21
 L  CAP_22
 L  CAP_23
 L  CAP_24
 L  CONF_3_4_0
 L  CONF_3_4_1
 L  CONF_3_4_2
 L  CONF_3_4_3
 L  CONF_3_4_4
 L  CONF_3_4_5
 L  CONF_3_4_6
 L  CONF_3_4_7
 L  CONF_3_4_8
 L  CONF_3_4_9
 L  CONF_3_4_10
 L  CONF_3_4_11
 L  CONF_3_4_12
 L  CONF_3_4_13
 L  CONF_3_4_14
 L  CONF_3_4_15
 L  CONF_3_4_16
 L  CONF_3_4_17
 L  CONF_3_4_18
 L  CONF_3_4_19
 L  CONF_3_4_20
 L  CONF_3_4_21
 L  CONF_3_4_22
 L  CONF_3_4_23
 L  CONF_3_4_24
 L  CONF_16_17_0
 L  CONF_16_17_1
 L  CONF_16_17_2
 L  CONF_16_17_3
 L  CONF_16_17_4
 L  CONF_16_17_5
 L  CONF_16_17_6
 L  CONF_16_17_7
 L  CONF_16_17_8
 L  CONF_16_17_9
 L  CONF_16_17_10
 L  CONF_16_17_11
 L  CONF_16_17_12
 L  CONF_16_17_13
 L  CONF_16_17_14
 L  CONF_16_17_15
 L  CONF_16_17_16
 L  CONF_16_17_17
 L  CONF_16_17_18
 L  CONF_16_17_19
 L  CONF_16_17_20
 L  CONF_16_17_21
 L  CONF_16_17_22
 L  CONF_16_17_23
 L  CONF_16_17_24
 L  CONF_20_23_0
 L  CONF_20_23_1
 L  CONF_20_23_2
 L  CONF_20_23_3
 L  CONF_20_23_4
 L  CONF_20_23_5
 L  CONF_20_23_6
 L  CONF_20_23_7
 L  CONF_20_23_8
 L  CONF_20_23_9
 L  CONF_20_23_10
 L  CONF_20_23_11
 L  CONF_20_23_12
 L  CONF_20_23_13
 L  CONF_20_23_14
 L  CONF_20_23_15
 L  CONF_20_23_16
 L  CONF_20_23_17
 L  CONF_20_23_18
 L  CONF_20_23_19
 L  CONF_20_23_20
 L  CONF_20_23_21
 L  CONF_20_23_22
 L  CONF_20_23_23
 L  CONF_20_23_24
 L  CONF_12_13_0
 L  CONF_12_13_1
 L  CONF_12_13_2
 L  CONF_12_13_3
 L  CONF_12_13_4
 L  CONF_12_13_5
 L  CONF_12_13_6
 L  CONF_12_13_7
 L  CONF_12_13_8
 L  CONF_12_13_9
 L  CONF_12_13_10
 L  CONF_12_13_11
 L  CONF_12_13_12
 L  CONF_12_13_13
 L  CONF_12_13_14
 L  CONF_12_13_15
 L  CONF_12_13_16
 L  CONF_12_13_17
 L  CONF_12_13_18
 L  CONF_12_13_19
 L  CONF_12_13_20
 L  CONF_12_13_21
 L  CONF_12_13_22
 L  CONF_12_13_23
 L  CONF_12_13_24
 L  CONF_21_22_0
 L  CONF_21_22_1
 L  CONF_21_22_2
 L  CONF_21_22_3
 L  CONF_21_22_4
 L  CONF_21_22_5
 L  CONF_21_22_6
 L  CONF_21_22_7
 L  CONF_21_22_8
 L  CONF_21_22_9
 L  CONF_21_22_10
 L  CONF_21_22_11
 L  CONF_21_22_12
 L  CONF_21_22_13
 L  CONF_21_22_14
 L  CONF_21_22_15
 L  CONF_21_22_16
 L  CONF_21_22_17
 L  CONF_21_22_18
 L  CONF_21_22_19
 L  CONF_21_22_20
 L  CONF_21_22_21
 L  CONF_21_22_22
 L  CONF_21_22_23
 L  CONF_21_22_24
 L  CONF_5_7_0
 L  CONF_5_7_1
 L  CONF_5_7_2
 L  CONF_5_7_3
 L  CONF_5_7_4
 L  CONF_5_7_5
 L  CONF_5_7_6
 L  CONF_5_7_7
 L  CONF_5_7_8
 L  CONF_5_7_9
 L  CONF_5_7_10
 L  CONF_5_7_11
 L  CONF_5_7_12
 L  CONF_5_7_13
 L  CONF_5_7_14
 L  CONF_5_7_15
 L  CONF_5_7_16
 L  CONF_5_7_17
 L  CONF_5_7_18
 L  CONF_5_7_19
 L  CONF_5_7_20
 L  CONF_5_7_21
 L  CONF_5_7_22
 L  CONF_5_7_23
 L  CONF_5_7_24
 L  CONF_22_23_0
 L  CONF_22_23_1
 L  CONF_22_23_2
 L  CONF_22_23_3
 L  CONF_22_23_4
 L  CONF_22_23_5
 L  CONF_22_23_6
 L  CONF_22_23_7
 L  CONF_22_23_8
 L  CONF_22_23_9
 L  CONF_22_23_10
 L  CONF_22_23_11
 L  CONF_22_23_12
 L  CONF_22_23_13
 L  CONF_22_23_14
 L  CONF_22_23_15
 L  CONF_22_23_16
 L  CONF_22_23_17
 L  CONF_22_23_18
 L  CONF_22_23_19
 L  CONF_22_23_20
 L  CONF_22_23_21
 L  CONF_22_23_22
 L  CONF_22_23_23
 L  CONF_22_23_24
 L  CONF_0_2_0
 L  CONF_0_2_1
 L  CONF_0_2_2
 L  CONF_0_2_3
 L  CONF_0_2_4
 L  CONF_0_2_5
 L  CONF_0_2_6
 L  CONF_0_2_7
 L  CONF_0_2_8
 L  CONF_0_2_9
 L  CONF_0_2_10
 L  CONF_0_2_11
 L  CONF_0_2_12
 L  CONF_0_2_13
 L  CONF_0_2_14
 L  CONF_0_2_15
 L  CONF_0_2_16
 L  CONF_0_2_17
 L  CONF_0_2_18
 L  CONF_0_2_19
 L  CONF_0_2_20
 L  CONF_0_2_21
 L  CONF_0_2_22
 L  CONF_0_2_23
 L  CONF_0_2_24
 L  CONF_8_9_0
 L  CONF_8_9_1
 L  CONF_8_9_2
 L  CONF_8_9_3
 L  CONF_8_9_4
 L  CONF_8_9_5
 L  CONF_8_9_6
 L  CONF_8_9_7
 L  CONF_8_9_8
 L  CONF_8_9_9
 L  CONF_8_9_10
 L  CONF_8_9_11
 L  CONF_8_9_12
 L  CONF_8_9_13
 L  CONF_8_9_14
 L  CONF_8_9_15
 L  CONF_8_9_16
 L  CONF_8_9_17
 L  CONF_8_9_18
 L  CONF_8_9_19
 L  CONF_8_9_20
 L  CONF_8_9_21
 L  CONF_8_9_22
 L  CONF_8_9_23
 L  CONF_8_9_24
 L  CONF_17_18_0
 L  CONF_17_18_1
 L  CONF_17_18_2
 L  CONF_17_18_3
 L  CONF_17_18_4
 L  CONF_17_18_5
 L  CONF_17_18_6
 L  CONF_17_18_7
 L  CONF_17_18_8
 L  CONF_17_18_9
 L  CONF_17_18_10
 L  CONF_17_18_11
 L  CONF_17_18_12
 L  CONF_17_18_13
 L  CONF_17_18_14
 L  CONF_17_18_15
 L  CONF_17_18_16
 L  CONF_17_18_17
 L  CONF_17_18_18
 L  CONF_17_18_19
 L  CONF_17_18_20
 L  CONF_17_18_21
 L  CONF_17_18_22
 L  CONF_17_18_23
 L  CONF_17_18_24
 L  CONF_11_14_0
 L  CONF_11_14_1
 L  CONF_11_14_2
 L  CONF_11_14_3
 L  CONF_11_14_4
 L  CONF_11_14_5
 L  CONF_11_14_6
 L  CONF_11_14_7
 L  CONF_11_14_8
 L  CONF_11_14_9
 L  CONF_11_14_10
 L  CONF_11_14_11
 L  CONF_11_14_12
 L  CONF_11_14_13
 L  CONF_11_14_14
 L  CONF_11_14_15
 L  CONF_11_14_16
 L  CONF_11_14_17
 L  CONF_11_14_18
 L  CONF_11_14_19
 L  CONF_11_14_20
 L  CONF_11_14_21
 L  CONF_11_14_22
 L  CONF_11_14_23
 L  CONF_11_14_24
 L  CONF_1_3_0
 L  CONF_1_3_1
 L  CONF_1_3_2
 L  CONF_1_3_3
 L  CONF_1_3_4
 L  CONF_1_3_5
 L  CONF_1_3_6
 L  CONF_1_3_7
 L  CONF_1_3_8
 L  CONF_1_3_9
 L  CONF_1_3_10
 L  CONF_1_3_11
 L  CONF_1_3_12
 L  CONF_1_3_13
 L  CONF_1_3_14
 L  CONF_1_3_15
 L  CONF_1_3_16
 L  CONF_1_3_17
 L  CONF_1_3_18
 L  CONF_1_3_19
 L  CONF_1_3_20
 L  CONF_1_3_21
 L  CONF_1_3_22
 L  CONF_1_3_23
 L  CONF_1_3_24
 L  CONF_10_12_0
 L  CONF_10_12_1
 L  CONF_10_12_2
 L  CONF_10_12_3
 L  CONF_10_12_4
 L  CONF_10_12_5
 L  CONF_10_12_6
 L  CONF_10_12_7
 L  CONF_10_12_8
 L  CONF_10_12_9
 L  CONF_10_12_10
 L  CONF_10_12_11
 L  CONF_10_12_12
 L  CONF_10_12_13
 L  CONF_10_12_14
 L  CONF_10_12_15
 L  CONF_10_12_16
 L  CONF_10_12_17
 L  CONF_10_12_18
 L  CONF_10_12_19
 L  CONF_10_12_20
 L  CONF_10_12_21
 L  CONF_10_12_22
 L  CONF_10_12_23
 L  CONF_10_12_24
 L  CONF_13_14_0
 L  CONF_13_14_1
 L  CONF_13_14_2
 L  CONF_13_14_3
 L  CONF_13_14_4
 L  CONF_13_14_5
 L  CONF_13_14_6
 L  CONF_13_14_7
 L  CONF_13_14_8
 L  CONF_13_14_9
 L  CONF_13_14_10
 L  CONF_13_14_11
 L  CONF_13_14_12
 L  CONF_13_14_13
 L  CONF_13_14_14
 L  CONF_13_14_15
 L  CONF_13_14_16
 L  CONF_13_14_17
 L  CONF_13_14_18
 L  CONF_13_14_19
 L  CONF_13_14_20
 L  CONF_13_14_21
 L  CONF_13_14_22
 L  CONF_13_14_23
 L  CONF_13_14_24
 L  CONF_16_19_0
 L  CONF_16_19_1
 L  CONF_16_19_2
 L  CONF_16_19_3
 L  CONF_16_19_4
 L  CONF_16_19_5
 L  CONF_16_19_6
 L  CONF_16_19_7
 L  CONF_16_19_8
 L  CONF_16_19_9
 L  CONF_16_19_10
 L  CONF_16_19_11
 L  CONF_16_19_12
 L  CONF_16_19_13
 L  CONF_16_19_14
 L  CONF_16_19_15
 L  CONF_16_19_16
 L  CONF_16_19_17
 L  CONF_16_19_18
 L  CONF_16_19_19
 L  CONF_16_19_20
 L  CONF_16_19_21
 L  CONF_16_19_22
 L  CONF_16_19_23
 L  CONF_16_19_24
 L  CONF_6_8_0
 L  CONF_6_8_1
 L  CONF_6_8_2
 L  CONF_6_8_3
 L  CONF_6_8_4
 L  CONF_6_8_5
 L  CONF_6_8_6
 L  CONF_6_8_7
 L  CONF_6_8_8
 L  CONF_6_8_9
 L  CONF_6_8_10
 L  CONF_6_8_11
 L  CONF_6_8_12
 L  CONF_6_8_13
 L  CONF_6_8_14
 L  CONF_6_8_15
 L  CONF_6_8_16
 L  CONF_6_8_17
 L  CONF_6_8_18
 L  CONF_6_8_19
 L  CONF_6_8_20
 L  CONF_6_8_21
 L  CONF_6_8_22
 L  CONF_6_8_23
 L  CONF_6_8_24
 L  CONF_15_17_0
 L  CONF_15_17_1
 L  CONF_15_17_2
 L  CONF_15_17_3
 L  CONF_15_17_4
 L  CONF_15_17_5
 L  CONF_15_17_6
 L  CONF_15_17_7
 L  CONF_15_17_8
 L  CONF_15_17_9
 L  CONF_15_17_10
 L  CONF_15_17_11
 L  CONF_15_17_12
 L  CONF_15_17_13
 L  CONF_15_17_14
 L  CONF_15_17_15
 L  CONF_15_17_16
 L  CONF_15_17_17
 L  CONF_15_17_18
 L  CONF_15_17_19
 L  CONF_15_17_20
 L  CONF_15_17_21
 L  CONF_15_17_22
 L  CONF_15_17_23
 L  CONF_15_17_24
 L  CONF_18_19_0
 L  CONF_18_19_1
 L  CONF_18_19_2
 L  CONF_18_19_3
 L  CONF_18_19_4
 L  CONF_18_19_5
 L  CONF_18_19_6
 L  CONF_18_19_7
 L  CONF_18_19_8
 L  CONF_18_19_9
 L  CONF_18_19_10
 L  CONF_18_19_11
 L  CONF_18_19_12
 L  CONF_18_19_13
 L  CONF_18_19_14
 L  CONF_18_19_15
 L  CONF_18_19_16
 L  CONF_18_19_17
 L  CONF_18_19_18
 L  CONF_18_19_19
 L  CONF_18_19_20
 L  CONF_18_19_21
 L  CONF_18_19_22
 L  CONF_18_19_23
 L  CONF_18_19_24
 L  CONF_5_6_0
 L  CONF_5_6_1
 L  CONF_5_6_2
 L  CONF_5_6_3
 L  CONF_5_6_4
 L  CONF_5_6_5
 L  CONF_5_6_6
 L  CONF_5_6_7
 L  CONF_5_6_8
 L  CONF_5_6_9
 L  CONF_5_6_10
 L  CONF_5_6_11
 L  CONF_5_6_12
 L  CONF_5_6_13
 L  CONF_5_6_14
 L  CONF_5_6_15
 L  CONF_5_6_16
 L  CONF_5_6_17
 L  CONF_5_6_18
 L  CONF_5_6_19
 L  CONF_5_6_20
 L  CONF_5_6_21
 L  CONF_5_6_22
 L  CONF_5_6_23
 L  CONF_5_6_24
 L  CONF_21_24_0
 L  CONF_21_24_1
 L  CONF_21_24_2
 L  CONF_21_24_3
 L  CONF_21_24_4
 L  CONF_21_24_5
 L  CONF_21_24_6
 L  CONF_21_24_7
 L  CONF_21_24_8
 L  CONF_21_24_9
 L  CONF_21_24_10
 L  CONF_21_24_11
 L  CONF_21_24_12
 L  CONF_21_24_13
 L  CONF_21_24_14
 L  CONF_21_24_15
 L  CONF_21_24_16
 L  CONF_21_24_17
 L  CONF_21_24_18
 L  CONF_21_24_19
 L  CONF_21_24_20
 L  CONF_21_24_21
 L  CONF_21_24_22
 L  CONF_21_24_23
 L  CONF_21_24_24
 L  CONF_20_22_0
 L  CONF_20_22_1
 L  CONF_20_22_2
 L  CONF_20_22_3
 L  CONF_20_22_4
 L  CONF_20_22_5
 L  CONF_20_22_6
 L  CONF_20_22_7
 L  CONF_20_22_8
 L  CONF_20_22_9
 L  CONF_20_22_10
 L  CONF_20_22_11
 L  CONF_20_22_12
 L  CONF_20_22_13
 L  CONF_20_22_14
 L  CONF_20_22_15
 L  CONF_20_22_16
 L  CONF_20_22_17
 L  CONF_20_22_18
 L  CONF_20_22_19
 L  CONF_20_22_20
 L  CONF_20_22_21
 L  CONF_20_22_22
 L  CONF_20_22_23
 L  CONF_20_22_24
 L  CONF_5_9_0
 L  CONF_5_9_1
 L  CONF_5_9_2
 L  CONF_5_9_3
 L  CONF_5_9_4
 L  CONF_5_9_5
 L  CONF_5_9_6
 L  CONF_5_9_7
 L  CONF_5_9_8
 L  CONF_5_9_9
 L  CONF_5_9_10
 L  CONF_5_9_11
 L  CONF_5_9_12
 L  CONF_5_9_13
 L  CONF_5_9_14
 L  CONF_5_9_15
 L  CONF_5_9_16
 L  CONF_5_9_17
 L  CONF_5_9_18
 L  CONF_5_9_19
 L  CONF_5_9_20
 L  CONF_5_9_21
 L  CONF_5_9_22
 L  CONF_5_9_23
 L  CONF_5_9_24
 L  CONF_23_24_0
 L  CONF_23_24_1
 L  CONF_23_24_2
 L  CONF_23_24_3
 L  CONF_23_24_4
 L  CONF_23_24_5
 L  CONF_23_24_6
 L  CONF_23_24_7
 L  CONF_23_24_8
 L  CONF_23_24_9
 L  CONF_23_24_10
 L  CONF_23_24_11
 L  CONF_23_24_12
 L  CONF_23_24_13
 L  CONF_23_24_14
 L  CONF_23_24_15
 L  CONF_23_24_16
 L  CONF_23_24_17
 L  CONF_23_24_18
 L  CONF_23_24_19
 L  CONF_23_24_20
 L  CONF_23_24_21
 L  CONF_23_24_22
 L  CONF_23_24_23
 L  CONF_23_24_24
 L  CONF_0_1_0
 L  CONF_0_1_1
 L  CONF_0_1_2
 L  CONF_0_1_3
 L  CONF_0_1_4
 L  CONF_0_1_5
 L  CONF_0_1_6
 L  CONF_0_1_7
 L  CONF_0_1_8
 L  CONF_0_1_9
 L  CONF_0_1_10
 L  CONF_0_1_11
 L  CONF_0_1_12
 L  CONF_0_1_13
 L  CONF_0_1_14
 L  CONF_0_1_15
 L  CONF_0_1_16
 L  CONF_0_1_17
 L  CONF_0_1_18
 L  CONF_0_1_19
 L  CONF_0_1_20
 L  CONF_0_1_21
 L  CONF_0_1_22
 L  CONF_0_1_23
 L  CONF_0_1_24
 L  CONF_2_4_0
 L  CONF_2_4_1
 L  CONF_2_4_2
 L  CONF_2_4_3
 L  CONF_2_4_4
 L  CONF_2_4_5
 L  CONF_2_4_6
 L  CONF_2_4_7
 L  CONF_2_4_8
 L  CONF_2_4_9
 L  CONF_2_4_10
 L  CONF_2_4_11
 L  CONF_2_4_12
 L  CONF_2_4_13
 L  CONF_2_4_14
 L  CONF_2_4_15
 L  CONF_2_4_16
 L  CONF_2_4_17
 L  CONF_2_4_18
 L  CONF_2_4_19
 L  CONF_2_4_20
 L  CONF_2_4_21
 L  CONF_2_4_22
 L  CONF_2_4_23
 L  CONF_2_4_24
 L  CONF_1_2_0
 L  CONF_1_2_1
 L  CONF_1_2_2
 L  CONF_1_2_3
 L  CONF_1_2_4
 L  CONF_1_2_5
 L  CONF_1_2_6
 L  CONF_1_2_7
 L  CONF_1_2_8
 L  CONF_1_2_9
 L  CONF_1_2_10
 L  CONF_1_2_11
 L  CONF_1_2_12
 L  CONF_1_2_13
 L  CONF_1_2_14
 L  CONF_1_2_15
 L  CONF_1_2_16
 L  CONF_1_2_17
 L  CONF_1_2_18
 L  CONF_1_2_19
 L  CONF_1_2_20
 L  CONF_1_2_21
 L  CONF_1_2_22
 L  CONF_1_2_23
 L  CONF_1_2_24
 L  CONF_0_4_0
 L  CONF_0_4_1
 L  CONF_0_4_2
 L  CONF_0_4_3
 L  CONF_0_4_4
 L  CONF_0_4_5
 L  CONF_0_4_6
 L  CONF_0_4_7
 L  CONF_0_4_8
 L  CONF_0_4_9
 L  CONF_0_4_10
 L  CONF_0_4_11
 L  CONF_0_4_12
 L  CONF_0_4_13
 L  CONF_0_4_14
 L  CONF_0_4_15
 L  CONF_0_4_16
 L  CONF_0_4_17
 L  CONF_0_4_18
 L  CONF_0_4_19
 L  CONF_0_4_20
 L  CONF_0_4_21
 L  CONF_0_4_22
 L  CONF_0_4_23
 L  CONF_0_4_24
 L  CONF_10_11_0
 L  CONF_10_11_1
 L  CONF_10_11_2
 L  CONF_10_11_3
 L  CONF_10_11_4
 L  CONF_10_11_5
 L  CONF_10_11_6
 L  CONF_10_11_7
 L  CONF_10_11_8
 L  CONF_10_11_9
 L  CONF_10_11_10
 L  CONF_10_11_11
 L  CONF_10_11_12
 L  CONF_10_11_13
 L  CONF_10_11_14
 L  CONF_10_11_15
 L  CONF_10_11_16
 L  CONF_10_11_17
 L  CONF_10_11_18
 L  CONF_10_11_19
 L  CONF_10_11_20
 L  CONF_10_11_21
 L  CONF_10_11_22
 L  CONF_10_11_23
 L  CONF_10_11_24
 L  CONF_10_14_0
 L  CONF_10_14_1
 L  CONF_10_14_2
 L  CONF_10_14_3
 L  CONF_10_14_4
 L  CONF_10_14_5
 L  CONF_10_14_6
 L  CONF_10_14_7
 L  CONF_10_14_8
 L  CONF_10_14_9
 L  CONF_10_14_10
 L  CONF_10_14_11
 L  CONF_10_14_12
 L  CONF_10_14_13
 L  CONF_10_14_14
 L  CONF_10_14_15
 L  CONF_10_14_16
 L  CONF_10_14_17
 L  CONF_10_14_18
 L  CONF_10_14_19
 L  CONF_10_14_20
 L  CONF_10_14_21
 L  CONF_10_14_22
 L  CONF_10_14_23
 L  CONF_10_14_24
 L  CONF_11_13_0
 L  CONF_11_13_1
 L  CONF_11_13_2
 L  CONF_11_13_3
 L  CONF_11_13_4
 L  CONF_11_13_5
 L  CONF_11_13_6
 L  CONF_11_13_7
 L  CONF_11_13_8
 L  CONF_11_13_9
 L  CONF_11_13_10
 L  CONF_11_13_11
 L  CONF_11_13_12
 L  CONF_11_13_13
 L  CONF_11_13_14
 L  CONF_11_13_15
 L  CONF_11_13_16
 L  CONF_11_13_17
 L  CONF_11_13_18
 L  CONF_11_13_19
 L  CONF_11_13_20
 L  CONF_11_13_21
 L  CONF_11_13_22
 L  CONF_11_13_23
 L  CONF_11_13_24
 L  CONF_7_9_0
 L  CONF_7_9_1
 L  CONF_7_9_2
 L  CONF_7_9_3
 L  CONF_7_9_4
 L  CONF_7_9_5
 L  CONF_7_9_6
 L  CONF_7_9_7
 L  CONF_7_9_8
 L  CONF_7_9_9
 L  CONF_7_9_10
 L  CONF_7_9_11
 L  CONF_7_9_12
 L  CONF_7_9_13
 L  CONF_7_9_14
 L  CONF_7_9_15
 L  CONF_7_9_16
 L  CONF_7_9_17
 L  CONF_7_9_18
 L  CONF_7_9_19
 L  CONF_7_9_20
 L  CONF_7_9_21
 L  CONF_7_9_22
 L  CONF_7_9_23
 L  CONF_7_9_24
 L  CONF_6_7_0
 L  CONF_6_7_1
 L  CONF_6_7_2
 L  CONF_6_7_3
 L  CONF_6_7_4
 L  CONF_6_7_5
 L  CONF_6_7_6
 L  CONF_6_7_7
 L  CONF_6_7_8
 L  CONF_6_7_9
 L  CONF_6_7_10
 L  CONF_6_7_11
 L  CONF_6_7_12
 L  CONF_6_7_13
 L  CONF_6_7_14
 L  CONF_6_7_15
 L  CONF_6_7_16
 L  CONF_6_7_17
 L  CONF_6_7_18
 L  CONF_6_7_19
 L  CONF_6_7_20
 L  CONF_6_7_21
 L  CONF_6_7_22
 L  CONF_6_7_23
 L  CONF_6_7_24
 L  CONF_15_16_0
 L  CONF_15_16_1
 L  CONF_15_16_2
 L  CONF_15_16_3
 L  CONF_15_16_4
 L  CONF_15_16_5
 L  CONF_15_16_6
 L  CONF_15_16_7
 L  CONF_15_16_8
 L  CONF_15_16_9
 L  CONF_15_16_10
 L  CONF_15_16_11
 L  CONF_15_16_12
 L  CONF_15_16_13
 L  CONF_15_16_14
 L  CONF_15_16_15
 L  CONF_15_16_16
 L  CONF_15_16_17
 L  CONF_15_16_18
 L  CONF_15_16_19
 L  CONF_15_16_20
 L  CONF_15_16_21
 L  CONF_15_16_22
 L  CONF_15_16_23
 L  CONF_15_16_24
 L  CONF_15_18_0
 L  CONF_15_18_1
 L  CONF_15_18_2
 L  CONF_15_18_3
 L  CONF_15_18_4
 L  CONF_15_18_5
 L  CONF_15_18_6
 L  CONF_15_18_7
 L  CONF_15_18_8
 L  CONF_15_18_9
 L  CONF_15_18_10
 L  CONF_15_18_11
 L  CONF_15_18_12
 L  CONF_15_18_13
 L  CONF_15_18_14
 L  CONF_15_18_15
 L  CONF_15_18_16
 L  CONF_15_18_17
 L  CONF_15_18_18
 L  CONF_15_18_19
 L  CONF_15_18_20
 L  CONF_15_18_21
 L  CONF_15_18_22
 L  CONF_15_18_23
 L  CONF_15_18_24
 L  CONF_15_19_0
 L  CONF_15_19_1
 L  CONF_15_19_2
 L  CONF_15_19_3
 L  CONF_15_19_4
 L  CONF_15_19_5
 L  CONF_15_19_6
 L  CONF_15_19_7
 L  CONF_15_19_8
 L  CONF_15_19_9
 L  CONF_15_19_10
 L  CONF_15_19_11
 L  CONF_15_19_12
 L  CONF_15_19_13
 L  CONF_15_19_14
 L  CONF_15_19_15
 L  CONF_15_19_16
 L  CONF_15_19_17
 L  CONF_15_19_18
 L  CONF_15_19_19
 L  CONF_15_19_20
 L  CONF_15_19_21
 L  CONF_15_19_22
 L  CONF_15_19_23
 L  CONF_15_19_24
 L  CONF_16_18_0
 L  CONF_16_18_1
 L  CONF_16_18_2
 L  CONF_16_18_3
 L  CONF_16_18_4
 L  CONF_16_18_5
 L  CONF_16_18_6
 L  CONF_16_18_7
 L  CONF_16_18_8
 L  CONF_16_18_9
 L  CONF_16_18_10
 L  CONF_16_18_11
 L  CONF_16_18_12
 L  CONF_16_18_13
 L  CONF_16_18_14
 L  CONF_16_18_15
 L  CONF_16_18_16
 L  CONF_16_18_17
 L  CONF_16_18_18
 L  CONF_16_18_19
 L  CONF_16_18_20
 L  CONF_16_18_21
 L  CONF_16_18_22
 L  CONF_16_18_23
 L  CONF_16_18_24
 L  CONF_12_14_0
 L  CONF_12_14_1
 L  CONF_12_14_2
 L  CONF_12_14_3
 L  CONF_12_14_4
 L  CONF_12_14_5
 L  CONF_12_14_6
 L  CONF_12_14_7
 L  CONF_12_14_8
 L  CONF_12_14_9
 L  CONF_12_14_10
 L  CONF_12_14_11
 L  CONF_12_14_12
 L  CONF_12_14_13
 L  CONF_12_14_14
 L  CONF_12_14_15
 L  CONF_12_14_16
 L  CONF_12_14_17
 L  CONF_12_14_18
 L  CONF_12_14_19
 L  CONF_12_14_20
 L  CONF_12_14_21
 L  CONF_12_14_22
 L  CONF_12_14_23
 L  CONF_12_14_24
 L  CONF_20_21_0
 L  CONF_20_21_1
 L  CONF_20_21_2
 L  CONF_20_21_3
 L  CONF_20_21_4
 L  CONF_20_21_5
 L  CONF_20_21_6
 L  CONF_20_21_7
 L  CONF_20_21_8
 L  CONF_20_21_9
 L  CONF_20_21_10
 L  CONF_20_21_11
 L  CONF_20_21_12
 L  CONF_20_21_13
 L  CONF_20_21_14
 L  CONF_20_21_15
 L  CONF_20_21_16
 L  CONF_20_21_17
 L  CONF_20_21_18
 L  CONF_20_21_19
 L  CONF_20_21_20
 L  CONF_20_21_21
 L  CONF_20_21_22
 L  CONF_20_21_23
 L  CONF_20_21_24
 L  CONF_21_23_0
 L  CONF_21_23_1
 L  CONF_21_23_2
 L  CONF_21_23_3
 L  CONF_21_23_4
 L  CONF_21_23_5
 L  CONF_21_23_6
 L  CONF_21_23_7
 L  CONF_21_23_8
 L  CONF_21_23_9
 L  CONF_21_23_10
 L  CONF_21_23_11
 L  CONF_21_23_12
 L  CONF_21_23_13
 L  CONF_21_23_14
 L  CONF_21_23_15
 L  CONF_21_23_16
 L  CONF_21_23_17
 L  CONF_21_23_18
 L  CONF_21_23_19
 L  CONF_21_23_20
 L  CONF_21_23_21
 L  CONF_21_23_22
 L  CONF_21_23_23
 L  CONF_21_23_24
 L  CONF_20_24_0
 L  CONF_20_24_1
 L  CONF_20_24_2
 L  CONF_20_24_3
 L  CONF_20_24_4
 L  CONF_20_24_5
 L  CONF_20_24_6
 L  CONF_20_24_7
 L  CONF_20_24_8
 L  CONF_20_24_9
 L  CONF_20_24_10
 L  CONF_20_24_11
 L  CONF_20_24_12
 L  CONF_20_24_13
 L  CONF_20_24_14
 L  CONF_20_24_15
 L  CONF_20_24_16
 L  CONF_20_24_17
 L  CONF_20_24_18
 L  CONF_20_24_19
 L  CONF_20_24_20
 L  CONF_20_24_21
 L  CONF_20_24_22
 L  CONF_20_24_23
 L  CONF_20_24_24
 L  CONF_5_8_0
 L  CONF_5_8_1
 L  CONF_5_8_2
 L  CONF_5_8_3
 L  CONF_5_8_4
 L  CONF_5_8_5
 L  CONF_5_8_6
 L  CONF_5_8_7
 L  CONF_5_8_8
 L  CONF_5_8_9
 L  CONF_5_8_10
 L  CONF_5_8_11
 L  CONF_5_8_12
 L  CONF_5_8_13
 L  CONF_5_8_14
 L  CONF_5_8_15
 L  CONF_5_8_16
 L  CONF_5_8_17
 L  CONF_5_8_18
 L  CONF_5_8_19
 L  CONF_5_8_20
 L  CONF_5_8_21
 L  CONF_5_8_22
 L  CONF_5_8_23
 L  CONF_5_8_24
 L  CONF_22_24_0
 L  CONF_22_24_1
 L  CONF_22_24_2
 L  CONF_22_24_3
 L  CONF_22_24_4
 L  CONF_22_24_5
 L  CONF_22_24_6
 L  CONF_22_24_7
 L  CONF_22_24_8
 L  CONF_22_24_9
 L  CONF_22_24_10
 L  CONF_22_24_11
 L  CONF_22_24_12
 L  CONF_22_24_13
 L  CONF_22_24_14
 L  CONF_22_24_15
 L  CONF_22_24_16
 L  CONF_22_24_17
 L  CONF_22_24_18
 L  CONF_22_24_19
 L  CONF_22_24_20
 L  CONF_22_24_21
 L  CONF_22_24_22
 L  CONF_22_24_23
 L  CONF_22_24_24
 L  CONF_0_3_0
 L  CONF_0_3_1
 L  CONF_0_3_2
 L  CONF_0_3_3
 L  CONF_0_3_4
 L  CONF_0_3_5
 L  CONF_0_3_6
 L  CONF_0_3_7
 L  CONF_0_3_8
 L  CONF_0_3_9
 L  CONF_0_3_10
 L  CONF_0_3_11
 L  CONF_0_3_12
 L  CONF_0_3_13
 L  CONF_0_3_14
 L  CONF_0_3_15
 L  CONF_0_3_16
 L  CONF_0_3_17
 L  CONF_0_3_18
 L  CONF_0_3_19
 L  CONF_0_3_20
 L  CONF_0_3_21
 L  CONF_0_3_22
 L  CONF_0_3_23
 L  CONF_0_3_24
 L  CONF_17_19_0
 L  CONF_17_19_1
 L  CONF_17_19_2
 L  CONF_17_19_3
 L  CONF_17_19_4
 L  CONF_17_19_5
 L  CONF_17_19_6
 L  CONF_17_19_7
 L  CONF_17_19_8
 L  CONF_17_19_9
 L  CONF_17_19_10
 L  CONF_17_19_11
 L  CONF_17_19_12
 L  CONF_17_19_13
 L  CONF_17_19_14
 L  CONF_17_19_15
 L  CONF_17_19_16
 L  CONF_17_19_17
 L  CONF_17_19_18
 L  CONF_17_19_19
 L  CONF_17_19_20
 L  CONF_17_19_21
 L  CONF_17_19_22
 L  CONF_17_19_23
 L  CONF_17_19_24
 L  CONF_1_4_0
 L  CONF_1_4_1
 L  CONF_1_4_2
 L  CONF_1_4_3
 L  CONF_1_4_4
 L  CONF_1_4_5
 L  CONF_1_4_6
 L  CONF_1_4_7
 L  CONF_1_4_8
 L  CONF_1_4_9
 L  CONF_1_4_10
 L  CONF_1_4_11
 L  CONF_1_4_12
 L  CONF_1_4_13
 L  CONF_1_4_14
 L  CONF_1_4_15
 L  CONF_1_4_16
 L  CONF_1_4_17
 L  CONF_1_4_18
 L  CONF_1_4_19
 L  CONF_1_4_20
 L  CONF_1_4_21
 L  CONF_1_4_22
 L  CONF_1_4_23
 L  CONF_1_4_24
 L  CONF_10_13_0
 L  CONF_10_13_1
 L  CONF_10_13_2
 L  CONF_10_13_3
 L  CONF_10_13_4
 L  CONF_10_13_5
 L  CONF_10_13_6
 L  CONF_10_13_7
 L  CONF_10_13_8
 L  CONF_10_13_9
 L  CONF_10_13_10
 L  CONF_10_13_11
 L  CONF_10_13_12
 L  CONF_10_13_13
 L  CONF_10_13_14
 L  CONF_10_13_15
 L  CONF_10_13_16
 L  CONF_10_13_17
 L  CONF_10_13_18
 L  CONF_10_13_19
 L  CONF_10_13_20
 L  CONF_10_13_21
 L  CONF_10_13_22
 L  CONF_10_13_23
 L  CONF_10_13_24
 L  CONF_2_3_0
 L  CONF_2_3_1
 L  CONF_2_3_2
 L  CONF_2_3_3
 L  CONF_2_3_4
 L  CONF_2_3_5
 L  CONF_2_3_6
 L  CONF_2_3_7
 L  CONF_2_3_8
 L  CONF_2_3_9
 L  CONF_2_3_10
 L  CONF_2_3_11
 L  CONF_2_3_12
 L  CONF_2_3_13
 L  CONF_2_3_14
 L  CONF_2_3_15
 L  CONF_2_3_16
 L  CONF_2_3_17
 L  CONF_2_3_18
 L  CONF_2_3_19
 L  CONF_2_3_20
 L  CONF_2_3_21
 L  CONF_2_3_22
 L  CONF_2_3_23
 L  CONF_2_3_24
 L  CONF_11_12_0
 L  CONF_11_12_1
 L  CONF_11_12_2
 L  CONF_11_12_3
 L  CONF_11_12_4
 L  CONF_11_12_5
 L  CONF_11_12_6
 L  CONF_11_12_7
 L  CONF_11_12_8
 L  CONF_11_12_9
 L  CONF_11_12_10
 L  CONF_11_12_11
 L  CONF_11_12_12
 L  CONF_11_12_13
 L  CONF_11_12_14
 L  CONF_11_12_15
 L  CONF_11_12_16
 L  CONF_11_12_17
 L  CONF_11_12_18
 L  CONF_11_12_19
 L  CONF_11_12_20
 L  CONF_11_12_21
 L  CONF_11_12_22
 L  CONF_11_12_23
 L  CONF_11_12_24
 L  CONF_6_9_0
 L  CONF_6_9_1
 L  CONF_6_9_2
 L  CONF_6_9_3
 L  CONF_6_9_4
 L  CONF_6_9_5
 L  CONF_6_9_6
 L  CONF_6_9_7
 L  CONF_6_9_8
 L  CONF_6_9_9
 L  CONF_6_9_10
 L  CONF_6_9_11
 L  CONF_6_9_12
 L  CONF_6_9_13
 L  CONF_6_9_14
 L  CONF_6_9_15
 L  CONF_6_9_16
 L  CONF_6_9_17
 L  CONF_6_9_18
 L  CONF_6_9_19
 L  CONF_6_9_20
 L  CONF_6_9_21
 L  CONF_6_9_22
 L  CONF_6_9_23
 L  CONF_6_9_24
 L  CONF_7_8_0
 L  CONF_7_8_1
 L  CONF_7_8_2
 L  CONF_7_8_3
 L  CONF_7_8_4
 L  CONF_7_8_5
 L  CONF_7_8_6
 L  CONF_7_8_7
 L  CONF_7_8_8
 L  CONF_7_8_9
 L  CONF_7_8_10
 L  CONF_7_8_11
 L  CONF_7_8_12
 L  CONF_7_8_13
 L  CONF_7_8_14
 L  CONF_7_8_15
 L  CONF_7_8_16
 L  CONF_7_8_17
 L  CONF_7_8_18
 L  CONF_7_8_19
 L  CONF_7_8_20
 L  CONF_7_8_21
 L  CONF_7_8_22
 L  CONF_7_8_23
 L  CONF_7_8_24
COLUMNS
    x_0_0       ASSIGN_0  1.0
    x_0_0       CAP_0  24
    x_0_0       CONF_0_1_0  1.0
    x_0_0       CONF_0_2_0  1.0
    x_0_0       CONF_0_3_0  1.0
    x_0_0       CONF_0_4_0  1.0
    x_0_1       ASSIGN_0  1.0
    x_0_1       CAP_1  24
    x_0_1       CONF_0_1_1  1.0
    x_0_1       CONF_0_2_1  1.0
    x_0_1       CONF_0_3_1  1.0
    x_0_1       CONF_0_4_1  1.0
    x_0_2       ASSIGN_0  1.0
    x_0_2       CAP_2  24
    x_0_2       CONF_0_1_2  1.0
    x_0_2       CONF_0_2_2  1.0
    x_0_2       CONF_0_3_2  1.0
    x_0_2       CONF_0_4_2  1.0
    x_0_3       ASSIGN_0  1.0
    x_0_3       CAP_3  24
    x_0_3       CONF_0_1_3  1.0
    x_0_3       CONF_0_2_3  1.0
    x_0_3       CONF_0_3_3  1.0
    x_0_3       CONF_0_4_3  1.0
    x_0_4       ASSIGN_0  1.0
    x_0_4       CAP_4  24
    x_0_4       CONF_0_1_4  1.0
    x_0_4       CONF_0_2_4  1.0
    x_0_4       CONF_0_3_4  1.0
    x_0_4       CONF_0_4_4  1.0
    x_0_5       ASSIGN_0  1.0
    x_0_5       CAP_5  24
    x_0_5       CONF_0_1_5  1.0
    x_0_5       CONF_0_2_5  1.0
    x_0_5       CONF_0_3_5  1.0
    x_0_5       CONF_0_4_5  1.0
    x_0_6       ASSIGN_0  1.0
    x_0_6       CAP_6  24
    x_0_6       CONF_0_1_6  1.0
    x_0_6       CONF_0_2_6  1.0
    x_0_6       CONF_0_3_6  1.0
    x_0_6       CONF_0_4_6  1.0
    x_0_7       ASSIGN_0  1.0
    x_0_7       CAP_7  24
    x_0_7       CONF_0_1_7  1.0
    x_0_7       CONF_0_2_7  1.0
    x_0_7       CONF_0_3_7  1.0
    x_0_7       CONF_0_4_7  1.0
    x_0_8       ASSIGN_0  1.0
    x_0_8       CAP_8  24
    x_0_8       CONF_0_1_8  1.0
    x_0_8       CONF_0_2_8  1.0
    x_0_8       CONF_0_3_8  1.0
    x_0_8       CONF_0_4_8  1.0
    x_0_9       ASSIGN_0  1.0
    x_0_9       CAP_9  24
    x_0_9       CONF_0_1_9  1.0
    x_0_9       CONF_0_2_9  1.0
    x_0_9       CONF_0_3_9  1.0
    x_0_9       CONF_0_4_9  1.0
    x_0_10      ASSIGN_0  1.0
    x_0_10      CAP_10  24
    x_0_10      CONF_0_1_10  1.0
    x_0_10      CONF_0_2_10  1.0
    x_0_10      CONF_0_3_10  1.0
    x_0_10      CONF_0_4_10  1.0
    x_0_11      ASSIGN_0  1.0
    x_0_11      CAP_11  24
    x_0_11      CONF_0_1_11  1.0
    x_0_11      CONF_0_2_11  1.0
    x_0_11      CONF_0_3_11  1.0
    x_0_11      CONF_0_4_11  1.0
    x_0_12      ASSIGN_0  1.0
    x_0_12      CAP_12  24
    x_0_12      CONF_0_1_12  1.0
    x_0_12      CONF_0_2_12  1.0
    x_0_12      CONF_0_3_12  1.0
    x_0_12      CONF_0_4_12  1.0
    x_0_13      ASSIGN_0  1.0
    x_0_13      CAP_13  24
    x_0_13      CONF_0_1_13  1.0
    x_0_13      CONF_0_2_13  1.0
    x_0_13      CONF_0_3_13  1.0
    x_0_13      CONF_0_4_13  1.0
    x_0_14      ASSIGN_0  1.0
    x_0_14      CAP_14  24
    x_0_14      CONF_0_1_14  1.0
    x_0_14      CONF_0_2_14  1.0
    x_0_14      CONF_0_3_14  1.0
    x_0_14      CONF_0_4_14  1.0
    x_0_15      ASSIGN_0  1.0
    x_0_15      CAP_15  24
    x_0_15      CONF_0_1_15  1.0
    x_0_15      CONF_0_2_15  1.0
    x_0_15      CONF_0_3_15  1.0
    x_0_15      CONF_0_4_15  1.0
    x_0_16      ASSIGN_0  1.0
    x_0_16      CAP_16  24
    x_0_16      CONF_0_1_16  1.0
    x_0_16      CONF_0_2_16  1.0
    x_0_16      CONF_0_3_16  1.0
    x_0_16      CONF_0_4_16  1.0
    x_0_17      ASSIGN_0  1.0
    x_0_17      CAP_17  24
    x_0_17      CONF_0_1_17  1.0
    x_0_17      CONF_0_2_17  1.0
    x_0_17      CONF_0_3_17  1.0
    x_0_17      CONF_0_4_17  1.0
    x_0_18      ASSIGN_0  1.0
    x_0_18      CAP_18  24
    x_0_18      CONF_0_1_18  1.0
    x_0_18      CONF_0_2_18  1.0
    x_0_18      CONF_0_3_18  1.0
    x_0_18      CONF_0_4_18  1.0
    x_0_19      ASSIGN_0  1.0
    x_0_19      CAP_19  24
    x_0_19      CONF_0_1_19  1.0
    x_0_19      CONF_0_2_19  1.0
    x_0_19      CONF_0_3_19  1.0
    x_0_19      CONF_0_4_19  1.0
    x_0_20      ASSIGN_0  1.0
    x_0_20      CAP_20  24
    x_0_20      CONF_0_1_20  1.0
    x_0_20      CONF_0_2_20  1.0
    x_0_20      CONF_0_3_20  1.0
    x_0_20      CONF_0_4_20  1.0
    x_0_21      ASSIGN_0  1.0
    x_0_21      CAP_21  24
    x_0_21      CONF_0_1_21  1.0
    x_0_21      CONF_0_2_21  1.0
    x_0_21      CONF_0_3_21  1.0
    x_0_21      CONF_0_4_21  1.0
    x_0_22      ASSIGN_0  1.0
    x_0_22      CAP_22  24
    x_0_22      CONF_0_1_22  1.0
    x_0_22      CONF_0_2_22  1.0
    x_0_22      CONF_0_3_22  1.0
    x_0_22      CONF_0_4_22  1.0
    x_0_23      ASSIGN_0  1.0
    x_0_23      CAP_23  24
    x_0_23      CONF_0_1_23  1.0
    x_0_23      CONF_0_2_23  1.0
    x_0_23      CONF_0_3_23  1.0
    x_0_23      CONF_0_4_23  1.0
    x_0_24      ASSIGN_0  1.0
    x_0_24      CAP_24  24
    x_0_24      CONF_0_1_24  1.0
    x_0_24      CONF_0_2_24  1.0
    x_0_24      CONF_0_3_24  1.0
    x_0_24      CONF_0_4_24  1.0
    x_1_0       ASSIGN_1  1.0
    x_1_0       CAP_0  31
    x_1_0       CONF_0_1_0  1.0
    x_1_0       CONF_1_2_0  1.0
    x_1_0       CONF_1_3_0  1.0
    x_1_0       CONF_1_4_0  1.0
    x_1_1       ASSIGN_1  1.0
    x_1_1       CAP_1  31
    x_1_1       CONF_0_1_1  1.0
    x_1_1       CONF_1_2_1  1.0
    x_1_1       CONF_1_3_1  1.0
    x_1_1       CONF_1_4_1  1.0
    x_1_2       ASSIGN_1  1.0
    x_1_2       CAP_2  31
    x_1_2       CONF_0_1_2  1.0
    x_1_2       CONF_1_2_2  1.0
    x_1_2       CONF_1_3_2  1.0
    x_1_2       CONF_1_4_2  1.0
    x_1_3       ASSIGN_1  1.0
    x_1_3       CAP_3  31
    x_1_3       CONF_0_1_3  1.0
    x_1_3       CONF_1_2_3  1.0
    x_1_3       CONF_1_3_3  1.0
    x_1_3       CONF_1_4_3  1.0
    x_1_4       ASSIGN_1  1.0
    x_1_4       CAP_4  31
    x_1_4       CONF_0_1_4  1.0
    x_1_4       CONF_1_2_4  1.0
    x_1_4       CONF_1_3_4  1.0
    x_1_4       CONF_1_4_4  1.0
    x_1_5       ASSIGN_1  1.0
    x_1_5       CAP_5  31
    x_1_5       CONF_0_1_5  1.0
    x_1_5       CONF_1_2_5  1.0
    x_1_5       CONF_1_3_5  1.0
    x_1_5       CONF_1_4_5  1.0
    x_1_6       ASSIGN_1  1.0
    x_1_6       CAP_6  31
    x_1_6       CONF_0_1_6  1.0
    x_1_6       CONF_1_2_6  1.0
    x_1_6       CONF_1_3_6  1.0
    x_1_6       CONF_1_4_6  1.0
    x_1_7       ASSIGN_1  1.0
    x_1_7       CAP_7  31
    x_1_7       CONF_0_1_7  1.0
    x_1_7       CONF_1_2_7  1.0
    x_1_7       CONF_1_3_7  1.0
    x_1_7       CONF_1_4_7  1.0
    x_1_8       ASSIGN_1  1.0
    x_1_8       CAP_8  31
    x_1_8       CONF_0_1_8  1.0
    x_1_8       CONF_1_2_8  1.0
    x_1_8       CONF_1_3_8  1.0
    x_1_8       CONF_1_4_8  1.0
    x_1_9       ASSIGN_1  1.0
    x_1_9       CAP_9  31
    x_1_9       CONF_0_1_9  1.0
    x_1_9       CONF_1_2_9  1.0
    x_1_9       CONF_1_3_9  1.0
    x_1_9       CONF_1_4_9  1.0
    x_1_10      ASSIGN_1  1.0
    x_1_10      CAP_10  31
    x_1_10      CONF_0_1_10  1.0
    x_1_10      CONF_1_2_10  1.0
    x_1_10      CONF_1_3_10  1.0
    x_1_10      CONF_1_4_10  1.0
    x_1_11      ASSIGN_1  1.0
    x_1_11      CAP_11  31
    x_1_11      CONF_0_1_11  1.0
    x_1_11      CONF_1_2_11  1.0
    x_1_11      CONF_1_3_11  1.0
    x_1_11      CONF_1_4_11  1.0
    x_1_12      ASSIGN_1  1.0
    x_1_12      CAP_12  31
    x_1_12      CONF_0_1_12  1.0
    x_1_12      CONF_1_2_12  1.0
    x_1_12      CONF_1_3_12  1.0
    x_1_12      CONF_1_4_12  1.0
    x_1_13      ASSIGN_1  1.0
    x_1_13      CAP_13  31
    x_1_13      CONF_0_1_13  1.0
    x_1_13      CONF_1_2_13  1.0
    x_1_13      CONF_1_3_13  1.0
    x_1_13      CONF_1_4_13  1.0
    x_1_14      ASSIGN_1  1.0
    x_1_14      CAP_14  31
    x_1_14      CONF_0_1_14  1.0
    x_1_14      CONF_1_2_14  1.0
    x_1_14      CONF_1_3_14  1.0
    x_1_14      CONF_1_4_14  1.0
    x_1_15      ASSIGN_1  1.0
    x_1_15      CAP_15  31
    x_1_15      CONF_0_1_15  1.0
    x_1_15      CONF_1_2_15  1.0
    x_1_15      CONF_1_3_15  1.0
    x_1_15      CONF_1_4_15  1.0
    x_1_16      ASSIGN_1  1.0
    x_1_16      CAP_16  31
    x_1_16      CONF_0_1_16  1.0
    x_1_16      CONF_1_2_16  1.0
    x_1_16      CONF_1_3_16  1.0
    x_1_16      CONF_1_4_16  1.0
    x_1_17      ASSIGN_1  1.0
    x_1_17      CAP_17  31
    x_1_17      CONF_0_1_17  1.0
    x_1_17      CONF_1_2_17  1.0
    x_1_17      CONF_1_3_17  1.0
    x_1_17      CONF_1_4_17  1.0
    x_1_18      ASSIGN_1  1.0
    x_1_18      CAP_18  31
    x_1_18      CONF_0_1_18  1.0
    x_1_18      CONF_1_2_18  1.0
    x_1_18      CONF_1_3_18  1.0
    x_1_18      CONF_1_4_18  1.0
    x_1_19      ASSIGN_1  1.0
    x_1_19      CAP_19  31
    x_1_19      CONF_0_1_19  1.0
    x_1_19      CONF_1_2_19  1.0
    x_1_19      CONF_1_3_19  1.0
    x_1_19      CONF_1_4_19  1.0
    x_1_20      ASSIGN_1  1.0
    x_1_20      CAP_20  31
    x_1_20      CONF_0_1_20  1.0
    x_1_20      CONF_1_2_20  1.0
    x_1_20      CONF_1_3_20  1.0
    x_1_20      CONF_1_4_20  1.0
    x_1_21      ASSIGN_1  1.0
    x_1_21      CAP_21  31
    x_1_21      CONF_0_1_21  1.0
    x_1_21      CONF_1_2_21  1.0
    x_1_21      CONF_1_3_21  1.0
    x_1_21      CONF_1_4_21  1.0
    x_1_22      ASSIGN_1  1.0
    x_1_22      CAP_22  31
    x_1_22      CONF_0_1_22  1.0
    x_1_22      CONF_1_2_22  1.0
    x_1_22      CONF_1_3_22  1.0
    x_1_22      CONF_1_4_22  1.0
    x_1_23      ASSIGN_1  1.0
    x_1_23      CAP_23  31
    x_1_23      CONF_0_1_23  1.0
    x_1_23      CONF_1_2_23  1.0
    x_1_23      CONF_1_3_23  1.0
    x_1_23      CONF_1_4_23  1.0
    x_1_24      ASSIGN_1  1.0
    x_1_24      CAP_24  31
    x_1_24      CONF_0_1_24  1.0
    x_1_24      CONF_1_2_24  1.0
    x_1_24      CONF_1_3_24  1.0
    x_1_24      CONF_1_4_24  1.0
    x_2_0       ASSIGN_2  1.0
    x_2_0       CAP_0  46
    x_2_0       CONF_0_2_0  1.0
    x_2_0       CONF_1_2_0  1.0
    x_2_0       CONF_2_3_0  1.0
    x_2_0       CONF_2_4_0  1.0
    x_2_1       ASSIGN_2  1.0
    x_2_1       CAP_1  46
    x_2_1       CONF_0_2_1  1.0
    x_2_1       CONF_1_2_1  1.0
    x_2_1       CONF_2_3_1  1.0
    x_2_1       CONF_2_4_1  1.0
    x_2_2       ASSIGN_2  1.0
    x_2_2       CAP_2  46
    x_2_2       CONF_0_2_2  1.0
    x_2_2       CONF_1_2_2  1.0
    x_2_2       CONF_2_3_2  1.0
    x_2_2       CONF_2_4_2  1.0
    x_2_3       ASSIGN_2  1.0
    x_2_3       CAP_3  46
    x_2_3       CONF_0_2_3  1.0
    x_2_3       CONF_1_2_3  1.0
    x_2_3       CONF_2_3_3  1.0
    x_2_3       CONF_2_4_3  1.0
    x_2_4       ASSIGN_2  1.0
    x_2_4       CAP_4  46
    x_2_4       CONF_0_2_4  1.0
    x_2_4       CONF_1_2_4  1.0
    x_2_4       CONF_2_3_4  1.0
    x_2_4       CONF_2_4_4  1.0
    x_2_5       ASSIGN_2  1.0
    x_2_5       CAP_5  46
    x_2_5       CONF_0_2_5  1.0
    x_2_5       CONF_1_2_5  1.0
    x_2_5       CONF_2_3_5  1.0
    x_2_5       CONF_2_4_5  1.0
    x_2_6       ASSIGN_2  1.0
    x_2_6       CAP_6  46
    x_2_6       CONF_0_2_6  1.0
    x_2_6       CONF_1_2_6  1.0
    x_2_6       CONF_2_3_6  1.0
    x_2_6       CONF_2_4_6  1.0
    x_2_7       ASSIGN_2  1.0
    x_2_7       CAP_7  46
    x_2_7       CONF_0_2_7  1.0
    x_2_7       CONF_1_2_7  1.0
    x_2_7       CONF_2_3_7  1.0
    x_2_7       CONF_2_4_7  1.0
    x_2_8       ASSIGN_2  1.0
    x_2_8       CAP_8  46
    x_2_8       CONF_0_2_8  1.0
    x_2_8       CONF_1_2_8  1.0
    x_2_8       CONF_2_3_8  1.0
    x_2_8       CONF_2_4_8  1.0
    x_2_9       ASSIGN_2  1.0
    x_2_9       CAP_9  46
    x_2_9       CONF_0_2_9  1.0
    x_2_9       CONF_1_2_9  1.0
    x_2_9       CONF_2_3_9  1.0
    x_2_9       CONF_2_4_9  1.0
    x_2_10      ASSIGN_2  1.0
    x_2_10      CAP_10  46
    x_2_10      CONF_0_2_10  1.0
    x_2_10      CONF_1_2_10  1.0
    x_2_10      CONF_2_3_10  1.0
    x_2_10      CONF_2_4_10  1.0
    x_2_11      ASSIGN_2  1.0
    x_2_11      CAP_11  46
    x_2_11      CONF_0_2_11  1.0
    x_2_11      CONF_1_2_11  1.0
    x_2_11      CONF_2_3_11  1.0
    x_2_11      CONF_2_4_11  1.0
    x_2_12      ASSIGN_2  1.0
    x_2_12      CAP_12  46
    x_2_12      CONF_0_2_12  1.0
    x_2_12      CONF_1_2_12  1.0
    x_2_12      CONF_2_3_12  1.0
    x_2_12      CONF_2_4_12  1.0
    x_2_13      ASSIGN_2  1.0
    x_2_13      CAP_13  46
    x_2_13      CONF_0_2_13  1.0
    x_2_13      CONF_1_2_13  1.0
    x_2_13      CONF_2_3_13  1.0
    x_2_13      CONF_2_4_13  1.0
    x_2_14      ASSIGN_2  1.0
    x_2_14      CAP_14  46
    x_2_14      CONF_0_2_14  1.0
    x_2_14      CONF_1_2_14  1.0
    x_2_14      CONF_2_3_14  1.0
    x_2_14      CONF_2_4_14  1.0
    x_2_15      ASSIGN_2  1.0
    x_2_15      CAP_15  46
    x_2_15      CONF_0_2_15  1.0
    x_2_15      CONF_1_2_15  1.0
    x_2_15      CONF_2_3_15  1.0
    x_2_15      CONF_2_4_15  1.0
    x_2_16      ASSIGN_2  1.0
    x_2_16      CAP_16  46
    x_2_16      CONF_0_2_16  1.0
    x_2_16      CONF_1_2_16  1.0
    x_2_16      CONF_2_3_16  1.0
    x_2_16      CONF_2_4_16  1.0
    x_2_17      ASSIGN_2  1.0
    x_2_17      CAP_17  46
    x_2_17      CONF_0_2_17  1.0
    x_2_17      CONF_1_2_17  1.0
    x_2_17      CONF_2_3_17  1.0
    x_2_17      CONF_2_4_17  1.0
    x_2_18      ASSIGN_2  1.0
    x_2_18      CAP_18  46
    x_2_18      CONF_0_2_18  1.0
    x_2_18      CONF_1_2_18  1.0
    x_2_18      CONF_2_3_18  1.0
    x_2_18      CONF_2_4_18  1.0
    x_2_19      ASSIGN_2  1.0
    x_2_19      CAP_19  46
    x_2_19      CONF_0_2_19  1.0
    x_2_19      CONF_1_2_19  1.0
    x_2_19      CONF_2_3_19  1.0
    x_2_19      CONF_2_4_19  1.0
    x_2_20      ASSIGN_2  1.0
    x_2_20      CAP_20  46
    x_2_20      CONF_0_2_20  1.0
    x_2_20      CONF_1_2_20  1.0
    x_2_20      CONF_2_3_20  1.0
    x_2_20      CONF_2_4_20  1.0
    x_2_21      ASSIGN_2  1.0
    x_2_21      CAP_21  46
    x_2_21      CONF_0_2_21  1.0
    x_2_21      CONF_1_2_21  1.0
    x_2_21      CONF_2_3_21  1.0
    x_2_21      CONF_2_4_21  1.0
    x_2_22      ASSIGN_2  1.0
    x_2_22      CAP_22  46
    x_2_22      CONF_0_2_22  1.0
    x_2_22      CONF_1_2_22  1.0
    x_2_22      CONF_2_3_22  1.0
    x_2_22      CONF_2_4_22  1.0
    x_2_23      ASSIGN_2  1.0
    x_2_23      CAP_23  46
    x_2_23      CONF_0_2_23  1.0
    x_2_23      CONF_1_2_23  1.0
    x_2_23      CONF_2_3_23  1.0
    x_2_23      CONF_2_4_23  1.0
    x_2_24      ASSIGN_2  1.0
    x_2_24      CAP_24  46
    x_2_24      CONF_0_2_24  1.0
    x_2_24      CONF_1_2_24  1.0
    x_2_24      CONF_2_3_24  1.0
    x_2_24      CONF_2_4_24  1.0
    x_3_0       ASSIGN_3  1.0
    x_3_0       CAP_0  40
    x_3_0       CONF_0_3_0  1.0
    x_3_0       CONF_1_3_0  1.0
    x_3_0       CONF_2_3_0  1.0
    x_3_0       CONF_3_4_0  1.0
    x_3_1       ASSIGN_3  1.0
    x_3_1       CAP_1  40
    x_3_1       CONF_0_3_1  1.0
    x_3_1       CONF_1_3_1  1.0
    x_3_1       CONF_2_3_1  1.0
    x_3_1       CONF_3_4_1  1.0
    x_3_2       ASSIGN_3  1.0
    x_3_2       CAP_2  40
    x_3_2       CONF_0_3_2  1.0
    x_3_2       CONF_1_3_2  1.0
    x_3_2       CONF_2_3_2  1.0
    x_3_2       CONF_3_4_2  1.0
    x_3_3       ASSIGN_3  1.0
    x_3_3       CAP_3  40
    x_3_3       CONF_0_3_3  1.0
    x_3_3       CONF_1_3_3  1.0
    x_3_3       CONF_2_3_3  1.0
    x_3_3       CONF_3_4_3  1.0
    x_3_4       ASSIGN_3  1.0
    x_3_4       CAP_4  40
    x_3_4       CONF_0_3_4  1.0
    x_3_4       CONF_1_3_4  1.0
    x_3_4       CONF_2_3_4  1.0
    x_3_4       CONF_3_4_4  1.0
    x_3_5       ASSIGN_3  1.0
    x_3_5       CAP_5  40
    x_3_5       CONF_0_3_5  1.0
    x_3_5       CONF_1_3_5  1.0
    x_3_5       CONF_2_3_5  1.0
    x_3_5       CONF_3_4_5  1.0
    x_3_6       ASSIGN_3  1.0
    x_3_6       CAP_6  40
    x_3_6       CONF_0_3_6  1.0
    x_3_6       CONF_1_3_6  1.0
    x_3_6       CONF_2_3_6  1.0
    x_3_6       CONF_3_4_6  1.0
    x_3_7       ASSIGN_3  1.0
    x_3_7       CAP_7  40
    x_3_7       CONF_0_3_7  1.0
    x_3_7       CONF_1_3_7  1.0
    x_3_7       CONF_2_3_7  1.0
    x_3_7       CONF_3_4_7  1.0
    x_3_8       ASSIGN_3  1.0
    x_3_8       CAP_8  40
    x_3_8       CONF_0_3_8  1.0
    x_3_8       CONF_1_3_8  1.0
    x_3_8       CONF_2_3_8  1.0
    x_3_8       CONF_3_4_8  1.0
    x_3_9       ASSIGN_3  1.0
    x_3_9       CAP_9  40
    x_3_9       CONF_0_3_9  1.0
    x_3_9       CONF_1_3_9  1.0
    x_3_9       CONF_2_3_9  1.0
    x_3_9       CONF_3_4_9  1.0
    x_3_10      ASSIGN_3  1.0
    x_3_10      CAP_10  40
    x_3_10      CONF_0_3_10  1.0
    x_3_10      CONF_1_3_10  1.0
    x_3_10      CONF_2_3_10  1.0
    x_3_10      CONF_3_4_10  1.0
    x_3_11      ASSIGN_3  1.0
    x_3_11      CAP_11  40
    x_3_11      CONF_0_3_11  1.0
    x_3_11      CONF_1_3_11  1.0
    x_3_11      CONF_2_3_11  1.0
    x_3_11      CONF_3_4_11  1.0
    x_3_12      ASSIGN_3  1.0
    x_3_12      CAP_12  40
    x_3_12      CONF_0_3_12  1.0
    x_3_12      CONF_1_3_12  1.0
    x_3_12      CONF_2_3_12  1.0
    x_3_12      CONF_3_4_12  1.0
    x_3_13      ASSIGN_3  1.0
    x_3_13      CAP_13  40
    x_3_13      CONF_0_3_13  1.0
    x_3_13      CONF_1_3_13  1.0
    x_3_13      CONF_2_3_13  1.0
    x_3_13      CONF_3_4_13  1.0
    x_3_14      ASSIGN_3  1.0
    x_3_14      CAP_14  40
    x_3_14      CONF_0_3_14  1.0
    x_3_14      CONF_1_3_14  1.0
    x_3_14      CONF_2_3_14  1.0
    x_3_14      CONF_3_4_14  1.0
    x_3_15      ASSIGN_3  1.0
    x_3_15      CAP_15  40
    x_3_15      CONF_0_3_15  1.0
    x_3_15      CONF_1_3_15  1.0
    x_3_15      CONF_2_3_15  1.0
    x_3_15      CONF_3_4_15  1.0
    x_3_16      ASSIGN_3  1.0
    x_3_16      CAP_16  40
    x_3_16      CONF_0_3_16  1.0
    x_3_16      CONF_1_3_16  1.0
    x_3_16      CONF_2_3_16  1.0
    x_3_16      CONF_3_4_16  1.0
    x_3_17      ASSIGN_3  1.0
    x_3_17      CAP_17  40
    x_3_17      CONF_0_3_17  1.0
    x_3_17      CONF_1_3_17  1.0
    x_3_17      CONF_2_3_17  1.0
    x_3_17      CONF_3_4_17  1.0
    x_3_18      ASSIGN_3  1.0
    x_3_18      CAP_18  40
    x_3_18      CONF_0_3_18  1.0
    x_3_18      CONF_1_3_18  1.0
    x_3_18      CONF_2_3_18  1.0
    x_3_18      CONF_3_4_18  1.0
    x_3_19      ASSIGN_3  1.0
    x_3_19      CAP_19  40
    x_3_19      CONF_0_3_19  1.0
    x_3_19      CONF_1_3_19  1.0
    x_3_19      CONF_2_3_19  1.0
    x_3_19      CONF_3_4_19  1.0
    x_3_20      ASSIGN_3  1.0
    x_3_20      CAP_20  40
    x_3_20      CONF_0_3_20  1.0
    x_3_20      CONF_1_3_20  1.0
    x_3_20      CONF_2_3_20  1.0
    x_3_20      CONF_3_4_20  1.0
    x_3_21      ASSIGN_3  1.0
    x_3_21      CAP_21  40
    x_3_21      CONF_0_3_21  1.0
    x_3_21      CONF_1_3_21  1.0
    x_3_21      CONF_2_3_21  1.0
    x_3_21      CONF_3_4_21  1.0
    x_3_22      ASSIGN_3  1.0
    x_3_22      CAP_22  40
    x_3_22      CONF_0_3_22  1.0
    x_3_22      CONF_1_3_22  1.0
    x_3_22      CONF_2_3_22  1.0
    x_3_22      CONF_3_4_22  1.0
    x_3_23      ASSIGN_3  1.0
    x_3_23      CAP_23  40
    x_3_23      CONF_0_3_23  1.0
    x_3_23      CONF_1_3_23  1.0
    x_3_23      CONF_2_3_23  1.0
    x_3_23      CONF_3_4_23  1.0
    x_3_24      ASSIGN_3  1.0
    x_3_24      CAP_24  40
    x_3_24      CONF_0_3_24  1.0
    x_3_24      CONF_1_3_24  1.0
    x_3_24      CONF_2_3_24  1.0
    x_3_24      CONF_3_4_24  1.0
    x_4_0       ASSIGN_4  1.0
    x_4_0       CAP_0  32
    x_4_0       CONF_0_4_0  1.0
    x_4_0       CONF_1_4_0  1.0
    x_4_0       CONF_2_4_0  1.0
    x_4_0       CONF_3_4_0  1.0
    x_4_1       ASSIGN_4  1.0
    x_4_1       CAP_1  32
    x_4_1       CONF_0_4_1  1.0
    x_4_1       CONF_1_4_1  1.0
    x_4_1       CONF_2_4_1  1.0
    x_4_1       CONF_3_4_1  1.0
    x_4_2       ASSIGN_4  1.0
    x_4_2       CAP_2  32
    x_4_2       CONF_0_4_2  1.0
    x_4_2       CONF_1_4_2  1.0
    x_4_2       CONF_2_4_2  1.0
    x_4_2       CONF_3_4_2  1.0
    x_4_3       ASSIGN_4  1.0
    x_4_3       CAP_3  32
    x_4_3       CONF_0_4_3  1.0
    x_4_3       CONF_1_4_3  1.0
    x_4_3       CONF_2_4_3  1.0
    x_4_3       CONF_3_4_3  1.0
    x_4_4       ASSIGN_4  1.0
    x_4_4       CAP_4  32
    x_4_4       CONF_0_4_4  1.0
    x_4_4       CONF_1_4_4  1.0
    x_4_4       CONF_2_4_4  1.0
    x_4_4       CONF_3_4_4  1.0
    x_4_5       ASSIGN_4  1.0
    x_4_5       CAP_5  32
    x_4_5       CONF_0_4_5  1.0
    x_4_5       CONF_1_4_5  1.0
    x_4_5       CONF_2_4_5  1.0
    x_4_5       CONF_3_4_5  1.0
    x_4_6       ASSIGN_4  1.0
    x_4_6       CAP_6  32
    x_4_6       CONF_0_4_6  1.0
    x_4_6       CONF_1_4_6  1.0
    x_4_6       CONF_2_4_6  1.0
    x_4_6       CONF_3_4_6  1.0
    x_4_7       ASSIGN_4  1.0
    x_4_7       CAP_7  32
    x_4_7       CONF_0_4_7  1.0
    x_4_7       CONF_1_4_7  1.0
    x_4_7       CONF_2_4_7  1.0
    x_4_7       CONF_3_4_7  1.0
    x_4_8       ASSIGN_4  1.0
    x_4_8       CAP_8  32
    x_4_8       CONF_0_4_8  1.0
    x_4_8       CONF_1_4_8  1.0
    x_4_8       CONF_2_4_8  1.0
    x_4_8       CONF_3_4_8  1.0
    x_4_9       ASSIGN_4  1.0
    x_4_9       CAP_9  32
    x_4_9       CONF_0_4_9  1.0
    x_4_9       CONF_1_4_9  1.0
    x_4_9       CONF_2_4_9  1.0
    x_4_9       CONF_3_4_9  1.0
    x_4_10      ASSIGN_4  1.0
    x_4_10      CAP_10  32
    x_4_10      CONF_0_4_10  1.0
    x_4_10      CONF_1_4_10  1.0
    x_4_10      CONF_2_4_10  1.0
    x_4_10      CONF_3_4_10  1.0
    x_4_11      ASSIGN_4  1.0
    x_4_11      CAP_11  32
    x_4_11      CONF_0_4_11  1.0
    x_4_11      CONF_1_4_11  1.0
    x_4_11      CONF_2_4_11  1.0
    x_4_11      CONF_3_4_11  1.0
    x_4_12      ASSIGN_4  1.0
    x_4_12      CAP_12  32
    x_4_12      CONF_0_4_12  1.0
    x_4_12      CONF_1_4_12  1.0
    x_4_12      CONF_2_4_12  1.0
    x_4_12      CONF_3_4_12  1.0
    x_4_13      ASSIGN_4  1.0
    x_4_13      CAP_13  32
    x_4_13      CONF_0_4_13  1.0
    x_4_13      CONF_1_4_13  1.0
    x_4_13      CONF_2_4_13  1.0
    x_4_13      CONF_3_4_13  1.0
    x_4_14      ASSIGN_4  1.0
    x_4_14      CAP_14  32
    x_4_14      CONF_0_4_14  1.0
    x_4_14      CONF_1_4_14  1.0
    x_4_14      CONF_2_4_14  1.0
    x_4_14      CONF_3_4_14  1.0
    x_4_15      ASSIGN_4  1.0
    x_4_15      CAP_15  32
    x_4_15      CONF_0_4_15  1.0
    x_4_15      CONF_1_4_15  1.0
    x_4_15      CONF_2_4_15  1.0
    x_4_15      CONF_3_4_15  1.0
    x_4_16      ASSIGN_4  1.0
    x_4_16      CAP_16  32
    x_4_16      CONF_0_4_16  1.0
    x_4_16      CONF_1_4_16  1.0
    x_4_16      CONF_2_4_16  1.0
    x_4_16      CONF_3_4_16  1.0
    x_4_17      ASSIGN_4  1.0
    x_4_17      CAP_17  32
    x_4_17      CONF_0_4_17  1.0
    x_4_17      CONF_1_4_17  1.0
    x_4_17      CONF_2_4_17  1.0
    x_4_17      CONF_3_4_17  1.0
    x_4_18      ASSIGN_4  1.0
    x_4_18      CAP_18  32
    x_4_18      CONF_0_4_18  1.0
    x_4_18      CONF_1_4_18  1.0
    x_4_18      CONF_2_4_18  1.0
    x_4_18      CONF_3_4_18  1.0
    x_4_19      ASSIGN_4  1.0
    x_4_19      CAP_19  32
    x_4_19      CONF_0_4_19  1.0
    x_4_19      CONF_1_4_19  1.0
    x_4_19      CONF_2_4_19  1.0
    x_4_19      CONF_3_4_19  1.0
    x_4_20      ASSIGN_4  1.0
    x_4_20      CAP_20  32
    x_4_20      CONF_0_4_20  1.0
    x_4_20      CONF_1_4_20  1.0
    x_4_20      CONF_2_4_20  1.0
    x_4_20      CONF_3_4_20  1.0
    x_4_21      ASSIGN_4  1.0
    x_4_21      CAP_21  32
    x_4_21      CONF_0_4_21  1.0
    x_4_21      CONF_1_4_21  1.0
    x_4_21      CONF_2_4_21  1.0
    x_4_21      CONF_3_4_21  1.0
    x_4_22      ASSIGN_4  1.0
    x_4_22      CAP_22  32
    x_4_22      CONF_0_4_22  1.0
    x_4_22      CONF_1_4_22  1.0
    x_4_22      CONF_2_4_22  1.0
    x_4_22      CONF_3_4_22  1.0
    x_4_23      ASSIGN_4  1.0
    x_4_23      CAP_23  32
    x_4_23      CONF_0_4_23  1.0
    x_4_23      CONF_1_4_23  1.0
    x_4_23      CONF_2_4_23  1.0
    x_4_23      CONF_3_4_23  1.0
    x_4_24      ASSIGN_4  1.0
    x_4_24      CAP_24  32
    x_4_24      CONF_0_4_24  1.0
    x_4_24      CONF_1_4_24  1.0
    x_4_24      CONF_2_4_24  1.0
    x_4_24      CONF_3_4_24  1.0
    x_5_0       ASSIGN_5  1.0
    x_5_0       CAP_0  34
    x_5_0       CONF_5_6_0  1.0
    x_5_0       CONF_5_7_0  1.0
    x_5_0       CONF_5_8_0  1.0
    x_5_0       CONF_5_9_0  1.0
    x_5_1       ASSIGN_5  1.0
    x_5_1       CAP_1  34
    x_5_1       CONF_5_6_1  1.0
    x_5_1       CONF_5_7_1  1.0
    x_5_1       CONF_5_8_1  1.0
    x_5_1       CONF_5_9_1  1.0
    x_5_2       ASSIGN_5  1.0
    x_5_2       CAP_2  34
    x_5_2       CONF_5_6_2  1.0
    x_5_2       CONF_5_7_2  1.0
    x_5_2       CONF_5_8_2  1.0
    x_5_2       CONF_5_9_2  1.0
    x_5_3       ASSIGN_5  1.0
    x_5_3       CAP_3  34
    x_5_3       CONF_5_6_3  1.0
    x_5_3       CONF_5_7_3  1.0
    x_5_3       CONF_5_8_3  1.0
    x_5_3       CONF_5_9_3  1.0
    x_5_4       ASSIGN_5  1.0
    x_5_4       CAP_4  34
    x_5_4       CONF_5_6_4  1.0
    x_5_4       CONF_5_7_4  1.0
    x_5_4       CONF_5_8_4  1.0
    x_5_4       CONF_5_9_4  1.0
    x_5_5       ASSIGN_5  1.0
    x_5_5       CAP_5  34
    x_5_5       CONF_5_6_5  1.0
    x_5_5       CONF_5_7_5  1.0
    x_5_5       CONF_5_8_5  1.0
    x_5_5       CONF_5_9_5  1.0
    x_5_6       ASSIGN_5  1.0
    x_5_6       CAP_6  34
    x_5_6       CONF_5_6_6  1.0
    x_5_6       CONF_5_7_6  1.0
    x_5_6       CONF_5_8_6  1.0
    x_5_6       CONF_5_9_6  1.0
    x_5_7       ASSIGN_5  1.0
    x_5_7       CAP_7  34
    x_5_7       CONF_5_6_7  1.0
    x_5_7       CONF_5_7_7  1.0
    x_5_7       CONF_5_8_7  1.0
    x_5_7       CONF_5_9_7  1.0
    x_5_8       ASSIGN_5  1.0
    x_5_8       CAP_8  34
    x_5_8       CONF_5_6_8  1.0
    x_5_8       CONF_5_7_8  1.0
    x_5_8       CONF_5_8_8  1.0
    x_5_8       CONF_5_9_8  1.0
    x_5_9       ASSIGN_5  1.0
    x_5_9       CAP_9  34
    x_5_9       CONF_5_6_9  1.0
    x_5_9       CONF_5_7_9  1.0
    x_5_9       CONF_5_8_9  1.0
    x_5_9       CONF_5_9_9  1.0
    x_5_10      ASSIGN_5  1.0
    x_5_10      CAP_10  34
    x_5_10      CONF_5_6_10  1.0
    x_5_10      CONF_5_7_10  1.0
    x_5_10      CONF_5_8_10  1.0
    x_5_10      CONF_5_9_10  1.0
    x_5_11      ASSIGN_5  1.0
    x_5_11      CAP_11  34
    x_5_11      CONF_5_6_11  1.0
    x_5_11      CONF_5_7_11  1.0
    x_5_11      CONF_5_8_11  1.0
    x_5_11      CONF_5_9_11  1.0
    x_5_12      ASSIGN_5  1.0
    x_5_12      CAP_12  34
    x_5_12      CONF_5_6_12  1.0
    x_5_12      CONF_5_7_12  1.0
    x_5_12      CONF_5_8_12  1.0
    x_5_12      CONF_5_9_12  1.0
    x_5_13      ASSIGN_5  1.0
    x_5_13      CAP_13  34
    x_5_13      CONF_5_6_13  1.0
    x_5_13      CONF_5_7_13  1.0
    x_5_13      CONF_5_8_13  1.0
    x_5_13      CONF_5_9_13  1.0
    x_5_14      ASSIGN_5  1.0
    x_5_14      CAP_14  34
    x_5_14      CONF_5_6_14  1.0
    x_5_14      CONF_5_7_14  1.0
    x_5_14      CONF_5_8_14  1.0
    x_5_14      CONF_5_9_14  1.0
    x_5_15      ASSIGN_5  1.0
    x_5_15      CAP_15  34
    x_5_15      CONF_5_6_15  1.0
    x_5_15      CONF_5_7_15  1.0
    x_5_15      CONF_5_8_15  1.0
    x_5_15      CONF_5_9_15  1.0
    x_5_16      ASSIGN_5  1.0
    x_5_16      CAP_16  34
    x_5_16      CONF_5_6_16  1.0
    x_5_16      CONF_5_7_16  1.0
    x_5_16      CONF_5_8_16  1.0
    x_5_16      CONF_5_9_16  1.0
    x_5_17      ASSIGN_5  1.0
    x_5_17      CAP_17  34
    x_5_17      CONF_5_6_17  1.0
    x_5_17      CONF_5_7_17  1.0
    x_5_17      CONF_5_8_17  1.0
    x_5_17      CONF_5_9_17  1.0
    x_5_18      ASSIGN_5  1.0
    x_5_18      CAP_18  34
    x_5_18      CONF_5_6_18  1.0
    x_5_18      CONF_5_7_18  1.0
    x_5_18      CONF_5_8_18  1.0
    x_5_18      CONF_5_9_18  1.0
    x_5_19      ASSIGN_5  1.0
    x_5_19      CAP_19  34
    x_5_19      CONF_5_6_19  1.0
    x_5_19      CONF_5_7_19  1.0
    x_5_19      CONF_5_8_19  1.0
    x_5_19      CONF_5_9_19  1.0
    x_5_20      ASSIGN_5  1.0
    x_5_20      CAP_20  34
    x_5_20      CONF_5_6_20  1.0
    x_5_20      CONF_5_7_20  1.0
    x_5_20      CONF_5_8_20  1.0
    x_5_20      CONF_5_9_20  1.0
    x_5_21      ASSIGN_5  1.0
    x_5_21      CAP_21  34
    x_5_21      CONF_5_6_21  1.0
    x_5_21      CONF_5_7_21  1.0
    x_5_21      CONF_5_8_21  1.0
    x_5_21      CONF_5_9_21  1.0
    x_5_22      ASSIGN_5  1.0
    x_5_22      CAP_22  34
    x_5_22      CONF_5_6_22  1.0
    x_5_22      CONF_5_7_22  1.0
    x_5_22      CONF_5_8_22  1.0
    x_5_22      CONF_5_9_22  1.0
    x_5_23      ASSIGN_5  1.0
    x_5_23      CAP_23  34
    x_5_23      CONF_5_6_23  1.0
    x_5_23      CONF_5_7_23  1.0
    x_5_23      CONF_5_8_23  1.0
    x_5_23      CONF_5_9_23  1.0
    x_5_24      ASSIGN_5  1.0
    x_5_24      CAP_24  34
    x_5_24      CONF_5_6_24  1.0
    x_5_24      CONF_5_7_24  1.0
    x_5_24      CONF_5_8_24  1.0
    x_5_24      CONF_5_9_24  1.0
    x_6_0       ASSIGN_6  1.0
    x_6_0       CAP_0  51
    x_6_0       CONF_5_6_0  1.0
    x_6_0       CONF_6_7_0  1.0
    x_6_0       CONF_6_8_0  1.0
    x_6_0       CONF_6_9_0  1.0
    x_6_1       ASSIGN_6  1.0
    x_6_1       CAP_1  51
    x_6_1       CONF_5_6_1  1.0
    x_6_1       CONF_6_7_1  1.0
    x_6_1       CONF_6_8_1  1.0
    x_6_1       CONF_6_9_1  1.0
    x_6_2       ASSIGN_6  1.0
    x_6_2       CAP_2  51
    x_6_2       CONF_5_6_2  1.0
    x_6_2       CONF_6_7_2  1.0
    x_6_2       CONF_6_8_2  1.0
    x_6_2       CONF_6_9_2  1.0
    x_6_3       ASSIGN_6  1.0
    x_6_3       CAP_3  51
    x_6_3       CONF_5_6_3  1.0
    x_6_3       CONF_6_7_3  1.0
    x_6_3       CONF_6_8_3  1.0
    x_6_3       CONF_6_9_3  1.0
    x_6_4       ASSIGN_6  1.0
    x_6_4       CAP_4  51
    x_6_4       CONF_5_6_4  1.0
    x_6_4       CONF_6_7_4  1.0
    x_6_4       CONF_6_8_4  1.0
    x_6_4       CONF_6_9_4  1.0
    x_6_5       ASSIGN_6  1.0
    x_6_5       CAP_5  51
    x_6_5       CONF_5_6_5  1.0
    x_6_5       CONF_6_7_5  1.0
    x_6_5       CONF_6_8_5  1.0
    x_6_5       CONF_6_9_5  1.0
    x_6_6       ASSIGN_6  1.0
    x_6_6       CAP_6  51
    x_6_6       CONF_5_6_6  1.0
    x_6_6       CONF_6_7_6  1.0
    x_6_6       CONF_6_8_6  1.0
    x_6_6       CONF_6_9_6  1.0
    x_6_7       ASSIGN_6  1.0
    x_6_7       CAP_7  51
    x_6_7       CONF_5_6_7  1.0
    x_6_7       CONF_6_7_7  1.0
    x_6_7       CONF_6_8_7  1.0
    x_6_7       CONF_6_9_7  1.0
    x_6_8       ASSIGN_6  1.0
    x_6_8       CAP_8  51
    x_6_8       CONF_5_6_8  1.0
    x_6_8       CONF_6_7_8  1.0
    x_6_8       CONF_6_8_8  1.0
    x_6_8       CONF_6_9_8  1.0
    x_6_9       ASSIGN_6  1.0
    x_6_9       CAP_9  51
    x_6_9       CONF_5_6_9  1.0
    x_6_9       CONF_6_7_9  1.0
    x_6_9       CONF_6_8_9  1.0
    x_6_9       CONF_6_9_9  1.0
    x_6_10      ASSIGN_6  1.0
    x_6_10      CAP_10  51
    x_6_10      CONF_5_6_10  1.0
    x_6_10      CONF_6_7_10  1.0
    x_6_10      CONF_6_8_10  1.0
    x_6_10      CONF_6_9_10  1.0
    x_6_11      ASSIGN_6  1.0
    x_6_11      CAP_11  51
    x_6_11      CONF_5_6_11  1.0
    x_6_11      CONF_6_7_11  1.0
    x_6_11      CONF_6_8_11  1.0
    x_6_11      CONF_6_9_11  1.0
    x_6_12      ASSIGN_6  1.0
    x_6_12      CAP_12  51
    x_6_12      CONF_5_6_12  1.0
    x_6_12      CONF_6_7_12  1.0
    x_6_12      CONF_6_8_12  1.0
    x_6_12      CONF_6_9_12  1.0
    x_6_13      ASSIGN_6  1.0
    x_6_13      CAP_13  51
    x_6_13      CONF_5_6_13  1.0
    x_6_13      CONF_6_7_13  1.0
    x_6_13      CONF_6_8_13  1.0
    x_6_13      CONF_6_9_13  1.0
    x_6_14      ASSIGN_6  1.0
    x_6_14      CAP_14  51
    x_6_14      CONF_5_6_14  1.0
    x_6_14      CONF_6_7_14  1.0
    x_6_14      CONF_6_8_14  1.0
    x_6_14      CONF_6_9_14  1.0
    x_6_15      ASSIGN_6  1.0
    x_6_15      CAP_15  51
    x_6_15      CONF_5_6_15  1.0
    x_6_15      CONF_6_7_15  1.0
    x_6_15      CONF_6_8_15  1.0
    x_6_15      CONF_6_9_15  1.0
    x_6_16      ASSIGN_6  1.0
    x_6_16      CAP_16  51
    x_6_16      CONF_5_6_16  1.0
    x_6_16      CONF_6_7_16  1.0
    x_6_16      CONF_6_8_16  1.0
    x_6_16      CONF_6_9_16  1.0
    x_6_17      ASSIGN_6  1.0
    x_6_17      CAP_17  51
    x_6_17      CONF_5_6_17  1.0
    x_6_17      CONF_6_7_17  1.0
    x_6_17      CONF_6_8_17  1.0
    x_6_17      CONF_6_9_17  1.0
    x_6_18      ASSIGN_6  1.0
    x_6_18      CAP_18  51
    x_6_18      CONF_5_6_18  1.0
    x_6_18      CONF_6_7_18  1.0
    x_6_18      CONF_6_8_18  1.0
    x_6_18      CONF_6_9_18  1.0
    x_6_19      ASSIGN_6  1.0
    x_6_19      CAP_19  51
    x_6_19      CONF_5_6_19  1.0
    x_6_19      CONF_6_7_19  1.0
    x_6_19      CONF_6_8_19  1.0
    x_6_19      CONF_6_9_19  1.0
    x_6_20      ASSIGN_6  1.0
    x_6_20      CAP_20  51
    x_6_20      CONF_5_6_20  1.0
    x_6_20      CONF_6_7_20  1.0
    x_6_20      CONF_6_8_20  1.0
    x_6_20      CONF_6_9_20  1.0
    x_6_21      ASSIGN_6  1.0
    x_6_21      CAP_21  51
    x_6_21      CONF_5_6_21  1.0
    x_6_21      CONF_6_7_21  1.0
    x_6_21      CONF_6_8_21  1.0
    x_6_21      CONF_6_9_21  1.0
    x_6_22      ASSIGN_6  1.0
    x_6_22      CAP_22  51
    x_6_22      CONF_5_6_22  1.0
    x_6_22      CONF_6_7_22  1.0
    x_6_22      CONF_6_8_22  1.0
    x_6_22      CONF_6_9_22  1.0
    x_6_23      ASSIGN_6  1.0
    x_6_23      CAP_23  51
    x_6_23      CONF_5_6_23  1.0
    x_6_23      CONF_6_7_23  1.0
    x_6_23      CONF_6_8_23  1.0
    x_6_23      CONF_6_9_23  1.0
    x_6_24      ASSIGN_6  1.0
    x_6_24      CAP_24  51
    x_6_24      CONF_5_6_24  1.0
    x_6_24      CONF_6_7_24  1.0
    x_6_24      CONF_6_8_24  1.0
    x_6_24      CONF_6_9_24  1.0
    x_7_0       ASSIGN_7  1.0
    x_7_0       CAP_0  42
    x_7_0       CONF_5_7_0  1.0
    x_7_0       CONF_6_7_0  1.0
    x_7_0       CONF_7_8_0  1.0
    x_7_0       CONF_7_9_0  1.0
    x_7_1       ASSIGN_7  1.0
    x_7_1       CAP_1  42
    x_7_1       CONF_5_7_1  1.0
    x_7_1       CONF_6_7_1  1.0
    x_7_1       CONF_7_8_1  1.0
    x_7_1       CONF_7_9_1  1.0
    x_7_2       ASSIGN_7  1.0
    x_7_2       CAP_2  42
    x_7_2       CONF_5_7_2  1.0
    x_7_2       CONF_6_7_2  1.0
    x_7_2       CONF_7_8_2  1.0
    x_7_2       CONF_7_9_2  1.0
    x_7_3       ASSIGN_7  1.0
    x_7_3       CAP_3  42
    x_7_3       CONF_5_7_3  1.0
    x_7_3       CONF_6_7_3  1.0
    x_7_3       CONF_7_8_3  1.0
    x_7_3       CONF_7_9_3  1.0
    x_7_4       ASSIGN_7  1.0
    x_7_4       CAP_4  42
    x_7_4       CONF_5_7_4  1.0
    x_7_4       CONF_6_7_4  1.0
    x_7_4       CONF_7_8_4  1.0
    x_7_4       CONF_7_9_4  1.0
    x_7_5       ASSIGN_7  1.0
    x_7_5       CAP_5  42
    x_7_5       CONF_5_7_5  1.0
    x_7_5       CONF_6_7_5  1.0
    x_7_5       CONF_7_8_5  1.0
    x_7_5       CONF_7_9_5  1.0
    x_7_6       ASSIGN_7  1.0
    x_7_6       CAP_6  42
    x_7_6       CONF_5_7_6  1.0
    x_7_6       CONF_6_7_6  1.0
    x_7_6       CONF_7_8_6  1.0
    x_7_6       CONF_7_9_6  1.0
    x_7_7       ASSIGN_7  1.0
    x_7_7       CAP_7  42
    x_7_7       CONF_5_7_7  1.0
    x_7_7       CONF_6_7_7  1.0
    x_7_7       CONF_7_8_7  1.0
    x_7_7       CONF_7_9_7  1.0
    x_7_8       ASSIGN_7  1.0
    x_7_8       CAP_8  42
    x_7_8       CONF_5_7_8  1.0
    x_7_8       CONF_6_7_8  1.0
    x_7_8       CONF_7_8_8  1.0
    x_7_8       CONF_7_9_8  1.0
    x_7_9       ASSIGN_7  1.0
    x_7_9       CAP_9  42
    x_7_9       CONF_5_7_9  1.0
    x_7_9       CONF_6_7_9  1.0
    x_7_9       CONF_7_8_9  1.0
    x_7_9       CONF_7_9_9  1.0
    x_7_10      ASSIGN_7  1.0
    x_7_10      CAP_10  42
    x_7_10      CONF_5_7_10  1.0
    x_7_10      CONF_6_7_10  1.0
    x_7_10      CONF_7_8_10  1.0
    x_7_10      CONF_7_9_10  1.0
    x_7_11      ASSIGN_7  1.0
    x_7_11      CAP_11  42
    x_7_11      CONF_5_7_11  1.0
    x_7_11      CONF_6_7_11  1.0
    x_7_11      CONF_7_8_11  1.0
    x_7_11      CONF_7_9_11  1.0
    x_7_12      ASSIGN_7  1.0
    x_7_12      CAP_12  42
    x_7_12      CONF_5_7_12  1.0
    x_7_12      CONF_6_7_12  1.0
    x_7_12      CONF_7_8_12  1.0
    x_7_12      CONF_7_9_12  1.0
    x_7_13      ASSIGN_7  1.0
    x_7_13      CAP_13  42
    x_7_13      CONF_5_7_13  1.0
    x_7_13      CONF_6_7_13  1.0
    x_7_13      CONF_7_8_13  1.0
    x_7_13      CONF_7_9_13  1.0
    x_7_14      ASSIGN_7  1.0
    x_7_14      CAP_14  42
    x_7_14      CONF_5_7_14  1.0
    x_7_14      CONF_6_7_14  1.0
    x_7_14      CONF_7_8_14  1.0
    x_7_14      CONF_7_9_14  1.0
    x_7_15      ASSIGN_7  1.0
    x_7_15      CAP_15  42
    x_7_15      CONF_5_7_15  1.0
    x_7_15      CONF_6_7_15  1.0
    x_7_15      CONF_7_8_15  1.0
    x_7_15      CONF_7_9_15  1.0
    x_7_16      ASSIGN_7  1.0
    x_7_16      CAP_16  42
    x_7_16      CONF_5_7_16  1.0
    x_7_16      CONF_6_7_16  1.0
    x_7_16      CONF_7_8_16  1.0
    x_7_16      CONF_7_9_16  1.0
    x_7_17      ASSIGN_7  1.0
    x_7_17      CAP_17  42
    x_7_17      CONF_5_7_17  1.0
    x_7_17      CONF_6_7_17  1.0
    x_7_17      CONF_7_8_17  1.0
    x_7_17      CONF_7_9_17  1.0
    x_7_18      ASSIGN_7  1.0
    x_7_18      CAP_18  42
    x_7_18      CONF_5_7_18  1.0
    x_7_18      CONF_6_7_18  1.0
    x_7_18      CONF_7_8_18  1.0
    x_7_18      CONF_7_9_18  1.0
    x_7_19      ASSIGN_7  1.0
    x_7_19      CAP_19  42
    x_7_19      CONF_5_7_19  1.0
    x_7_19      CONF_6_7_19  1.0
    x_7_19      CONF_7_8_19  1.0
    x_7_19      CONF_7_9_19  1.0
    x_7_20      ASSIGN_7  1.0
    x_7_20      CAP_20  42
    x_7_20      CONF_5_7_20  1.0
    x_7_20      CONF_6_7_20  1.0
    x_7_20      CONF_7_8_20  1.0
    x_7_20      CONF_7_9_20  1.0
    x_7_21      ASSIGN_7  1.0
    x_7_21      CAP_21  42
    x_7_21      CONF_5_7_21  1.0
    x_7_21      CONF_6_7_21  1.0
    x_7_21      CONF_7_8_21  1.0
    x_7_21      CONF_7_9_21  1.0
    x_7_22      ASSIGN_7  1.0
    x_7_22      CAP_22  42
    x_7_22      CONF_5_7_22  1.0
    x_7_22      CONF_6_7_22  1.0
    x_7_22      CONF_7_8_22  1.0
    x_7_22      CONF_7_9_22  1.0
    x_7_23      ASSIGN_7  1.0
    x_7_23      CAP_23  42
    x_7_23      CONF_5_7_23  1.0
    x_7_23      CONF_6_7_23  1.0
    x_7_23      CONF_7_8_23  1.0
    x_7_23      CONF_7_9_23  1.0
    x_7_24      ASSIGN_7  1.0
    x_7_24      CAP_24  42
    x_7_24      CONF_5_7_24  1.0
    x_7_24      CONF_6_7_24  1.0
    x_7_24      CONF_7_8_24  1.0
    x_7_24      CONF_7_9_24  1.0
    x_8_0       ASSIGN_8  1.0
    x_8_0       CAP_0  20
    x_8_0       CONF_5_8_0  1.0
    x_8_0       CONF_6_8_0  1.0
    x_8_0       CONF_7_8_0  1.0
    x_8_0       CONF_8_9_0  1.0
    x_8_1       ASSIGN_8  1.0
    x_8_1       CAP_1  20
    x_8_1       CONF_5_8_1  1.0
    x_8_1       CONF_6_8_1  1.0
    x_8_1       CONF_7_8_1  1.0
    x_8_1       CONF_8_9_1  1.0
    x_8_2       ASSIGN_8  1.0
    x_8_2       CAP_2  20
    x_8_2       CONF_5_8_2  1.0
    x_8_2       CONF_6_8_2  1.0
    x_8_2       CONF_7_8_2  1.0
    x_8_2       CONF_8_9_2  1.0
    x_8_3       ASSIGN_8  1.0
    x_8_3       CAP_3  20
    x_8_3       CONF_5_8_3  1.0
    x_8_3       CONF_6_8_3  1.0
    x_8_3       CONF_7_8_3  1.0
    x_8_3       CONF_8_9_3  1.0
    x_8_4       ASSIGN_8  1.0
    x_8_4       CAP_4  20
    x_8_4       CONF_5_8_4  1.0
    x_8_4       CONF_6_8_4  1.0
    x_8_4       CONF_7_8_4  1.0
    x_8_4       CONF_8_9_4  1.0
    x_8_5       ASSIGN_8  1.0
    x_8_5       CAP_5  20
    x_8_5       CONF_5_8_5  1.0
    x_8_5       CONF_6_8_5  1.0
    x_8_5       CONF_7_8_5  1.0
    x_8_5       CONF_8_9_5  1.0
    x_8_6       ASSIGN_8  1.0
    x_8_6       CAP_6  20
    x_8_6       CONF_5_8_6  1.0
    x_8_6       CONF_6_8_6  1.0
    x_8_6       CONF_7_8_6  1.0
    x_8_6       CONF_8_9_6  1.0
    x_8_7       ASSIGN_8  1.0
    x_8_7       CAP_7  20
    x_8_7       CONF_5_8_7  1.0
    x_8_7       CONF_6_8_7  1.0
    x_8_7       CONF_7_8_7  1.0
    x_8_7       CONF_8_9_7  1.0
    x_8_8       ASSIGN_8  1.0
    x_8_8       CAP_8  20
    x_8_8       CONF_5_8_8  1.0
    x_8_8       CONF_6_8_8  1.0
    x_8_8       CONF_7_8_8  1.0
    x_8_8       CONF_8_9_8  1.0
    x_8_9       ASSIGN_8  1.0
    x_8_9       CAP_9  20
    x_8_9       CONF_5_8_9  1.0
    x_8_9       CONF_6_8_9  1.0
    x_8_9       CONF_7_8_9  1.0
    x_8_9       CONF_8_9_9  1.0
    x_8_10      ASSIGN_8  1.0
    x_8_10      CAP_10  20
    x_8_10      CONF_5_8_10  1.0
    x_8_10      CONF_6_8_10  1.0
    x_8_10      CONF_7_8_10  1.0
    x_8_10      CONF_8_9_10  1.0
    x_8_11      ASSIGN_8  1.0
    x_8_11      CAP_11  20
    x_8_11      CONF_5_8_11  1.0
    x_8_11      CONF_6_8_11  1.0
    x_8_11      CONF_7_8_11  1.0
    x_8_11      CONF_8_9_11  1.0
    x_8_12      ASSIGN_8  1.0
    x_8_12      CAP_12  20
    x_8_12      CONF_5_8_12  1.0
    x_8_12      CONF_6_8_12  1.0
    x_8_12      CONF_7_8_12  1.0
    x_8_12      CONF_8_9_12  1.0
    x_8_13      ASSIGN_8  1.0
    x_8_13      CAP_13  20
    x_8_13      CONF_5_8_13  1.0
    x_8_13      CONF_6_8_13  1.0
    x_8_13      CONF_7_8_13  1.0
    x_8_13      CONF_8_9_13  1.0
    x_8_14      ASSIGN_8  1.0
    x_8_14      CAP_14  20
    x_8_14      CONF_5_8_14  1.0
    x_8_14      CONF_6_8_14  1.0
    x_8_14      CONF_7_8_14  1.0
    x_8_14      CONF_8_9_14  1.0
    x_8_15      ASSIGN_8  1.0
    x_8_15      CAP_15  20
    x_8_15      CONF_5_8_15  1.0
    x_8_15      CONF_6_8_15  1.0
    x_8_15      CONF_7_8_15  1.0
    x_8_15      CONF_8_9_15  1.0
    x_8_16      ASSIGN_8  1.0
    x_8_16      CAP_16  20
    x_8_16      CONF_5_8_16  1.0
    x_8_16      CONF_6_8_16  1.0
    x_8_16      CONF_7_8_16  1.0
    x_8_16      CONF_8_9_16  1.0
    x_8_17      ASSIGN_8  1.0
    x_8_17      CAP_17  20
    x_8_17      CONF_5_8_17  1.0
    x_8_17      CONF_6_8_17  1.0
    x_8_17      CONF_7_8_17  1.0
    x_8_17      CONF_8_9_17  1.0
    x_8_18      ASSIGN_8  1.0
    x_8_18      CAP_18  20
    x_8_18      CONF_5_8_18  1.0
    x_8_18      CONF_6_8_18  1.0
    x_8_18      CONF_7_8_18  1.0
    x_8_18      CONF_8_9_18  1.0
    x_8_19      ASSIGN_8  1.0
    x_8_19      CAP_19  20
    x_8_19      CONF_5_8_19  1.0
    x_8_19      CONF_6_8_19  1.0
    x_8_19      CONF_7_8_19  1.0
    x_8_19      CONF_8_9_19  1.0
    x_8_20      ASSIGN_8  1.0
    x_8_20      CAP_20  20
    x_8_20      CONF_5_8_20  1.0
    x_8_20      CONF_6_8_20  1.0
    x_8_20      CONF_7_8_20  1.0
    x_8_20      CONF_8_9_20  1.0
    x_8_21      ASSIGN_8  1.0
    x_8_21      CAP_21  20
    x_8_21      CONF_5_8_21  1.0
    x_8_21      CONF_6_8_21  1.0
    x_8_21      CONF_7_8_21  1.0
    x_8_21      CONF_8_9_21  1.0
    x_8_22      ASSIGN_8  1.0
    x_8_22      CAP_22  20
    x_8_22      CONF_5_8_22  1.0
    x_8_22      CONF_6_8_22  1.0
    x_8_22      CONF_7_8_22  1.0
    x_8_22      CONF_8_9_22  1.0
    x_8_23      ASSIGN_8  1.0
    x_8_23      CAP_23  20
    x_8_23      CONF_5_8_23  1.0
    x_8_23      CONF_6_8_23  1.0
    x_8_23      CONF_7_8_23  1.0
    x_8_23      CONF_8_9_23  1.0
    x_8_24      ASSIGN_8  1.0
    x_8_24      CAP_24  20
    x_8_24      CONF_5_8_24  1.0
    x_8_24      CONF_6_8_24  1.0
    x_8_24      CONF_7_8_24  1.0
    x_8_24      CONF_8_9_24  1.0
    x_9_0       ASSIGN_9  1.0
    x_9_0       CAP_0  45
    x_9_0       CONF_5_9_0  1.0
    x_9_0       CONF_6_9_0  1.0
    x_9_0       CONF_7_9_0  1.0
    x_9_0       CONF_8_9_0  1.0
    x_9_1       ASSIGN_9  1.0
    x_9_1       CAP_1  45
    x_9_1       CONF_5_9_1  1.0
    x_9_1       CONF_6_9_1  1.0
    x_9_1       CONF_7_9_1  1.0
    x_9_1       CONF_8_9_1  1.0
    x_9_2       ASSIGN_9  1.0
    x_9_2       CAP_2  45
    x_9_2       CONF_5_9_2  1.0
    x_9_2       CONF_6_9_2  1.0
    x_9_2       CONF_7_9_2  1.0
    x_9_2       CONF_8_9_2  1.0
    x_9_3       ASSIGN_9  1.0
    x_9_3       CAP_3  45
    x_9_3       CONF_5_9_3  1.0
    x_9_3       CONF_6_9_3  1.0
    x_9_3       CONF_7_9_3  1.0
    x_9_3       CONF_8_9_3  1.0
    x_9_4       ASSIGN_9  1.0
    x_9_4       CAP_4  45
    x_9_4       CONF_5_9_4  1.0
    x_9_4       CONF_6_9_4  1.0
    x_9_4       CONF_7_9_4  1.0
    x_9_4       CONF_8_9_4  1.0
    x_9_5       ASSIGN_9  1.0
    x_9_5       CAP_5  45
    x_9_5       CONF_5_9_5  1.0
    x_9_5       CONF_6_9_5  1.0
    x_9_5       CONF_7_9_5  1.0
    x_9_5       CONF_8_9_5  1.0
    x_9_6       ASSIGN_9  1.0
    x_9_6       CAP_6  45
    x_9_6       CONF_5_9_6  1.0
    x_9_6       CONF_6_9_6  1.0
    x_9_6       CONF_7_9_6  1.0
    x_9_6       CONF_8_9_6  1.0
    x_9_7       ASSIGN_9  1.0
    x_9_7       CAP_7  45
    x_9_7       CONF_5_9_7  1.0
    x_9_7       CONF_6_9_7  1.0
    x_9_7       CONF_7_9_7  1.0
    x_9_7       CONF_8_9_7  1.0
    x_9_8       ASSIGN_9  1.0
    x_9_8       CAP_8  45
    x_9_8       CONF_5_9_8  1.0
    x_9_8       CONF_6_9_8  1.0
    x_9_8       CONF_7_9_8  1.0
    x_9_8       CONF_8_9_8  1.0
    x_9_9       ASSIGN_9  1.0
    x_9_9       CAP_9  45
    x_9_9       CONF_5_9_9  1.0
    x_9_9       CONF_6_9_9  1.0
    x_9_9       CONF_7_9_9  1.0
    x_9_9       CONF_8_9_9  1.0
    x_9_10      ASSIGN_9  1.0
    x_9_10      CAP_10  45
    x_9_10      CONF_5_9_10  1.0
    x_9_10      CONF_6_9_10  1.0
    x_9_10      CONF_7_9_10  1.0
    x_9_10      CONF_8_9_10  1.0
    x_9_11      ASSIGN_9  1.0
    x_9_11      CAP_11  45
    x_9_11      CONF_5_9_11  1.0
    x_9_11      CONF_6_9_11  1.0
    x_9_11      CONF_7_9_11  1.0
    x_9_11      CONF_8_9_11  1.0
    x_9_12      ASSIGN_9  1.0
    x_9_12      CAP_12  45
    x_9_12      CONF_5_9_12  1.0
    x_9_12      CONF_6_9_12  1.0
    x_9_12      CONF_7_9_12  1.0
    x_9_12      CONF_8_9_12  1.0
    x_9_13      ASSIGN_9  1.0
    x_9_13      CAP_13  45
    x_9_13      CONF_5_9_13  1.0
    x_9_13      CONF_6_9_13  1.0
    x_9_13      CONF_7_9_13  1.0
    x_9_13      CONF_8_9_13  1.0
    x_9_14      ASSIGN_9  1.0
    x_9_14      CAP_14  45
    x_9_14      CONF_5_9_14  1.0
    x_9_14      CONF_6_9_14  1.0
    x_9_14      CONF_7_9_14  1.0
    x_9_14      CONF_8_9_14  1.0
    x_9_15      ASSIGN_9  1.0
    x_9_15      CAP_15  45
    x_9_15      CONF_5_9_15  1.0
    x_9_15      CONF_6_9_15  1.0
    x_9_15      CONF_7_9_15  1.0
    x_9_15      CONF_8_9_15  1.0
    x_9_16      ASSIGN_9  1.0
    x_9_16      CAP_16  45
    x_9_16      CONF_5_9_16  1.0
    x_9_16      CONF_6_9_16  1.0
    x_9_16      CONF_7_9_16  1.0
    x_9_16      CONF_8_9_16  1.0
    x_9_17      ASSIGN_9  1.0
    x_9_17      CAP_17  45
    x_9_17      CONF_5_9_17  1.0
    x_9_17      CONF_6_9_17  1.0
    x_9_17      CONF_7_9_17  1.0
    x_9_17      CONF_8_9_17  1.0
    x_9_18      ASSIGN_9  1.0
    x_9_18      CAP_18  45
    x_9_18      CONF_5_9_18  1.0
    x_9_18      CONF_6_9_18  1.0
    x_9_18      CONF_7_9_18  1.0
    x_9_18      CONF_8_9_18  1.0
    x_9_19      ASSIGN_9  1.0
    x_9_19      CAP_19  45
    x_9_19      CONF_5_9_19  1.0
    x_9_19      CONF_6_9_19  1.0
    x_9_19      CONF_7_9_19  1.0
    x_9_19      CONF_8_9_19  1.0
    x_9_20      ASSIGN_9  1.0
    x_9_20      CAP_20  45
    x_9_20      CONF_5_9_20  1.0
    x_9_20      CONF_6_9_20  1.0
    x_9_20      CONF_7_9_20  1.0
    x_9_20      CONF_8_9_20  1.0
    x_9_21      ASSIGN_9  1.0
    x_9_21      CAP_21  45
    x_9_21      CONF_5_9_21  1.0
    x_9_21      CONF_6_9_21  1.0
    x_9_21      CONF_7_9_21  1.0
    x_9_21      CONF_8_9_21  1.0
    x_9_22      ASSIGN_9  1.0
    x_9_22      CAP_22  45
    x_9_22      CONF_5_9_22  1.0
    x_9_22      CONF_6_9_22  1.0
    x_9_22      CONF_7_9_22  1.0
    x_9_22      CONF_8_9_22  1.0
    x_9_23      ASSIGN_9  1.0
    x_9_23      CAP_23  45
    x_9_23      CONF_5_9_23  1.0
    x_9_23      CONF_6_9_23  1.0
    x_9_23      CONF_7_9_23  1.0
    x_9_23      CONF_8_9_23  1.0
    x_9_24      ASSIGN_9  1.0
    x_9_24      CAP_24  45
    x_9_24      CONF_5_9_24  1.0
    x_9_24      CONF_6_9_24  1.0
    x_9_24      CONF_7_9_24  1.0
    x_9_24      CONF_8_9_24  1.0
    x_10_0      ASSIGN_10  1.0
    x_10_0      CAP_0  52
    x_10_0      CONF_10_11_0  1.0
    x_10_0      CONF_10_12_0  1.0
    x_10_0      CONF_10_13_0  1.0
    x_10_0      CONF_10_14_0  1.0
    x_10_1      ASSIGN_10  1.0
    x_10_1      CAP_1  52
    x_10_1      CONF_10_11_1  1.0
    x_10_1      CONF_10_12_1  1.0
    x_10_1      CONF_10_13_1  1.0
    x_10_1      CONF_10_14_1  1.0
    x_10_2      ASSIGN_10  1.0
    x_10_2      CAP_2  52
    x_10_2      CONF_10_11_2  1.0
    x_10_2      CONF_10_12_2  1.0
    x_10_2      CONF_10_13_2  1.0
    x_10_2      CONF_10_14_2  1.0
    x_10_3      ASSIGN_10  1.0
    x_10_3      CAP_3  52
    x_10_3      CONF_10_11_3  1.0
    x_10_3      CONF_10_12_3  1.0
    x_10_3      CONF_10_13_3  1.0
    x_10_3      CONF_10_14_3  1.0
    x_10_4      ASSIGN_10  1.0
    x_10_4      CAP_4  52
    x_10_4      CONF_10_11_4  1.0
    x_10_4      CONF_10_12_4  1.0
    x_10_4      CONF_10_13_4  1.0
    x_10_4      CONF_10_14_4  1.0
    x_10_5      ASSIGN_10  1.0
    x_10_5      CAP_5  52
    x_10_5      CONF_10_11_5  1.0
    x_10_5      CONF_10_12_5  1.0
    x_10_5      CONF_10_13_5  1.0
    x_10_5      CONF_10_14_5  1.0
    x_10_6      ASSIGN_10  1.0
    x_10_6      CAP_6  52
    x_10_6      CONF_10_11_6  1.0
    x_10_6      CONF_10_12_6  1.0
    x_10_6      CONF_10_13_6  1.0
    x_10_6      CONF_10_14_6  1.0
    x_10_7      ASSIGN_10  1.0
    x_10_7      CAP_7  52
    x_10_7      CONF_10_11_7  1.0
    x_10_7      CONF_10_12_7  1.0
    x_10_7      CONF_10_13_7  1.0
    x_10_7      CONF_10_14_7  1.0
    x_10_8      ASSIGN_10  1.0
    x_10_8      CAP_8  52
    x_10_8      CONF_10_11_8  1.0
    x_10_8      CONF_10_12_8  1.0
    x_10_8      CONF_10_13_8  1.0
    x_10_8      CONF_10_14_8  1.0
    x_10_9      ASSIGN_10  1.0
    x_10_9      CAP_9  52
    x_10_9      CONF_10_11_9  1.0
    x_10_9      CONF_10_12_9  1.0
    x_10_9      CONF_10_13_9  1.0
    x_10_9      CONF_10_14_9  1.0
    x_10_10     ASSIGN_10  1.0
    x_10_10     CAP_10  52
    x_10_10     CONF_10_11_10  1.0
    x_10_10     CONF_10_12_10  1.0
    x_10_10     CONF_10_13_10  1.0
    x_10_10     CONF_10_14_10  1.0
    x_10_11     ASSIGN_10  1.0
    x_10_11     CAP_11  52
    x_10_11     CONF_10_11_11  1.0
    x_10_11     CONF_10_12_11  1.0
    x_10_11     CONF_10_13_11  1.0
    x_10_11     CONF_10_14_11  1.0
    x_10_12     ASSIGN_10  1.0
    x_10_12     CAP_12  52
    x_10_12     CONF_10_11_12  1.0
    x_10_12     CONF_10_12_12  1.0
    x_10_12     CONF_10_13_12  1.0
    x_10_12     CONF_10_14_12  1.0
    x_10_13     ASSIGN_10  1.0
    x_10_13     CAP_13  52
    x_10_13     CONF_10_11_13  1.0
    x_10_13     CONF_10_12_13  1.0
    x_10_13     CONF_10_13_13  1.0
    x_10_13     CONF_10_14_13  1.0
    x_10_14     ASSIGN_10  1.0
    x_10_14     CAP_14  52
    x_10_14     CONF_10_11_14  1.0
    x_10_14     CONF_10_12_14  1.0
    x_10_14     CONF_10_13_14  1.0
    x_10_14     CONF_10_14_14  1.0
    x_10_15     ASSIGN_10  1.0
    x_10_15     CAP_15  52
    x_10_15     CONF_10_11_15  1.0
    x_10_15     CONF_10_12_15  1.0
    x_10_15     CONF_10_13_15  1.0
    x_10_15     CONF_10_14_15  1.0
    x_10_16     ASSIGN_10  1.0
    x_10_16     CAP_16  52
    x_10_16     CONF_10_11_16  1.0
    x_10_16     CONF_10_12_16  1.0
    x_10_16     CONF_10_13_16  1.0
    x_10_16     CONF_10_14_16  1.0
    x_10_17     ASSIGN_10  1.0
    x_10_17     CAP_17  52
    x_10_17     CONF_10_11_17  1.0
    x_10_17     CONF_10_12_17  1.0
    x_10_17     CONF_10_13_17  1.0
    x_10_17     CONF_10_14_17  1.0
    x_10_18     ASSIGN_10  1.0
    x_10_18     CAP_18  52
    x_10_18     CONF_10_11_18  1.0
    x_10_18     CONF_10_12_18  1.0
    x_10_18     CONF_10_13_18  1.0
    x_10_18     CONF_10_14_18  1.0
    x_10_19     ASSIGN_10  1.0
    x_10_19     CAP_19  52
    x_10_19     CONF_10_11_19  1.0
    x_10_19     CONF_10_12_19  1.0
    x_10_19     CONF_10_13_19  1.0
    x_10_19     CONF_10_14_19  1.0
    x_10_20     ASSIGN_10  1.0
    x_10_20     CAP_20  52
    x_10_20     CONF_10_11_20  1.0
    x_10_20     CONF_10_12_20  1.0
    x_10_20     CONF_10_13_20  1.0
    x_10_20     CONF_10_14_20  1.0
    x_10_21     ASSIGN_10  1.0
    x_10_21     CAP_21  52
    x_10_21     CONF_10_11_21  1.0
    x_10_21     CONF_10_12_21  1.0
    x_10_21     CONF_10_13_21  1.0
    x_10_21     CONF_10_14_21  1.0
    x_10_22     ASSIGN_10  1.0
    x_10_22     CAP_22  52
    x_10_22     CONF_10_11_22  1.0
    x_10_22     CONF_10_12_22  1.0
    x_10_22     CONF_10_13_22  1.0
    x_10_22     CONF_10_14_22  1.0
    x_10_23     ASSIGN_10  1.0
    x_10_23     CAP_23  52
    x_10_23     CONF_10_11_23  1.0
    x_10_23     CONF_10_12_23  1.0
    x_10_23     CONF_10_13_23  1.0
    x_10_23     CONF_10_14_23  1.0
    x_10_24     ASSIGN_10  1.0
    x_10_24     CAP_24  52
    x_10_24     CONF_10_11_24  1.0
    x_10_24     CONF_10_12_24  1.0
    x_10_24     CONF_10_13_24  1.0
    x_10_24     CONF_10_14_24  1.0
    x_11_0      ASSIGN_11  1.0
    x_11_0      CAP_0  40
    x_11_0      CONF_10_11_0  1.0
    x_11_0      CONF_11_12_0  1.0
    x_11_0      CONF_11_13_0  1.0
    x_11_0      CONF_11_14_0  1.0
    x_11_1      ASSIGN_11  1.0
    x_11_1      CAP_1  40
    x_11_1      CONF_10_11_1  1.0
    x_11_1      CONF_11_12_1  1.0
    x_11_1      CONF_11_13_1  1.0
    x_11_1      CONF_11_14_1  1.0
    x_11_2      ASSIGN_11  1.0
    x_11_2      CAP_2  40
    x_11_2      CONF_10_11_2  1.0
    x_11_2      CONF_11_12_2  1.0
    x_11_2      CONF_11_13_2  1.0
    x_11_2      CONF_11_14_2  1.0
    x_11_3      ASSIGN_11  1.0
    x_11_3      CAP_3  40
    x_11_3      CONF_10_11_3  1.0
    x_11_3      CONF_11_12_3  1.0
    x_11_3      CONF_11_13_3  1.0
    x_11_3      CONF_11_14_3  1.0
    x_11_4      ASSIGN_11  1.0
    x_11_4      CAP_4  40
    x_11_4      CONF_10_11_4  1.0
    x_11_4      CONF_11_12_4  1.0
    x_11_4      CONF_11_13_4  1.0
    x_11_4      CONF_11_14_4  1.0
    x_11_5      ASSIGN_11  1.0
    x_11_5      CAP_5  40
    x_11_5      CONF_10_11_5  1.0
    x_11_5      CONF_11_12_5  1.0
    x_11_5      CONF_11_13_5  1.0
    x_11_5      CONF_11_14_5  1.0
    x_11_6      ASSIGN_11  1.0
    x_11_6      CAP_6  40
    x_11_6      CONF_10_11_6  1.0
    x_11_6      CONF_11_12_6  1.0
    x_11_6      CONF_11_13_6  1.0
    x_11_6      CONF_11_14_6  1.0
    x_11_7      ASSIGN_11  1.0
    x_11_7      CAP_7  40
    x_11_7      CONF_10_11_7  1.0
    x_11_7      CONF_11_12_7  1.0
    x_11_7      CONF_11_13_7  1.0
    x_11_7      CONF_11_14_7  1.0
    x_11_8      ASSIGN_11  1.0
    x_11_8      CAP_8  40
    x_11_8      CONF_10_11_8  1.0
    x_11_8      CONF_11_12_8  1.0
    x_11_8      CONF_11_13_8  1.0
    x_11_8      CONF_11_14_8  1.0
    x_11_9      ASSIGN_11  1.0
    x_11_9      CAP_9  40
    x_11_9      CONF_10_11_9  1.0
    x_11_9      CONF_11_12_9  1.0
    x_11_9      CONF_11_13_9  1.0
    x_11_9      CONF_11_14_9  1.0
    x_11_10     ASSIGN_11  1.0
    x_11_10     CAP_10  40
    x_11_10     CONF_10_11_10  1.0
    x_11_10     CONF_11_12_10  1.0
    x_11_10     CONF_11_13_10  1.0
    x_11_10     CONF_11_14_10  1.0
    x_11_11     ASSIGN_11  1.0
    x_11_11     CAP_11  40
    x_11_11     CONF_10_11_11  1.0
    x_11_11     CONF_11_12_11  1.0
    x_11_11     CONF_11_13_11  1.0
    x_11_11     CONF_11_14_11  1.0
    x_11_12     ASSIGN_11  1.0
    x_11_12     CAP_12  40
    x_11_12     CONF_10_11_12  1.0
    x_11_12     CONF_11_12_12  1.0
    x_11_12     CONF_11_13_12  1.0
    x_11_12     CONF_11_14_12  1.0
    x_11_13     ASSIGN_11  1.0
    x_11_13     CAP_13  40
    x_11_13     CONF_10_11_13  1.0
    x_11_13     CONF_11_12_13  1.0
    x_11_13     CONF_11_13_13  1.0
    x_11_13     CONF_11_14_13  1.0
    x_11_14     ASSIGN_11  1.0
    x_11_14     CAP_14  40
    x_11_14     CONF_10_11_14  1.0
    x_11_14     CONF_11_12_14  1.0
    x_11_14     CONF_11_13_14  1.0
    x_11_14     CONF_11_14_14  1.0
    x_11_15     ASSIGN_11  1.0
    x_11_15     CAP_15  40
    x_11_15     CONF_10_11_15  1.0
    x_11_15     CONF_11_12_15  1.0
    x_11_15     CONF_11_13_15  1.0
    x_11_15     CONF_11_14_15  1.0
    x_11_16     ASSIGN_11  1.0
    x_11_16     CAP_16  40
    x_11_16     CONF_10_11_16  1.0
    x_11_16     CONF_11_12_16  1.0
    x_11_16     CONF_11_13_16  1.0
    x_11_16     CONF_11_14_16  1.0
    x_11_17     ASSIGN_11  1.0
    x_11_17     CAP_17  40
    x_11_17     CONF_10_11_17  1.0
    x_11_17     CONF_11_12_17  1.0
    x_11_17     CONF_11_13_17  1.0
    x_11_17     CONF_11_14_17  1.0
    x_11_18     ASSIGN_11  1.0
    x_11_18     CAP_18  40
    x_11_18     CONF_10_11_18  1.0
    x_11_18     CONF_11_12_18  1.0
    x_11_18     CONF_11_13_18  1.0
    x_11_18     CONF_11_14_18  1.0
    x_11_19     ASSIGN_11  1.0
    x_11_19     CAP_19  40
    x_11_19     CONF_10_11_19  1.0
    x_11_19     CONF_11_12_19  1.0
    x_11_19     CONF_11_13_19  1.0
    x_11_19     CONF_11_14_19  1.0
    x_11_20     ASSIGN_11  1.0
    x_11_20     CAP_20  40
    x_11_20     CONF_10_11_20  1.0
    x_11_20     CONF_11_12_20  1.0
    x_11_20     CONF_11_13_20  1.0
    x_11_20     CONF_11_14_20  1.0
    x_11_21     ASSIGN_11  1.0
    x_11_21     CAP_21  40
    x_11_21     CONF_10_11_21  1.0
    x_11_21     CONF_11_12_21  1.0
    x_11_21     CONF_11_13_21  1.0
    x_11_21     CONF_11_14_21  1.0
    x_11_22     ASSIGN_11  1.0
    x_11_22     CAP_22  40
    x_11_22     CONF_10_11_22  1.0
    x_11_22     CONF_11_12_22  1.0
    x_11_22     CONF_11_13_22  1.0
    x_11_22     CONF_11_14_22  1.0
    x_11_23     ASSIGN_11  1.0
    x_11_23     CAP_23  40
    x_11_23     CONF_10_11_23  1.0
    x_11_23     CONF_11_12_23  1.0
    x_11_23     CONF_11_13_23  1.0
    x_11_23     CONF_11_14_23  1.0
    x_11_24     ASSIGN_11  1.0
    x_11_24     CAP_24  40
    x_11_24     CONF_10_11_24  1.0
    x_11_24     CONF_11_12_24  1.0
    x_11_24     CONF_11_13_24  1.0
    x_11_24     CONF_11_14_24  1.0
    x_12_0      ASSIGN_12  1.0
    x_12_0      CAP_0  45
    x_12_0      CONF_10_12_0  1.0
    x_12_0      CONF_11_12_0  1.0
    x_12_0      CONF_12_13_0  1.0
    x_12_0      CONF_12_14_0  1.0
    x_12_1      ASSIGN_12  1.0
    x_12_1      CAP_1  45
    x_12_1      CONF_10_12_1  1.0
    x_12_1      CONF_11_12_1  1.0
    x_12_1      CONF_12_13_1  1.0
    x_12_1      CONF_12_14_1  1.0
    x_12_2      ASSIGN_12  1.0
    x_12_2      CAP_2  45
    x_12_2      CONF_10_12_2  1.0
    x_12_2      CONF_11_12_2  1.0
    x_12_2      CONF_12_13_2  1.0
    x_12_2      CONF_12_14_2  1.0
    x_12_3      ASSIGN_12  1.0
    x_12_3      CAP_3  45
    x_12_3      CONF_10_12_3  1.0
    x_12_3      CONF_11_12_3  1.0
    x_12_3      CONF_12_13_3  1.0
    x_12_3      CONF_12_14_3  1.0
    x_12_4      ASSIGN_12  1.0
    x_12_4      CAP_4  45
    x_12_4      CONF_10_12_4  1.0
    x_12_4      CONF_11_12_4  1.0
    x_12_4      CONF_12_13_4  1.0
    x_12_4      CONF_12_14_4  1.0
    x_12_5      ASSIGN_12  1.0
    x_12_5      CAP_5  45
    x_12_5      CONF_10_12_5  1.0
    x_12_5      CONF_11_12_5  1.0
    x_12_5      CONF_12_13_5  1.0
    x_12_5      CONF_12_14_5  1.0
    x_12_6      ASSIGN_12  1.0
    x_12_6      CAP_6  45
    x_12_6      CONF_10_12_6  1.0
    x_12_6      CONF_11_12_6  1.0
    x_12_6      CONF_12_13_6  1.0
    x_12_6      CONF_12_14_6  1.0
    x_12_7      ASSIGN_12  1.0
    x_12_7      CAP_7  45
    x_12_7      CONF_10_12_7  1.0
    x_12_7      CONF_11_12_7  1.0
    x_12_7      CONF_12_13_7  1.0
    x_12_7      CONF_12_14_7  1.0
    x_12_8      ASSIGN_12  1.0
    x_12_8      CAP_8  45
    x_12_8      CONF_10_12_8  1.0
    x_12_8      CONF_11_12_8  1.0
    x_12_8      CONF_12_13_8  1.0
    x_12_8      CONF_12_14_8  1.0
    x_12_9      ASSIGN_12  1.0
    x_12_9      CAP_9  45
    x_12_9      CONF_10_12_9  1.0
    x_12_9      CONF_11_12_9  1.0
    x_12_9      CONF_12_13_9  1.0
    x_12_9      CONF_12_14_9  1.0
    x_12_10     ASSIGN_12  1.0
    x_12_10     CAP_10  45
    x_12_10     CONF_10_12_10  1.0
    x_12_10     CONF_11_12_10  1.0
    x_12_10     CONF_12_13_10  1.0
    x_12_10     CONF_12_14_10  1.0
    x_12_11     ASSIGN_12  1.0
    x_12_11     CAP_11  45
    x_12_11     CONF_10_12_11  1.0
    x_12_11     CONF_11_12_11  1.0
    x_12_11     CONF_12_13_11  1.0
    x_12_11     CONF_12_14_11  1.0
    x_12_12     ASSIGN_12  1.0
    x_12_12     CAP_12  45
    x_12_12     CONF_10_12_12  1.0
    x_12_12     CONF_11_12_12  1.0
    x_12_12     CONF_12_13_12  1.0
    x_12_12     CONF_12_14_12  1.0
    x_12_13     ASSIGN_12  1.0
    x_12_13     CAP_13  45
    x_12_13     CONF_10_12_13  1.0
    x_12_13     CONF_11_12_13  1.0
    x_12_13     CONF_12_13_13  1.0
    x_12_13     CONF_12_14_13  1.0
    x_12_14     ASSIGN_12  1.0
    x_12_14     CAP_14  45
    x_12_14     CONF_10_12_14  1.0
    x_12_14     CONF_11_12_14  1.0
    x_12_14     CONF_12_13_14  1.0
    x_12_14     CONF_12_14_14  1.0
    x_12_15     ASSIGN_12  1.0
    x_12_15     CAP_15  45
    x_12_15     CONF_10_12_15  1.0
    x_12_15     CONF_11_12_15  1.0
    x_12_15     CONF_12_13_15  1.0
    x_12_15     CONF_12_14_15  1.0
    x_12_16     ASSIGN_12  1.0
    x_12_16     CAP_16  45
    x_12_16     CONF_10_12_16  1.0
    x_12_16     CONF_11_12_16  1.0
    x_12_16     CONF_12_13_16  1.0
    x_12_16     CONF_12_14_16  1.0
    x_12_17     ASSIGN_12  1.0
    x_12_17     CAP_17  45
    x_12_17     CONF_10_12_17  1.0
    x_12_17     CONF_11_12_17  1.0
    x_12_17     CONF_12_13_17  1.0
    x_12_17     CONF_12_14_17  1.0
    x_12_18     ASSIGN_12  1.0
    x_12_18     CAP_18  45
    x_12_18     CONF_10_12_18  1.0
    x_12_18     CONF_11_12_18  1.0
    x_12_18     CONF_12_13_18  1.0
    x_12_18     CONF_12_14_18  1.0
    x_12_19     ASSIGN_12  1.0
    x_12_19     CAP_19  45
    x_12_19     CONF_10_12_19  1.0
    x_12_19     CONF_11_12_19  1.0
    x_12_19     CONF_12_13_19  1.0
    x_12_19     CONF_12_14_19  1.0
    x_12_20     ASSIGN_12  1.0
    x_12_20     CAP_20  45
    x_12_20     CONF_10_12_20  1.0
    x_12_20     CONF_11_12_20  1.0
    x_12_20     CONF_12_13_20  1.0
    x_12_20     CONF_12_14_20  1.0
    x_12_21     ASSIGN_12  1.0
    x_12_21     CAP_21  45
    x_12_21     CONF_10_12_21  1.0
    x_12_21     CONF_11_12_21  1.0
    x_12_21     CONF_12_13_21  1.0
    x_12_21     CONF_12_14_21  1.0
    x_12_22     ASSIGN_12  1.0
    x_12_22     CAP_22  45
    x_12_22     CONF_10_12_22  1.0
    x_12_22     CONF_11_12_22  1.0
    x_12_22     CONF_12_13_22  1.0
    x_12_22     CONF_12_14_22  1.0
    x_12_23     ASSIGN_12  1.0
    x_12_23     CAP_23  45
    x_12_23     CONF_10_12_23  1.0
    x_12_23     CONF_11_12_23  1.0
    x_12_23     CONF_12_13_23  1.0
    x_12_23     CONF_12_14_23  1.0
    x_12_24     ASSIGN_12  1.0
    x_12_24     CAP_24  45
    x_12_24     CONF_10_12_24  1.0
    x_12_24     CONF_11_12_24  1.0
    x_12_24     CONF_12_13_24  1.0
    x_12_24     CONF_12_14_24  1.0
    x_13_0      ASSIGN_13  1.0
    x_13_0      CAP_0  53
    x_13_0      CONF_10_13_0  1.0
    x_13_0      CONF_11_13_0  1.0
    x_13_0      CONF_12_13_0  1.0
    x_13_0      CONF_13_14_0  1.0
    x_13_1      ASSIGN_13  1.0
    x_13_1      CAP_1  53
    x_13_1      CONF_10_13_1  1.0
    x_13_1      CONF_11_13_1  1.0
    x_13_1      CONF_12_13_1  1.0
    x_13_1      CONF_13_14_1  1.0
    x_13_2      ASSIGN_13  1.0
    x_13_2      CAP_2  53
    x_13_2      CONF_10_13_2  1.0
    x_13_2      CONF_11_13_2  1.0
    x_13_2      CONF_12_13_2  1.0
    x_13_2      CONF_13_14_2  1.0
    x_13_3      ASSIGN_13  1.0
    x_13_3      CAP_3  53
    x_13_3      CONF_10_13_3  1.0
    x_13_3      CONF_11_13_3  1.0
    x_13_3      CONF_12_13_3  1.0
    x_13_3      CONF_13_14_3  1.0
    x_13_4      ASSIGN_13  1.0
    x_13_4      CAP_4  53
    x_13_4      CONF_10_13_4  1.0
    x_13_4      CONF_11_13_4  1.0
    x_13_4      CONF_12_13_4  1.0
    x_13_4      CONF_13_14_4  1.0
    x_13_5      ASSIGN_13  1.0
    x_13_5      CAP_5  53
    x_13_5      CONF_10_13_5  1.0
    x_13_5      CONF_11_13_5  1.0
    x_13_5      CONF_12_13_5  1.0
    x_13_5      CONF_13_14_5  1.0
    x_13_6      ASSIGN_13  1.0
    x_13_6      CAP_6  53
    x_13_6      CONF_10_13_6  1.0
    x_13_6      CONF_11_13_6  1.0
    x_13_6      CONF_12_13_6  1.0
    x_13_6      CONF_13_14_6  1.0
    x_13_7      ASSIGN_13  1.0
    x_13_7      CAP_7  53
    x_13_7      CONF_10_13_7  1.0
    x_13_7      CONF_11_13_7  1.0
    x_13_7      CONF_12_13_7  1.0
    x_13_7      CONF_13_14_7  1.0
    x_13_8      ASSIGN_13  1.0
    x_13_8      CAP_8  53
    x_13_8      CONF_10_13_8  1.0
    x_13_8      CONF_11_13_8  1.0
    x_13_8      CONF_12_13_8  1.0
    x_13_8      CONF_13_14_8  1.0
    x_13_9      ASSIGN_13  1.0
    x_13_9      CAP_9  53
    x_13_9      CONF_10_13_9  1.0
    x_13_9      CONF_11_13_9  1.0
    x_13_9      CONF_12_13_9  1.0
    x_13_9      CONF_13_14_9  1.0
    x_13_10     ASSIGN_13  1.0
    x_13_10     CAP_10  53
    x_13_10     CONF_10_13_10  1.0
    x_13_10     CONF_11_13_10  1.0
    x_13_10     CONF_12_13_10  1.0
    x_13_10     CONF_13_14_10  1.0
    x_13_11     ASSIGN_13  1.0
    x_13_11     CAP_11  53
    x_13_11     CONF_10_13_11  1.0
    x_13_11     CONF_11_13_11  1.0
    x_13_11     CONF_12_13_11  1.0
    x_13_11     CONF_13_14_11  1.0
    x_13_12     ASSIGN_13  1.0
    x_13_12     CAP_12  53
    x_13_12     CONF_10_13_12  1.0
    x_13_12     CONF_11_13_12  1.0
    x_13_12     CONF_12_13_12  1.0
    x_13_12     CONF_13_14_12  1.0
    x_13_13     ASSIGN_13  1.0
    x_13_13     CAP_13  53
    x_13_13     CONF_10_13_13  1.0
    x_13_13     CONF_11_13_13  1.0
    x_13_13     CONF_12_13_13  1.0
    x_13_13     CONF_13_14_13  1.0
    x_13_14     ASSIGN_13  1.0
    x_13_14     CAP_14  53
    x_13_14     CONF_10_13_14  1.0
    x_13_14     CONF_11_13_14  1.0
    x_13_14     CONF_12_13_14  1.0
    x_13_14     CONF_13_14_14  1.0
    x_13_15     ASSIGN_13  1.0
    x_13_15     CAP_15  53
    x_13_15     CONF_10_13_15  1.0
    x_13_15     CONF_11_13_15  1.0
    x_13_15     CONF_12_13_15  1.0
    x_13_15     CONF_13_14_15  1.0
    x_13_16     ASSIGN_13  1.0
    x_13_16     CAP_16  53
    x_13_16     CONF_10_13_16  1.0
    x_13_16     CONF_11_13_16  1.0
    x_13_16     CONF_12_13_16  1.0
    x_13_16     CONF_13_14_16  1.0
    x_13_17     ASSIGN_13  1.0
    x_13_17     CAP_17  53
    x_13_17     CONF_10_13_17  1.0
    x_13_17     CONF_11_13_17  1.0
    x_13_17     CONF_12_13_17  1.0
    x_13_17     CONF_13_14_17  1.0
    x_13_18     ASSIGN_13  1.0
    x_13_18     CAP_18  53
    x_13_18     CONF_10_13_18  1.0
    x_13_18     CONF_11_13_18  1.0
    x_13_18     CONF_12_13_18  1.0
    x_13_18     CONF_13_14_18  1.0
    x_13_19     ASSIGN_13  1.0
    x_13_19     CAP_19  53
    x_13_19     CONF_10_13_19  1.0
    x_13_19     CONF_11_13_19  1.0
    x_13_19     CONF_12_13_19  1.0
    x_13_19     CONF_13_14_19  1.0
    x_13_20     ASSIGN_13  1.0
    x_13_20     CAP_20  53
    x_13_20     CONF_10_13_20  1.0
    x_13_20     CONF_11_13_20  1.0
    x_13_20     CONF_12_13_20  1.0
    x_13_20     CONF_13_14_20  1.0
    x_13_21     ASSIGN_13  1.0
    x_13_21     CAP_21  53
    x_13_21     CONF_10_13_21  1.0
    x_13_21     CONF_11_13_21  1.0
    x_13_21     CONF_12_13_21  1.0
    x_13_21     CONF_13_14_21  1.0
    x_13_22     ASSIGN_13  1.0
    x_13_22     CAP_22  53
    x_13_22     CONF_10_13_22  1.0
    x_13_22     CONF_11_13_22  1.0
    x_13_22     CONF_12_13_22  1.0
    x_13_22     CONF_13_14_22  1.0
    x_13_23     ASSIGN_13  1.0
    x_13_23     CAP_23  53
    x_13_23     CONF_10_13_23  1.0
    x_13_23     CONF_11_13_23  1.0
    x_13_23     CONF_12_13_23  1.0
    x_13_23     CONF_13_14_23  1.0
    x_13_24     ASSIGN_13  1.0
    x_13_24     CAP_24  53
    x_13_24     CONF_10_13_24  1.0
    x_13_24     CONF_11_13_24  1.0
    x_13_24     CONF_12_13_24  1.0
    x_13_24     CONF_13_14_24  1.0
    x_14_0      ASSIGN_14  1.0
    x_14_0      CAP_0  50
    x_14_0      CONF_10_14_0  1.0
    x_14_0      CONF_11_14_0  1.0
    x_14_0      CONF_12_14_0  1.0
    x_14_0      CONF_13_14_0  1.0
    x_14_1      ASSIGN_14  1.0
    x_14_1      CAP_1  50
    x_14_1      CONF_10_14_1  1.0
    x_14_1      CONF_11_14_1  1.0
    x_14_1      CONF_12_14_1  1.0
    x_14_1      CONF_13_14_1  1.0
    x_14_2      ASSIGN_14  1.0
    x_14_2      CAP_2  50
    x_14_2      CONF_10_14_2  1.0
    x_14_2      CONF_11_14_2  1.0
    x_14_2      CONF_12_14_2  1.0
    x_14_2      CONF_13_14_2  1.0
    x_14_3      ASSIGN_14  1.0
    x_14_3      CAP_3  50
    x_14_3      CONF_10_14_3  1.0
    x_14_3      CONF_11_14_3  1.0
    x_14_3      CONF_12_14_3  1.0
    x_14_3      CONF_13_14_3  1.0
    x_14_4      ASSIGN_14  1.0
    x_14_4      CAP_4  50
    x_14_4      CONF_10_14_4  1.0
    x_14_4      CONF_11_14_4  1.0
    x_14_4      CONF_12_14_4  1.0
    x_14_4      CONF_13_14_4  1.0
    x_14_5      ASSIGN_14  1.0
    x_14_5      CAP_5  50
    x_14_5      CONF_10_14_5  1.0
    x_14_5      CONF_11_14_5  1.0
    x_14_5      CONF_12_14_5  1.0
    x_14_5      CONF_13_14_5  1.0
    x_14_6      ASSIGN_14  1.0
    x_14_6      CAP_6  50
    x_14_6      CONF_10_14_6  1.0
    x_14_6      CONF_11_14_6  1.0
    x_14_6      CONF_12_14_6  1.0
    x_14_6      CONF_13_14_6  1.0
    x_14_7      ASSIGN_14  1.0
    x_14_7      CAP_7  50
    x_14_7      CONF_10_14_7  1.0
    x_14_7      CONF_11_14_7  1.0
    x_14_7      CONF_12_14_7  1.0
    x_14_7      CONF_13_14_7  1.0
    x_14_8      ASSIGN_14  1.0
    x_14_8      CAP_8  50
    x_14_8      CONF_10_14_8  1.0
    x_14_8      CONF_11_14_8  1.0
    x_14_8      CONF_12_14_8  1.0
    x_14_8      CONF_13_14_8  1.0
    x_14_9      ASSIGN_14  1.0
    x_14_9      CAP_9  50
    x_14_9      CONF_10_14_9  1.0
    x_14_9      CONF_11_14_9  1.0
    x_14_9      CONF_12_14_9  1.0
    x_14_9      CONF_13_14_9  1.0
    x_14_10     ASSIGN_14  1.0
    x_14_10     CAP_10  50
    x_14_10     CONF_10_14_10  1.0
    x_14_10     CONF_11_14_10  1.0
    x_14_10     CONF_12_14_10  1.0
    x_14_10     CONF_13_14_10  1.0
    x_14_11     ASSIGN_14  1.0
    x_14_11     CAP_11  50
    x_14_11     CONF_10_14_11  1.0
    x_14_11     CONF_11_14_11  1.0
    x_14_11     CONF_12_14_11  1.0
    x_14_11     CONF_13_14_11  1.0
    x_14_12     ASSIGN_14  1.0
    x_14_12     CAP_12  50
    x_14_12     CONF_10_14_12  1.0
    x_14_12     CONF_11_14_12  1.0
    x_14_12     CONF_12_14_12  1.0
    x_14_12     CONF_13_14_12  1.0
    x_14_13     ASSIGN_14  1.0
    x_14_13     CAP_13  50
    x_14_13     CONF_10_14_13  1.0
    x_14_13     CONF_11_14_13  1.0
    x_14_13     CONF_12_14_13  1.0
    x_14_13     CONF_13_14_13  1.0
    x_14_14     ASSIGN_14  1.0
    x_14_14     CAP_14  50
    x_14_14     CONF_10_14_14  1.0
    x_14_14     CONF_11_14_14  1.0
    x_14_14     CONF_12_14_14  1.0
    x_14_14     CONF_13_14_14  1.0
    x_14_15     ASSIGN_14  1.0
    x_14_15     CAP_15  50
    x_14_15     CONF_10_14_15  1.0
    x_14_15     CONF_11_14_15  1.0
    x_14_15     CONF_12_14_15  1.0
    x_14_15     CONF_13_14_15  1.0
    x_14_16     ASSIGN_14  1.0
    x_14_16     CAP_16  50
    x_14_16     CONF_10_14_16  1.0
    x_14_16     CONF_11_14_16  1.0
    x_14_16     CONF_12_14_16  1.0
    x_14_16     CONF_13_14_16  1.0
    x_14_17     ASSIGN_14  1.0
    x_14_17     CAP_17  50
    x_14_17     CONF_10_14_17  1.0
    x_14_17     CONF_11_14_17  1.0
    x_14_17     CONF_12_14_17  1.0
    x_14_17     CONF_13_14_17  1.0
    x_14_18     ASSIGN_14  1.0
    x_14_18     CAP_18  50
    x_14_18     CONF_10_14_18  1.0
    x_14_18     CONF_11_14_18  1.0
    x_14_18     CONF_12_14_18  1.0
    x_14_18     CONF_13_14_18  1.0
    x_14_19     ASSIGN_14  1.0
    x_14_19     CAP_19  50
    x_14_19     CONF_10_14_19  1.0
    x_14_19     CONF_11_14_19  1.0
    x_14_19     CONF_12_14_19  1.0
    x_14_19     CONF_13_14_19  1.0
    x_14_20     ASSIGN_14  1.0
    x_14_20     CAP_20  50
    x_14_20     CONF_10_14_20  1.0
    x_14_20     CONF_11_14_20  1.0
    x_14_20     CONF_12_14_20  1.0
    x_14_20     CONF_13_14_20  1.0
    x_14_21     ASSIGN_14  1.0
    x_14_21     CAP_21  50
    x_14_21     CONF_10_14_21  1.0
    x_14_21     CONF_11_14_21  1.0
    x_14_21     CONF_12_14_21  1.0
    x_14_21     CONF_13_14_21  1.0
    x_14_22     ASSIGN_14  1.0
    x_14_22     CAP_22  50
    x_14_22     CONF_10_14_22  1.0
    x_14_22     CONF_11_14_22  1.0
    x_14_22     CONF_12_14_22  1.0
    x_14_22     CONF_13_14_22  1.0
    x_14_23     ASSIGN_14  1.0
    x_14_23     CAP_23  50
    x_14_23     CONF_10_14_23  1.0
    x_14_23     CONF_11_14_23  1.0
    x_14_23     CONF_12_14_23  1.0
    x_14_23     CONF_13_14_23  1.0
    x_14_24     ASSIGN_14  1.0
    x_14_24     CAP_24  50
    x_14_24     CONF_10_14_24  1.0
    x_14_24     CONF_11_14_24  1.0
    x_14_24     CONF_12_14_24  1.0
    x_14_24     CONF_13_14_24  1.0
    x_15_0      ASSIGN_15  1.0
    x_15_0      CAP_0  28
    x_15_0      CONF_15_16_0  1.0
    x_15_0      CONF_15_17_0  1.0
    x_15_0      CONF_15_18_0  1.0
    x_15_0      CONF_15_19_0  1.0
    x_15_1      ASSIGN_15  1.0
    x_15_1      CAP_1  28
    x_15_1      CONF_15_16_1  1.0
    x_15_1      CONF_15_17_1  1.0
    x_15_1      CONF_15_18_1  1.0
    x_15_1      CONF_15_19_1  1.0
    x_15_2      ASSIGN_15  1.0
    x_15_2      CAP_2  28
    x_15_2      CONF_15_16_2  1.0
    x_15_2      CONF_15_17_2  1.0
    x_15_2      CONF_15_18_2  1.0
    x_15_2      CONF_15_19_2  1.0
    x_15_3      ASSIGN_15  1.0
    x_15_3      CAP_3  28
    x_15_3      CONF_15_16_3  1.0
    x_15_3      CONF_15_17_3  1.0
    x_15_3      CONF_15_18_3  1.0
    x_15_3      CONF_15_19_3  1.0
    x_15_4      ASSIGN_15  1.0
    x_15_4      CAP_4  28
    x_15_4      CONF_15_16_4  1.0
    x_15_4      CONF_15_17_4  1.0
    x_15_4      CONF_15_18_4  1.0
    x_15_4      CONF_15_19_4  1.0
    x_15_5      ASSIGN_15  1.0
    x_15_5      CAP_5  28
    x_15_5      CONF_15_16_5  1.0
    x_15_5      CONF_15_17_5  1.0
    x_15_5      CONF_15_18_5  1.0
    x_15_5      CONF_15_19_5  1.0
    x_15_6      ASSIGN_15  1.0
    x_15_6      CAP_6  28
    x_15_6      CONF_15_16_6  1.0
    x_15_6      CONF_15_17_6  1.0
    x_15_6      CONF_15_18_6  1.0
    x_15_6      CONF_15_19_6  1.0
    x_15_7      ASSIGN_15  1.0
    x_15_7      CAP_7  28
    x_15_7      CONF_15_16_7  1.0
    x_15_7      CONF_15_17_7  1.0
    x_15_7      CONF_15_18_7  1.0
    x_15_7      CONF_15_19_7  1.0
    x_15_8      ASSIGN_15  1.0
    x_15_8      CAP_8  28
    x_15_8      CONF_15_16_8  1.0
    x_15_8      CONF_15_17_8  1.0
    x_15_8      CONF_15_18_8  1.0
    x_15_8      CONF_15_19_8  1.0
    x_15_9      ASSIGN_15  1.0
    x_15_9      CAP_9  28
    x_15_9      CONF_15_16_9  1.0
    x_15_9      CONF_15_17_9  1.0
    x_15_9      CONF_15_18_9  1.0
    x_15_9      CONF_15_19_9  1.0
    x_15_10     ASSIGN_15  1.0
    x_15_10     CAP_10  28
    x_15_10     CONF_15_16_10  1.0
    x_15_10     CONF_15_17_10  1.0
    x_15_10     CONF_15_18_10  1.0
    x_15_10     CONF_15_19_10  1.0
    x_15_11     ASSIGN_15  1.0
    x_15_11     CAP_11  28
    x_15_11     CONF_15_16_11  1.0
    x_15_11     CONF_15_17_11  1.0
    x_15_11     CONF_15_18_11  1.0
    x_15_11     CONF_15_19_11  1.0
    x_15_12     ASSIGN_15  1.0
    x_15_12     CAP_12  28
    x_15_12     CONF_15_16_12  1.0
    x_15_12     CONF_15_17_12  1.0
    x_15_12     CONF_15_18_12  1.0
    x_15_12     CONF_15_19_12  1.0
    x_15_13     ASSIGN_15  1.0
    x_15_13     CAP_13  28
    x_15_13     CONF_15_16_13  1.0
    x_15_13     CONF_15_17_13  1.0
    x_15_13     CONF_15_18_13  1.0
    x_15_13     CONF_15_19_13  1.0
    x_15_14     ASSIGN_15  1.0
    x_15_14     CAP_14  28
    x_15_14     CONF_15_16_14  1.0
    x_15_14     CONF_15_17_14  1.0
    x_15_14     CONF_15_18_14  1.0
    x_15_14     CONF_15_19_14  1.0
    x_15_15     ASSIGN_15  1.0
    x_15_15     CAP_15  28
    x_15_15     CONF_15_16_15  1.0
    x_15_15     CONF_15_17_15  1.0
    x_15_15     CONF_15_18_15  1.0
    x_15_15     CONF_15_19_15  1.0
    x_15_16     ASSIGN_15  1.0
    x_15_16     CAP_16  28
    x_15_16     CONF_15_16_16  1.0
    x_15_16     CONF_15_17_16  1.0
    x_15_16     CONF_15_18_16  1.0
    x_15_16     CONF_15_19_16  1.0
    x_15_17     ASSIGN_15  1.0
    x_15_17     CAP_17  28
    x_15_17     CONF_15_16_17  1.0
    x_15_17     CONF_15_17_17  1.0
    x_15_17     CONF_15_18_17  1.0
    x_15_17     CONF_15_19_17  1.0
    x_15_18     ASSIGN_15  1.0
    x_15_18     CAP_18  28
    x_15_18     CONF_15_16_18  1.0
    x_15_18     CONF_15_17_18  1.0
    x_15_18     CONF_15_18_18  1.0
    x_15_18     CONF_15_19_18  1.0
    x_15_19     ASSIGN_15  1.0
    x_15_19     CAP_19  28
    x_15_19     CONF_15_16_19  1.0
    x_15_19     CONF_15_17_19  1.0
    x_15_19     CONF_15_18_19  1.0
    x_15_19     CONF_15_19_19  1.0
    x_15_20     ASSIGN_15  1.0
    x_15_20     CAP_20  28
    x_15_20     CONF_15_16_20  1.0
    x_15_20     CONF_15_17_20  1.0
    x_15_20     CONF_15_18_20  1.0
    x_15_20     CONF_15_19_20  1.0
    x_15_21     ASSIGN_15  1.0
    x_15_21     CAP_21  28
    x_15_21     CONF_15_16_21  1.0
    x_15_21     CONF_15_17_21  1.0
    x_15_21     CONF_15_18_21  1.0
    x_15_21     CONF_15_19_21  1.0
    x_15_22     ASSIGN_15  1.0
    x_15_22     CAP_22  28
    x_15_22     CONF_15_16_22  1.0
    x_15_22     CONF_15_17_22  1.0
    x_15_22     CONF_15_18_22  1.0
    x_15_22     CONF_15_19_22  1.0
    x_15_23     ASSIGN_15  1.0
    x_15_23     CAP_23  28
    x_15_23     CONF_15_16_23  1.0
    x_15_23     CONF_15_17_23  1.0
    x_15_23     CONF_15_18_23  1.0
    x_15_23     CONF_15_19_23  1.0
    x_15_24     ASSIGN_15  1.0
    x_15_24     CAP_24  28
    x_15_24     CONF_15_16_24  1.0
    x_15_24     CONF_15_17_24  1.0
    x_15_24     CONF_15_18_24  1.0
    x_15_24     CONF_15_19_24  1.0
    x_16_0      ASSIGN_16  1.0
    x_16_0      CAP_0  47
    x_16_0      CONF_15_16_0  1.0
    x_16_0      CONF_16_17_0  1.0
    x_16_0      CONF_16_18_0  1.0
    x_16_0      CONF_16_19_0  1.0
    x_16_1      ASSIGN_16  1.0
    x_16_1      CAP_1  47
    x_16_1      CONF_15_16_1  1.0
    x_16_1      CONF_16_17_1  1.0
    x_16_1      CONF_16_18_1  1.0
    x_16_1      CONF_16_19_1  1.0
    x_16_2      ASSIGN_16  1.0
    x_16_2      CAP_2  47
    x_16_2      CONF_15_16_2  1.0
    x_16_2      CONF_16_17_2  1.0
    x_16_2      CONF_16_18_2  1.0
    x_16_2      CONF_16_19_2  1.0
    x_16_3      ASSIGN_16  1.0
    x_16_3      CAP_3  47
    x_16_3      CONF_15_16_3  1.0
    x_16_3      CONF_16_17_3  1.0
    x_16_3      CONF_16_18_3  1.0
    x_16_3      CONF_16_19_3  1.0
    x_16_4      ASSIGN_16  1.0
    x_16_4      CAP_4  47
    x_16_4      CONF_15_16_4  1.0
    x_16_4      CONF_16_17_4  1.0
    x_16_4      CONF_16_18_4  1.0
    x_16_4      CONF_16_19_4  1.0
    x_16_5      ASSIGN_16  1.0
    x_16_5      CAP_5  47
    x_16_5      CONF_15_16_5  1.0
    x_16_5      CONF_16_17_5  1.0
    x_16_5      CONF_16_18_5  1.0
    x_16_5      CONF_16_19_5  1.0
    x_16_6      ASSIGN_16  1.0
    x_16_6      CAP_6  47
    x_16_6      CONF_15_16_6  1.0
    x_16_6      CONF_16_17_6  1.0
    x_16_6      CONF_16_18_6  1.0
    x_16_6      CONF_16_19_6  1.0
    x_16_7      ASSIGN_16  1.0
    x_16_7      CAP_7  47
    x_16_7      CONF_15_16_7  1.0
    x_16_7      CONF_16_17_7  1.0
    x_16_7      CONF_16_18_7  1.0
    x_16_7      CONF_16_19_7  1.0
    x_16_8      ASSIGN_16  1.0
    x_16_8      CAP_8  47
    x_16_8      CONF_15_16_8  1.0
    x_16_8      CONF_16_17_8  1.0
    x_16_8      CONF_16_18_8  1.0
    x_16_8      CONF_16_19_8  1.0
    x_16_9      ASSIGN_16  1.0
    x_16_9      CAP_9  47
    x_16_9      CONF_15_16_9  1.0
    x_16_9      CONF_16_17_9  1.0
    x_16_9      CONF_16_18_9  1.0
    x_16_9      CONF_16_19_9  1.0
    x_16_10     ASSIGN_16  1.0
    x_16_10     CAP_10  47
    x_16_10     CONF_15_16_10  1.0
    x_16_10     CONF_16_17_10  1.0
    x_16_10     CONF_16_18_10  1.0
    x_16_10     CONF_16_19_10  1.0
    x_16_11     ASSIGN_16  1.0
    x_16_11     CAP_11  47
    x_16_11     CONF_15_16_11  1.0
    x_16_11     CONF_16_17_11  1.0
    x_16_11     CONF_16_18_11  1.0
    x_16_11     CONF_16_19_11  1.0
    x_16_12     ASSIGN_16  1.0
    x_16_12     CAP_12  47
    x_16_12     CONF_15_16_12  1.0
    x_16_12     CONF_16_17_12  1.0
    x_16_12     CONF_16_18_12  1.0
    x_16_12     CONF_16_19_12  1.0
    x_16_13     ASSIGN_16  1.0
    x_16_13     CAP_13  47
    x_16_13     CONF_15_16_13  1.0
    x_16_13     CONF_16_17_13  1.0
    x_16_13     CONF_16_18_13  1.0
    x_16_13     CONF_16_19_13  1.0
    x_16_14     ASSIGN_16  1.0
    x_16_14     CAP_14  47
    x_16_14     CONF_15_16_14  1.0
    x_16_14     CONF_16_17_14  1.0
    x_16_14     CONF_16_18_14  1.0
    x_16_14     CONF_16_19_14  1.0
    x_16_15     ASSIGN_16  1.0
    x_16_15     CAP_15  47
    x_16_15     CONF_15_16_15  1.0
    x_16_15     CONF_16_17_15  1.0
    x_16_15     CONF_16_18_15  1.0
    x_16_15     CONF_16_19_15  1.0
    x_16_16     ASSIGN_16  1.0
    x_16_16     CAP_16  47
    x_16_16     CONF_15_16_16  1.0
    x_16_16     CONF_16_17_16  1.0
    x_16_16     CONF_16_18_16  1.0
    x_16_16     CONF_16_19_16  1.0
    x_16_17     ASSIGN_16  1.0
    x_16_17     CAP_17  47
    x_16_17     CONF_15_16_17  1.0
    x_16_17     CONF_16_17_17  1.0
    x_16_17     CONF_16_18_17  1.0
    x_16_17     CONF_16_19_17  1.0
    x_16_18     ASSIGN_16  1.0
    x_16_18     CAP_18  47
    x_16_18     CONF_15_16_18  1.0
    x_16_18     CONF_16_17_18  1.0
    x_16_18     CONF_16_18_18  1.0
    x_16_18     CONF_16_19_18  1.0
    x_16_19     ASSIGN_16  1.0
    x_16_19     CAP_19  47
    x_16_19     CONF_15_16_19  1.0
    x_16_19     CONF_16_17_19  1.0
    x_16_19     CONF_16_18_19  1.0
    x_16_19     CONF_16_19_19  1.0
    x_16_20     ASSIGN_16  1.0
    x_16_20     CAP_20  47
    x_16_20     CONF_15_16_20  1.0
    x_16_20     CONF_16_17_20  1.0
    x_16_20     CONF_16_18_20  1.0
    x_16_20     CONF_16_19_20  1.0
    x_16_21     ASSIGN_16  1.0
    x_16_21     CAP_21  47
    x_16_21     CONF_15_16_21  1.0
    x_16_21     CONF_16_17_21  1.0
    x_16_21     CONF_16_18_21  1.0
    x_16_21     CONF_16_19_21  1.0
    x_16_22     ASSIGN_16  1.0
    x_16_22     CAP_22  47
    x_16_22     CONF_15_16_22  1.0
    x_16_22     CONF_16_17_22  1.0
    x_16_22     CONF_16_18_22  1.0
    x_16_22     CONF_16_19_22  1.0
    x_16_23     ASSIGN_16  1.0
    x_16_23     CAP_23  47
    x_16_23     CONF_15_16_23  1.0
    x_16_23     CONF_16_17_23  1.0
    x_16_23     CONF_16_18_23  1.0
    x_16_23     CONF_16_19_23  1.0
    x_16_24     ASSIGN_16  1.0
    x_16_24     CAP_24  47
    x_16_24     CONF_15_16_24  1.0
    x_16_24     CONF_16_17_24  1.0
    x_16_24     CONF_16_18_24  1.0
    x_16_24     CONF_16_19_24  1.0
    x_17_0      ASSIGN_17  1.0
    x_17_0      CAP_0  53
    x_17_0      CONF_15_17_0  1.0
    x_17_0      CONF_16_17_0  1.0
    x_17_0      CONF_17_18_0  1.0
    x_17_0      CONF_17_19_0  1.0
    x_17_1      ASSIGN_17  1.0
    x_17_1      CAP_1  53
    x_17_1      CONF_15_17_1  1.0
    x_17_1      CONF_16_17_1  1.0
    x_17_1      CONF_17_18_1  1.0
    x_17_1      CONF_17_19_1  1.0
    x_17_2      ASSIGN_17  1.0
    x_17_2      CAP_2  53
    x_17_2      CONF_15_17_2  1.0
    x_17_2      CONF_16_17_2  1.0
    x_17_2      CONF_17_18_2  1.0
    x_17_2      CONF_17_19_2  1.0
    x_17_3      ASSIGN_17  1.0
    x_17_3      CAP_3  53
    x_17_3      CONF_15_17_3  1.0
    x_17_3      CONF_16_17_3  1.0
    x_17_3      CONF_17_18_3  1.0
    x_17_3      CONF_17_19_3  1.0
    x_17_4      ASSIGN_17  1.0
    x_17_4      CAP_4  53
    x_17_4      CONF_15_17_4  1.0
    x_17_4      CONF_16_17_4  1.0
    x_17_4      CONF_17_18_4  1.0
    x_17_4      CONF_17_19_4  1.0
    x_17_5      ASSIGN_17  1.0
    x_17_5      CAP_5  53
    x_17_5      CONF_15_17_5  1.0
    x_17_5      CONF_16_17_5  1.0
    x_17_5      CONF_17_18_5  1.0
    x_17_5      CONF_17_19_5  1.0
    x_17_6      ASSIGN_17  1.0
    x_17_6      CAP_6  53
    x_17_6      CONF_15_17_6  1.0
    x_17_6      CONF_16_17_6  1.0
    x_17_6      CONF_17_18_6  1.0
    x_17_6      CONF_17_19_6  1.0
    x_17_7      ASSIGN_17  1.0
    x_17_7      CAP_7  53
    x_17_7      CONF_15_17_7  1.0
    x_17_7      CONF_16_17_7  1.0
    x_17_7      CONF_17_18_7  1.0
    x_17_7      CONF_17_19_7  1.0
    x_17_8      ASSIGN_17  1.0
    x_17_8      CAP_8  53
    x_17_8      CONF_15_17_8  1.0
    x_17_8      CONF_16_17_8  1.0
    x_17_8      CONF_17_18_8  1.0
    x_17_8      CONF_17_19_8  1.0
    x_17_9      ASSIGN_17  1.0
    x_17_9      CAP_9  53
    x_17_9      CONF_15_17_9  1.0
    x_17_9      CONF_16_17_9  1.0
    x_17_9      CONF_17_18_9  1.0
    x_17_9      CONF_17_19_9  1.0
    x_17_10     ASSIGN_17  1.0
    x_17_10     CAP_10  53
    x_17_10     CONF_15_17_10  1.0
    x_17_10     CONF_16_17_10  1.0
    x_17_10     CONF_17_18_10  1.0
    x_17_10     CONF_17_19_10  1.0
    x_17_11     ASSIGN_17  1.0
    x_17_11     CAP_11  53
    x_17_11     CONF_15_17_11  1.0
    x_17_11     CONF_16_17_11  1.0
    x_17_11     CONF_17_18_11  1.0
    x_17_11     CONF_17_19_11  1.0
    x_17_12     ASSIGN_17  1.0
    x_17_12     CAP_12  53
    x_17_12     CONF_15_17_12  1.0
    x_17_12     CONF_16_17_12  1.0
    x_17_12     CONF_17_18_12  1.0
    x_17_12     CONF_17_19_12  1.0
    x_17_13     ASSIGN_17  1.0
    x_17_13     CAP_13  53
    x_17_13     CONF_15_17_13  1.0
    x_17_13     CONF_16_17_13  1.0
    x_17_13     CONF_17_18_13  1.0
    x_17_13     CONF_17_19_13  1.0
    x_17_14     ASSIGN_17  1.0
    x_17_14     CAP_14  53
    x_17_14     CONF_15_17_14  1.0
    x_17_14     CONF_16_17_14  1.0
    x_17_14     CONF_17_18_14  1.0
    x_17_14     CONF_17_19_14  1.0
    x_17_15     ASSIGN_17  1.0
    x_17_15     CAP_15  53
    x_17_15     CONF_15_17_15  1.0
    x_17_15     CONF_16_17_15  1.0
    x_17_15     CONF_17_18_15  1.0
    x_17_15     CONF_17_19_15  1.0
    x_17_16     ASSIGN_17  1.0
    x_17_16     CAP_16  53
    x_17_16     CONF_15_17_16  1.0
    x_17_16     CONF_16_17_16  1.0
    x_17_16     CONF_17_18_16  1.0
    x_17_16     CONF_17_19_16  1.0
    x_17_17     ASSIGN_17  1.0
    x_17_17     CAP_17  53
    x_17_17     CONF_15_17_17  1.0
    x_17_17     CONF_16_17_17  1.0
    x_17_17     CONF_17_18_17  1.0
    x_17_17     CONF_17_19_17  1.0
    x_17_18     ASSIGN_17  1.0
    x_17_18     CAP_18  53
    x_17_18     CONF_15_17_18  1.0
    x_17_18     CONF_16_17_18  1.0
    x_17_18     CONF_17_18_18  1.0
    x_17_18     CONF_17_19_18  1.0
    x_17_19     ASSIGN_17  1.0
    x_17_19     CAP_19  53
    x_17_19     CONF_15_17_19  1.0
    x_17_19     CONF_16_17_19  1.0
    x_17_19     CONF_17_18_19  1.0
    x_17_19     CONF_17_19_19  1.0
    x_17_20     ASSIGN_17  1.0
    x_17_20     CAP_20  53
    x_17_20     CONF_15_17_20  1.0
    x_17_20     CONF_16_17_20  1.0
    x_17_20     CONF_17_18_20  1.0
    x_17_20     CONF_17_19_20  1.0
    x_17_21     ASSIGN_17  1.0
    x_17_21     CAP_21  53
    x_17_21     CONF_15_17_21  1.0
    x_17_21     CONF_16_17_21  1.0
    x_17_21     CONF_17_18_21  1.0
    x_17_21     CONF_17_19_21  1.0
    x_17_22     ASSIGN_17  1.0
    x_17_22     CAP_22  53
    x_17_22     CONF_15_17_22  1.0
    x_17_22     CONF_16_17_22  1.0
    x_17_22     CONF_17_18_22  1.0
    x_17_22     CONF_17_19_22  1.0
    x_17_23     ASSIGN_17  1.0
    x_17_23     CAP_23  53
    x_17_23     CONF_15_17_23  1.0
    x_17_23     CONF_16_17_23  1.0
    x_17_23     CONF_17_18_23  1.0
    x_17_23     CONF_17_19_23  1.0
    x_17_24     ASSIGN_17  1.0
    x_17_24     CAP_24  53
    x_17_24     CONF_15_17_24  1.0
    x_17_24     CONF_16_17_24  1.0
    x_17_24     CONF_17_18_24  1.0
    x_17_24     CONF_17_19_24  1.0
    x_18_0      ASSIGN_18  1.0
    x_18_0      CAP_0  53
    x_18_0      CONF_15_18_0  1.0
    x_18_0      CONF_16_18_0  1.0
    x_18_0      CONF_17_18_0  1.0
    x_18_0      CONF_18_19_0  1.0
    x_18_1      ASSIGN_18  1.0
    x_18_1      CAP_1  53
    x_18_1      CONF_15_18_1  1.0
    x_18_1      CONF_16_18_1  1.0
    x_18_1      CONF_17_18_1  1.0
    x_18_1      CONF_18_19_1  1.0
    x_18_2      ASSIGN_18  1.0
    x_18_2      CAP_2  53
    x_18_2      CONF_15_18_2  1.0
    x_18_2      CONF_16_18_2  1.0
    x_18_2      CONF_17_18_2  1.0
    x_18_2      CONF_18_19_2  1.0
    x_18_3      ASSIGN_18  1.0
    x_18_3      CAP_3  53
    x_18_3      CONF_15_18_3  1.0
    x_18_3      CONF_16_18_3  1.0
    x_18_3      CONF_17_18_3  1.0
    x_18_3      CONF_18_19_3  1.0
    x_18_4      ASSIGN_18  1.0
    x_18_4      CAP_4  53
    x_18_4      CONF_15_18_4  1.0
    x_18_4      CONF_16_18_4  1.0
    x_18_4      CONF_17_18_4  1.0
    x_18_4      CONF_18_19_4  1.0
    x_18_5      ASSIGN_18  1.0
    x_18_5      CAP_5  53
    x_18_5      CONF_15_18_5  1.0
    x_18_5      CONF_16_18_5  1.0
    x_18_5      CONF_17_18_5  1.0
    x_18_5      CONF_18_19_5  1.0
    x_18_6      ASSIGN_18  1.0
    x_18_6      CAP_6  53
    x_18_6      CONF_15_18_6  1.0
    x_18_6      CONF_16_18_6  1.0
    x_18_6      CONF_17_18_6  1.0
    x_18_6      CONF_18_19_6  1.0
    x_18_7      ASSIGN_18  1.0
    x_18_7      CAP_7  53
    x_18_7      CONF_15_18_7  1.0
    x_18_7      CONF_16_18_7  1.0
    x_18_7      CONF_17_18_7  1.0
    x_18_7      CONF_18_19_7  1.0
    x_18_8      ASSIGN_18  1.0
    x_18_8      CAP_8  53
    x_18_8      CONF_15_18_8  1.0
    x_18_8      CONF_16_18_8  1.0
    x_18_8      CONF_17_18_8  1.0
    x_18_8      CONF_18_19_8  1.0
    x_18_9      ASSIGN_18  1.0
    x_18_9      CAP_9  53
    x_18_9      CONF_15_18_9  1.0
    x_18_9      CONF_16_18_9  1.0
    x_18_9      CONF_17_18_9  1.0
    x_18_9      CONF_18_19_9  1.0
    x_18_10     ASSIGN_18  1.0
    x_18_10     CAP_10  53
    x_18_10     CONF_15_18_10  1.0
    x_18_10     CONF_16_18_10  1.0
    x_18_10     CONF_17_18_10  1.0
    x_18_10     CONF_18_19_10  1.0
    x_18_11     ASSIGN_18  1.0
    x_18_11     CAP_11  53
    x_18_11     CONF_15_18_11  1.0
    x_18_11     CONF_16_18_11  1.0
    x_18_11     CONF_17_18_11  1.0
    x_18_11     CONF_18_19_11  1.0
    x_18_12     ASSIGN_18  1.0
    x_18_12     CAP_12  53
    x_18_12     CONF_15_18_12  1.0
    x_18_12     CONF_16_18_12  1.0
    x_18_12     CONF_17_18_12  1.0
    x_18_12     CONF_18_19_12  1.0
    x_18_13     ASSIGN_18  1.0
    x_18_13     CAP_13  53
    x_18_13     CONF_15_18_13  1.0
    x_18_13     CONF_16_18_13  1.0
    x_18_13     CONF_17_18_13  1.0
    x_18_13     CONF_18_19_13  1.0
    x_18_14     ASSIGN_18  1.0
    x_18_14     CAP_14  53
    x_18_14     CONF_15_18_14  1.0
    x_18_14     CONF_16_18_14  1.0
    x_18_14     CONF_17_18_14  1.0
    x_18_14     CONF_18_19_14  1.0
    x_18_15     ASSIGN_18  1.0
    x_18_15     CAP_15  53
    x_18_15     CONF_15_18_15  1.0
    x_18_15     CONF_16_18_15  1.0
    x_18_15     CONF_17_18_15  1.0
    x_18_15     CONF_18_19_15  1.0
    x_18_16     ASSIGN_18  1.0
    x_18_16     CAP_16  53
    x_18_16     CONF_15_18_16  1.0
    x_18_16     CONF_16_18_16  1.0
    x_18_16     CONF_17_18_16  1.0
    x_18_16     CONF_18_19_16  1.0
    x_18_17     ASSIGN_18  1.0
    x_18_17     CAP_17  53
    x_18_17     CONF_15_18_17  1.0
    x_18_17     CONF_16_18_17  1.0
    x_18_17     CONF_17_18_17  1.0
    x_18_17     CONF_18_19_17  1.0
    x_18_18     ASSIGN_18  1.0
    x_18_18     CAP_18  53
    x_18_18     CONF_15_18_18  1.0
    x_18_18     CONF_16_18_18  1.0
    x_18_18     CONF_17_18_18  1.0
    x_18_18     CONF_18_19_18  1.0
    x_18_19     ASSIGN_18  1.0
    x_18_19     CAP_19  53
    x_18_19     CONF_15_18_19  1.0
    x_18_19     CONF_16_18_19  1.0
    x_18_19     CONF_17_18_19  1.0
    x_18_19     CONF_18_19_19  1.0
    x_18_20     ASSIGN_18  1.0
    x_18_20     CAP_20  53
    x_18_20     CONF_15_18_20  1.0
    x_18_20     CONF_16_18_20  1.0
    x_18_20     CONF_17_18_20  1.0
    x_18_20     CONF_18_19_20  1.0
    x_18_21     ASSIGN_18  1.0
    x_18_21     CAP_21  53
    x_18_21     CONF_15_18_21  1.0
    x_18_21     CONF_16_18_21  1.0
    x_18_21     CONF_17_18_21  1.0
    x_18_21     CONF_18_19_21  1.0
    x_18_22     ASSIGN_18  1.0
    x_18_22     CAP_22  53
    x_18_22     CONF_15_18_22  1.0
    x_18_22     CONF_16_18_22  1.0
    x_18_22     CONF_17_18_22  1.0
    x_18_22     CONF_18_19_22  1.0
    x_18_23     ASSIGN_18  1.0
    x_18_23     CAP_23  53
    x_18_23     CONF_15_18_23  1.0
    x_18_23     CONF_16_18_23  1.0
    x_18_23     CONF_17_18_23  1.0
    x_18_23     CONF_18_19_23  1.0
    x_18_24     ASSIGN_18  1.0
    x_18_24     CAP_24  53
    x_18_24     CONF_15_18_24  1.0
    x_18_24     CONF_16_18_24  1.0
    x_18_24     CONF_17_18_24  1.0
    x_18_24     CONF_18_19_24  1.0
    x_19_0      ASSIGN_19  1.0
    x_19_0      CAP_0  41
    x_19_0      CONF_15_19_0  1.0
    x_19_0      CONF_16_19_0  1.0
    x_19_0      CONF_17_19_0  1.0
    x_19_0      CONF_18_19_0  1.0
    x_19_1      ASSIGN_19  1.0
    x_19_1      CAP_1  41
    x_19_1      CONF_15_19_1  1.0
    x_19_1      CONF_16_19_1  1.0
    x_19_1      CONF_17_19_1  1.0
    x_19_1      CONF_18_19_1  1.0
    x_19_2      ASSIGN_19  1.0
    x_19_2      CAP_2  41
    x_19_2      CONF_15_19_2  1.0
    x_19_2      CONF_16_19_2  1.0
    x_19_2      CONF_17_19_2  1.0
    x_19_2      CONF_18_19_2  1.0
    x_19_3      ASSIGN_19  1.0
    x_19_3      CAP_3  41
    x_19_3      CONF_15_19_3  1.0
    x_19_3      CONF_16_19_3  1.0
    x_19_3      CONF_17_19_3  1.0
    x_19_3      CONF_18_19_3  1.0
    x_19_4      ASSIGN_19  1.0
    x_19_4      CAP_4  41
    x_19_4      CONF_15_19_4  1.0
    x_19_4      CONF_16_19_4  1.0
    x_19_4      CONF_17_19_4  1.0
    x_19_4      CONF_18_19_4  1.0
    x_19_5      ASSIGN_19  1.0
    x_19_5      CAP_5  41
    x_19_5      CONF_15_19_5  1.0
    x_19_5      CONF_16_19_5  1.0
    x_19_5      CONF_17_19_5  1.0
    x_19_5      CONF_18_19_5  1.0
    x_19_6      ASSIGN_19  1.0
    x_19_6      CAP_6  41
    x_19_6      CONF_15_19_6  1.0
    x_19_6      CONF_16_19_6  1.0
    x_19_6      CONF_17_19_6  1.0
    x_19_6      CONF_18_19_6  1.0
    x_19_7      ASSIGN_19  1.0
    x_19_7      CAP_7  41
    x_19_7      CONF_15_19_7  1.0
    x_19_7      CONF_16_19_7  1.0
    x_19_7      CONF_17_19_7  1.0
    x_19_7      CONF_18_19_7  1.0
    x_19_8      ASSIGN_19  1.0
    x_19_8      CAP_8  41
    x_19_8      CONF_15_19_8  1.0
    x_19_8      CONF_16_19_8  1.0
    x_19_8      CONF_17_19_8  1.0
    x_19_8      CONF_18_19_8  1.0
    x_19_9      ASSIGN_19  1.0
    x_19_9      CAP_9  41
    x_19_9      CONF_15_19_9  1.0
    x_19_9      CONF_16_19_9  1.0
    x_19_9      CONF_17_19_9  1.0
    x_19_9      CONF_18_19_9  1.0
    x_19_10     ASSIGN_19  1.0
    x_19_10     CAP_10  41
    x_19_10     CONF_15_19_10  1.0
    x_19_10     CONF_16_19_10  1.0
    x_19_10     CONF_17_19_10  1.0
    x_19_10     CONF_18_19_10  1.0
    x_19_11     ASSIGN_19  1.0
    x_19_11     CAP_11  41
    x_19_11     CONF_15_19_11  1.0
    x_19_11     CONF_16_19_11  1.0
    x_19_11     CONF_17_19_11  1.0
    x_19_11     CONF_18_19_11  1.0
    x_19_12     ASSIGN_19  1.0
    x_19_12     CAP_12  41
    x_19_12     CONF_15_19_12  1.0
    x_19_12     CONF_16_19_12  1.0
    x_19_12     CONF_17_19_12  1.0
    x_19_12     CONF_18_19_12  1.0
    x_19_13     ASSIGN_19  1.0
    x_19_13     CAP_13  41
    x_19_13     CONF_15_19_13  1.0
    x_19_13     CONF_16_19_13  1.0
    x_19_13     CONF_17_19_13  1.0
    x_19_13     CONF_18_19_13  1.0
    x_19_14     ASSIGN_19  1.0
    x_19_14     CAP_14  41
    x_19_14     CONF_15_19_14  1.0
    x_19_14     CONF_16_19_14  1.0
    x_19_14     CONF_17_19_14  1.0
    x_19_14     CONF_18_19_14  1.0
    x_19_15     ASSIGN_19  1.0
    x_19_15     CAP_15  41
    x_19_15     CONF_15_19_15  1.0
    x_19_15     CONF_16_19_15  1.0
    x_19_15     CONF_17_19_15  1.0
    x_19_15     CONF_18_19_15  1.0
    x_19_16     ASSIGN_19  1.0
    x_19_16     CAP_16  41
    x_19_16     CONF_15_19_16  1.0
    x_19_16     CONF_16_19_16  1.0
    x_19_16     CONF_17_19_16  1.0
    x_19_16     CONF_18_19_16  1.0
    x_19_17     ASSIGN_19  1.0
    x_19_17     CAP_17  41
    x_19_17     CONF_15_19_17  1.0
    x_19_17     CONF_16_19_17  1.0
    x_19_17     CONF_17_19_17  1.0
    x_19_17     CONF_18_19_17  1.0
    x_19_18     ASSIGN_19  1.0
    x_19_18     CAP_18  41
    x_19_18     CONF_15_19_18  1.0
    x_19_18     CONF_16_19_18  1.0
    x_19_18     CONF_17_19_18  1.0
    x_19_18     CONF_18_19_18  1.0
    x_19_19     ASSIGN_19  1.0
    x_19_19     CAP_19  41
    x_19_19     CONF_15_19_19  1.0
    x_19_19     CONF_16_19_19  1.0
    x_19_19     CONF_17_19_19  1.0
    x_19_19     CONF_18_19_19  1.0
    x_19_20     ASSIGN_19  1.0
    x_19_20     CAP_20  41
    x_19_20     CONF_15_19_20  1.0
    x_19_20     CONF_16_19_20  1.0
    x_19_20     CONF_17_19_20  1.0
    x_19_20     CONF_18_19_20  1.0
    x_19_21     ASSIGN_19  1.0
    x_19_21     CAP_21  41
    x_19_21     CONF_15_19_21  1.0
    x_19_21     CONF_16_19_21  1.0
    x_19_21     CONF_17_19_21  1.0
    x_19_21     CONF_18_19_21  1.0
    x_19_22     ASSIGN_19  1.0
    x_19_22     CAP_22  41
    x_19_22     CONF_15_19_22  1.0
    x_19_22     CONF_16_19_22  1.0
    x_19_22     CONF_17_19_22  1.0
    x_19_22     CONF_18_19_22  1.0
    x_19_23     ASSIGN_19  1.0
    x_19_23     CAP_23  41
    x_19_23     CONF_15_19_23  1.0
    x_19_23     CONF_16_19_23  1.0
    x_19_23     CONF_17_19_23  1.0
    x_19_23     CONF_18_19_23  1.0
    x_19_24     ASSIGN_19  1.0
    x_19_24     CAP_24  41
    x_19_24     CONF_15_19_24  1.0
    x_19_24     CONF_16_19_24  1.0
    x_19_24     CONF_17_19_24  1.0
    x_19_24     CONF_18_19_24  1.0
    x_20_0      ASSIGN_20  1.0
    x_20_0      CAP_0  20
    x_20_0      CONF_20_21_0  1.0
    x_20_0      CONF_20_22_0  1.0
    x_20_0      CONF_20_23_0  1.0
    x_20_0      CONF_20_24_0  1.0
    x_20_1      ASSIGN_20  1.0
    x_20_1      CAP_1  20
    x_20_1      CONF_20_21_1  1.0
    x_20_1      CONF_20_22_1  1.0
    x_20_1      CONF_20_23_1  1.0
    x_20_1      CONF_20_24_1  1.0
    x_20_2      ASSIGN_20  1.0
    x_20_2      CAP_2  20
    x_20_2      CONF_20_21_2  1.0
    x_20_2      CONF_20_22_2  1.0
    x_20_2      CONF_20_23_2  1.0
    x_20_2      CONF_20_24_2  1.0
    x_20_3      ASSIGN_20  1.0
    x_20_3      CAP_3  20
    x_20_3      CONF_20_21_3  1.0
    x_20_3      CONF_20_22_3  1.0
    x_20_3      CONF_20_23_3  1.0
    x_20_3      CONF_20_24_3  1.0
    x_20_4      ASSIGN_20  1.0
    x_20_4      CAP_4  20
    x_20_4      CONF_20_21_4  1.0
    x_20_4      CONF_20_22_4  1.0
    x_20_4      CONF_20_23_4  1.0
    x_20_4      CONF_20_24_4  1.0
    x_20_5      ASSIGN_20  1.0
    x_20_5      CAP_5  20
    x_20_5      CONF_20_21_5  1.0
    x_20_5      CONF_20_22_5  1.0
    x_20_5      CONF_20_23_5  1.0
    x_20_5      CONF_20_24_5  1.0
    x_20_6      ASSIGN_20  1.0
    x_20_6      CAP_6  20
    x_20_6      CONF_20_21_6  1.0
    x_20_6      CONF_20_22_6  1.0
    x_20_6      CONF_20_23_6  1.0
    x_20_6      CONF_20_24_6  1.0
    x_20_7      ASSIGN_20  1.0
    x_20_7      CAP_7  20
    x_20_7      CONF_20_21_7  1.0
    x_20_7      CONF_20_22_7  1.0
    x_20_7      CONF_20_23_7  1.0
    x_20_7      CONF_20_24_7  1.0
    x_20_8      ASSIGN_20  1.0
    x_20_8      CAP_8  20
    x_20_8      CONF_20_21_8  1.0
    x_20_8      CONF_20_22_8  1.0
    x_20_8      CONF_20_23_8  1.0
    x_20_8      CONF_20_24_8  1.0
    x_20_9      ASSIGN_20  1.0
    x_20_9      CAP_9  20
    x_20_9      CONF_20_21_9  1.0
    x_20_9      CONF_20_22_9  1.0
    x_20_9      CONF_20_23_9  1.0
    x_20_9      CONF_20_24_9  1.0
    x_20_10     ASSIGN_20  1.0
    x_20_10     CAP_10  20
    x_20_10     CONF_20_21_10  1.0
    x_20_10     CONF_20_22_10  1.0
    x_20_10     CONF_20_23_10  1.0
    x_20_10     CONF_20_24_10  1.0
    x_20_11     ASSIGN_20  1.0
    x_20_11     CAP_11  20
    x_20_11     CONF_20_21_11  1.0
    x_20_11     CONF_20_22_11  1.0
    x_20_11     CONF_20_23_11  1.0
    x_20_11     CONF_20_24_11  1.0
    x_20_12     ASSIGN_20  1.0
    x_20_12     CAP_12  20
    x_20_12     CONF_20_21_12  1.0
    x_20_12     CONF_20_22_12  1.0
    x_20_12     CONF_20_23_12  1.0
    x_20_12     CONF_20_24_12  1.0
    x_20_13     ASSIGN_20  1.0
    x_20_13     CAP_13  20
    x_20_13     CONF_20_21_13  1.0
    x_20_13     CONF_20_22_13  1.0
    x_20_13     CONF_20_23_13  1.0
    x_20_13     CONF_20_24_13  1.0
    x_20_14     ASSIGN_20  1.0
    x_20_14     CAP_14  20
    x_20_14     CONF_20_21_14  1.0
    x_20_14     CONF_20_22_14  1.0
    x_20_14     CONF_20_23_14  1.0
    x_20_14     CONF_20_24_14  1.0
    x_20_15     ASSIGN_20  1.0
    x_20_15     CAP_15  20
    x_20_15     CONF_20_21_15  1.0
    x_20_15     CONF_20_22_15  1.0
    x_20_15     CONF_20_23_15  1.0
    x_20_15     CONF_20_24_15  1.0
    x_20_16     ASSIGN_20  1.0
    x_20_16     CAP_16  20
    x_20_16     CONF_20_21_16  1.0
    x_20_16     CONF_20_22_16  1.0
    x_20_16     CONF_20_23_16  1.0
    x_20_16     CONF_20_24_16  1.0
    x_20_17     ASSIGN_20  1.0
    x_20_17     CAP_17  20
    x_20_17     CONF_20_21_17  1.0
    x_20_17     CONF_20_22_17  1.0
    x_20_17     CONF_20_23_17  1.0
    x_20_17     CONF_20_24_17  1.0
    x_20_18     ASSIGN_20  1.0
    x_20_18     CAP_18  20
    x_20_18     CONF_20_21_18  1.0
    x_20_18     CONF_20_22_18  1.0
    x_20_18     CONF_20_23_18  1.0
    x_20_18     CONF_20_24_18  1.0
    x_20_19     ASSIGN_20  1.0
    x_20_19     CAP_19  20
    x_20_19     CONF_20_21_19  1.0
    x_20_19     CONF_20_22_19  1.0
    x_20_19     CONF_20_23_19  1.0
    x_20_19     CONF_20_24_19  1.0
    x_20_20     ASSIGN_20  1.0
    x_20_20     CAP_20  20
    x_20_20     CONF_20_21_20  1.0
    x_20_20     CONF_20_22_20  1.0
    x_20_20     CONF_20_23_20  1.0
    x_20_20     CONF_20_24_20  1.0
    x_20_21     ASSIGN_20  1.0
    x_20_21     CAP_21  20
    x_20_21     CONF_20_21_21  1.0
    x_20_21     CONF_20_22_21  1.0
    x_20_21     CONF_20_23_21  1.0
    x_20_21     CONF_20_24_21  1.0
    x_20_22     ASSIGN_20  1.0
    x_20_22     CAP_22  20
    x_20_22     CONF_20_21_22  1.0
    x_20_22     CONF_20_22_22  1.0
    x_20_22     CONF_20_23_22  1.0
    x_20_22     CONF_20_24_22  1.0
    x_20_23     ASSIGN_20  1.0
    x_20_23     CAP_23  20
    x_20_23     CONF_20_21_23  1.0
    x_20_23     CONF_20_22_23  1.0
    x_20_23     CONF_20_23_23  1.0
    x_20_23     CONF_20_24_23  1.0
    x_20_24     ASSIGN_20  1.0
    x_20_24     CAP_24  20
    x_20_24     CONF_20_21_24  1.0
    x_20_24     CONF_20_22_24  1.0
    x_20_24     CONF_20_23_24  1.0
    x_20_24     CONF_20_24_24  1.0
    x_21_0      ASSIGN_21  1.0
    x_21_0      CAP_0  59
    x_21_0      CONF_20_21_0  1.0
    x_21_0      CONF_21_22_0  1.0
    x_21_0      CONF_21_23_0  1.0
    x_21_0      CONF_21_24_0  1.0
    x_21_1      ASSIGN_21  1.0
    x_21_1      CAP_1  59
    x_21_1      CONF_20_21_1  1.0
    x_21_1      CONF_21_22_1  1.0
    x_21_1      CONF_21_23_1  1.0
    x_21_1      CONF_21_24_1  1.0
    x_21_2      ASSIGN_21  1.0
    x_21_2      CAP_2  59
    x_21_2      CONF_20_21_2  1.0
    x_21_2      CONF_21_22_2  1.0
    x_21_2      CONF_21_23_2  1.0
    x_21_2      CONF_21_24_2  1.0
    x_21_3      ASSIGN_21  1.0
    x_21_3      CAP_3  59
    x_21_3      CONF_20_21_3  1.0
    x_21_3      CONF_21_22_3  1.0
    x_21_3      CONF_21_23_3  1.0
    x_21_3      CONF_21_24_3  1.0
    x_21_4      ASSIGN_21  1.0
    x_21_4      CAP_4  59
    x_21_4      CONF_20_21_4  1.0
    x_21_4      CONF_21_22_4  1.0
    x_21_4      CONF_21_23_4  1.0
    x_21_4      CONF_21_24_4  1.0
    x_21_5      ASSIGN_21  1.0
    x_21_5      CAP_5  59
    x_21_5      CONF_20_21_5  1.0
    x_21_5      CONF_21_22_5  1.0
    x_21_5      CONF_21_23_5  1.0
    x_21_5      CONF_21_24_5  1.0
    x_21_6      ASSIGN_21  1.0
    x_21_6      CAP_6  59
    x_21_6      CONF_20_21_6  1.0
    x_21_6      CONF_21_22_6  1.0
    x_21_6      CONF_21_23_6  1.0
    x_21_6      CONF_21_24_6  1.0
    x_21_7      ASSIGN_21  1.0
    x_21_7      CAP_7  59
    x_21_7      CONF_20_21_7  1.0
    x_21_7      CONF_21_22_7  1.0
    x_21_7      CONF_21_23_7  1.0
    x_21_7      CONF_21_24_7  1.0
    x_21_8      ASSIGN_21  1.0
    x_21_8      CAP_8  59
    x_21_8      CONF_20_21_8  1.0
    x_21_8      CONF_21_22_8  1.0
    x_21_8      CONF_21_23_8  1.0
    x_21_8      CONF_21_24_8  1.0
    x_21_9      ASSIGN_21  1.0
    x_21_9      CAP_9  59
    x_21_9      CONF_20_21_9  1.0
    x_21_9      CONF_21_22_9  1.0
    x_21_9      CONF_21_23_9  1.0
    x_21_9      CONF_21_24_9  1.0
    x_21_10     ASSIGN_21  1.0
    x_21_10     CAP_10  59
    x_21_10     CONF_20_21_10  1.0
    x_21_10     CONF_21_22_10  1.0
    x_21_10     CONF_21_23_10  1.0
    x_21_10     CONF_21_24_10  1.0
    x_21_11     ASSIGN_21  1.0
    x_21_11     CAP_11  59
    x_21_11     CONF_20_21_11  1.0
    x_21_11     CONF_21_22_11  1.0
    x_21_11     CONF_21_23_11  1.0
    x_21_11     CONF_21_24_11  1.0
    x_21_12     ASSIGN_21  1.0
    x_21_12     CAP_12  59
    x_21_12     CONF_20_21_12  1.0
    x_21_12     CONF_21_22_12  1.0
    x_21_12     CONF_21_23_12  1.0
    x_21_12     CONF_21_24_12  1.0
    x_21_13     ASSIGN_21  1.0
    x_21_13     CAP_13  59
    x_21_13     CONF_20_21_13  1.0
    x_21_13     CONF_21_22_13  1.0
    x_21_13     CONF_21_23_13  1.0
    x_21_13     CONF_21_24_13  1.0
    x_21_14     ASSIGN_21  1.0
    x_21_14     CAP_14  59
    x_21_14     CONF_20_21_14  1.0
    x_21_14     CONF_21_22_14  1.0
    x_21_14     CONF_21_23_14  1.0
    x_21_14     CONF_21_24_14  1.0
    x_21_15     ASSIGN_21  1.0
    x_21_15     CAP_15  59
    x_21_15     CONF_20_21_15  1.0
    x_21_15     CONF_21_22_15  1.0
    x_21_15     CONF_21_23_15  1.0
    x_21_15     CONF_21_24_15  1.0
    x_21_16     ASSIGN_21  1.0
    x_21_16     CAP_16  59
    x_21_16     CONF_20_21_16  1.0
    x_21_16     CONF_21_22_16  1.0
    x_21_16     CONF_21_23_16  1.0
    x_21_16     CONF_21_24_16  1.0
    x_21_17     ASSIGN_21  1.0
    x_21_17     CAP_17  59
    x_21_17     CONF_20_21_17  1.0
    x_21_17     CONF_21_22_17  1.0
    x_21_17     CONF_21_23_17  1.0
    x_21_17     CONF_21_24_17  1.0
    x_21_18     ASSIGN_21  1.0
    x_21_18     CAP_18  59
    x_21_18     CONF_20_21_18  1.0
    x_21_18     CONF_21_22_18  1.0
    x_21_18     CONF_21_23_18  1.0
    x_21_18     CONF_21_24_18  1.0
    x_21_19     ASSIGN_21  1.0
    x_21_19     CAP_19  59
    x_21_19     CONF_20_21_19  1.0
    x_21_19     CONF_21_22_19  1.0
    x_21_19     CONF_21_23_19  1.0
    x_21_19     CONF_21_24_19  1.0
    x_21_20     ASSIGN_21  1.0
    x_21_20     CAP_20  59
    x_21_20     CONF_20_21_20  1.0
    x_21_20     CONF_21_22_20  1.0
    x_21_20     CONF_21_23_20  1.0
    x_21_20     CONF_21_24_20  1.0
    x_21_21     ASSIGN_21  1.0
    x_21_21     CAP_21  59
    x_21_21     CONF_20_21_21  1.0
    x_21_21     CONF_21_22_21  1.0
    x_21_21     CONF_21_23_21  1.0
    x_21_21     CONF_21_24_21  1.0
    x_21_22     ASSIGN_21  1.0
    x_21_22     CAP_22  59
    x_21_22     CONF_20_21_22  1.0
    x_21_22     CONF_21_22_22  1.0
    x_21_22     CONF_21_23_22  1.0
    x_21_22     CONF_21_24_22  1.0
    x_21_23     ASSIGN_21  1.0
    x_21_23     CAP_23  59
    x_21_23     CONF_20_21_23  1.0
    x_21_23     CONF_21_22_23  1.0
    x_21_23     CONF_21_23_23  1.0
    x_21_23     CONF_21_24_23  1.0
    x_21_24     ASSIGN_21  1.0
    x_21_24     CAP_24  59
    x_21_24     CONF_20_21_24  1.0
    x_21_24     CONF_21_22_24  1.0
    x_21_24     CONF_21_23_24  1.0
    x_21_24     CONF_21_24_24  1.0
    x_22_0      ASSIGN_22  1.0
    x_22_0      CAP_0  21
    x_22_0      CONF_20_22_0  1.0
    x_22_0      CONF_21_22_0  1.0
    x_22_0      CONF_22_23_0  1.0
    x_22_0      CONF_22_24_0  1.0
    x_22_1      ASSIGN_22  1.0
    x_22_1      CAP_1  21
    x_22_1      CONF_20_22_1  1.0
    x_22_1      CONF_21_22_1  1.0
    x_22_1      CONF_22_23_1  1.0
    x_22_1      CONF_22_24_1  1.0
    x_22_2      ASSIGN_22  1.0
    x_22_2      CAP_2  21
    x_22_2      CONF_20_22_2  1.0
    x_22_2      CONF_21_22_2  1.0
    x_22_2      CONF_22_23_2  1.0
    x_22_2      CONF_22_24_2  1.0
    x_22_3      ASSIGN_22  1.0
    x_22_3      CAP_3  21
    x_22_3      CONF_20_22_3  1.0
    x_22_3      CONF_21_22_3  1.0
    x_22_3      CONF_22_23_3  1.0
    x_22_3      CONF_22_24_3  1.0
    x_22_4      ASSIGN_22  1.0
    x_22_4      CAP_4  21
    x_22_4      CONF_20_22_4  1.0
    x_22_4      CONF_21_22_4  1.0
    x_22_4      CONF_22_23_4  1.0
    x_22_4      CONF_22_24_4  1.0
    x_22_5      ASSIGN_22  1.0
    x_22_5      CAP_5  21
    x_22_5      CONF_20_22_5  1.0
    x_22_5      CONF_21_22_5  1.0
    x_22_5      CONF_22_23_5  1.0
    x_22_5      CONF_22_24_5  1.0
    x_22_6      ASSIGN_22  1.0
    x_22_6      CAP_6  21
    x_22_6      CONF_20_22_6  1.0
    x_22_6      CONF_21_22_6  1.0
    x_22_6      CONF_22_23_6  1.0
    x_22_6      CONF_22_24_6  1.0
    x_22_7      ASSIGN_22  1.0
    x_22_7      CAP_7  21
    x_22_7      CONF_20_22_7  1.0
    x_22_7      CONF_21_22_7  1.0
    x_22_7      CONF_22_23_7  1.0
    x_22_7      CONF_22_24_7  1.0
    x_22_8      ASSIGN_22  1.0
    x_22_8      CAP_8  21
    x_22_8      CONF_20_22_8  1.0
    x_22_8      CONF_21_22_8  1.0
    x_22_8      CONF_22_23_8  1.0
    x_22_8      CONF_22_24_8  1.0
    x_22_9      ASSIGN_22  1.0
    x_22_9      CAP_9  21
    x_22_9      CONF_20_22_9  1.0
    x_22_9      CONF_21_22_9  1.0
    x_22_9      CONF_22_23_9  1.0
    x_22_9      CONF_22_24_9  1.0
    x_22_10     ASSIGN_22  1.0
    x_22_10     CAP_10  21
    x_22_10     CONF_20_22_10  1.0
    x_22_10     CONF_21_22_10  1.0
    x_22_10     CONF_22_23_10  1.0
    x_22_10     CONF_22_24_10  1.0
    x_22_11     ASSIGN_22  1.0
    x_22_11     CAP_11  21
    x_22_11     CONF_20_22_11  1.0
    x_22_11     CONF_21_22_11  1.0
    x_22_11     CONF_22_23_11  1.0
    x_22_11     CONF_22_24_11  1.0
    x_22_12     ASSIGN_22  1.0
    x_22_12     CAP_12  21
    x_22_12     CONF_20_22_12  1.0
    x_22_12     CONF_21_22_12  1.0
    x_22_12     CONF_22_23_12  1.0
    x_22_12     CONF_22_24_12  1.0
    x_22_13     ASSIGN_22  1.0
    x_22_13     CAP_13  21
    x_22_13     CONF_20_22_13  1.0
    x_22_13     CONF_21_22_13  1.0
    x_22_13     CONF_22_23_13  1.0
    x_22_13     CONF_22_24_13  1.0
    x_22_14     ASSIGN_22  1.0
    x_22_14     CAP_14  21
    x_22_14     CONF_20_22_14  1.0
    x_22_14     CONF_21_22_14  1.0
    x_22_14     CONF_22_23_14  1.0
    x_22_14     CONF_22_24_14  1.0
    x_22_15     ASSIGN_22  1.0
    x_22_15     CAP_15  21
    x_22_15     CONF_20_22_15  1.0
    x_22_15     CONF_21_22_15  1.0
    x_22_15     CONF_22_23_15  1.0
    x_22_15     CONF_22_24_15  1.0
    x_22_16     ASSIGN_22  1.0
    x_22_16     CAP_16  21
    x_22_16     CONF_20_22_16  1.0
    x_22_16     CONF_21_22_16  1.0
    x_22_16     CONF_22_23_16  1.0
    x_22_16     CONF_22_24_16  1.0
    x_22_17     ASSIGN_22  1.0
    x_22_17     CAP_17  21
    x_22_17     CONF_20_22_17  1.0
    x_22_17     CONF_21_22_17  1.0
    x_22_17     CONF_22_23_17  1.0
    x_22_17     CONF_22_24_17  1.0
    x_22_18     ASSIGN_22  1.0
    x_22_18     CAP_18  21
    x_22_18     CONF_20_22_18  1.0
    x_22_18     CONF_21_22_18  1.0
    x_22_18     CONF_22_23_18  1.0
    x_22_18     CONF_22_24_18  1.0
    x_22_19     ASSIGN_22  1.0
    x_22_19     CAP_19  21
    x_22_19     CONF_20_22_19  1.0
    x_22_19     CONF_21_22_19  1.0
    x_22_19     CONF_22_23_19  1.0
    x_22_19     CONF_22_24_19  1.0
    x_22_20     ASSIGN_22  1.0
    x_22_20     CAP_20  21
    x_22_20     CONF_20_22_20  1.0
    x_22_20     CONF_21_22_20  1.0
    x_22_20     CONF_22_23_20  1.0
    x_22_20     CONF_22_24_20  1.0
    x_22_21     ASSIGN_22  1.0
    x_22_21     CAP_21  21
    x_22_21     CONF_20_22_21  1.0
    x_22_21     CONF_21_22_21  1.0
    x_22_21     CONF_22_23_21  1.0
    x_22_21     CONF_22_24_21  1.0
    x_22_22     ASSIGN_22  1.0
    x_22_22     CAP_22  21
    x_22_22     CONF_20_22_22  1.0
    x_22_22     CONF_21_22_22  1.0
    x_22_22     CONF_22_23_22  1.0
    x_22_22     CONF_22_24_22  1.0
    x_22_23     ASSIGN_22  1.0
    x_22_23     CAP_23  21
    x_22_23     CONF_20_22_23  1.0
    x_22_23     CONF_21_22_23  1.0
    x_22_23     CONF_22_23_23  1.0
    x_22_23     CONF_22_24_23  1.0
    x_22_24     ASSIGN_22  1.0
    x_22_24     CAP_24  21
    x_22_24     CONF_20_22_24  1.0
    x_22_24     CONF_21_22_24  1.0
    x_22_24     CONF_22_23_24  1.0
    x_22_24     CONF_22_24_24  1.0
    x_23_0      ASSIGN_23  1.0
    x_23_0      CAP_0  62
    x_23_0      CONF_20_23_0  1.0
    x_23_0      CONF_21_23_0  1.0
    x_23_0      CONF_22_23_0  1.0
    x_23_0      CONF_23_24_0  1.0
    x_23_1      ASSIGN_23  1.0
    x_23_1      CAP_1  62
    x_23_1      CONF_20_23_1  1.0
    x_23_1      CONF_21_23_1  1.0
    x_23_1      CONF_22_23_1  1.0
    x_23_1      CONF_23_24_1  1.0
    x_23_2      ASSIGN_23  1.0
    x_23_2      CAP_2  62
    x_23_2      CONF_20_23_2  1.0
    x_23_2      CONF_21_23_2  1.0
    x_23_2      CONF_22_23_2  1.0
    x_23_2      CONF_23_24_2  1.0
    x_23_3      ASSIGN_23  1.0
    x_23_3      CAP_3  62
    x_23_3      CONF_20_23_3  1.0
    x_23_3      CONF_21_23_3  1.0
    x_23_3      CONF_22_23_3  1.0
    x_23_3      CONF_23_24_3  1.0
    x_23_4      ASSIGN_23  1.0
    x_23_4      CAP_4  62
    x_23_4      CONF_20_23_4  1.0
    x_23_4      CONF_21_23_4  1.0
    x_23_4      CONF_22_23_4  1.0
    x_23_4      CONF_23_24_4  1.0
    x_23_5      ASSIGN_23  1.0
    x_23_5      CAP_5  62
    x_23_5      CONF_20_23_5  1.0
    x_23_5      CONF_21_23_5  1.0
    x_23_5      CONF_22_23_5  1.0
    x_23_5      CONF_23_24_5  1.0
    x_23_6      ASSIGN_23  1.0
    x_23_6      CAP_6  62
    x_23_6      CONF_20_23_6  1.0
    x_23_6      CONF_21_23_6  1.0
    x_23_6      CONF_22_23_6  1.0
    x_23_6      CONF_23_24_6  1.0
    x_23_7      ASSIGN_23  1.0
    x_23_7      CAP_7  62
    x_23_7      CONF_20_23_7  1.0
    x_23_7      CONF_21_23_7  1.0
    x_23_7      CONF_22_23_7  1.0
    x_23_7      CONF_23_24_7  1.0
    x_23_8      ASSIGN_23  1.0
    x_23_8      CAP_8  62
    x_23_8      CONF_20_23_8  1.0
    x_23_8      CONF_21_23_8  1.0
    x_23_8      CONF_22_23_8  1.0
    x_23_8      CONF_23_24_8  1.0
    x_23_9      ASSIGN_23  1.0
    x_23_9      CAP_9  62
    x_23_9      CONF_20_23_9  1.0
    x_23_9      CONF_21_23_9  1.0
    x_23_9      CONF_22_23_9  1.0
    x_23_9      CONF_23_24_9  1.0
    x_23_10     ASSIGN_23  1.0
    x_23_10     CAP_10  62
    x_23_10     CONF_20_23_10  1.0
    x_23_10     CONF_21_23_10  1.0
    x_23_10     CONF_22_23_10  1.0
    x_23_10     CONF_23_24_10  1.0
    x_23_11     ASSIGN_23  1.0
    x_23_11     CAP_11  62
    x_23_11     CONF_20_23_11  1.0
    x_23_11     CONF_21_23_11  1.0
    x_23_11     CONF_22_23_11  1.0
    x_23_11     CONF_23_24_11  1.0
    x_23_12     ASSIGN_23  1.0
    x_23_12     CAP_12  62
    x_23_12     CONF_20_23_12  1.0
    x_23_12     CONF_21_23_12  1.0
    x_23_12     CONF_22_23_12  1.0
    x_23_12     CONF_23_24_12  1.0
    x_23_13     ASSIGN_23  1.0
    x_23_13     CAP_13  62
    x_23_13     CONF_20_23_13  1.0
    x_23_13     CONF_21_23_13  1.0
    x_23_13     CONF_22_23_13  1.0
    x_23_13     CONF_23_24_13  1.0
    x_23_14     ASSIGN_23  1.0
    x_23_14     CAP_14  62
    x_23_14     CONF_20_23_14  1.0
    x_23_14     CONF_21_23_14  1.0
    x_23_14     CONF_22_23_14  1.0
    x_23_14     CONF_23_24_14  1.0
    x_23_15     ASSIGN_23  1.0
    x_23_15     CAP_15  62
    x_23_15     CONF_20_23_15  1.0
    x_23_15     CONF_21_23_15  1.0
    x_23_15     CONF_22_23_15  1.0
    x_23_15     CONF_23_24_15  1.0
    x_23_16     ASSIGN_23  1.0
    x_23_16     CAP_16  62
    x_23_16     CONF_20_23_16  1.0
    x_23_16     CONF_21_23_16  1.0
    x_23_16     CONF_22_23_16  1.0
    x_23_16     CONF_23_24_16  1.0
    x_23_17     ASSIGN_23  1.0
    x_23_17     CAP_17  62
    x_23_17     CONF_20_23_17  1.0
    x_23_17     CONF_21_23_17  1.0
    x_23_17     CONF_22_23_17  1.0
    x_23_17     CONF_23_24_17  1.0
    x_23_18     ASSIGN_23  1.0
    x_23_18     CAP_18  62
    x_23_18     CONF_20_23_18  1.0
    x_23_18     CONF_21_23_18  1.0
    x_23_18     CONF_22_23_18  1.0
    x_23_18     CONF_23_24_18  1.0
    x_23_19     ASSIGN_23  1.0
    x_23_19     CAP_19  62
    x_23_19     CONF_20_23_19  1.0
    x_23_19     CONF_21_23_19  1.0
    x_23_19     CONF_22_23_19  1.0
    x_23_19     CONF_23_24_19  1.0
    x_23_20     ASSIGN_23  1.0
    x_23_20     CAP_20  62
    x_23_20     CONF_20_23_20  1.0
    x_23_20     CONF_21_23_20  1.0
    x_23_20     CONF_22_23_20  1.0
    x_23_20     CONF_23_24_20  1.0
    x_23_21     ASSIGN_23  1.0
    x_23_21     CAP_21  62
    x_23_21     CONF_20_23_21  1.0
    x_23_21     CONF_21_23_21  1.0
    x_23_21     CONF_22_23_21  1.0
    x_23_21     CONF_23_24_21  1.0
    x_23_22     ASSIGN_23  1.0
    x_23_22     CAP_22  62
    x_23_22     CONF_20_23_22  1.0
    x_23_22     CONF_21_23_22  1.0
    x_23_22     CONF_22_23_22  1.0
    x_23_22     CONF_23_24_22  1.0
    x_23_23     ASSIGN_23  1.0
    x_23_23     CAP_23  62
    x_23_23     CONF_20_23_23  1.0
    x_23_23     CONF_21_23_23  1.0
    x_23_23     CONF_22_23_23  1.0
    x_23_23     CONF_23_24_23  1.0
    x_23_24     ASSIGN_23  1.0
    x_23_24     CAP_24  62
    x_23_24     CONF_20_23_24  1.0
    x_23_24     CONF_21_23_24  1.0
    x_23_24     CONF_22_23_24  1.0
    x_23_24     CONF_23_24_24  1.0
    x_24_0      ASSIGN_24  1.0
    x_24_0      CAP_0  64
    x_24_0      CONF_20_24_0  1.0
    x_24_0      CONF_21_24_0  1.0
    x_24_0      CONF_22_24_0  1.0
    x_24_0      CONF_23_24_0  1.0
    x_24_1      ASSIGN_24  1.0
    x_24_1      CAP_1  64
    x_24_1      CONF_20_24_1  1.0
    x_24_1      CONF_21_24_1  1.0
    x_24_1      CONF_22_24_1  1.0
    x_24_1      CONF_23_24_1  1.0
    x_24_2      ASSIGN_24  1.0
    x_24_2      CAP_2  64
    x_24_2      CONF_20_24_2  1.0
    x_24_2      CONF_21_24_2  1.0
    x_24_2      CONF_22_24_2  1.0
    x_24_2      CONF_23_24_2  1.0
    x_24_3      ASSIGN_24  1.0
    x_24_3      CAP_3  64
    x_24_3      CONF_20_24_3  1.0
    x_24_3      CONF_21_24_3  1.0
    x_24_3      CONF_22_24_3  1.0
    x_24_3      CONF_23_24_3  1.0
    x_24_4      ASSIGN_24  1.0
    x_24_4      CAP_4  64
    x_24_4      CONF_20_24_4  1.0
    x_24_4      CONF_21_24_4  1.0
    x_24_4      CONF_22_24_4  1.0
    x_24_4      CONF_23_24_4  1.0
    x_24_5      ASSIGN_24  1.0
    x_24_5      CAP_5  64
    x_24_5      CONF_20_24_5  1.0
    x_24_5      CONF_21_24_5  1.0
    x_24_5      CONF_22_24_5  1.0
    x_24_5      CONF_23_24_5  1.0
    x_24_6      ASSIGN_24  1.0
    x_24_6      CAP_6  64
    x_24_6      CONF_20_24_6  1.0
    x_24_6      CONF_21_24_6  1.0
    x_24_6      CONF_22_24_6  1.0
    x_24_6      CONF_23_24_6  1.0
    x_24_7      ASSIGN_24  1.0
    x_24_7      CAP_7  64
    x_24_7      CONF_20_24_7  1.0
    x_24_7      CONF_21_24_7  1.0
    x_24_7      CONF_22_24_7  1.0
    x_24_7      CONF_23_24_7  1.0
    x_24_8      ASSIGN_24  1.0
    x_24_8      CAP_8  64
    x_24_8      CONF_20_24_8  1.0
    x_24_8      CONF_21_24_8  1.0
    x_24_8      CONF_22_24_8  1.0
    x_24_8      CONF_23_24_8  1.0
    x_24_9      ASSIGN_24  1.0
    x_24_9      CAP_9  64
    x_24_9      CONF_20_24_9  1.0
    x_24_9      CONF_21_24_9  1.0
    x_24_9      CONF_22_24_9  1.0
    x_24_9      CONF_23_24_9  1.0
    x_24_10     ASSIGN_24  1.0
    x_24_10     CAP_10  64
    x_24_10     CONF_20_24_10  1.0
    x_24_10     CONF_21_24_10  1.0
    x_24_10     CONF_22_24_10  1.0
    x_24_10     CONF_23_24_10  1.0
    x_24_11     ASSIGN_24  1.0
    x_24_11     CAP_11  64
    x_24_11     CONF_20_24_11  1.0
    x_24_11     CONF_21_24_11  1.0
    x_24_11     CONF_22_24_11  1.0
    x_24_11     CONF_23_24_11  1.0
    x_24_12     ASSIGN_24  1.0
    x_24_12     CAP_12  64
    x_24_12     CONF_20_24_12  1.0
    x_24_12     CONF_21_24_12  1.0
    x_24_12     CONF_22_24_12  1.0
    x_24_12     CONF_23_24_12  1.0
    x_24_13     ASSIGN_24  1.0
    x_24_13     CAP_13  64
    x_24_13     CONF_20_24_13  1.0
    x_24_13     CONF_21_24_13  1.0
    x_24_13     CONF_22_24_13  1.0
    x_24_13     CONF_23_24_13  1.0
    x_24_14     ASSIGN_24  1.0
    x_24_14     CAP_14  64
    x_24_14     CONF_20_24_14  1.0
    x_24_14     CONF_21_24_14  1.0
    x_24_14     CONF_22_24_14  1.0
    x_24_14     CONF_23_24_14  1.0
    x_24_15     ASSIGN_24  1.0
    x_24_15     CAP_15  64
    x_24_15     CONF_20_24_15  1.0
    x_24_15     CONF_21_24_15  1.0
    x_24_15     CONF_22_24_15  1.0
    x_24_15     CONF_23_24_15  1.0
    x_24_16     ASSIGN_24  1.0
    x_24_16     CAP_16  64
    x_24_16     CONF_20_24_16  1.0
    x_24_16     CONF_21_24_16  1.0
    x_24_16     CONF_22_24_16  1.0
    x_24_16     CONF_23_24_16  1.0
    x_24_17     ASSIGN_24  1.0
    x_24_17     CAP_17  64
    x_24_17     CONF_20_24_17  1.0
    x_24_17     CONF_21_24_17  1.0
    x_24_17     CONF_22_24_17  1.0
    x_24_17     CONF_23_24_17  1.0
    x_24_18     ASSIGN_24  1.0
    x_24_18     CAP_18  64
    x_24_18     CONF_20_24_18  1.0
    x_24_18     CONF_21_24_18  1.0
    x_24_18     CONF_22_24_18  1.0
    x_24_18     CONF_23_24_18  1.0
    x_24_19     ASSIGN_24  1.0
    x_24_19     CAP_19  64
    x_24_19     CONF_20_24_19  1.0
    x_24_19     CONF_21_24_19  1.0
    x_24_19     CONF_22_24_19  1.0
    x_24_19     CONF_23_24_19  1.0
    x_24_20     ASSIGN_24  1.0
    x_24_20     CAP_20  64
    x_24_20     CONF_20_24_20  1.0
    x_24_20     CONF_21_24_20  1.0
    x_24_20     CONF_22_24_20  1.0
    x_24_20     CONF_23_24_20  1.0
    x_24_21     ASSIGN_24  1.0
    x_24_21     CAP_21  64
    x_24_21     CONF_20_24_21  1.0
    x_24_21     CONF_21_24_21  1.0
    x_24_21     CONF_22_24_21  1.0
    x_24_21     CONF_23_24_21  1.0
    x_24_22     ASSIGN_24  1.0
    x_24_22     CAP_22  64
    x_24_22     CONF_20_24_22  1.0
    x_24_22     CONF_21_24_22  1.0
    x_24_22     CONF_22_24_22  1.0
    x_24_22     CONF_23_24_22  1.0
    x_24_23     ASSIGN_24  1.0
    x_24_23     CAP_23  64
    x_24_23     CONF_20_24_23  1.0
    x_24_23     CONF_21_24_23  1.0
    x_24_23     CONF_22_24_23  1.0
    x_24_23     CONF_23_24_23  1.0
    x_24_24     ASSIGN_24  1.0
    x_24_24     CAP_24  64
    x_24_24     CONF_20_24_24  1.0
    x_24_24     CONF_21_24_24  1.0
    x_24_24     CONF_22_24_24  1.0
    x_24_24     CONF_23_24_24  1.0
    y_0         OBJ       1.0
    y_0         CAP_0  -200
    y_0         CONF_3_4_0  -1.0
    y_0         CONF_16_17_0  -1.0
    y_0         CONF_20_23_0  -1.0
    y_0         CONF_12_13_0  -1.0
    y_0         CONF_21_22_0  -1.0
    y_0         CONF_5_7_0  -1.0
    y_0         CONF_22_23_0  -1.0
    y_0         CONF_0_2_0  -1.0
    y_0         CONF_8_9_0  -1.0
    y_0         CONF_17_18_0  -1.0
    y_0         CONF_11_14_0  -1.0
    y_0         CONF_1_3_0  -1.0
    y_0         CONF_10_12_0  -1.0
    y_0         CONF_13_14_0  -1.0
    y_0         CONF_16_19_0  -1.0
    y_0         CONF_6_8_0  -1.0
    y_0         CONF_15_17_0  -1.0
    y_0         CONF_18_19_0  -1.0
    y_0         CONF_5_6_0  -1.0
    y_0         CONF_21_24_0  -1.0
    y_0         CONF_20_22_0  -1.0
    y_0         CONF_5_9_0  -1.0
    y_0         CONF_23_24_0  -1.0
    y_0         CONF_0_1_0  -1.0
    y_0         CONF_2_4_0  -1.0
    y_0         CONF_1_2_0  -1.0
    y_0         CONF_0_4_0  -1.0
    y_0         CONF_10_11_0  -1.0
    y_0         CONF_10_14_0  -1.0
    y_0         CONF_11_13_0  -1.0
    y_0         CONF_7_9_0  -1.0
    y_0         CONF_6_7_0  -1.0
    y_0         CONF_15_16_0  -1.0
    y_0         CONF_15_18_0  -1.0
    y_0         CONF_15_19_0  -1.0
    y_0         CONF_16_18_0  -1.0
    y_0         CONF_12_14_0  -1.0
    y_0         CONF_20_21_0  -1.0
    y_0         CONF_21_23_0  -1.0
    y_0         CONF_20_24_0  -1.0
    y_0         CONF_5_8_0  -1.0
    y_0         CONF_22_24_0  -1.0
    y_0         CONF_0_3_0  -1.0
    y_0         CONF_17_19_0  -1.0
    y_0         CONF_1_4_0  -1.0
    y_0         CONF_10_13_0  -1.0
    y_0         CONF_2_3_0  -1.0
    y_0         CONF_11_12_0  -1.0
    y_0         CONF_6_9_0  -1.0
    y_0         CONF_7_8_0  -1.0
    y_1         OBJ       1.0
    y_1         CAP_1  -200
    y_1         CONF_3_4_1  -1.0
    y_1         CONF_16_17_1  -1.0
    y_1         CONF_20_23_1  -1.0
    y_1         CONF_12_13_1  -1.0
    y_1         CONF_21_22_1  -1.0
    y_1         CONF_5_7_1  -1.0
    y_1         CONF_22_23_1  -1.0
    y_1         CONF_0_2_1  -1.0
    y_1         CONF_8_9_1  -1.0
    y_1         CONF_17_18_1  -1.0
    y_1         CONF_11_14_1  -1.0
    y_1         CONF_1_3_1  -1.0
    y_1         CONF_10_12_1  -1.0
    y_1         CONF_13_14_1  -1.0
    y_1         CONF_16_19_1  -1.0
    y_1         CONF_6_8_1  -1.0
    y_1         CONF_15_17_1  -1.0
    y_1         CONF_18_19_1  -1.0
    y_1         CONF_5_6_1  -1.0
    y_1         CONF_21_24_1  -1.0
    y_1         CONF_20_22_1  -1.0
    y_1         CONF_5_9_1  -1.0
    y_1         CONF_23_24_1  -1.0
    y_1         CONF_0_1_1  -1.0
    y_1         CONF_2_4_1  -1.0
    y_1         CONF_1_2_1  -1.0
    y_1         CONF_0_4_1  -1.0
    y_1         CONF_10_11_1  -1.0
    y_1         CONF_10_14_1  -1.0
    y_1         CONF_11_13_1  -1.0
    y_1         CONF_7_9_1  -1.0
    y_1         CONF_6_7_1  -1.0
    y_1         CONF_15_16_1  -1.0
    y_1         CONF_15_18_1  -1.0
    y_1         CONF_15_19_1  -1.0
    y_1         CONF_16_18_1  -1.0
    y_1         CONF_12_14_1  -1.0
    y_1         CONF_20_21_1  -1.0
    y_1         CONF_21_23_1  -1.0
    y_1         CONF_20_24_1  -1.0
    y_1         CONF_5_8_1  -1.0
    y_1         CONF_22_24_1  -1.0
    y_1         CONF_0_3_1  -1.0
    y_1         CONF_17_19_1  -1.0
    y_1         CONF_1_4_1  -1.0
    y_1         CONF_10_13_1  -1.0
    y_1         CONF_2_3_1  -1.0
    y_1         CONF_11_12_1  -1.0
    y_1         CONF_6_9_1  -1.0
    y_1         CONF_7_8_1  -1.0
    y_2         OBJ       1.0
    y_2         CAP_2  -200
    y_2         CONF_3_4_2  -1.0
    y_2         CONF_16_17_2  -1.0
    y_2         CONF_20_23_2  -1.0
    y_2         CONF_12_13_2  -1.0
    y_2         CONF_21_22_2  -1.0
    y_2         CONF_5_7_2  -1.0
    y_2         CONF_22_23_2  -1.0
    y_2         CONF_0_2_2  -1.0
    y_2         CONF_8_9_2  -1.0
    y_2         CONF_17_18_2  -1.0
    y_2         CONF_11_14_2  -1.0
    y_2         CONF_1_3_2  -1.0
    y_2         CONF_10_12_2  -1.0
    y_2         CONF_13_14_2  -1.0
    y_2         CONF_16_19_2  -1.0
    y_2         CONF_6_8_2  -1.0
    y_2         CONF_15_17_2  -1.0
    y_2         CONF_18_19_2  -1.0
    y_2         CONF_5_6_2  -1.0
    y_2         CONF_21_24_2  -1.0
    y_2         CONF_20_22_2  -1.0
    y_2         CONF_5_9_2  -1.0
    y_2         CONF_23_24_2  -1.0
    y_2         CONF_0_1_2  -1.0
    y_2         CONF_2_4_2  -1.0
    y_2         CONF_1_2_2  -1.0
    y_2         CONF_0_4_2  -1.0
    y_2         CONF_10_11_2  -1.0
    y_2         CONF_10_14_2  -1.0
    y_2         CONF_11_13_2  -1.0
    y_2         CONF_7_9_2  -1.0
    y_2         CONF_6_7_2  -1.0
    y_2         CONF_15_16_2  -1.0
    y_2         CONF_15_18_2  -1.0
    y_2         CONF_15_19_2  -1.0
    y_2         CONF_16_18_2  -1.0
    y_2         CONF_12_14_2  -1.0
    y_2         CONF_20_21_2  -1.0
    y_2         CONF_21_23_2  -1.0
    y_2         CONF_20_24_2  -1.0
    y_2         CONF_5_8_2  -1.0
    y_2         CONF_22_24_2  -1.0
    y_2         CONF_0_3_2  -1.0
    y_2         CONF_17_19_2  -1.0
    y_2         CONF_1_4_2  -1.0
    y_2         CONF_10_13_2  -1.0
    y_2         CONF_2_3_2  -1.0
    y_2         CONF_11_12_2  -1.0
    y_2         CONF_6_9_2  -1.0
    y_2         CONF_7_8_2  -1.0
    y_3         OBJ       1.0
    y_3         CAP_3  -200
    y_3         CONF_3_4_3  -1.0
    y_3         CONF_16_17_3  -1.0
    y_3         CONF_20_23_3  -1.0
    y_3         CONF_12_13_3  -1.0
    y_3         CONF_21_22_3  -1.0
    y_3         CONF_5_7_3  -1.0
    y_3         CONF_22_23_3  -1.0
    y_3         CONF_0_2_3  -1.0
    y_3         CONF_8_9_3  -1.0
    y_3         CONF_17_18_3  -1.0
    y_3         CONF_11_14_3  -1.0
    y_3         CONF_1_3_3  -1.0
    y_3         CONF_10_12_3  -1.0
    y_3         CONF_13_14_3  -1.0
    y_3         CONF_16_19_3  -1.0
    y_3         CONF_6_8_3  -1.0
    y_3         CONF_15_17_3  -1.0
    y_3         CONF_18_19_3  -1.0
    y_3         CONF_5_6_3  -1.0
    y_3         CONF_21_24_3  -1.0
    y_3         CONF_20_22_3  -1.0
    y_3         CONF_5_9_3  -1.0
    y_3         CONF_23_24_3  -1.0
    y_3         CONF_0_1_3  -1.0
    y_3         CONF_2_4_3  -1.0
    y_3         CONF_1_2_3  -1.0
    y_3         CONF_0_4_3  -1.0
    y_3         CONF_10_11_3  -1.0
    y_3         CONF_10_14_3  -1.0
    y_3         CONF_11_13_3  -1.0
    y_3         CONF_7_9_3  -1.0
    y_3         CONF_6_7_3  -1.0
    y_3         CONF_15_16_3  -1.0
    y_3         CONF_15_18_3  -1.0
    y_3         CONF_15_19_3  -1.0
    y_3         CONF_16_18_3  -1.0
    y_3         CONF_12_14_3  -1.0
    y_3         CONF_20_21_3  -1.0
    y_3         CONF_21_23_3  -1.0
    y_3         CONF_20_24_3  -1.0
    y_3         CONF_5_8_3  -1.0
    y_3         CONF_22_24_3  -1.0
    y_3         CONF_0_3_3  -1.0
    y_3         CONF_17_19_3  -1.0
    y_3         CONF_1_4_3  -1.0
    y_3         CONF_10_13_3  -1.0
    y_3         CONF_2_3_3  -1.0
    y_3         CONF_11_12_3  -1.0
    y_3         CONF_6_9_3  -1.0
    y_3         CONF_7_8_3  -1.0
    y_4         OBJ       1.0
    y_4         CAP_4  -200
    y_4         CONF_3_4_4  -1.0
    y_4         CONF_16_17_4  -1.0
    y_4         CONF_20_23_4  -1.0
    y_4         CONF_12_13_4  -1.0
    y_4         CONF_21_22_4  -1.0
    y_4         CONF_5_7_4  -1.0
    y_4         CONF_22_23_4  -1.0
    y_4         CONF_0_2_4  -1.0
    y_4         CONF_8_9_4  -1.0
    y_4         CONF_17_18_4  -1.0
    y_4         CONF_11_14_4  -1.0
    y_4         CONF_1_3_4  -1.0
    y_4         CONF_10_12_4  -1.0
    y_4         CONF_13_14_4  -1.0
    y_4         CONF_16_19_4  -1.0
    y_4         CONF_6_8_4  -1.0
    y_4         CONF_15_17_4  -1.0
    y_4         CONF_18_19_4  -1.0
    y_4         CONF_5_6_4  -1.0
    y_4         CONF_21_24_4  -1.0
    y_4         CONF_20_22_4  -1.0
    y_4         CONF_5_9_4  -1.0
    y_4         CONF_23_24_4  -1.0
    y_4         CONF_0_1_4  -1.0
    y_4         CONF_2_4_4  -1.0
    y_4         CONF_1_2_4  -1.0
    y_4         CONF_0_4_4  -1.0
    y_4         CONF_10_11_4  -1.0
    y_4         CONF_10_14_4  -1.0
    y_4         CONF_11_13_4  -1.0
    y_4         CONF_7_9_4  -1.0
    y_4         CONF_6_7_4  -1.0
    y_4         CONF_15_16_4  -1.0
    y_4         CONF_15_18_4  -1.0
    y_4         CONF_15_19_4  -1.0
    y_4         CONF_16_18_4  -1.0
    y_4         CONF_12_14_4  -1.0
    y_4         CONF_20_21_4  -1.0
    y_4         CONF_21_23_4  -1.0
    y_4         CONF_20_24_4  -1.0
    y_4         CONF_5_8_4  -1.0
    y_4         CONF_22_24_4  -1.0
    y_4         CONF_0_3_4  -1.0
    y_4         CONF_17_19_4  -1.0
    y_4         CONF_1_4_4  -1.0
    y_4         CONF_10_13_4  -1.0
    y_4         CONF_2_3_4  -1.0
    y_4         CONF_11_12_4  -1.0
    y_4         CONF_6_9_4  -1.0
    y_4         CONF_7_8_4  -1.0
    y_5         OBJ       1.0
    y_5         CAP_5  -200
    y_5         CONF_3_4_5  -1.0
    y_5         CONF_16_17_5  -1.0
    y_5         CONF_20_23_5  -1.0
    y_5         CONF_12_13_5  -1.0
    y_5         CONF_21_22_5  -1.0
    y_5         CONF_5_7_5  -1.0
    y_5         CONF_22_23_5  -1.0
    y_5         CONF_0_2_5  -1.0
    y_5         CONF_8_9_5  -1.0
    y_5         CONF_17_18_5  -1.0
    y_5         CONF_11_14_5  -1.0
    y_5         CONF_1_3_5  -1.0
    y_5         CONF_10_12_5  -1.0
    y_5         CONF_13_14_5  -1.0
    y_5         CONF_16_19_5  -1.0
    y_5         CONF_6_8_5  -1.0
    y_5         CONF_15_17_5  -1.0
    y_5         CONF_18_19_5  -1.0
    y_5         CONF_5_6_5  -1.0
    y_5         CONF_21_24_5  -1.0
    y_5         CONF_20_22_5  -1.0
    y_5         CONF_5_9_5  -1.0
    y_5         CONF_23_24_5  -1.0
    y_5         CONF_0_1_5  -1.0
    y_5         CONF_2_4_5  -1.0
    y_5         CONF_1_2_5  -1.0
    y_5         CONF_0_4_5  -1.0
    y_5         CONF_10_11_5  -1.0
    y_5         CONF_10_14_5  -1.0
    y_5         CONF_11_13_5  -1.0
    y_5         CONF_7_9_5  -1.0
    y_5         CONF_6_7_5  -1.0
    y_5         CONF_15_16_5  -1.0
    y_5         CONF_15_18_5  -1.0
    y_5         CONF_15_19_5  -1.0
    y_5         CONF_16_18_5  -1.0
    y_5         CONF_12_14_5  -1.0
    y_5         CONF_20_21_5  -1.0
    y_5         CONF_21_23_5  -1.0
    y_5         CONF_20_24_5  -1.0
    y_5         CONF_5_8_5  -1.0
    y_5         CONF_22_24_5  -1.0
    y_5         CONF_0_3_5  -1.0
    y_5         CONF_17_19_5  -1.0
    y_5         CONF_1_4_5  -1.0
    y_5         CONF_10_13_5  -1.0
    y_5         CONF_2_3_5  -1.0
    y_5         CONF_11_12_5  -1.0
    y_5         CONF_6_9_5  -1.0
    y_5         CONF_7_8_5  -1.0
    y_6         OBJ       1.0
    y_6         CAP_6  -200
    y_6         CONF_3_4_6  -1.0
    y_6         CONF_16_17_6  -1.0
    y_6         CONF_20_23_6  -1.0
    y_6         CONF_12_13_6  -1.0
    y_6         CONF_21_22_6  -1.0
    y_6         CONF_5_7_6  -1.0
    y_6         CONF_22_23_6  -1.0
    y_6         CONF_0_2_6  -1.0
    y_6         CONF_8_9_6  -1.0
    y_6         CONF_17_18_6  -1.0
    y_6         CONF_11_14_6  -1.0
    y_6         CONF_1_3_6  -1.0
    y_6         CONF_10_12_6  -1.0
    y_6         CONF_13_14_6  -1.0
    y_6         CONF_16_19_6  -1.0
    y_6         CONF_6_8_6  -1.0
    y_6         CONF_15_17_6  -1.0
    y_6         CONF_18_19_6  -1.0
    y_6         CONF_5_6_6  -1.0
    y_6         CONF_21_24_6  -1.0
    y_6         CONF_20_22_6  -1.0
    y_6         CONF_5_9_6  -1.0
    y_6         CONF_23_24_6  -1.0
    y_6         CONF_0_1_6  -1.0
    y_6         CONF_2_4_6  -1.0
    y_6         CONF_1_2_6  -1.0
    y_6         CONF_0_4_6  -1.0
    y_6         CONF_10_11_6  -1.0
    y_6         CONF_10_14_6  -1.0
    y_6         CONF_11_13_6  -1.0
    y_6         CONF_7_9_6  -1.0
    y_6         CONF_6_7_6  -1.0
    y_6         CONF_15_16_6  -1.0
    y_6         CONF_15_18_6  -1.0
    y_6         CONF_15_19_6  -1.0
    y_6         CONF_16_18_6  -1.0
    y_6         CONF_12_14_6  -1.0
    y_6         CONF_20_21_6  -1.0
    y_6         CONF_21_23_6  -1.0
    y_6         CONF_20_24_6  -1.0
    y_6         CONF_5_8_6  -1.0
    y_6         CONF_22_24_6  -1.0
    y_6         CONF_0_3_6  -1.0
    y_6         CONF_17_19_6  -1.0
    y_6         CONF_1_4_6  -1.0
    y_6         CONF_10_13_6  -1.0
    y_6         CONF_2_3_6  -1.0
    y_6         CONF_11_12_6  -1.0
    y_6         CONF_6_9_6  -1.0
    y_6         CONF_7_8_6  -1.0
    y_7         OBJ       1.0
    y_7         CAP_7  -200
    y_7         CONF_3_4_7  -1.0
    y_7         CONF_16_17_7  -1.0
    y_7         CONF_20_23_7  -1.0
    y_7         CONF_12_13_7  -1.0
    y_7         CONF_21_22_7  -1.0
    y_7         CONF_5_7_7  -1.0
    y_7         CONF_22_23_7  -1.0
    y_7         CONF_0_2_7  -1.0
    y_7         CONF_8_9_7  -1.0
    y_7         CONF_17_18_7  -1.0
    y_7         CONF_11_14_7  -1.0
    y_7         CONF_1_3_7  -1.0
    y_7         CONF_10_12_7  -1.0
    y_7         CONF_13_14_7  -1.0
    y_7         CONF_16_19_7  -1.0
    y_7         CONF_6_8_7  -1.0
    y_7         CONF_15_17_7  -1.0
    y_7         CONF_18_19_7  -1.0
    y_7         CONF_5_6_7  -1.0
    y_7         CONF_21_24_7  -1.0
    y_7         CONF_20_22_7  -1.0
    y_7         CONF_5_9_7  -1.0
    y_7         CONF_23_24_7  -1.0
    y_7         CONF_0_1_7  -1.0
    y_7         CONF_2_4_7  -1.0
    y_7         CONF_1_2_7  -1.0
    y_7         CONF_0_4_7  -1.0
    y_7         CONF_10_11_7  -1.0
    y_7         CONF_10_14_7  -1.0
    y_7         CONF_11_13_7  -1.0
    y_7         CONF_7_9_7  -1.0
    y_7         CONF_6_7_7  -1.0
    y_7         CONF_15_16_7  -1.0
    y_7         CONF_15_18_7  -1.0
    y_7         CONF_15_19_7  -1.0
    y_7         CONF_16_18_7  -1.0
    y_7         CONF_12_14_7  -1.0
    y_7         CONF_20_21_7  -1.0
    y_7         CONF_21_23_7  -1.0
    y_7         CONF_20_24_7  -1.0
    y_7         CONF_5_8_7  -1.0
    y_7         CONF_22_24_7  -1.0
    y_7         CONF_0_3_7  -1.0
    y_7         CONF_17_19_7  -1.0
    y_7         CONF_1_4_7  -1.0
    y_7         CONF_10_13_7  -1.0
    y_7         CONF_2_3_7  -1.0
    y_7         CONF_11_12_7  -1.0
    y_7         CONF_6_9_7  -1.0
    y_7         CONF_7_8_7  -1.0
    y_8         OBJ       1.0
    y_8         CAP_8  -200
    y_8         CONF_3_4_8  -1.0
    y_8         CONF_16_17_8  -1.0
    y_8         CONF_20_23_8  -1.0
    y_8         CONF_12_13_8  -1.0
    y_8         CONF_21_22_8  -1.0
    y_8         CONF_5_7_8  -1.0
    y_8         CONF_22_23_8  -1.0
    y_8         CONF_0_2_8  -1.0
    y_8         CONF_8_9_8  -1.0
    y_8         CONF_17_18_8  -1.0
    y_8         CONF_11_14_8  -1.0
    y_8         CONF_1_3_8  -1.0
    y_8         CONF_10_12_8  -1.0
    y_8         CONF_13_14_8  -1.0
    y_8         CONF_16_19_8  -1.0
    y_8         CONF_6_8_8  -1.0
    y_8         CONF_15_17_8  -1.0
    y_8         CONF_18_19_8  -1.0
    y_8         CONF_5_6_8  -1.0
    y_8         CONF_21_24_8  -1.0
    y_8         CONF_20_22_8  -1.0
    y_8         CONF_5_9_8  -1.0
    y_8         CONF_23_24_8  -1.0
    y_8         CONF_0_1_8  -1.0
    y_8         CONF_2_4_8  -1.0
    y_8         CONF_1_2_8  -1.0
    y_8         CONF_0_4_8  -1.0
    y_8         CONF_10_11_8  -1.0
    y_8         CONF_10_14_8  -1.0
    y_8         CONF_11_13_8  -1.0
    y_8         CONF_7_9_8  -1.0
    y_8         CONF_6_7_8  -1.0
    y_8         CONF_15_16_8  -1.0
    y_8         CONF_15_18_8  -1.0
    y_8         CONF_15_19_8  -1.0
    y_8         CONF_16_18_8  -1.0
    y_8         CONF_12_14_8  -1.0
    y_8         CONF_20_21_8  -1.0
    y_8         CONF_21_23_8  -1.0
    y_8         CONF_20_24_8  -1.0
    y_8         CONF_5_8_8  -1.0
    y_8         CONF_22_24_8  -1.0
    y_8         CONF_0_3_8  -1.0
    y_8         CONF_17_19_8  -1.0
    y_8         CONF_1_4_8  -1.0
    y_8         CONF_10_13_8  -1.0
    y_8         CONF_2_3_8  -1.0
    y_8         CONF_11_12_8  -1.0
    y_8         CONF_6_9_8  -1.0
    y_8         CONF_7_8_8  -1.0
    y_9         OBJ       1.0
    y_9         CAP_9  -200
    y_9         CONF_3_4_9  -1.0
    y_9         CONF_16_17_9  -1.0
    y_9         CONF_20_23_9  -1.0
    y_9         CONF_12_13_9  -1.0
    y_9         CONF_21_22_9  -1.0
    y_9         CONF_5_7_9  -1.0
    y_9         CONF_22_23_9  -1.0
    y_9         CONF_0_2_9  -1.0
    y_9         CONF_8_9_9  -1.0
    y_9         CONF_17_18_9  -1.0
    y_9         CONF_11_14_9  -1.0
    y_9         CONF_1_3_9  -1.0
    y_9         CONF_10_12_9  -1.0
    y_9         CONF_13_14_9  -1.0
    y_9         CONF_16_19_9  -1.0
    y_9         CONF_6_8_9  -1.0
    y_9         CONF_15_17_9  -1.0
    y_9         CONF_18_19_9  -1.0
    y_9         CONF_5_6_9  -1.0
    y_9         CONF_21_24_9  -1.0
    y_9         CONF_20_22_9  -1.0
    y_9         CONF_5_9_9  -1.0
    y_9         CONF_23_24_9  -1.0
    y_9         CONF_0_1_9  -1.0
    y_9         CONF_2_4_9  -1.0
    y_9         CONF_1_2_9  -1.0
    y_9         CONF_0_4_9  -1.0
    y_9         CONF_10_11_9  -1.0
    y_9         CONF_10_14_9  -1.0
    y_9         CONF_11_13_9  -1.0
    y_9         CONF_7_9_9  -1.0
    y_9         CONF_6_7_9  -1.0
    y_9         CONF_15_16_9  -1.0
    y_9         CONF_15_18_9  -1.0
    y_9         CONF_15_19_9  -1.0
    y_9         CONF_16_18_9  -1.0
    y_9         CONF_12_14_9  -1.0
    y_9         CONF_20_21_9  -1.0
    y_9         CONF_21_23_9  -1.0
    y_9         CONF_20_24_9  -1.0
    y_9         CONF_5_8_9  -1.0
    y_9         CONF_22_24_9  -1.0
    y_9         CONF_0_3_9  -1.0
    y_9         CONF_17_19_9  -1.0
    y_9         CONF_1_4_9  -1.0
    y_9         CONF_10_13_9  -1.0
    y_9         CONF_2_3_9  -1.0
    y_9         CONF_11_12_9  -1.0
    y_9         CONF_6_9_9  -1.0
    y_9         CONF_7_8_9  -1.0
    y_10        OBJ       1.0
    y_10        CAP_10  -200
    y_10        CONF_3_4_10  -1.0
    y_10        CONF_16_17_10  -1.0
    y_10        CONF_20_23_10  -1.0
    y_10        CONF_12_13_10  -1.0
    y_10        CONF_21_22_10  -1.0
    y_10        CONF_5_7_10  -1.0
    y_10        CONF_22_23_10  -1.0
    y_10        CONF_0_2_10  -1.0
    y_10        CONF_8_9_10  -1.0
    y_10        CONF_17_18_10  -1.0
    y_10        CONF_11_14_10  -1.0
    y_10        CONF_1_3_10  -1.0
    y_10        CONF_10_12_10  -1.0
    y_10        CONF_13_14_10  -1.0
    y_10        CONF_16_19_10  -1.0
    y_10        CONF_6_8_10  -1.0
    y_10        CONF_15_17_10  -1.0
    y_10        CONF_18_19_10  -1.0
    y_10        CONF_5_6_10  -1.0
    y_10        CONF_21_24_10  -1.0
    y_10        CONF_20_22_10  -1.0
    y_10        CONF_5_9_10  -1.0
    y_10        CONF_23_24_10  -1.0
    y_10        CONF_0_1_10  -1.0
    y_10        CONF_2_4_10  -1.0
    y_10        CONF_1_2_10  -1.0
    y_10        CONF_0_4_10  -1.0
    y_10        CONF_10_11_10  -1.0
    y_10        CONF_10_14_10  -1.0
    y_10        CONF_11_13_10  -1.0
    y_10        CONF_7_9_10  -1.0
    y_10        CONF_6_7_10  -1.0
    y_10        CONF_15_16_10  -1.0
    y_10        CONF_15_18_10  -1.0
    y_10        CONF_15_19_10  -1.0
    y_10        CONF_16_18_10  -1.0
    y_10        CONF_12_14_10  -1.0
    y_10        CONF_20_21_10  -1.0
    y_10        CONF_21_23_10  -1.0
    y_10        CONF_20_24_10  -1.0
    y_10        CONF_5_8_10  -1.0
    y_10        CONF_22_24_10  -1.0
    y_10        CONF_0_3_10  -1.0
    y_10        CONF_17_19_10  -1.0
    y_10        CONF_1_4_10  -1.0
    y_10        CONF_10_13_10  -1.0
    y_10        CONF_2_3_10  -1.0
    y_10        CONF_11_12_10  -1.0
    y_10        CONF_6_9_10  -1.0
    y_10        CONF_7_8_10  -1.0
    y_11        OBJ       1.0
    y_11        CAP_11  -200
    y_11        CONF_3_4_11  -1.0
    y_11        CONF_16_17_11  -1.0
    y_11        CONF_20_23_11  -1.0
    y_11        CONF_12_13_11  -1.0
    y_11        CONF_21_22_11  -1.0
    y_11        CONF_5_7_11  -1.0
    y_11        CONF_22_23_11  -1.0
    y_11        CONF_0_2_11  -1.0
    y_11        CONF_8_9_11  -1.0
    y_11        CONF_17_18_11  -1.0
    y_11        CONF_11_14_11  -1.0
    y_11        CONF_1_3_11  -1.0
    y_11        CONF_10_12_11  -1.0
    y_11        CONF_13_14_11  -1.0
    y_11        CONF_16_19_11  -1.0
    y_11        CONF_6_8_11  -1.0
    y_11        CONF_15_17_11  -1.0
    y_11        CONF_18_19_11  -1.0
    y_11        CONF_5_6_11  -1.0
    y_11        CONF_21_24_11  -1.0
    y_11        CONF_20_22_11  -1.0
    y_11        CONF_5_9_11  -1.0
    y_11        CONF_23_24_11  -1.0
    y_11        CONF_0_1_11  -1.0
    y_11        CONF_2_4_11  -1.0
    y_11        CONF_1_2_11  -1.0
    y_11        CONF_0_4_11  -1.0
    y_11        CONF_10_11_11  -1.0
    y_11        CONF_10_14_11  -1.0
    y_11        CONF_11_13_11  -1.0
    y_11        CONF_7_9_11  -1.0
    y_11        CONF_6_7_11  -1.0
    y_11        CONF_15_16_11  -1.0
    y_11        CONF_15_18_11  -1.0
    y_11        CONF_15_19_11  -1.0
    y_11        CONF_16_18_11  -1.0
    y_11        CONF_12_14_11  -1.0
    y_11        CONF_20_21_11  -1.0
    y_11        CONF_21_23_11  -1.0
    y_11        CONF_20_24_11  -1.0
    y_11        CONF_5_8_11  -1.0
    y_11        CONF_22_24_11  -1.0
    y_11        CONF_0_3_11  -1.0
    y_11        CONF_17_19_11  -1.0
    y_11        CONF_1_4_11  -1.0
    y_11        CONF_10_13_11  -1.0
    y_11        CONF_2_3_11  -1.0
    y_11        CONF_11_12_11  -1.0
    y_11        CONF_6_9_11  -1.0
    y_11        CONF_7_8_11  -1.0
    y_12        OBJ       1.0
    y_12        CAP_12  -200
    y_12        CONF_3_4_12  -1.0
    y_12        CONF_16_17_12  -1.0
    y_12        CONF_20_23_12  -1.0
    y_12        CONF_12_13_12  -1.0
    y_12        CONF_21_22_12  -1.0
    y_12        CONF_5_7_12  -1.0
    y_12        CONF_22_23_12  -1.0
    y_12        CONF_0_2_12  -1.0
    y_12        CONF_8_9_12  -1.0
    y_12        CONF_17_18_12  -1.0
    y_12        CONF_11_14_12  -1.0
    y_12        CONF_1_3_12  -1.0
    y_12        CONF_10_12_12  -1.0
    y_12        CONF_13_14_12  -1.0
    y_12        CONF_16_19_12  -1.0
    y_12        CONF_6_8_12  -1.0
    y_12        CONF_15_17_12  -1.0
    y_12        CONF_18_19_12  -1.0
    y_12        CONF_5_6_12  -1.0
    y_12        CONF_21_24_12  -1.0
    y_12        CONF_20_22_12  -1.0
    y_12        CONF_5_9_12  -1.0
    y_12        CONF_23_24_12  -1.0
    y_12        CONF_0_1_12  -1.0
    y_12        CONF_2_4_12  -1.0
    y_12        CONF_1_2_12  -1.0
    y_12        CONF_0_4_12  -1.0
    y_12        CONF_10_11_12  -1.0
    y_12        CONF_10_14_12  -1.0
    y_12        CONF_11_13_12  -1.0
    y_12        CONF_7_9_12  -1.0
    y_12        CONF_6_7_12  -1.0
    y_12        CONF_15_16_12  -1.0
    y_12        CONF_15_18_12  -1.0
    y_12        CONF_15_19_12  -1.0
    y_12        CONF_16_18_12  -1.0
    y_12        CONF_12_14_12  -1.0
    y_12        CONF_20_21_12  -1.0
    y_12        CONF_21_23_12  -1.0
    y_12        CONF_20_24_12  -1.0
    y_12        CONF_5_8_12  -1.0
    y_12        CONF_22_24_12  -1.0
    y_12        CONF_0_3_12  -1.0
    y_12        CONF_17_19_12  -1.0
    y_12        CONF_1_4_12  -1.0
    y_12        CONF_10_13_12  -1.0
    y_12        CONF_2_3_12  -1.0
    y_12        CONF_11_12_12  -1.0
    y_12        CONF_6_9_12  -1.0
    y_12        CONF_7_8_12  -1.0
    y_13        OBJ       1.0
    y_13        CAP_13  -200
    y_13        CONF_3_4_13  -1.0
    y_13        CONF_16_17_13  -1.0
    y_13        CONF_20_23_13  -1.0
    y_13        CONF_12_13_13  -1.0
    y_13        CONF_21_22_13  -1.0
    y_13        CONF_5_7_13  -1.0
    y_13        CONF_22_23_13  -1.0
    y_13        CONF_0_2_13  -1.0
    y_13        CONF_8_9_13  -1.0
    y_13        CONF_17_18_13  -1.0
    y_13        CONF_11_14_13  -1.0
    y_13        CONF_1_3_13  -1.0
    y_13        CONF_10_12_13  -1.0
    y_13        CONF_13_14_13  -1.0
    y_13        CONF_16_19_13  -1.0
    y_13        CONF_6_8_13  -1.0
    y_13        CONF_15_17_13  -1.0
    y_13        CONF_18_19_13  -1.0
    y_13        CONF_5_6_13  -1.0
    y_13        CONF_21_24_13  -1.0
    y_13        CONF_20_22_13  -1.0
    y_13        CONF_5_9_13  -1.0
    y_13        CONF_23_24_13  -1.0
    y_13        CONF_0_1_13  -1.0
    y_13        CONF_2_4_13  -1.0
    y_13        CONF_1_2_13  -1.0
    y_13        CONF_0_4_13  -1.0
    y_13        CONF_10_11_13  -1.0
    y_13        CONF_10_14_13  -1.0
    y_13        CONF_11_13_13  -1.0
    y_13        CONF_7_9_13  -1.0
    y_13        CONF_6_7_13  -1.0
    y_13        CONF_15_16_13  -1.0
    y_13        CONF_15_18_13  -1.0
    y_13        CONF_15_19_13  -1.0
    y_13        CONF_16_18_13  -1.0
    y_13        CONF_12_14_13  -1.0
    y_13        CONF_20_21_13  -1.0
    y_13        CONF_21_23_13  -1.0
    y_13        CONF_20_24_13  -1.0
    y_13        CONF_5_8_13  -1.0
    y_13        CONF_22_24_13  -1.0
    y_13        CONF_0_3_13  -1.0
    y_13        CONF_17_19_13  -1.0
    y_13        CONF_1_4_13  -1.0
    y_13        CONF_10_13_13  -1.0
    y_13        CONF_2_3_13  -1.0
    y_13        CONF_11_12_13  -1.0
    y_13        CONF_6_9_13  -1.0
    y_13        CONF_7_8_13  -1.0
    y_14        OBJ       1.0
    y_14        CAP_14  -200
    y_14        CONF_3_4_14  -1.0
    y_14        CONF_16_17_14  -1.0
    y_14        CONF_20_23_14  -1.0
    y_14        CONF_12_13_14  -1.0
    y_14        CONF_21_22_14  -1.0
    y_14        CONF_5_7_14  -1.0
    y_14        CONF_22_23_14  -1.0
    y_14        CONF_0_2_14  -1.0
    y_14        CONF_8_9_14  -1.0
    y_14        CONF_17_18_14  -1.0
    y_14        CONF_11_14_14  -1.0
    y_14        CONF_1_3_14  -1.0
    y_14        CONF_10_12_14  -1.0
    y_14        CONF_13_14_14  -1.0
    y_14        CONF_16_19_14  -1.0
    y_14        CONF_6_8_14  -1.0
    y_14        CONF_15_17_14  -1.0
    y_14        CONF_18_19_14  -1.0
    y_14        CONF_5_6_14  -1.0
    y_14        CONF_21_24_14  -1.0
    y_14        CONF_20_22_14  -1.0
    y_14        CONF_5_9_14  -1.0
    y_14        CONF_23_24_14  -1.0
    y_14        CONF_0_1_14  -1.0
    y_14        CONF_2_4_14  -1.0
    y_14        CONF_1_2_14  -1.0
    y_14        CONF_0_4_14  -1.0
    y_14        CONF_10_11_14  -1.0
    y_14        CONF_10_14_14  -1.0
    y_14        CONF_11_13_14  -1.0
    y_14        CONF_7_9_14  -1.0
    y_14        CONF_6_7_14  -1.0
    y_14        CONF_15_16_14  -1.0
    y_14        CONF_15_18_14  -1.0
    y_14        CONF_15_19_14  -1.0
    y_14        CONF_16_18_14  -1.0
    y_14        CONF_12_14_14  -1.0
    y_14        CONF_20_21_14  -1.0
    y_14        CONF_21_23_14  -1.0
    y_14        CONF_20_24_14  -1.0
    y_14        CONF_5_8_14  -1.0
    y_14        CONF_22_24_14  -1.0
    y_14        CONF_0_3_14  -1.0
    y_14        CONF_17_19_14  -1.0
    y_14        CONF_1_4_14  -1.0
    y_14        CONF_10_13_14  -1.0
    y_14        CONF_2_3_14  -1.0
    y_14        CONF_11_12_14  -1.0
    y_14        CONF_6_9_14  -1.0
    y_14        CONF_7_8_14  -1.0
    y_15        OBJ       1.0
    y_15        CAP_15  -200
    y_15        CONF_3_4_15  -1.0
    y_15        CONF_16_17_15  -1.0
    y_15        CONF_20_23_15  -1.0
    y_15        CONF_12_13_15  -1.0
    y_15        CONF_21_22_15  -1.0
    y_15        CONF_5_7_15  -1.0
    y_15        CONF_22_23_15  -1.0
    y_15        CONF_0_2_15  -1.0
    y_15        CONF_8_9_15  -1.0
    y_15        CONF_17_18_15  -1.0
    y_15        CONF_11_14_15  -1.0
    y_15        CONF_1_3_15  -1.0
    y_15        CONF_10_12_15  -1.0
    y_15        CONF_13_14_15  -1.0
    y_15        CONF_16_19_15  -1.0
    y_15        CONF_6_8_15  -1.0
    y_15        CONF_15_17_15  -1.0
    y_15        CONF_18_19_15  -1.0
    y_15        CONF_5_6_15  -1.0
    y_15        CONF_21_24_15  -1.0
    y_15        CONF_20_22_15  -1.0
    y_15        CONF_5_9_15  -1.0
    y_15        CONF_23_24_15  -1.0
    y_15        CONF_0_1_15  -1.0
    y_15        CONF_2_4_15  -1.0
    y_15        CONF_1_2_15  -1.0
    y_15        CONF_0_4_15  -1.0
    y_15        CONF_10_11_15  -1.0
    y_15        CONF_10_14_15  -1.0
    y_15        CONF_11_13_15  -1.0
    y_15        CONF_7_9_15  -1.0
    y_15        CONF_6_7_15  -1.0
    y_15        CONF_15_16_15  -1.0
    y_15        CONF_15_18_15  -1.0
    y_15        CONF_15_19_15  -1.0
    y_15        CONF_16_18_15  -1.0
    y_15        CONF_12_14_15  -1.0
    y_15        CONF_20_21_15  -1.0
    y_15        CONF_21_23_15  -1.0
    y_15        CONF_20_24_15  -1.0
    y_15        CONF_5_8_15  -1.0
    y_15        CONF_22_24_15  -1.0
    y_15        CONF_0_3_15  -1.0
    y_15        CONF_17_19_15  -1.0
    y_15        CONF_1_4_15  -1.0
    y_15        CONF_10_13_15  -1.0
    y_15        CONF_2_3_15  -1.0
    y_15        CONF_11_12_15  -1.0
    y_15        CONF_6_9_15  -1.0
    y_15        CONF_7_8_15  -1.0
    y_16        OBJ       1.0
    y_16        CAP_16  -200
    y_16        CONF_3_4_16  -1.0
    y_16        CONF_16_17_16  -1.0
    y_16        CONF_20_23_16  -1.0
    y_16        CONF_12_13_16  -1.0
    y_16        CONF_21_22_16  -1.0
    y_16        CONF_5_7_16  -1.0
    y_16        CONF_22_23_16  -1.0
    y_16        CONF_0_2_16  -1.0
    y_16        CONF_8_9_16  -1.0
    y_16        CONF_17_18_16  -1.0
    y_16        CONF_11_14_16  -1.0
    y_16        CONF_1_3_16  -1.0
    y_16        CONF_10_12_16  -1.0
    y_16        CONF_13_14_16  -1.0
    y_16        CONF_16_19_16  -1.0
    y_16        CONF_6_8_16  -1.0
    y_16        CONF_15_17_16  -1.0
    y_16        CONF_18_19_16  -1.0
    y_16        CONF_5_6_16  -1.0
    y_16        CONF_21_24_16  -1.0
    y_16        CONF_20_22_16  -1.0
    y_16        CONF_5_9_16  -1.0
    y_16        CONF_23_24_16  -1.0
    y_16        CONF_0_1_16  -1.0
    y_16        CONF_2_4_16  -1.0
    y_16        CONF_1_2_16  -1.0
    y_16        CONF_0_4_16  -1.0
    y_16        CONF_10_11_16  -1.0
    y_16        CONF_10_14_16  -1.0
    y_16        CONF_11_13_16  -1.0
    y_16        CONF_7_9_16  -1.0
    y_16        CONF_6_7_16  -1.0
    y_16        CONF_15_16_16  -1.0
    y_16        CONF_15_18_16  -1.0
    y_16        CONF_15_19_16  -1.0
    y_16        CONF_16_18_16  -1.0
    y_16        CONF_12_14_16  -1.0
    y_16        CONF_20_21_16  -1.0
    y_16        CONF_21_23_16  -1.0
    y_16        CONF_20_24_16  -1.0
    y_16        CONF_5_8_16  -1.0
    y_16        CONF_22_24_16  -1.0
    y_16        CONF_0_3_16  -1.0
    y_16        CONF_17_19_16  -1.0
    y_16        CONF_1_4_16  -1.0
    y_16        CONF_10_13_16  -1.0
    y_16        CONF_2_3_16  -1.0
    y_16        CONF_11_12_16  -1.0
    y_16        CONF_6_9_16  -1.0
    y_16        CONF_7_8_16  -1.0
    y_17        OBJ       1.0
    y_17        CAP_17  -200
    y_17        CONF_3_4_17  -1.0
    y_17        CONF_16_17_17  -1.0
    y_17        CONF_20_23_17  -1.0
    y_17        CONF_12_13_17  -1.0
    y_17        CONF_21_22_17  -1.0
    y_17        CONF_5_7_17  -1.0
    y_17        CONF_22_23_17  -1.0
    y_17        CONF_0_2_17  -1.0
    y_17        CONF_8_9_17  -1.0
    y_17        CONF_17_18_17  -1.0
    y_17        CONF_11_14_17  -1.0
    y_17        CONF_1_3_17  -1.0
    y_17        CONF_10_12_17  -1.0
    y_17        CONF_13_14_17  -1.0
    y_17        CONF_16_19_17  -1.0
    y_17        CONF_6_8_17  -1.0
    y_17        CONF_15_17_17  -1.0
    y_17        CONF_18_19_17  -1.0
    y_17        CONF_5_6_17  -1.0
    y_17        CONF_21_24_17  -1.0
    y_17        CONF_20_22_17  -1.0
    y_17        CONF_5_9_17  -1.0
    y_17        CONF_23_24_17  -1.0
    y_17        CONF_0_1_17  -1.0
    y_17        CONF_2_4_17  -1.0
    y_17        CONF_1_2_17  -1.0
    y_17        CONF_0_4_17  -1.0
    y_17        CONF_10_11_17  -1.0
    y_17        CONF_10_14_17  -1.0
    y_17        CONF_11_13_17  -1.0
    y_17        CONF_7_9_17  -1.0
    y_17        CONF_6_7_17  -1.0
    y_17        CONF_15_16_17  -1.0
    y_17        CONF_15_18_17  -1.0
    y_17        CONF_15_19_17  -1.0
    y_17        CONF_16_18_17  -1.0
    y_17        CONF_12_14_17  -1.0
    y_17        CONF_20_21_17  -1.0
    y_17        CONF_21_23_17  -1.0
    y_17        CONF_20_24_17  -1.0
    y_17        CONF_5_8_17  -1.0
    y_17        CONF_22_24_17  -1.0
    y_17        CONF_0_3_17  -1.0
    y_17        CONF_17_19_17  -1.0
    y_17        CONF_1_4_17  -1.0
    y_17        CONF_10_13_17  -1.0
    y_17        CONF_2_3_17  -1.0
    y_17        CONF_11_12_17  -1.0
    y_17        CONF_6_9_17  -1.0
    y_17        CONF_7_8_17  -1.0
    y_18        OBJ       1.0
    y_18        CAP_18  -200
    y_18        CONF_3_4_18  -1.0
    y_18        CONF_16_17_18  -1.0
    y_18        CONF_20_23_18  -1.0
    y_18        CONF_12_13_18  -1.0
    y_18        CONF_21_22_18  -1.0
    y_18        CONF_5_7_18  -1.0
    y_18        CONF_22_23_18  -1.0
    y_18        CONF_0_2_18  -1.0
    y_18        CONF_8_9_18  -1.0
    y_18        CONF_17_18_18  -1.0
    y_18        CONF_11_14_18  -1.0
    y_18        CONF_1_3_18  -1.0
    y_18        CONF_10_12_18  -1.0
    y_18        CONF_13_14_18  -1.0
    y_18        CONF_16_19_18  -1.0
    y_18        CONF_6_8_18  -1.0
    y_18        CONF_15_17_18  -1.0
    y_18        CONF_18_19_18  -1.0
    y_18        CONF_5_6_18  -1.0
    y_18        CONF_21_24_18  -1.0
    y_18        CONF_20_22_18  -1.0
    y_18        CONF_5_9_18  -1.0
    y_18        CONF_23_24_18  -1.0
    y_18        CONF_0_1_18  -1.0
    y_18        CONF_2_4_18  -1.0
    y_18        CONF_1_2_18  -1.0
    y_18        CONF_0_4_18  -1.0
    y_18        CONF_10_11_18  -1.0
    y_18        CONF_10_14_18  -1.0
    y_18        CONF_11_13_18  -1.0
    y_18        CONF_7_9_18  -1.0
    y_18        CONF_6_7_18  -1.0
    y_18        CONF_15_16_18  -1.0
    y_18        CONF_15_18_18  -1.0
    y_18        CONF_15_19_18  -1.0
    y_18        CONF_16_18_18  -1.0
    y_18        CONF_12_14_18  -1.0
    y_18        CONF_20_21_18  -1.0
    y_18        CONF_21_23_18  -1.0
    y_18        CONF_20_24_18  -1.0
    y_18        CONF_5_8_18  -1.0
    y_18        CONF_22_24_18  -1.0
    y_18        CONF_0_3_18  -1.0
    y_18        CONF_17_19_18  -1.0
    y_18        CONF_1_4_18  -1.0
    y_18        CONF_10_13_18  -1.0
    y_18        CONF_2_3_18  -1.0
    y_18        CONF_11_12_18  -1.0
    y_18        CONF_6_9_18  -1.0
    y_18        CONF_7_8_18  -1.0
    y_19        OBJ       1.0
    y_19        CAP_19  -200
    y_19        CONF_3_4_19  -1.0
    y_19        CONF_16_17_19  -1.0
    y_19        CONF_20_23_19  -1.0
    y_19        CONF_12_13_19  -1.0
    y_19        CONF_21_22_19  -1.0
    y_19        CONF_5_7_19  -1.0
    y_19        CONF_22_23_19  -1.0
    y_19        CONF_0_2_19  -1.0
    y_19        CONF_8_9_19  -1.0
    y_19        CONF_17_18_19  -1.0
    y_19        CONF_11_14_19  -1.0
    y_19        CONF_1_3_19  -1.0
    y_19        CONF_10_12_19  -1.0
    y_19        CONF_13_14_19  -1.0
    y_19        CONF_16_19_19  -1.0
    y_19        CONF_6_8_19  -1.0
    y_19        CONF_15_17_19  -1.0
    y_19        CONF_18_19_19  -1.0
    y_19        CONF_5_6_19  -1.0
    y_19        CONF_21_24_19  -1.0
    y_19        CONF_20_22_19  -1.0
    y_19        CONF_5_9_19  -1.0
    y_19        CONF_23_24_19  -1.0
    y_19        CONF_0_1_19  -1.0
    y_19        CONF_2_4_19  -1.0
    y_19        CONF_1_2_19  -1.0
    y_19        CONF_0_4_19  -1.0
    y_19        CONF_10_11_19  -1.0
    y_19        CONF_10_14_19  -1.0
    y_19        CONF_11_13_19  -1.0
    y_19        CONF_7_9_19  -1.0
    y_19        CONF_6_7_19  -1.0
    y_19        CONF_15_16_19  -1.0
    y_19        CONF_15_18_19  -1.0
    y_19        CONF_15_19_19  -1.0
    y_19        CONF_16_18_19  -1.0
    y_19        CONF_12_14_19  -1.0
    y_19        CONF_20_21_19  -1.0
    y_19        CONF_21_23_19  -1.0
    y_19        CONF_20_24_19  -1.0
    y_19        CONF_5_8_19  -1.0
    y_19        CONF_22_24_19  -1.0
    y_19        CONF_0_3_19  -1.0
    y_19        CONF_17_19_19  -1.0
    y_19        CONF_1_4_19  -1.0
    y_19        CONF_10_13_19  -1.0
    y_19        CONF_2_3_19  -1.0
    y_19        CONF_11_12_19  -1.0
    y_19        CONF_6_9_19  -1.0
    y_19        CONF_7_8_19  -1.0
    y_20        OBJ       1.0
    y_20        CAP_20  -200
    y_20        CONF_3_4_20  -1.0
    y_20        CONF_16_17_20  -1.0
    y_20        CONF_20_23_20  -1.0
    y_20        CONF_12_13_20  -1.0
    y_20        CONF_21_22_20  -1.0
    y_20        CONF_5_7_20  -1.0
    y_20        CONF_22_23_20  -1.0
    y_20        CONF_0_2_20  -1.0
    y_20        CONF_8_9_20  -1.0
    y_20        CONF_17_18_20  -1.0
    y_20        CONF_11_14_20  -1.0
    y_20        CONF_1_3_20  -1.0
    y_20        CONF_10_12_20  -1.0
    y_20        CONF_13_14_20  -1.0
    y_20        CONF_16_19_20  -1.0
    y_20        CONF_6_8_20  -1.0
    y_20        CONF_15_17_20  -1.0
    y_20        CONF_18_19_20  -1.0
    y_20        CONF_5_6_20  -1.0
    y_20        CONF_21_24_20  -1.0
    y_20        CONF_20_22_20  -1.0
    y_20        CONF_5_9_20  -1.0
    y_20        CONF_23_24_20  -1.0
    y_20        CONF_0_1_20  -1.0
    y_20        CONF_2_4_20  -1.0
    y_20        CONF_1_2_20  -1.0
    y_20        CONF_0_4_20  -1.0
    y_20        CONF_10_11_20  -1.0
    y_20        CONF_10_14_20  -1.0
    y_20        CONF_11_13_20  -1.0
    y_20        CONF_7_9_20  -1.0
    y_20        CONF_6_7_20  -1.0
    y_20        CONF_15_16_20  -1.0
    y_20        CONF_15_18_20  -1.0
    y_20        CONF_15_19_20  -1.0
    y_20        CONF_16_18_20  -1.0
    y_20        CONF_12_14_20  -1.0
    y_20        CONF_20_21_20  -1.0
    y_20        CONF_21_23_20  -1.0
    y_20        CONF_20_24_20  -1.0
    y_20        CONF_5_8_20  -1.0
    y_20        CONF_22_24_20  -1.0
    y_20        CONF_0_3_20  -1.0
    y_20        CONF_17_19_20  -1.0
    y_20        CONF_1_4_20  -1.0
    y_20        CONF_10_13_20  -1.0
    y_20        CONF_2_3_20  -1.0
    y_20        CONF_11_12_20  -1.0
    y_20        CONF_6_9_20  -1.0
    y_20        CONF_7_8_20  -1.0
    y_21        OBJ       1.0
    y_21        CAP_21  -200
    y_21        CONF_3_4_21  -1.0
    y_21        CONF_16_17_21  -1.0
    y_21        CONF_20_23_21  -1.0
    y_21        CONF_12_13_21  -1.0
    y_21        CONF_21_22_21  -1.0
    y_21        CONF_5_7_21  -1.0
    y_21        CONF_22_23_21  -1.0
    y_21        CONF_0_2_21  -1.0
    y_21        CONF_8_9_21  -1.0
    y_21        CONF_17_18_21  -1.0
    y_21        CONF_11_14_21  -1.0
    y_21        CONF_1_3_21  -1.0
    y_21        CONF_10_12_21  -1.0
    y_21        CONF_13_14_21  -1.0
    y_21        CONF_16_19_21  -1.0
    y_21        CONF_6_8_21  -1.0
    y_21        CONF_15_17_21  -1.0
    y_21        CONF_18_19_21  -1.0
    y_21        CONF_5_6_21  -1.0
    y_21        CONF_21_24_21  -1.0
    y_21        CONF_20_22_21  -1.0
    y_21        CONF_5_9_21  -1.0
    y_21        CONF_23_24_21  -1.0
    y_21        CONF_0_1_21  -1.0
    y_21        CONF_2_4_21  -1.0
    y_21        CONF_1_2_21  -1.0
    y_21        CONF_0_4_21  -1.0
    y_21        CONF_10_11_21  -1.0
    y_21        CONF_10_14_21  -1.0
    y_21        CONF_11_13_21  -1.0
    y_21        CONF_7_9_21  -1.0
    y_21        CONF_6_7_21  -1.0
    y_21        CONF_15_16_21  -1.0
    y_21        CONF_15_18_21  -1.0
    y_21        CONF_15_19_21  -1.0
    y_21        CONF_16_18_21  -1.0
    y_21        CONF_12_14_21  -1.0
    y_21        CONF_20_21_21  -1.0
    y_21        CONF_21_23_21  -1.0
    y_21        CONF_20_24_21  -1.0
    y_21        CONF_5_8_21  -1.0
    y_21        CONF_22_24_21  -1.0
    y_21        CONF_0_3_21  -1.0
    y_21        CONF_17_19_21  -1.0
    y_21        CONF_1_4_21  -1.0
    y_21        CONF_10_13_21  -1.0
    y_21        CONF_2_3_21  -1.0
    y_21        CONF_11_12_21  -1.0
    y_21        CONF_6_9_21  -1.0
    y_21        CONF_7_8_21  -1.0
    y_22        OBJ       1.0
    y_22        CAP_22  -200
    y_22        CONF_3_4_22  -1.0
    y_22        CONF_16_17_22  -1.0
    y_22        CONF_20_23_22  -1.0
    y_22        CONF_12_13_22  -1.0
    y_22        CONF_21_22_22  -1.0
    y_22        CONF_5_7_22  -1.0
    y_22        CONF_22_23_22  -1.0
    y_22        CONF_0_2_22  -1.0
    y_22        CONF_8_9_22  -1.0
    y_22        CONF_17_18_22  -1.0
    y_22        CONF_11_14_22  -1.0
    y_22        CONF_1_3_22  -1.0
    y_22        CONF_10_12_22  -1.0
    y_22        CONF_13_14_22  -1.0
    y_22        CONF_16_19_22  -1.0
    y_22        CONF_6_8_22  -1.0
    y_22        CONF_15_17_22  -1.0
    y_22        CONF_18_19_22  -1.0
    y_22        CONF_5_6_22  -1.0
    y_22        CONF_21_24_22  -1.0
    y_22        CONF_20_22_22  -1.0
    y_22        CONF_5_9_22  -1.0
    y_22        CONF_23_24_22  -1.0
    y_22        CONF_0_1_22  -1.0
    y_22        CONF_2_4_22  -1.0
    y_22        CONF_1_2_22  -1.0
    y_22        CONF_0_4_22  -1.0
    y_22        CONF_10_11_22  -1.0
    y_22        CONF_10_14_22  -1.0
    y_22        CONF_11_13_22  -1.0
    y_22        CONF_7_9_22  -1.0
    y_22        CONF_6_7_22  -1.0
    y_22        CONF_15_16_22  -1.0
    y_22        CONF_15_18_22  -1.0
    y_22        CONF_15_19_22  -1.0
    y_22        CONF_16_18_22  -1.0
    y_22        CONF_12_14_22  -1.0
    y_22        CONF_20_21_22  -1.0
    y_22        CONF_21_23_22  -1.0
    y_22        CONF_20_24_22  -1.0
    y_22        CONF_5_8_22  -1.0
    y_22        CONF_22_24_22  -1.0
    y_22        CONF_0_3_22  -1.0
    y_22        CONF_17_19_22  -1.0
    y_22        CONF_1_4_22  -1.0
    y_22        CONF_10_13_22  -1.0
    y_22        CONF_2_3_22  -1.0
    y_22        CONF_11_12_22  -1.0
    y_22        CONF_6_9_22  -1.0
    y_22        CONF_7_8_22  -1.0
    y_23        OBJ       1.0
    y_23        CAP_23  -200
    y_23        CONF_3_4_23  -1.0
    y_23        CONF_16_17_23  -1.0
    y_23        CONF_20_23_23  -1.0
    y_23        CONF_12_13_23  -1.0
    y_23        CONF_21_22_23  -1.0
    y_23        CONF_5_7_23  -1.0
    y_23        CONF_22_23_23  -1.0
    y_23        CONF_0_2_23  -1.0
    y_23        CONF_8_9_23  -1.0
    y_23        CONF_17_18_23  -1.0
    y_23        CONF_11_14_23  -1.0
    y_23        CONF_1_3_23  -1.0
    y_23        CONF_10_12_23  -1.0
    y_23        CONF_13_14_23  -1.0
    y_23        CONF_16_19_23  -1.0
    y_23        CONF_6_8_23  -1.0
    y_23        CONF_15_17_23  -1.0
    y_23        CONF_18_19_23  -1.0
    y_23        CONF_5_6_23  -1.0
    y_23        CONF_21_24_23  -1.0
    y_23        CONF_20_22_23  -1.0
    y_23        CONF_5_9_23  -1.0
    y_23        CONF_23_24_23  -1.0
    y_23        CONF_0_1_23  -1.0
    y_23        CONF_2_4_23  -1.0
    y_23        CONF_1_2_23  -1.0
    y_23        CONF_0_4_23  -1.0
    y_23        CONF_10_11_23  -1.0
    y_23        CONF_10_14_23  -1.0
    y_23        CONF_11_13_23  -1.0
    y_23        CONF_7_9_23  -1.0
    y_23        CONF_6_7_23  -1.0
    y_23        CONF_15_16_23  -1.0
    y_23        CONF_15_18_23  -1.0
    y_23        CONF_15_19_23  -1.0
    y_23        CONF_16_18_23  -1.0
    y_23        CONF_12_14_23  -1.0
    y_23        CONF_20_21_23  -1.0
    y_23        CONF_21_23_23  -1.0
    y_23        CONF_20_24_23  -1.0
    y_23        CONF_5_8_23  -1.0
    y_23        CONF_22_24_23  -1.0
    y_23        CONF_0_3_23  -1.0
    y_23        CONF_17_19_23  -1.0
    y_23        CONF_1_4_23  -1.0
    y_23        CONF_10_13_23  -1.0
    y_23        CONF_2_3_23  -1.0
    y_23        CONF_11_12_23  -1.0
    y_23        CONF_6_9_23  -1.0
    y_23        CONF_7_8_23  -1.0
    y_24        OBJ       1.0
    y_24        CAP_24  -200
    y_24        CONF_3_4_24  -1.0
    y_24        CONF_16_17_24  -1.0
    y_24        CONF_20_23_24  -1.0
    y_24        CONF_12_13_24  -1.0
    y_24        CONF_21_22_24  -1.0
    y_24        CONF_5_7_24  -1.0
    y_24        CONF_22_23_24  -1.0
    y_24        CONF_0_2_24  -1.0
    y_24        CONF_8_9_24  -1.0
    y_24        CONF_17_18_24  -1.0
    y_24        CONF_11_14_24  -1.0
    y_24        CONF_1_3_24  -1.0
    y_24        CONF_10_12_24  -1.0
    y_24        CONF_13_14_24  -1.0
    y_24        CONF_16_19_24  -1.0
    y_24        CONF_6_8_24  -1.0
    y_24        CONF_15_17_24  -1.0
    y_24        CONF_18_19_24  -1.0
    y_24        CONF_5_6_24  -1.0
    y_24        CONF_21_24_24  -1.0
    y_24        CONF_20_22_24  -1.0
    y_24        CONF_5_9_24  -1.0
    y_24        CONF_23_24_24  -1.0
    y_24        CONF_0_1_24  -1.0
    y_24        CONF_2_4_24  -1.0
    y_24        CONF_1_2_24  -1.0
    y_24        CONF_0_4_24  -1.0
    y_24        CONF_10_11_24  -1.0
    y_24        CONF_10_14_24  -1.0
    y_24        CONF_11_13_24  -1.0
    y_24        CONF_7_9_24  -1.0
    y_24        CONF_6_7_24  -1.0
    y_24        CONF_15_16_24  -1.0
    y_24        CONF_15_18_24  -1.0
    y_24        CONF_15_19_24  -1.0
    y_24        CONF_16_18_24  -1.0
    y_24        CONF_12_14_24  -1.0
    y_24        CONF_20_21_24  -1.0
    y_24        CONF_21_23_24  -1.0
    y_24        CONF_20_24_24  -1.0
    y_24        CONF_5_8_24  -1.0
    y_24        CONF_22_24_24  -1.0
    y_24        CONF_0_3_24  -1.0
    y_24        CONF_17_19_24  -1.0
    y_24        CONF_1_4_24  -1.0
    y_24        CONF_10_13_24  -1.0
    y_24        CONF_2_3_24  -1.0
    y_24        CONF_11_12_24  -1.0
    y_24        CONF_6_9_24  -1.0
    y_24        CONF_7_8_24  -1.0
RHS
    RHS1      ASSIGN_0  1.0
    RHS1      ASSIGN_1  1.0
    RHS1      ASSIGN_2  1.0
    RHS1      ASSIGN_3  1.0
    RHS1      ASSIGN_4  1.0
    RHS1      ASSIGN_5  1.0
    RHS1      ASSIGN_6  1.0
    RHS1      ASSIGN_7  1.0
    RHS1      ASSIGN_8  1.0
    RHS1      ASSIGN_9  1.0
    RHS1      ASSIGN_10  1.0
    RHS1      ASSIGN_11  1.0
    RHS1      ASSIGN_12  1.0
    RHS1      ASSIGN_13  1.0
    RHS1      ASSIGN_14  1.0
    RHS1      ASSIGN_15  1.0
    RHS1      ASSIGN_16  1.0
    RHS1      ASSIGN_17  1.0
    RHS1      ASSIGN_18  1.0
    RHS1      ASSIGN_19  1.0
    RHS1      ASSIGN_20  1.0
    RHS1      ASSIGN_21  1.0
    RHS1      ASSIGN_22  1.0
    RHS1      ASSIGN_23  1.0
    RHS1      ASSIGN_24  1.0
BOUNDS
 BV BND1      y_0
 BV BND1      y_1
 BV BND1      y_2
 BV BND1      y_3
 BV BND1      y_4
 BV BND1      y_5
 BV BND1      y_6
 BV BND1      y_7
 BV BND1      y_8
 BV BND1      y_9
 BV BND1      y_10
 BV BND1      y_11
 BV BND1      y_12
 BV BND1      y_13
 BV BND1      y_14
 BV BND1      y_15
 BV BND1      y_16
 BV BND1      y_17
 BV BND1      y_18
 BV BND1      y_19
 BV BND1      y_20
 BV BND1      y_21
 BV BND1      y_22
 BV BND1      y_23
 BV BND1      y_24
 BV BND1      x_0_0
 BV BND1      x_0_1
 BV BND1      x_0_2
 BV BND1      x_0_3
 BV BND1      x_0_4
 BV BND1      x_0_5
 BV BND1      x_0_6
 BV BND1      x_0_7
 BV BND1      x_0_8
 BV BND1      x_0_9
 BV BND1      x_0_10
 BV BND1      x_0_11
 BV BND1      x_0_12
 BV BND1      x_0_13
 BV BND1      x_0_14
 BV BND1      x_0_15
 BV BND1      x_0_16
 BV BND1      x_0_17
 BV BND1      x_0_18
 BV BND1      x_0_19
 BV BND1      x_0_20
 BV BND1      x_0_21
 BV BND1      x_0_22
 BV BND1      x_0_23
 BV BND1      x_0_24
 BV BND1      x_1_0
 BV BND1      x_1_1
 BV BND1      x_1_2
 BV BND1      x_1_3
 BV BND1      x_1_4
 BV BND1      x_1_5
 BV BND1      x_1_6
 BV BND1      x_1_7
 BV BND1      x_1_8
 BV BND1      x_1_9
 BV BND1      x_1_10
 BV BND1      x_1_11
 BV BND1      x_1_12
 BV BND1      x_1_13
 BV BND1      x_1_14
 BV BND1      x_1_15
 BV BND1      x_1_16
 BV BND1      x_1_17
 BV BND1      x_1_18
 BV BND1      x_1_19
 BV BND1      x_1_20
 BV BND1      x_1_21
 BV BND1      x_1_22
 BV BND1      x_1_23
 BV BND1      x_1_24
 BV BND1      x_2_0
 BV BND1      x_2_1
 BV BND1      x_2_2
 BV BND1      x_2_3
 BV BND1      x_2_4
 BV BND1      x_2_5
 BV BND1      x_2_6
 BV BND1      x_2_7
 BV BND1      x_2_8
 BV BND1      x_2_9
 BV BND1      x_2_10
 BV BND1      x_2_11
 BV BND1      x_2_12
 BV BND1      x_2_13
 BV BND1      x_2_14
 BV BND1      x_2_15
 BV BND1      x_2_16
 BV BND1      x_2_17
 BV BND1      x_2_18
 BV BND1      x_2_19
 BV BND1      x_2_20
 BV BND1      x_2_21
 BV BND1      x_2_22
 BV BND1      x_2_23
 BV BND1      x_2_24
 BV BND1      x_3_0
 BV BND1      x_3_1
 BV BND1      x_3_2
 BV BND1      x_3_3
 BV BND1      x_3_4
 BV BND1      x_3_5
 BV BND1      x_3_6
 BV BND1      x_3_7
 BV BND1      x_3_8
 BV BND1      x_3_9
 BV BND1      x_3_10
 BV BND1      x_3_11
 BV BND1      x_3_12
 BV BND1      x_3_13
 BV BND1      x_3_14
 BV BND1      x_3_15
 BV BND1      x_3_16
 BV BND1      x_3_17
 BV BND1      x_3_18
 BV BND1      x_3_19
 BV BND1      x_3_20
 BV BND1      x_3_21
 BV BND1      x_3_22
 BV BND1      x_3_23
 BV BND1      x_3_24
 BV BND1      x_4_0
 BV BND1      x_4_1
 BV BND1      x_4_2
 BV BND1      x_4_3
 BV BND1      x_4_4
 BV BND1      x_4_5
 BV BND1      x_4_6
 BV BND1      x_4_7
 BV BND1      x_4_8
 BV BND1      x_4_9
 BV BND1      x_4_10
 BV BND1      x_4_11
 BV BND1      x_4_12
 BV BND1      x_4_13
 BV BND1      x_4_14
 BV BND1      x_4_15
 BV BND1      x_4_16
 BV BND1      x_4_17
 BV BND1      x_4_18
 BV BND1      x_4_19
 BV BND1      x_4_20
 BV BND1      x_4_21
 BV BND1      x_4_22
 BV BND1      x_4_23
 BV BND1      x_4_24
 BV BND1      x_5_0
 BV BND1      x_5_1
 BV BND1      x_5_2
 BV BND1      x_5_3
 BV BND1      x_5_4
 BV BND1      x_5_5
 BV BND1      x_5_6
 BV BND1      x_5_7
 BV BND1      x_5_8
 BV BND1      x_5_9
 BV BND1      x_5_10
 BV BND1      x_5_11
 BV BND1      x_5_12
 BV BND1      x_5_13
 BV BND1      x_5_14
 BV BND1      x_5_15
 BV BND1      x_5_16
 BV BND1      x_5_17
 BV BND1      x_5_18
 BV BND1      x_5_19
 BV BND1      x_5_20
 BV BND1      x_5_21
 BV BND1      x_5_22
 BV BND1      x_5_23
 BV BND1      x_5_24
 BV BND1      x_6_0
 BV BND1      x_6_1
 BV BND1      x_6_2
 BV BND1      x_6_3
 BV BND1      x_6_4
 BV BND1      x_6_5
 BV BND1      x_6_6
 BV BND1      x_6_7
 BV BND1      x_6_8
 BV BND1      x_6_9
 BV BND1      x_6_10
 BV BND1      x_6_11
 BV BND1      x_6_12
 BV BND1      x_6_13
 BV BND1      x_6_14
 BV BND1      x_6_15
 BV BND1      x_6_16
 BV BND1      x_6_17
 BV BND1      x_6_18
 BV BND1      x_6_19
 BV BND1      x_6_20
 BV BND1      x_6_21
 BV BND1      x_6_22
 BV BND1      x_6_23
 BV BND1      x_6_24
 BV BND1      x_7_0
 BV BND1      x_7_1
 BV BND1      x_7_2
 BV BND1      x_7_3
 BV BND1      x_7_4
 BV BND1      x_7_5
 BV BND1      x_7_6
 BV BND1      x_7_7
 BV BND1      x_7_8
 BV BND1      x_7_9
 BV BND1      x_7_10
 BV BND1      x_7_11
 BV BND1      x_7_12
 BV BND1      x_7_13
 BV BND1      x_7_14
 BV BND1      x_7_15
 BV BND1      x_7_16
 BV BND1      x_7_17
 BV BND1      x_7_18
 BV BND1      x_7_19
 BV BND1      x_7_20
 BV BND1      x_7_21
 BV BND1      x_7_22
 BV BND1      x_7_23
 BV BND1      x_7_24
 BV BND1      x_8_0
 BV BND1      x_8_1
 BV BND1      x_8_2
 BV BND1      x_8_3
 BV BND1      x_8_4
 BV BND1      x_8_5
 BV BND1      x_8_6
 BV BND1      x_8_7
 BV BND1      x_8_8
 BV BND1      x_8_9
 BV BND1      x_8_10
 BV BND1      x_8_11
 BV BND1      x_8_12
 BV BND1      x_8_13
 BV BND1      x_8_14
 BV BND1      x_8_15
 BV BND1      x_8_16
 BV BND1      x_8_17
 BV BND1      x_8_18
 BV BND1      x_8_19
 BV BND1      x_8_20
 BV BND1      x_8_21
 BV BND1      x_8_22
 BV BND1      x_8_23
 BV BND1      x_8_24
 BV BND1      x_9_0
 BV BND1      x_9_1
 BV BND1      x_9_2
 BV BND1      x_9_3
 BV BND1      x_9_4
 BV BND1      x_9_5
 BV BND1      x_9_6
 BV BND1      x_9_7
 BV BND1      x_9_8
 BV BND1      x_9_9
 BV BND1      x_9_10
 BV BND1      x_9_11
 BV BND1      x_9_12
 BV BND1      x_9_13
 BV BND1      x_9_14
 BV BND1      x_9_15
 BV BND1      x_9_16
 BV BND1      x_9_17
 BV BND1      x_9_18
 BV BND1      x_9_19
 BV BND1      x_9_20
 BV BND1      x_9_21
 BV BND1      x_9_22
 BV BND1      x_9_23
 BV BND1      x_9_24
 BV BND1      x_10_0
 BV BND1      x_10_1
 BV BND1      x_10_2
 BV BND1      x_10_3
 BV BND1      x_10_4
 BV BND1      x_10_5
 BV BND1      x_10_6
 BV BND1      x_10_7
 BV BND1      x_10_8
 BV BND1      x_10_9
 BV BND1      x_10_10
 BV BND1      x_10_11
 BV BND1      x_10_12
 BV BND1      x_10_13
 BV BND1      x_10_14
 BV BND1      x_10_15
 BV BND1      x_10_16
 BV BND1      x_10_17
 BV BND1      x_10_18
 BV BND1      x_10_19
 BV BND1      x_10_20
 BV BND1      x_10_21
 BV BND1      x_10_22
 BV BND1      x_10_23
 BV BND1      x_10_24
 BV BND1      x_11_0
 BV BND1      x_11_1
 BV BND1      x_11_2
 BV BND1      x_11_3
 BV BND1      x_11_4
 BV BND1      x_11_5
 BV BND1      x_11_6
 BV BND1      x_11_7
 BV BND1      x_11_8
 BV BND1      x_11_9
 BV BND1      x_11_10
 BV BND1      x_11_11
 BV BND1      x_11_12
 BV BND1      x_11_13
 BV BND1      x_11_14
 BV BND1      x_11_15
 BV BND1      x_11_16
 BV BND1      x_11_17
 BV BND1      x_11_18
 BV BND1      x_11_19
 BV BND1      x_11_20
 BV BND1      x_11_21
 BV BND1      x_11_22
 BV BND1      x_11_23
 BV BND1      x_11_24
 BV BND1      x_12_0
 BV BND1      x_12_1
 BV BND1      x_12_2
 BV BND1      x_12_3
 BV BND1      x_12_4
 BV BND1      x_12_5
 BV BND1      x_12_6
 BV BND1      x_12_7
 BV BND1      x_12_8
 BV BND1      x_12_9
 BV BND1      x_12_10
 BV BND1      x_12_11
 BV BND1      x_12_12
 BV BND1      x_12_13
 BV BND1      x_12_14
 BV BND1      x_12_15
 BV BND1      x_12_16
 BV BND1      x_12_17
 BV BND1      x_12_18
 BV BND1      x_12_19
 BV BND1      x_12_20
 BV BND1      x_12_21
 BV BND1      x_12_22
 BV BND1      x_12_23
 BV BND1      x_12_24
 BV BND1      x_13_0
 BV BND1      x_13_1
 BV BND1      x_13_2
 BV BND1      x_13_3
 BV BND1      x_13_4
 BV BND1      x_13_5
 BV BND1      x_13_6
 BV BND1      x_13_7
 BV BND1      x_13_8
 BV BND1      x_13_9
 BV BND1      x_13_10
 BV BND1      x_13_11
 BV BND1      x_13_12
 BV BND1      x_13_13
 BV BND1      x_13_14
 BV BND1      x_13_15
 BV BND1      x_13_16
 BV BND1      x_13_17
 BV BND1      x_13_18
 BV BND1      x_13_19
 BV BND1      x_13_20
 BV BND1      x_13_21
 BV BND1      x_13_22
 BV BND1      x_13_23
 BV BND1      x_13_24
 BV BND1      x_14_0
 BV BND1      x_14_1
 BV BND1      x_14_2
 BV BND1      x_14_3
 BV BND1      x_14_4
 BV BND1      x_14_5
 BV BND1      x_14_6
 BV BND1      x_14_7
 BV BND1      x_14_8
 BV BND1      x_14_9
 BV BND1      x_14_10
 BV BND1      x_14_11
 BV BND1      x_14_12
 BV BND1      x_14_13
 BV BND1      x_14_14
 BV BND1      x_14_15
 BV BND1      x_14_16
 BV BND1      x_14_17
 BV BND1      x_14_18
 BV BND1      x_14_19
 BV BND1      x_14_20
 BV BND1      x_14_21
 BV BND1      x_14_22
 BV BND1      x_14_23
 BV BND1      x_14_24
 BV BND1      x_15_0
 BV BND1      x_15_1
 BV BND1      x_15_2
 BV BND1      x_15_3
 BV BND1      x_15_4
 BV BND1      x_15_5
 BV BND1      x_15_6
 BV BND1      x_15_7
 BV BND1      x_15_8
 BV BND1      x_15_9
 BV BND1      x_15_10
 BV BND1      x_15_11
 BV BND1      x_15_12
 BV BND1      x_15_13
 BV BND1      x_15_14
 BV BND1      x_15_15
 BV BND1      x_15_16
 BV BND1      x_15_17
 BV BND1      x_15_18
 BV BND1      x_15_19
 BV BND1      x_15_20
 BV BND1      x_15_21
 BV BND1      x_15_22
 BV BND1      x_15_23
 BV BND1      x_15_24
 BV BND1      x_16_0
 BV BND1      x_16_1
 BV BND1      x_16_2
 BV BND1      x_16_3
 BV BND1      x_16_4
 BV BND1      x_16_5
 BV BND1      x_16_6
 BV BND1      x_16_7
 BV BND1      x_16_8
 BV BND1      x_16_9
 BV BND1      x_16_10
 BV BND1      x_16_11
 BV BND1      x_16_12
 BV BND1      x_16_13
 BV BND1      x_16_14
 BV BND1      x_16_15
 BV BND1      x_16_16
 BV BND1      x_16_17
 BV BND1      x_16_18
 BV BND1      x_16_19
 BV BND1      x_16_20
 BV BND1      x_16_21
 BV BND1      x_16_22
 BV BND1      x_16_23
 BV BND1      x_16_24
 BV BND1      x_17_0
 BV BND1      x_17_1
 BV BND1      x_17_2
 BV BND1      x_17_3
 BV BND1      x_17_4
 BV BND1      x_17_5
 BV BND1      x_17_6
 BV BND1      x_17_7
 BV BND1      x_17_8
 BV BND1      x_17_9
 BV BND1      x_17_10
 BV BND1      x_17_11
 BV BND1      x_17_12
 BV BND1      x_17_13
 BV BND1      x_17_14
 BV BND1      x_17_15
 BV BND1      x_17_16
 BV BND1      x_17_17
 BV BND1      x_17_18
 BV BND1      x_17_19
 BV BND1      x_17_20
 BV BND1      x_17_21
 BV BND1      x_17_22
 BV BND1      x_17_23
 BV BND1      x_17_24
 BV BND1      x_18_0
 BV BND1      x_18_1
 BV BND1      x_18_2
 BV BND1      x_18_3
 BV BND1      x_18_4
 BV BND1      x_18_5
 BV BND1      x_18_6
 BV BND1      x_18_7
 BV BND1      x_18_8
 BV BND1      x_18_9
 BV BND1      x_18_10
 BV BND1      x_18_11
 BV BND1      x_18_12
 BV BND1      x_18_13
 BV BND1      x_18_14
 BV BND1      x_18_15
 BV BND1      x_18_16
 BV BND1      x_18_17
 BV BND1      x_18_18
 BV BND1      x_18_19
 BV BND1      x_18_20
 BV BND1      x_18_21
 BV BND1      x_18_22
 BV BND1      x_18_23
 BV BND1      x_18_24
 BV BND1      x_19_0
 BV BND1      x_19_1
 BV BND1      x_19_2
 BV BND1      x_19_3
 BV BND1      x_19_4
 BV BND1      x_19_5
 BV BND1      x_19_6
 BV BND1      x_19_7
 BV BND1      x_19_8
 BV BND1      x_19_9
 BV BND1      x_19_10
 BV BND1      x_19_11
 BV BND1      x_19_12
 BV BND1      x_19_13
 BV BND1      x_19_14
 BV BND1      x_19_15
 BV BND1      x_19_16
 BV BND1      x_19_17
 BV BND1      x_19_18
 BV BND1      x_19_19
 BV BND1      x_19_20
 BV BND1      x_19_21
 BV BND1      x_19_22
 BV BND1      x_19_23
 BV BND1      x_19_24
 BV BND1      x_20_0
 BV BND1      x_20_1
 BV BND1      x_20_2
 BV BND1      x_20_3
 BV BND1      x_20_4
 BV BND1      x_20_5
 BV BND1      x_20_6
 BV BND1      x_20_7
 BV BND1      x_20_8
 BV BND1      x_20_9
 BV BND1      x_20_10
 BV BND1      x_20_11
 BV BND1      x_20_12
 BV BND1      x_20_13
 BV BND1      x_20_14
 BV BND1      x_20_15
 BV BND1      x_20_16
 BV BND1      x_20_17
 BV BND1      x_20_18
 BV BND1      x_20_19
 BV BND1      x_20_20
 BV BND1      x_20_21
 BV BND1      x_20_22
 BV BND1      x_20_23
 BV BND1      x_20_24
 BV BND1      x_21_0
 BV BND1      x_21_1
 BV BND1      x_21_2
 BV BND1      x_21_3
 BV BND1      x_21_4
 BV BND1      x_21_5
 BV BND1      x_21_6
 BV BND1      x_21_7
 BV BND1      x_21_8
 BV BND1      x_21_9
 BV BND1      x_21_10
 BV BND1      x_21_11
 BV BND1      x_21_12
 BV BND1      x_21_13
 BV BND1      x_21_14
 BV BND1      x_21_15
 BV BND1      x_21_16
 BV BND1      x_21_17
 BV BND1      x_21_18
 BV BND1      x_21_19
 BV BND1      x_21_20
 BV BND1      x_21_21
 BV BND1      x_21_22
 BV BND1      x_21_23
 BV BND1      x_21_24
 BV BND1      x_22_0
 BV BND1      x_22_1
 BV BND1      x_22_2
 BV BND1      x_22_3
 BV BND1      x_22_4
 BV BND1      x_22_5
 BV BND1      x_22_6
 BV BND1      x_22_7
 BV BND1      x_22_8
 BV BND1      x_22_9
 BV BND1      x_22_10
 BV BND1      x_22_11
 BV BND1      x_22_12
 BV BND1      x_22_13
 BV BND1      x_22_14
 BV BND1      x_22_15
 BV BND1      x_22_16
 BV BND1      x_22_17
 BV BND1      x_22_18
 BV BND1      x_22_19
 BV BND1      x_22_20
 BV BND1      x_22_21
 BV BND1      x_22_22
 BV BND1      x_22_23
 BV BND1      x_22_24
 BV BND1      x_23_0
 BV BND1      x_23_1
 BV BND1      x_23_2
 BV BND1      x_23_3
 BV BND1      x_23_4
 BV BND1      x_23_5
 BV BND1      x_23_6
 BV BND1      x_23_7
 BV BND1      x_23_8
 BV BND1      x_23_9
 BV BND1      x_23_10
 BV BND1      x_23_11
 BV BND1      x_23_12
 BV BND1      x_23_13
 BV BND1      x_23_14
 BV BND1      x_23_15
 BV BND1      x_23_16
 BV BND1      x_23_17
 BV BND1      x_23_18
 BV BND1      x_23_19
 BV BND1      x_23_20
 BV BND1      x_23_21
 BV BND1      x_23_22
 BV BND1      x_23_23
 BV BND1      x_23_24
 BV BND1      x_24_0
 BV BND1      x_24_1
 BV BND1      x_24_2
 BV BND1      x_24_3
 BV BND1      x_24_4
 BV BND1      x_24_5
 BV BND1      x_24_6
 BV BND1      x_24_7
 BV BND1      x_24_8
 BV BND1      x_24_9
 BV BND1      x_24_10
 BV BND1      x_24_11
 BV BND1      x_24_12
 BV BND1      x_24_13
 BV BND1      x_24_14
 BV BND1      x_24_15
 BV BND1      x_24_16
 BV BND1      x_24_17
 BV BND1      x_24_18
 BV BND1      x_24_19
 BV BND1      x_24_20
 BV BND1      x_24_21
 BV BND1      x_24_22
 BV BND1      x_24_23
 BV BND1      x_24_24
ENDATA
